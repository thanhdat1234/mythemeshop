jQuery(document).ready(function($){
	mts_testimonials_media_uploader();
	$('#mts_testimonial_form_shortcode').click(function(event) {
		$(this).select();
	});
});

function mts_testimonials_media_uploader(){
	var uploadID = '';

	jQuery('.upload-button').click(function() {
		uploadID = jQuery(this).prev('input');
		formfield = jQuery('.upload').attr('name');
		tb_show('', 'media-upload.php?type=file&tab=library&TB_iframe=true');
		//tb_show('', 'media-upload.php?referer=elm-settings&type=image&TB_iframe=true', false);  
		
		return false;
	});

	window.send_to_editor = function(html) {
		imgurl = jQuery(html).attr('href');
		uploadID.val(imgurl);
		tb_remove();
	};
}