<pre>
	<?php print_r($args); ?>
</pre>