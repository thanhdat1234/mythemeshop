<?php

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

include( 'admin.class.php' );