<?php

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

global $mts_testimonials_admin, $mts_testimonials_shortcode_generator;

$settings = mts_testimonials_get_settings();

?>
<div class="wrap testimonials">
	<?php 
	$mts_testimonials_admin->messages_html();
	$mts_testimonials_admin->settings_page_tabs_html();
	?>
	<h4><?php _e('Select options', 'mts-testimonials'); ?></h4>

	<div id="mtsg-form">
	<?php 
		$mts_testimonials_shortcode_generator->form_html();
	?>
	</div>

	<!-- <div id="mtsg-list">
	<?php 
		//$mts_testimonials_shortcode_generator->list_html();
	?>
	</div> -->

	<div id="mtsg-shortcode">
	<?php 
		$mts_testimonials_shortcode_generator->generated_shortcode_html();
	?>
	</div>

	<h3 class="mtsg-preview-heading"><?php _e('Preview:', 'mts-testimonials') ?></h3>
	<div id="mtsg-preview-wrapper">
		<div id="mtsg-preview">
		<?php 
			$mts_testimonials_shortcode_generator->preview_html();
		?>
		</div>
		
		<div class="mtsg-resize-help">
			<span class="dashicons dashicons-leftright"></span>
			<p class="description mtsg-help-text"><?php _e('Drag right border to resize preview. The shortcode on your site will always take up the full width available.', 'mts-testimonials') ?></p>
		</div>
	</div>
</div>