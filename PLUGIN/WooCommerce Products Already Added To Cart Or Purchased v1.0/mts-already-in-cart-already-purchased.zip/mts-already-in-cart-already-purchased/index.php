<?php
/*
Plugin Name: Already In Cart / Already Purchased
Plugin URI: https://www.mythemeshop.com
Description: [...]
Version: 1.0
Author: MyThemeShop
Plugin URI: https://www.mythemeshop.com
*/

class mts_woo_product_already {
	public $settings = array();
	public $plugin_slug = 'mwpa';
	public function __construct() {
		if (is_admin()) {
			add_action( 'admin_init', array($this, 'register_settings' ) );
			add_action( 'admin_menu', array($this, 'add_settings_page'), 99 );
		} else {
			add_action('woocommerce_before_single_product', array($this, 'show_messages'), 10);
		}

		// Default settings
		$default_options = array(
			'already_in_cart' => 0,
			'already_in_cart_text' => __('This product is already in your cart.', $this->plugin_slug),
			'already_purchased' => 0,
			'already_purchased_text' => __('You have already purchased this product.', $this->plugin_slug)
		);
		add_option( 'mwpa_options', $default_options);
		$this->settings = get_option( 'mwpa_options', $default_options );

	}

	function register_settings() {
		register_setting( 'mwpa_options', 'mwpa_options' );
	}


	function add_settings_page() {
		add_submenu_page( 'woocommerce', __('Already In Cart / Already Purchased', $this->plugin_slug), __('Already In Cart / Already Purchased', $this->plugin_slug), 'manage_options', 'manage-already-in-cart', array( $this, 'settings_page' ) ); 
	}

	function settings_page() { 
?>

<div class="wrap">
  <div id="icon-options-general" class="icon32"><br />
  </div>
  <h2><?php _e('WooCommerce Already In Cart / Already Purchased Settings', $this->plugin_slug); ?></h2>
  <br />
  <form method="post" action="options.php">
    <?php settings_fields( 'mwpa_options' ); ?>
    <table class="form-table" >
      <tr valign="top">
        <th scope="row"><label for="already_in_cart"><?php _e('Enable Already In Cart Message:', $this->plugin_slug); ?></label></th>
        <td>
        	<input name="mwpa_options[already_in_cart]" type="hidden" value="0" />
         	<input name="mwpa_options[already_in_cart]" type="checkbox" value="1" id="already_in_cart" <?php checked($this->settings['already_in_cart']); ?> />
        </td>
      </tr>

      <tr valign="top" id="already_in_cart_row">
        <th scope="row"><?php _e('Already In Cart Text:', $this->plugin_slug); ?></th>
        <td>
			<textarea name="mwpa_options[already_in_cart_text]" class="large-text"><?php echo esc_textarea($this->settings['already_in_cart_text']); ?></textarea>
			<br />
			<p class="description"><?php _e('Enter the message you would like to display on the product page.', $this->plugin_slug); ?></p>
        </td>
      </tr>

      <tr valign="top">
        <th scope="row"><label for="already_purchased"><?php _e('Enable Already Purchased Message:', $this->plugin_slug); ?></label></th>
        <td>
        	<input name="mwpa_options[already_purchased]" type="hidden" value="0" />
         	<input name="mwpa_options[already_purchased]" type="checkbox" value="1" id="already_purchased" <?php checked($this->settings['already_purchased']); ?> />
        </td>
      </tr>

      <tr valign="top" id="already_purchased_row">
        <th scope="row"><?php _e('Already Purchased Text:', $this->plugin_slug); ?></th>
        <td>
			<textarea name="mwpa_options[already_purchased_text]" class="large-text"><?php echo esc_textarea($this->settings['already_purchased_text']); ?></textarea>
			<br />
			<p class="description"><?php _e('Enter the message you would like to display on the product page.', $this->plugin_slug); ?></p>
        </td>
      </tr>

      <tr valign="top">
        <th scope="row"><?php submit_button(); ?></th>
      </tr>
    </table>
  </form>
</div>
<script type="text/javascript">
jQuery(document).ready(function($) {
	$('#already_in_cart').change(function(event) {
		$('#already_in_cart_row').toggle($(this).is(':checked'));
	}).change();
	$('#already_purchased').change(function(event) {
		$('#already_purchased_row').toggle($(this).is(':checked'));
	}).change();
});
</script>
<?php

	}

	function show_messages( ) { 
		global $woocommerce; 
		$cart_url = $woocommerce->cart->get_cart_url();
		
		$in_cart_notice = $this->settings['already_in_cart'];
		$message_in_cart = $this->settings['already_in_cart_text'];

		$purchased_notice = $this->settings['already_purchased'];
		$message_purchased = $this->settings['already_purchased_text'];
		
		$product_id = get_the_id(); 
		
		// 1. Already in cart
		$cartproducts = array();
		foreach ($woocommerce->cart->cart_contents as $cart_key => $cart_item_array) {
			$cartproducts[] = $cart_item_array['product_id'];
		}
		if ($in_cart_notice && in_array($product_id, $cartproducts) && ! isset($_REQUEST['added-to-cart'])) { // Product wasn't just added right now
			echo '<div class="woocommerce-message"><a href="'.$cart_url.'" class="button">'.__('View Cart &rarr;', $this->plugin_slug).'</a>'.$message_in_cart.'</div>';
		}

		// 2. Already purchased
		$user_id = get_current_user_id();
		$current_user= wp_get_current_user();
		$customer_email = $current_user->email;

		if ($purchased_notice && !empty($current_user->ID) && wc_customer_bought_product( $customer_email, $user_id, $product_id)) {
			echo '<div class="woocommerce-message"><a href="'.$cart_url.'" class="button">'.__('View Cart &rarr;', $this->plugin_slug).'</a>'.$message_purchased.'</div>';
		}
	}
}

$mts_woo_product_already = new mts_woo_product_already();