<?php

/**
 *
 * @link              https://mythemeshop.com
 * @since             1.0
 *
 * @wordpress-plugin
 * Plugin Name:       My WP Backup Pro
 * Plugin URI:        https://mythemeshop.com/plugins/my-wp-backup-pro/
 * Description:       My WP Backup is the best way to protect your data and website in the event of server loss, data corruption, hacking or other events, or to migrate your WordPress data quickly and easily.
 * Version:           1.2.2
 * Author:            MyThemeShop
 * Author URI:        https://mythemeshop.com
 * Text Domain:       my-wp-backup
 * Domain Path:       /languages
 * Support URI:       https://community.mythemeshop.com
 * Network:           true
 */

if ( ! defined( 'ABSPATH' ) ) { die; }

// Make it load My WP Backup FREE first, as it doesn't check if PRO has been loaded before
function mwpb_free_plugin_first() {
	$this_plugin     = 'my-wp-backup/my-wp-backup.php';
	$active_plugins  = get_option( 'active_plugins' );
	$this_plugin_key = array_search( $this_plugin, $active_plugins );
	if ( $this_plugin_key ) { // if it's 0 it's the first plugin already, no need to continue
		array_splice( $active_plugins, $this_plugin_key, 1 );
		array_unshift( $active_plugins, $this_plugin );
		update_option( 'active_plugins', $active_plugins );
	}
}

add_action( 'activated_plugin', 'mwpb_free_plugin_first' );

if ( class_exists( '\MyWPBackup\MyWPBackup' ) ) {
	add_action( 'admin_init', 'mwpb_plugin_deactivate' );
	function mwpb_plugin_deactivate() {
	    deactivate_plugins( 'my-wp-backup/my-wp-backup.php' );
	}

	add_action( 'admin_notices', 'mwpb_deactivate_plugin_notice' );
	function mwpb_deactivate_plugin_notice() {
	    ?>
	    <div class="updated">
	        <p><?php _e( 'My WP Backup (Free) plugin has been deactivated.', 'my-wp-backup' ); ?></p>
	    </div>
	    <?php
	}
} else {
	include('plugin-init.php');
}
