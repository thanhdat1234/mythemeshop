(function ($) {
    'use strict';

    var wrap = $('.wrap');

    wrap.navTab();
})(jQuery);