<?php
/*
 * Plugin Name: 	WooCommerce Checkout Field Modifier
 * Description: 	Allows Editing, Hiding or Showing on Woocommerce Checkout Fields
 * Version: 		1.0
 * Author: 			MyThemeShop.com
 * Author URI: 		https://mythemeshop.com
 *
 * Text Domain: woocommerce_checkout_field_modifier
 * Domain Path: /languages/
 */
?>
<?php

if (!defined('ABSPATH'))
    exit; // Exit if accessed directly

/**
 * Check if WooCommerce is active
 * */
if (in_array('woocommerce/woocommerce.php', apply_filters('active_plugins', get_option('active_plugins')))) {

    add_filter('woocommerce_get_settings_pages', 'wc_checkout_add_settings');
    function wc_checkout_add_settings($settings) {
        $settings[] = include( 'woocommerce-checkout-field-modifier-settings.php' );
        return $settings;
    }
	
    add_filter('woocommerce_checkout_fields', 'billing_checkout_fields');

    // localization
   add_action( 'plugins_loaded', 'wcfm_load_textdomain' );
   function wcfm_load_textdomain() {
       load_plugin_textdomain( 'woocommerce_checkout_field_modifier', false, dirname( plugin_basename( __FILE__ ) ) . '/languages/' ); 
   }
    function billing_checkout_fields($fields) {
        // Billing Country Fields
        $fields['billing']['billing_country']['label'] = get_option('wc_country_label');
        if (get_option('wc_country_required') == 'yes') {
            $fields['billing']['billing_country']['required'] = true;
        } else {
            $fields['billing']['billing_country']['required'] = false;
        }
        if (get_option('wc_country_hide') == 'hide') {
            unset($fields['billing']['billing_country']);
        }

        // Billing First Name Fields
        $fields['billing']['billing_first_name']['label'] = get_option('wc_first_name');
        $fields['billing']['billing_first_name']['placeholder'] = get_option('wc_first_name_ph');
        if (get_option('wc_first_name_required') == 'yes') {
            $fields['billing']['billing_first_name']['required'] = true;
        } else {
            $fields['billing']['billing_first_name']['required'] = false;
        }
        if (get_option('wc_first_name_hide') == 'hide') {
            unset($fields['billing']['billing_first_name']);
        }

        // Billing Last Name Fields
        $fields['billing']['billing_last_name']['label'] = get_option('wc_last_name');
        $fields['billing']['billing_last_name']['placeholder'] = get_option('wc_last_name_ph');
        if (get_option('wc_last_name_required') == 'yes') {
            $fields['billing']['billing_last_name']['required'] = true;
        } else {
            $fields['billing']['billing_last_name']['required'] = false;
        }
        if (get_option('wc_last_name_hide') == 'hide') {
            unset($fields['billing']['billing_last_name']);
        }

        // Billing Company Name Fields
        $fields['billing']['billing_company']['label'] = get_option('wc_company_name');
        $fields['billing']['billing_company']['placeholder'] = get_option('wc_company_name_ph');
        if (get_option('wc_company_name_required') == 'yes') {
            $fields['billing']['billing_company']['required'] = true;
        } else {
            $fields['billing']['billing_company']['required'] = false;
        }
        if (get_option('wc_company_name_hide') == 'hide') {
            unset($fields['billing']['billing_company']);
        }

        // Billing Email Address Fields
        $fields['billing']['billing_email']['label'] = get_option('wc_email_address_label');
        $fields['billing']['billing_email']['placeholder'] = get_option('wc_email_address_ph');
        if (get_option('wc_email_address_required') == 'yes') {
            $fields['billing']['billing_email']['required'] = true;
        } else {
            $fields['billing']['billing_email']['required'] = false;
        }
        if (get_option('wc_email_address_hide') == 'hide') {
            unset($fields['billing']['billing_email']);
        }

        // Billing Phone Fields
        $fields['billing']['billing_phone']['label'] = get_option('wc_phone_label');
        $fields['billing']['billing_phone']['placeholder'] = get_option('wc_phone_ph');
        if (get_option('wc_phone_required') == 'yes') {
            $fields['billing']['billing_phone']['required'] = true;
        } else {
            $fields['billing']['billing_phone']['required'] = false;
        }
        if (get_option('wc_phone_hide') == 'hide') {
            unset($fields['billing']['billing_phone']);
        }

        // Billing Address Line 1 Fields	
        if (get_option('wc_address_line_1_hide') == 'hide') {
            unset($fields['billing']['billing_address_1']);
        }

        // Billing Address Line 2 Fields
        if (get_option('wc_address_line_2_hide') == 'hide') {
            unset($fields['billing']['billing_address_2']);
        }

        // Billing Town / City Fields
        if (get_option('wc_town_city_hide') == 'hide') {
            unset($fields['billing']['billing_city']);
        }

        // Billing State / Country Fields
        if (get_option('wc_state_country_hide') == 'hide') {
            unset($fields['billing']['billing_state']);
        }

        // Billing Postcode / Zip Fields
        if (get_option('wc_postcode_zip_hide') == 'hide') {
            unset($fields['billing']['billing_postcode']);
        }
        return $fields;
    }
	

    add_filter('woocommerce_checkout_fields', 'shipping_checkout_fields');
    function shipping_checkout_fields($shipping_fields) {
        // Shipping Country Fields
        $shipping_fields['shipping']['shipping_country']['label'] = get_option('wc_ship_country_label');
        if (get_option('wc_ship_country_required') == 'yes') {
            $shipping_fields['shipping']['shipping_country']['required'] = true;
        } else {
            $shipping_fields['shipping']['shipping_country']['required'] = false;
        }
        if (get_option('wc_ship_country_hide') == 'hide') {
            unset($shipping_fields['shipping']['shipping_country']);
        }

        // Shipping First Name Fields
        $shipping_fields['shipping']['shipping_first_name']['label'] = get_option('wc_ship_first_name');
        $shipping_fields['shipping']['shipping_first_name']['placeholder'] = get_option('wc_ship_first_name_ph');
        if (get_option('wc_ship_first_name_required') == 'yes') {
            $shipping_fields['shipping']['shipping_first_name']['required'] = true;
        } else {
            $shipping_fields['shipping']['shipping_first_name']['required'] = false;
        }
        if (get_option('wc_ship_first_name_hide') == 'hide') {
            unset($shipping_fields['shipping']['shipping_first_name']);
        }

        // Shipping Last Name Fields
        $shipping_fields['shipping']['shipping_last_name']['label'] = get_option('wc_ship_last_name');
        $shipping_fields['shipping']['shipping_last_name']['placeholder'] = get_option('wc_ship_last_name_ph');
        if (get_option('wc_ship_last_name_required') == 'yes') {
            $shipping_fields['shipping']['shipping_last_name']['required'] = true;
        } else {
            $shipping_fields['shipping']['shipping_last_name']['required'] = false;
        }
        if (get_option('wc_ship_last_name_hide') == 'hide') {
            unset($shipping_fields['shipping']['shipping_last_name']);
        }

        // Shipping Company Fields
        $shipping_fields['shipping']['shipping_company']['label'] = get_option('wc_ship_company_name');
        $shipping_fields['shipping']['shipping_company']['placeholder'] = get_option('wc_ship_company_name_ph');
        if (get_option('wc_ship_company_name_required') == 'yes') {
            $shipping_fields['shipping']['shipping_company']['required'] = true;
        } else {
            $shipping_fields['shipping']['shipping_company']['required'] = false;
        }
        if (get_option('wc_ship_company_name_hide') == 'hide') {
            unset($shipping_fields['shipping']['shipping_company']);
        }

        // Shipping Address Line 1 Fields
        if (get_option('wc_ship_address_line_1_hide') == 'hide') {
            unset($shipping_fields['shipping']['shipping_address_1']);
        }

        // Shipping Address Line 2 Fields
        if (get_option('wc_ship_address_line_2_hide') == 'hide') {
            unset($shipping_fields['shipping']['shipping_address_2']);
        }

        // Shipping Town / City Fields
        if (get_option('wc_ship_town_city_hide') == 'hide') {
            unset($shipping_fields['shipping']['shipping_city']);
        }

        // Shipping State / Country Fields
        if (get_option('wc_ship_state_country_hide') == 'hide') {
            unset($shipping_fields['shipping']['shipping_state']);
        }

        // Shipping Postcode / Zip Fields
        if (get_option('wc_ship_postcode_zip_hide') == 'hide') {
            unset($shipping_fields['shipping']['shipping_postcode']);
        }
        return $shipping_fields;
    }

	
    add_filter('woocommerce_checkout_fields', 'additional_checkout_fields');
    function additional_checkout_fields($additional_fields) {
        // Order Notes Fields
        $additional_fields['order']['order_comments']['label'] = get_option('wc_order_notes_label');
        $additional_fields['order']['order_comments']['placeholder'] = get_option('wc_order_notes_ph');
        if (get_option('wc_order_notes_hide') == 'hide') {
            unset($additional_fields['order']['order_comments']);
        }
        return $additional_fields;
    }

	
    add_filter('woocommerce_default_address_fields', 'billing_shipping_default_address_fields');
    function billing_shipping_default_address_fields($address_fields) {
        // Billing and Shipping Address Line 1 Fields
        $address_fields['address_1']['label'] = get_option('wc_address_line_1');
        $address_fields['address_1']['placeholder'] = get_option('wc_address_line_1_ph');

        // Billing and Shipping Address Line 2 Fields	
        $address_fields['address_2']['label'] = get_option('wc_address_line_2');
        $address_fields['address_2']['placeholder'] = get_option('wc_address_line_2_ph');

        return $address_fields;
    }
	
}