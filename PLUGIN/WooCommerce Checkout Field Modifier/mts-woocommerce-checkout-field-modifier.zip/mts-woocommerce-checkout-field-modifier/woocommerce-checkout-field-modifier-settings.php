<?php

if (!defined('ABSPATH')) {
    exit; // Exit if accessed directly
}

if (!class_exists('woocommerce_checkout_field_modifier')) :

    /**
     * WC_Settings_Products
     */
    class woocommerce_checkout_field_modifier extends WC_Settings_Page {

        /**
         * Constructor.
         */
        public function __construct() {
			
            $this->id = 'wc_checkout';		
		
			add_filter('woocommerce_settings_tabs_array', array($this, 'add_settings_tab'), 50);
            add_action('woocommerce_sections_' . $this->id, array($this, 'output_sections'));
            add_action('woocommerce_settings_' . $this->id, array($this, 'output'));
            add_action('woocommerce_settings_save_' . $this->id, array($this, 'save'));
		
        }
		
		/**
         * Add plugin options tab
         *
         * @return array
         */
        public function add_settings_tab($settings_tabs) {
            $settings_tabs[$this->id] = __('WC Checkout Field Modifier', 'woocommerce_checkout_field_modifier');
            return $settings_tabs;
        }

        /**
         * Get sections
         *
         * @return array
         */
        public function get_sections() {

            $sections = array(
                '' => __('Billing Details', 'woocommerce_checkout_field_modifier'),
                'shipping' => __('Shipping Details', 'woocommerce_checkout_field_modifier'),
                'additional' => __('Additional Details', 'woocommerce_checkout_field_modifier'),
            );

            return apply_filters('woocommerce_get_sections_' . $this->id, $sections);
        }

        /**
         * Output the settings
         */
        public function output() {
            global $current_section;

            $settings = $this->get_settings($current_section);

            WC_Admin_Settings::output_fields($settings);
        }

        /**
         * Save settings
         */
        public function save() {
            global $current_section;

            $settings = $this->get_settings($current_section);
            WC_Admin_Settings::save_fields($settings);
        }

        /**
         * Get settings array
         *
         * @return array
         */
        public function get_settings($current_section = '') {
            if ('additional' == $current_section) {
					// Additional Checkout Details 
                $settings = array(
					// Order Notes Field Settings
                    array(
                        'title' => __('Order Notes', 'woocommerce_checkout_field_modifier'),
                        'type' => 'title',
                        'desc' => __('Customize Order Notes Field','woocommerce_checkout_field_modifier'),
                        'id' => 'wc_order_notes_title'
                    ),
                    array(
                        'title' => __('Order Notes Label', 'woocommerce_checkout_field_modifier'),
                        'desc' => __('', 'woocommerce_checkout_field_modifier'),
                        'id' => 'wc_order_notes_label',
                        'default' => '',
                        'type' => 'text',
                        'desc_tip' => __('Customize Order Notes Field','woocommerce_checkout_field_modifier'),
                    ),
                    array(
                        'title' => __('Order Notes Placeholder', 'woocommerce_checkout_field_modifier'),
                        'desc' => __('', 'woocommerce_checkout_field_modifier'),
                        'id' => 'wc_order_notes_ph',
                        'default' => __('Notes about your order, e.g. special notes for delivery','woocommerce_checkout_field_modifier'),
                        'type' => 'text',
                        'desc_tip' => __('Customize Order Notes Placeholder Field','woocommerce_checkout_field_modifier'),
                    ),
                    array(
                        'title' => __('Hide/Show Order Notes', 'woocommerce_checkout_field_modifier'),
                        'desc' => __('', 'woocommerce_checkout_field_modifier'),
                        'id' => 'wc_order_notes_hide',
                        'default' => 'show',
                        'css' => 'min-width:100px;',
                        'type' => 'select',
                        'options' => array(
                            'show' => __('Show', 'woocommerce_checkout_field_modifier'),
                            'hide' => __('Hide', 'woocommerce_checkout_field_modifier'),
                        ),
                        'desc_tip' => __('Select hide/show in the dropdown menu','woocommerce_checkout_field_modifier'),
                    ),
                    array(
                        'type' => 'sectionend',
                        'id' => 'additional_options'
                    ),
					array(
                        'title' => __('Address', 'woocommerce_checkout_field_modifier'),
                        'type' => 'title',
                        'desc' => sprintf(__('Customize Billing and Shipping Address Field','woocommerce_checkout_field_modifier')),
                        'id' => 'wc_addtional_address_title'
                    ),   
					array(
                        'title' => __('Address Line 1 Label', 'woocommerce_checkout_field_modifier'),
                        'desc' => __('', 'woocommerce_checkout_field_modifier'),
                        'id' => 'wc_address_line_1',
                        'default' => __('Address','woocommerce_checkout_field_modifier'),
                        'type' => 'text',
                        'desc_tip' => __('Customize Address Line 1 Field','woocommerce_checkout_field_modifier'),
                    ),
                    array(
                        'title' => __('Address Line 1 Placeholder', 'woocommerce_checkout_field_modifier'),
                        'desc' => __('', 'woocommerce_checkout_field_modifier'),
                        'id' => 'wc_address_line_1_ph',
                        'default' => __('Street address','woocommerce_checkout_field_modifier'),
                        'type' => 'text',
                        'desc_tip' => __('Customize Address Line 1 Placeholder Field','woocommerce_checkout_field_modifier'),
                    ),
					array(
                        'title' => __('Address Line 2 Label', 'woocommerce_checkout_field_modifier'),
                        'desc' => __('', 'woocommerce_checkout_field_modifier'),
                        'id' => 'wc_address_line_2',
                        'default' => __('Address','woocommerce_checkout_field_modifier'),
                        'type' => 'text',
                        'desc_tip' => __('Customize Address Line 2 Field','woocommerce_checkout_field_modifier'),
                    ),
                    array(
                        'title' => __('Address Line 2 Placeholder', 'woocommerce_checkout_field_modifier'),
                        'desc' => __('', 'woocommerce_checkout_field_modifier'),
                        'id' => 'wc_address_line_2_ph',
                        'default' => __('Apartment, suite, unit etc. (optional)','woocommerce_checkout_field_modifier'),
                        'type' => 'text',
                        'desc_tip' => __('Customize Address Line 2 Placeholder Field','woocommerce_checkout_field_modifier'),
                    ),
					array(
                        'type' => 'sectionend',
                        'id' => 'additional_options'
                    ),
                );
                // Shipping Checkout Details 
            } elseif ('shipping' == $current_section) {
                $settings = array(
                    // Shipping Country Field Settings
                    array(
                        'title' => __('Country', 'woocommerce_checkout_field_modifier'),
                        'type' => 'title',
                        'desc' => sprintf(__('Customize Country Field','woocommerce_checkout_field_modifier')),
                        'id' => 'wc_ship_country_title'
                    ),
                    array(
                        'title' => __('Country Label', 'woocommerce_checkout_field_modifier'),
                        'desc' => __('', 'woocommerce_checkout_field_modifier'),
                        'id' => 'wc_ship_country_label',
                        'default' => __('Country','woocommerce_checkout_field_modifier'),
                        'type' => 'text',
                        'desc_tip' => __('Customize Country Field','woocommerce_checkout_field_modifier'),
                    ),
                    array(
                        'title' => __('Country Required?', 'woocommerce_checkout_field_modifier'),
                        'desc' => __('', 'woocommerce_checkout_field_modifier'),
                        'id' => 'wc_ship_country_required',
                        'css' => 'min-width:100px;',
                        'default' => 'yes',
                        'type' => 'select',
                        'options' => array(
                            'yes' => __('Yes', 'woocommerce_checkout_field_modifier'),
                            'no' => __('No', 'woocommerce_checkout_field_modifier'),
                        ),
                        'desc_tip' => __('Select yes/no in the dropdown menu','woocommerce_checkout_field_modifier'),
                    ),
                    array(
                        'title' => __('Hide/Show Country', 'woocommerce_checkout_field_modifier'),
                        'desc' => __('', 'woocommerce_checkout_field_modifier'),
                        'id' => 'wc_ship_country_hide',
                        'default' => 'show',
                        'css' => 'min-width:100px;',
                        'type' => 'select',
                        'options' => array(
                            'show' => __('Show', 'woocommerce_checkout_field_modifier'),
                            'hide' => __('Hide', 'woocommerce_checkout_field_modifier'),
                        ),
                        'desc_tip' => __('Select hide/show in the dropdown menu','woocommerce_checkout_field_modifier'),
                    ),
                    array(
                        'type' => 'sectionend',
                        'id' => 'shipping_options'
                    ),
                    // Shipping First Name Field Settings
                    array(
                        'title' => __('First Name', 'woocommerce_checkout_field_modifier'),
                        'type' => 'title',
                        'desc' => sprintf(__('Customize First Name Field','woocommerce_checkout_field_modifier')),
                        'id' => 'wc_ship_first_name_title'
                    ),
                    array(
                        'title' => __('First Name Label', 'woocommerce_checkout_field_modifier'),
                        'desc' => __('', 'woocommerce_checkout_field_modifier'),
                        'id' => 'wc_ship_first_name',
                        'default' => __('First Name','woocommerce_checkout_field_modifier'),
                        'type' => 'text',
                        'desc_tip' => __('Customize First Name Field','woocommerce_checkout_field_modifier'),
                    ),
                    array(
                        'title' => __('First Name Placeholder', 'woocommerce_checkout_field_modifier'),
                        'desc' => __('', 'woocommerce_checkout_field_modifier'),
                        'id' => 'wc_ship_first_name_ph',
                        'default' => '',
                        'type' => 'text',
                        'desc_tip' => __('Customize First Name Placeholder Field','woocommerce_checkout_field_modifier'),
                    ),
                    array(
                        'title' => __('First Name Required?', 'woocommerce_checkout_field_modifier'),
                        'desc' => __('', 'woocommerce_checkout_field_modifier'),
                        'id' => 'wc_ship_first_name_required',
                        'css' => 'min-width:100px;',
                        'default' => 'yes',
                        'type' => 'select',
                        'options' => array(
                            'yes' => __('Yes', 'woocommerce_checkout_field_modifier'),
                            'no' => __('No', 'woocommerce_checkout_field_modifier'),
                        ),
                        'desc_tip' => __('Select yes/no in the dropdown menu','woocommerce_checkout_field_modifier'),
                    ),
                    array(
                        'title' => __('Hide/Show First Name', 'woocommerce_checkout_field_modifier'),
                        'desc' => __('', 'woocommerce_checkout_field_modifier'),
                        'id' => 'wc_ship_first_name_hide',
                        'default' => 'show',
                        'css' => 'min-width:100px;',
                        'type' => 'select',
                        'options' => array(
                            'show' => __('Show', 'woocommerce_checkout_field_modifier'),
                            'hide' => __('Hide', 'woocommerce_checkout_field_modifier'),
                        ),
                        'desc_tip' => __('Select hide/show in the dropdown menu','woocommerce_checkout_field_modifier'),
                    ),
                    array(
                        'type' => 'sectionend',
                        'id' => 'shipping_options'
                    ),
                    // Shipping Last Name Field Settings
                    array(
                        'title' => __('Last Name', 'woocommerce_checkout_field_modifier'),
                        'type' => 'title',
                        'desc' => sprintf(__('Customize Last Name Field','woocommerce_checkout_field_modifier')),
                        'id' => 'wc_ship_last_name_title'
                    ),
                    array(
                        'title' => __('Last Name Label', 'woocommerce_checkout_field_modifier'),
                        'desc' => __('', 'woocommerce_checkout_field_modifier'),
                        'id' => 'wc_ship_last_name',
                        'default' => __('Last Name','woocommerce_checkout_field_modifier'),
                        'type' => 'text',
                        'desc_tip' => __('Customize Last Name Field','woocommerce_checkout_field_modifier'),
                    ),
                    array(
                        'title' => __('Last Name Placeholder', 'woocommerce_checkout_field_modifier'),
                        'desc' => __('', 'woocommerce_checkout_field_modifier'),
                        'id' => 'wc_ship_last_name_ph',
                        'default' => '',
                        'type' => 'text',
                        'desc_tip' => __('Customize Last Name Placeholder Field','woocommerce_checkout_field_modifier'),
                    ),
                    array(
                        'title' => __('Last Name Required?', 'woocommerce_checkout_field_modifier'),
                        'desc' => __('', 'woocommerce_checkout_field_modifier'),
                        'id' => 'wc_ship_last_name_required',
                        'css' => 'min-width:100px;',
                        'default' => 'yes',
                        'type' => 'select',
                        'options' => array(
                            'yes' => __('Yes', 'woocommerce_checkout_field_modifier'),
                            'no' => __('No', 'woocommerce_checkout_field_modifier'),
                        ),
                        'desc_tip' => __('Select yes/no in the dropdown menu','woocommerce_checkout_field_modifier'),
                    ),
                    array(
                        'title' => __('Hide/Show Last Name', 'woocommerce_checkout_field_modifier'),
                        'desc' => __('', 'woocommerce_checkout_field_modifier'),
                        'id' => 'wc_ship_last_name_hide',
                        'default' => 'show',
                        'css' => 'min-width:100px;',
                        'type' => 'select',
                        'options' => array(
                            'show' => __('Show', 'woocommerce_checkout_field_modifier'),
                            'hide' => __('Hide', 'woocommerce_checkout_field_modifier'),
                        ),
                        'desc_tip' => __('Select hide/show in the dropdown menu','woocommerce_checkout_field_modifier'),
                    ),
                    array(
                        'type' => 'sectionend',
                        'id' => 'shipping_options'
                    ),
                    // Shipping Company Name Field Settings
                    array(
                        'title' => __('Company Name', 'woocommerce_checkout_field_modifier'),
                        'type' => 'title',
                        'desc' => sprintf(__('Customize Company Name Field','woocommerce_checkout_field_modifier')),
                        'id' => 'wc_ship_company_name_title'
                    ),
                    array(
                        'title' => __('Company Name Label', 'woocommerce_checkout_field_modifier'),
                        'desc' => __('', 'woocommerce_checkout_field_modifier'),
                        'id' => 'wc_ship_company_name',
                        'default' => __('Company Name','woocommerce_checkout_field_modifier'),
                        'type' => 'text',
                        'desc_tip' => __('Customize Company Name Field','woocommerce_checkout_field_modifier'),
                    ),
                    array(
                        'title' => __('Company Name Placeholder', 'woocommerce_checkout_field_modifier'),
                        'desc' => __('', 'woocommerce_checkout_field_modifier'),
                        'id' => 'wc_ship_company_name_ph',
                        'default' => '',
                        'type' => 'text',
                        'desc_tip' => __('Customize Company Name Placeholder Field','woocommerce_checkout_field_modifier'),
                    ),
                    array(
                        'title' => __('Company Name Required?', 'woocommerce_checkout_field_modifier'),
                        'desc' => __('', 'woocommerce_checkout_field_modifier'),
                        'id' => 'wc_ship_company_name_required',
                        'css' => 'min-width:100px;',
                        'default' => 'no',
                        'type' => 'select',
                        'options' => array(
                            'yes' => __('Yes', 'woocommerce_checkout_field_modifier'),
                            'no' => __('No', 'woocommerce_checkout_field_modifier'),
                        ),
                        'desc_tip' => __('Select yes/no in the dropdown menu','woocommerce_checkout_field_modifier'),
                    ),
                    array(
                        'title' => __('Hide/Show Company Name', 'woocommerce_checkout_field_modifier'),
                        'desc' => __('', 'woocommerce_checkout_field_modifier'),
                        'id' => 'wc_ship_company_name_hide',
                        'default' => 'show',
                        'css' => 'min-width:100px;',
                        'type' => 'select',
                        'options' => array(
                            'show' => __('Show', 'woocommerce_checkout_field_modifier'),
                            'hide' => __('Hide', 'woocommerce_checkout_field_modifier'),
                        ),
                        'desc_tip' => __('Select hide/show in the dropdown menu','woocommerce_checkout_field_modifier'),
                    ),
                    array(
                        'type' => 'sectionend',
                        'id' => 'shipping_options'
                    ),
                    // Shipping Address Line 1 Field Settings
                    array(
                        'title' => __('Address', 'woocommerce_checkout_field_modifier'),
                        'type' => 'title',
                        'desc' => sprintf(__('Customize Address Field','woocommerce_checkout_field_modifier')),
                        'id' => 'wc_ship_address_title'
                    ),                    
                    array(
                        'title' => __('Hide/Show Address Line 1', 'woocommerce_checkout_field_modifier'),
                        'desc' => __('', 'woocommerce_checkout_field_modifier'),
                        'id' => 'wc_ship_address_line_1_hide',
                        'default' => 'show',
                        'css' => 'min-width:100px;',
                        'type' => 'select',
                        'options' => array(
                            'show' => __('show', 'woocommerce_checkout_field_modifier'),
                            'hide' => __('hide', 'woocommerce_checkout_field_modifier'),
                        ),
                        'desc_tip' => __('Select hide/show in the dropdown menu','woocommerce_checkout_field_modifier'),
                    ),
                    // Shipping Address Line 2 Field Settings                    
                    array(
                        'title' => __('Hide/Show Address Line 2', 'woocommerce_checkout_field_modifier'),
                        'desc' => __('', 'woocommerce_checkout_field_modifier'),
                        'id' => 'wc_ship_address_line_2_hide',
                        'default' => 'show',
                        'css' => 'min-width:100px;',
                        'type' => 'select',
                        'options' => array(
                            'show' => __('show', 'woocommerce_checkout_field_modifier'),
                            'hide' => __('hide', 'woocommerce_checkout_field_modifier'),
                        ),
                        'desc_tip' => __('Select hide/show in the dropdown menu','woocommerce_checkout_field_modifier'),
                    ),
                    array(
                        'type' => 'sectionend',
                        'id' => 'shipping_options'
                    ),
                    // Shipping Town / City Field Settings
                    array(
                        'title' => __('Town / City', 'woocommerce_checkout_field_modifier'),
                        'type' => 'title',
                        'desc' => sprintf(__('Customize Town / City Field','woocommerce_checkout_field_modifier')),
                        'id' => 'wc_town_city_title'
                    ),
                    array(
                        'title' => __('Hide/Show Town / City', 'woocommerce_checkout_field_modifier'),
                        'desc' => __('', 'woocommerce_checkout_field_modifier'),
                        'id' => 'wc_ship_town_city_hide',
                        'default' => 'show',
                        'css' => 'min-width:100px;',
                        'type' => 'select',
                        'options' => array(
                            'show' => __('Show', 'woocommerce_checkout_field_modifier'),
                            'hide' => __('Hide', 'woocommerce_checkout_field_modifier'),
                        ),
                        'desc_tip' => __('Select hide/show in the dropdown menu','woocommerce_checkout_field_modifier'),
                    ),
                    array(
                        'type' => 'sectionend',
                        'id' => 'shipping_options'
                    ),
                    // Shipping State / Country Field Settings
                    array(
                        'title' => __('State / Country', 'woocommerce_checkout_field_modifier'),
                        'type' => 'title',
                        'desc' => sprintf(__('Customize State / Country Field','woocommerce_checkout_field_modifier')),
                        'id' => 'wc_ship_state_country_title'
                    ),
                    array(
                        'title' => __('Hide/Show State / Country', 'woocommerce_checkout_field_modifier'),
                        'desc' => __('', 'woocommerce_checkout_field_modifier'),
                        'id' => 'wc_ship_state_country_hide',
                        'default' => 'show',
                        'css' => 'min-width:100px;',
                        'type' => 'select',
                        'options' => array(
                            'show' => __('Show', 'woocommerce_checkout_field_modifier'),
                            'hide' => __('Hide', 'woocommerce_checkout_field_modifier'),
                        ),
                        'desc_tip' => __('Select hide/show in the dropdown menu','woocommerce_checkout_field_modifier'),
                    ),
                    array(
                        'type' => 'sectionend',
                        'id' => 'shipping_options'
                    ),
                    // Shipping Postcode / Zip Field Settings
                    array(
                        'title' => __('Postcode / Zip', 'woocommerce_checkout_field_modifier'),
                        'type' => 'title',
                        'desc' => sprintf(__('Customize Postcode / Zip Field','woocommerce_checkout_field_modifier')),
                        'id' => 'wc_postcode_zip_title'
                    ),
                    array(
                        'title' => __('Hide/Show Postcode / Zip', 'woocommerce_checkout_field_modifier'),
                        'desc' => __('', 'woocommerce_checkout_field_modifier'),
                        'id' => 'wc_ship_postcode_zip_hide',
                        'default' => 'show',
                        'css' => 'min-width:100px;',
                        'type' => 'select',
                        'options' => array(
                            'show' => __('Show', 'woocommerce_checkout_field_modifier'),
                            'hide' => __('Hide', 'woocommerce_checkout_field_modifier'),
                        ),
                        'desc_tip' => __('Select hide/show in the dropdown menu','woocommerce_checkout_field_modifier'),
                    ),
                    array(
                        'type' => 'sectionend',
                        'id' => 'shipping_options'
                    ),
                );
            } else {
                // Billing Checkout Details 
                $settings = array(
                    // Billing Country Details
                    array(
                        'title' => __('Country', 'woocommerce_checkout_field_modifier'),
                        'type' => 'title',
                        'desc' => sprintf(__('Customize Country Field','woocommerce_checkout_field_modifier')),
                        'id' => 'wc_country'
                    ),
                    array(
                        'title' => __('Country Label', 'woocommerce_checkout_field_modifier'),
                        'desc' => __('', 'woocommerce_checkout_field_modifier'),
                        'id' => 'wc_country_label',
                        'default' => __('Country','woocommerce_checkout_field_modifier'),
                        'type' => 'text',
                        'desc_tip' => __('Customize Country Field','woocommerce_checkout_field_modifier'),
                    ),
                    array(
                        'title' => __('Country Required?', 'woocommerce_checkout_field_modifier'),
                        'desc' => __('', 'woocommerce_checkout_field_modifier'),
                        'id' => 'wc_country_required',
                        'css' => 'min-width:100px;',
                        'default' => 'yes',
                        'type' => 'select',
                        'options' => array(
                            'yes' => __('Yes', 'woocommerce_checkout_field_modifier'),
                            'no' => __('No', 'woocommerce_checkout_field_modifier'),
                        ),
                        'desc_tip' => __('Select yes/no in the dropdown menu','woocommerce_checkout_field_modifier'),
                    ),
                    array(
                        'title' => __('Hide/Show Country', 'woocommerce_checkout_field_modifier'),
                        'desc' => __('', 'woocommerce_checkout_field_modifier'),
                        'id' => 'wc_country_hide',
                        'default' => 'show',
                        'css' => 'min-width:100px;',
                        'type' => 'select',
                        'options' => array(
                            'show' => __('Show', 'woocommerce_checkout_field_modifier'),
                            'hide' => __('Hide', 'woocommerce_checkout_field_modifier'),
                        ),
                        'desc_tip' => __('Select hide/show in the dropdown menu','woocommerce_checkout_field_modifier'),
                    ),
                    array(
                        'type' => 'sectionend',
                        'id' => 'billing_options'
                    ),
                    // Billing First Name Details
                    array(
                        'title' => __('First Name', 'woocommerce_checkout_field_modifier'),
                        'type' => 'title',
                        'desc' => sprintf(__('Customize First Name Field','woocommerce_checkout_field_modifier')),
                        'id' => 'wc_first_name_title'
                    ),
                    array(
                        'title' => __('First Name Label', 'woocommerce_checkout_field_modifier'),
                        'desc' => __('', 'woocommerce_checkout_field_modifier'),
                        'id' => 'wc_first_name',
                        'default' => __('First Name','woocommerce_checkout_field_modifier'),
                        'type' => 'text',
                        'desc_tip' => __('Customize First Name Field','woocommerce_checkout_field_modifier'),
                    ),
                    array(
                        'title' => __('First Name Placeholder', 'woocommerce_checkout_field_modifier'),
                        'desc' => __('', 'woocommerce_checkout_field_modifier'),
                        'id' => 'wc_first_name_ph',
                        'default' => '',
                        'type' => 'text',
                        'desc_tip' => __('Customize First Name Placeholder Field','woocommerce_checkout_field_modifier'),
                    ),
                    array(
                        'title' => __('First Name Required?', 'woocommerce_checkout_field_modifier'),
                        'desc' => __('', 'woocommerce_checkout_field_modifier'),
                        'id' => 'wc_first_name_required',
                        'css' => 'min-width:100px;',
                        'default' => 'yes',
                        'type' => 'select',
                        'options' => array(
                            'yes' => __('Yes', 'woocommerce_checkout_field_modifier'),
                            'no' => __('No', 'woocommerce_checkout_field_modifier'),
                        ),
                        'desc_tip' => __('Select yes/no in the dropdown menu','woocommerce_checkout_field_modifier'),
                    ),
                    array(
                        'title' => __('Hide/Show First Name', 'woocommerce_checkout_field_modifier'),
                        'desc' => __('', 'woocommerce_checkout_field_modifier'),
                        'id' => 'wc_first_name_hide',
                        'default' => 'show',
                        'css' => 'min-width:100px;',
                        'type' => 'select',
                        'options' => array(
                            'show' => __('Show', 'woocommerce_checkout_field_modifier'),
                            'hide' => __('Hide', 'woocommerce_checkout_field_modifier'),
                        ),
                        'desc_tip' => __('Select hide/show in the dropdown menu','woocommerce_checkout_field_modifier'),
                    ),
                    array(
                        'type' => 'sectionend',
                        'id' => 'billing_options'
                    ),
                    // Billing Last Name Details
                    array(
                        'title' => __('Last Name', 'woocommerce_checkout_field_modifier'),
                        'type' => 'title',
                        'desc' => sprintf(__('Customize Last Name Field','woocommerce_checkout_field_modifier')),
                        'id' => 'wc_last_name_title'
                    ),
                    array(
                        'title' => __('Last Name Label', 'woocommerce_checkout_field_modifier'),
                        'desc' => __('', 'woocommerce_checkout_field_modifier'),
                        'id' => 'wc_last_name',
                        'default' => __('Last Name','woocommerce_checkout_field_modifier'),
                        'type' => 'text',
                        'desc_tip' => __('Customize Last Name Field','woocommerce_checkout_field_modifier'),
                    ),
                    array(
                        'title' => __('Last Name Placeholder', 'woocommerce_checkout_field_modifier'),
                        'desc' => __('', 'woocommerce_checkout_field_modifier'),
                        'id' => 'wc_last_name_ph',
                        'default' => '',
                        'type' => 'text',
                        'desc_tip' => __('Customize Last Name Placeholder Field','woocommerce_checkout_field_modifier'),
                    ),
                    array(
                        'title' => __('Last Name Required?', 'woocommerce_checkout_field_modifier'),
                        'desc' => __('', 'woocommerce_checkout_field_modifier'),
                        'id' => 'wc_last_name_required',
                        'css' => 'min-width:100px;',
                        'default' => 'yes',
                        'type' => 'select',
                        'options' => array(
                            'yes' => __('Yes', 'woocommerce_checkout_field_modifier'),
                            'no' => __('No', 'woocommerce_checkout_field_modifier'),
                        ),
                        'desc_tip' => __('Select yes/no in the dropdown menu','woocommerce_checkout_field_modifier'),
                    ),
                    array(
                        'title' => __('Hide/Show Last Name', 'woocommerce_checkout_field_modifier'),
                        'desc' => __('', 'woocommerce_checkout_field_modifier'),
                        'id' => 'wc_last_name_hide',
                        'default' => 'show',
                        'css' => 'min-width:100px;',
                        'type' => 'select',
                        'options' => array(
                            'show' => __('Show', 'woocommerce_checkout_field_modifier'),
                            'hide' => __('Hide', 'woocommerce_checkout_field_modifier'),
                        ),
                        'desc_tip' => __('Select hide/show in the dropdown menu','woocommerce_checkout_field_modifier'),
                    ),
                    array(
                        'type' => 'sectionend',
                        'id' => 'billing_options'
                    ),
                    // Billing Company Name Details
                    array(
                        'title' => __('Company Name', 'woocommerce_checkout_field_modifier'),
                        'type' => 'title',
                        'desc' => sprintf(__('Customize Company Name Field','woocommerce_checkout_field_modifier')),
                        'id' => 'wc_company_name_title'
                    ),
                    array(
                        'title' => __('Company Name Label', 'woocommerce_checkout_field_modifier'),
                        'desc' => __('', 'woocommerce_checkout_field_modifier'),
                        'id' => 'wc_company_name',
                        'default' => __('Company Name','woocommerce_checkout_field_modifier'),
                        'type' => 'text',
                        'desc_tip' => __('Customize Company Name Field','woocommerce_checkout_field_modifier'),
                    ),
                    array(
                        'title' => __('Company Name Placeholder', 'woocommerce_checkout_field_modifier'),
                        'desc' => __('', 'woocommerce_checkout_field_modifier'),
                        'id' => 'wc_company_name_ph',
                        'default' => '',
                        'type' => 'text',
                        'desc_tip' => __('Customize Company Name Placeholder Field','woocommerce_checkout_field_modifier'),
                    ),
                    array(
                        'title' => __('Company Name Required?', 'woocommerce_checkout_field_modifier'),
                        'desc' => __('', 'woocommerce_checkout_field_modifier'),
                        'id' => 'wc_company_name_required',
                        'css' => 'min-width:100px;',
                        'default' => 'no',
                        'type' => 'select',
                        'options' => array(
                            'yes' => __('Yes', 'woocommerce_checkout_field_modifier'),
                            'no' => __('No', 'woocommerce_checkout_field_modifier'),
                        ),
                        'desc_tip' => __('Select yes/no in the dropdown menu','woocommerce_checkout_field_modifier'),
                    ),
                    array(
                        'title' => __('Hide/Show Company Name', 'woocommerce_checkout_field_modifier'),
                        'desc' => __('', 'woocommerce_checkout_field_modifier'),
                        'id' => 'wc_company_name_hide',
                        'default' => 'show',
                        'css' => 'min-width:100px;',
                        'type' => 'select',
                        'options' => array(
                            'show' => __('Show', 'woocommerce_checkout_field_modifier'),
                            'hide' => __('Hide', 'woocommerce_checkout_field_modifier'),
                        ),
                        'desc_tip' => __('Select hide/show in the dropdown menu','woocommerce_checkout_field_modifier'),
                    ),
                    array(
                        'type' => 'sectionend',
                        'id' => 'billing_options'
                    ),
                    // Billing Address Line 1 Details
                    array(
                        'title' => __('Address', 'woocommerce_checkout_field_modifier'),
                        'type' => 'title',
                        'desc' => sprintf(__('Customize Address Field','woocommerce_checkout_field_modifier')),
                        'id' => 'wc_address_title'
                    ),                    
                    array(
                        'title' => __('Hide/Show Address Line 1', 'woocommerce_checkout_field_modifier'),
                        'desc' => __('', 'woocommerce_checkout_field_modifier'),
                        'id' => 'wc_address_line_1_hide',
                        'default' => 'show',
                        'css' => 'min-width:100px;',
                        'type' => 'select',
                        'options' => array(
                            'show' => __('show', 'woocommerce_checkout_field_modifier'),
                            'hide' => __('hide', 'woocommerce_checkout_field_modifier'),
                        ),
                        'desc_tip' => __('Select hide/show in the dropdown menu','woocommerce_checkout_field_modifier'),
                    ),
                    // Billing Address Line 2 Details                    
                    array(
                        'title' => __('Hide/Show Address Line 2', 'woocommerce_checkout_field_modifier'),
                        'desc' => __('', 'woocommerce_checkout_field_modifier'),
                        'id' => 'wc_address_line_2_hide',
                        'default' => 'show',
                        'css' => 'min-width:100px;',
                        'type' => 'select',
                        'options' => array(
                            'show' => __('show', 'woocommerce_checkout_field_modifier'),
                            'hide' => __('hide', 'woocommerce_checkout_field_modifier'),
                        ),
                        'desc_tip' => __('Select hide/show in the dropdown menu','woocommerce_checkout_field_modifier'),
                    ),
                    array(
                        'type' => 'sectionend',
                        'id' => 'billing_options'
                    ),
                    // Billing Town / City Details
                    array(
                        'title' => __('Town / City', 'woocommerce_checkout_field_modifier'),
                        'type' => 'title',
                        'desc' => sprintf(__('Customize Town / City Field','woocommerce_checkout_field_modifier')),
                        'id' => 'wc_town_city_title'
                    ),
                    array(
                        'title' => __('Hide/Show Town / City', 'woocommerce_checkout_field_modifier'),
                        'desc' => __('', 'woocommerce_checkout_field_modifier'),
                        'id' => 'wc_town_city_hide',
                        'default' => 'show',
                        'css' => 'min-width:100px;',
                        'type' => 'select',
                        'options' => array(
                            'show' => __('Show', 'woocommerce_checkout_field_modifier'),
                            'hide' => __('Hide', 'woocommerce_checkout_field_modifier'),
                        ),
                        'desc_tip' => __('Select hide/show in the dropdown menu','woocommerce_checkout_field_modifier'),
                    ),
                    array(
                        'type' => 'sectionend',
                        'id' => 'billing_options'
                    ),
                    // Billing State / Country Details
                    array(
                        'title' => __('State / Country', 'woocommerce_checkout_field_modifier'),
                        'type' => 'title',
                        'desc' => sprintf(__('Customize State / Country Field','woocommerce_checkout_field_modifier')),
                        'id' => 'wc_state_country_title'
                    ),
                    array(
                        'title' => __('Hide/Show State / Country', 'woocommerce_checkout_field_modifier'),
                        'desc' => __('', 'woocommerce_checkout_field_modifier'),
                        'id' => 'wc_state_country_hide',
                        'default' => 'show',
                        'css' => 'min-width:100px;',
                        'type' => 'select',
                        'options' => array(
                            'show' => __('Show', 'woocommerce_checkout_field_modifier'),
                            'hide' => __('Hide', 'woocommerce_checkout_field_modifier'),
                        ),
                        'desc_tip' => __('Select hide/show in the dropdown menu','woocommerce_checkout_field_modifier'),
                    ),
                    array(
                        'type' => 'sectionend',
                        'id' => 'billing_options'
                    ),
                    // Billing Postcode / Zip Details
                    array(
                        'title' => __('Postcode / Zip', 'woocommerce_checkout_field_modifier'),
                        'type' => 'title',
                        'desc' => sprintf(__('Customize Postcode / Zip Field','woocommerce_checkout_field_modifier')),
                        'id' => 'wc_postcode_zip_title'
                    ),
                    array(
                        'title' => __('Hide/Show Postcode / Zip', 'woocommerce_checkout_field_modifier'),
                        'desc' => __('', 'woocommerce_checkout_field_modifier'),
                        'id' => 'wc_postcode_zip_hide',
                        'default' => 'show',
                        'css' => 'min-width:100px;',
                        'type' => 'select',
                        'options' => array(
                            'show' => __('Show', 'woocommerce_checkout_field_modifier'),
                            'hide' => __('Hide', 'woocommerce_checkout_field_modifier'),
                        ),
                        'desc_tip' => __('Select hide/show in the dropdown menu','woocommerce_checkout_field_modifier'),
                    ),
                    array(
                        'type' => 'sectionend',
                        'id' => 'billing_options'
                    ),
                    // Billing Email Address Details
                    array(
                        'title' => __('Email Address', 'woocommerce_checkout_field_modifier'),
                        'type' => 'title',
                        'desc' => sprintf(__('Customize Email Address Field','woocommerce_checkout_field_modifier')),
                        'id' => 'wc_email_address_title'
                    ),
                    array(
                        'title' => __('Email Address Label', 'woocommerce_checkout_field_modifier'),
                        'desc' => __('', 'woocommerce_checkout_field_modifier'),
                        'id' => 'wc_email_address_label',
                        'default' => __('Email Address','woocommerce_checkout_field_modifier'),
                        'type' => 'text',
                        'desc_tip' => __('Customize Email Address Field','woocommerce_checkout_field_modifier'),
                    ),
                    array(
                        'title' => __('Email Address Placeholder', 'woocommerce_checkout_field_modifier'),
                        'desc' => __('', 'woocommerce_checkout_field_modifier'),
                        'id' => 'wc_email_address_ph',
                        'default' => '',
                        'type' => 'text',
                        'desc_tip' => __('Customize Email Address Placeholder Field','woocommerce_checkout_field_modifier'),
                    ),
                    array(
                        'title' => __('Email Address Required?', 'woocommerce_checkout_field_modifier'),
                        'desc' => __('', 'woocommerce_checkout_field_modifier'),
                        'id' => 'wc_email_address_required',
                        'css' => 'min-width:100px;',
                        'default' => 'yes',
                        'type' => 'select',
                        'options' => array(
                            'yes' => __('Yes', 'woocommerce_checkout_field_modifier'),
                            'no' => __('No', 'woocommerce_checkout_field_modifier'),
                        ),
                        'desc_tip' => __('Select yes/no in the dropdown menu','woocommerce_checkout_field_modifier'),
                    ),
                    array(
                        'title' => __('Hide/Show Email Address', 'woocommerce_checkout_field_modifier'),
                        'desc' => __('', 'woocommerce_checkout_field_modifier'),
                        'id' => 'wc_email_address_hide',
                        'default' => 'show',
                        'css' => 'min-width:100px;',
                        'type' => 'select',
                        'options' => array(
                            'show' => __('Show', 'woocommerce_checkout_field_modifier'),
                            'hide' => __('Hide', 'woocommerce_checkout_field_modifier'),
                        ),
                        'desc_tip' => __('Select hide/show in the dropdown menu','woocommerce_checkout_field_modifier'),
                    ),
                    array(
                        'type' => 'sectionend',
                        'id' => 'billing_options'
                    ),
                    // Billing Phone Details
                    array(
                        'title' => __('Phone', 'woocommerce_checkout_field_modifier'),
                        'type' => 'title',
                        'desc' => sprintf(__('Customize Phone Field','woocommerce_checkout_field_modifier')),
                        'id' => 'wc_email_address_title'
                    ),
                    array(
                        'title' => __('Phone Label', 'woocommerce_checkout_field_modifier'),
                        'desc' => __('', 'woocommerce_checkout_field_modifier'),
                        'id' => 'wc_phone_label',
                        'default' => __('Phone','woocommerce_checkout_field_modifier'),
                        'type' => 'text',
                        'desc_tip' => __('Customize Phone Field','woocommerce_checkout_field_modifier'),
                    ),
                    array(
                        'title' => __('Phone Placeholder', 'woocommerce_checkout_field_modifier'),
                        'desc' => __('', 'woocommerce_checkout_field_modifier'),
                        'id' => 'wc_phone_ph',
                        'default' => '',
                        'type' => 'text',
                        'desc_tip' => __('Customize Phone Placeholder Field','woocommerce_checkout_field_modifier'),
                    ),
                    array(
                        'title' => __('Phone Required?', 'woocommerce_checkout_field_modifier'),
                        'desc' => __('', 'woocommerce_checkout_field_modifier'),
                        'id' => 'wc_phone_required',
                        'css' => 'min-width:100px;',
                        'default' => 'yes',
                        'type' => 'select',
                        'options' => array(
                            'yes' => __('Yes', 'woocommerce_checkout_field_modifier'),
                            'no' => __('No', 'woocommerce_checkout_field_modifier'),
                        ),
                        'desc_tip' => __('Select yes/no in the dropdown menu','woocommerce_checkout_field_modifier'),
                    ),
                    array(
                        'title' => __('Hide/Show Phone Address', 'woocommerce_checkout_field_modifier'),
                        'desc' => __('', 'woocommerce_checkout_field_modifier'),
                        'id' => 'wc_phone_hide',
                        'default' => 'show',
                        'css' => 'min-width:100px;',
                        'type' => 'select',
                        'options' => array(
                            'show' => __('Show', 'woocommerce_checkout_field_modifier'),
                            'hide' => __('Hide', 'woocommerce_checkout_field_modifier'),
                        ),
                        'desc_tip' => __('Select hide/show in the dropdown menu','woocommerce_checkout_field_modifier'),
                    ),
                    array(
                        'type' => 'sectionend',
                        'id' => 'billing_options'
                    ),
                );
            }

            return apply_filters('woocommerce_get_settings_' . $this->id, $settings, $current_section);
        }

    }
    endif;

return new woocommerce_checkout_field_modifier();