WP Subscribe Pro
=================================
Plugin Name: WP Subscribe Pro
Plugin URI: http://mythemeshop.com/plugins/wp-subscribe-pro/
Description: WP Subscribe Pro is the must-have subscription plugin for WordPress that will boost your conversion rates for newsletter subscribers and result in more residual traffic and earnings.
Author: MyThemesShop
Author URI: http://mythemeshop.com/