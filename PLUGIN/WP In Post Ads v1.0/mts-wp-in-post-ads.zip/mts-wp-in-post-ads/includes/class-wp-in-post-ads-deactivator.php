<?php

/**
 * Fired during plugin deactivation
 *
 * @link       https://mythemeshop.com
 * @since      1.0
 *
 * @package    wp-in-post-ads
 * @subpackage wp-in-post-ads/includes
 */

/**
 * Fired during plugin deactivation.
 *
 * This class defines all code necessary to run during the plugin's deactivation.
 *
 * @since      1.0
 * @package    wp-in-post-ads
 * @subpackage wp-in-post-ads/includes
 * @author     MyThemeShop
 */
class WP_In_Post_Ads_Deactivator {

	/**
	 * Short Description. (use period)
	 *
	 * Long Description.
	 *
	 * @since    1.0
	 */
	public static function deactivate() {
	}

}
