WP Review Pro
=================================
Plugin Name: WP Review Pro
Plugin URI: http://mythemeshop.com/plugins/wp-review-pro/
Description: Create reviews! Choose from Stars, Percentages, Circles or Points for review scores. Supports Retina Display, WPMU & Unlimited Color Schemes.
Version: 1.0.8
Author: MyThemesShop
Author URI: http://mythemeshop.com/