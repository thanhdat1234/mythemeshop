<!DOCTYPE html>
<?php $options = get_option('textured'); ?>
<html class="no-js" lang="en" dir="ltr">

<head>
	<meta charset="UTF-8">
	
	<title><?php wp_title(''); ?></title>

	<?php if ($options['mts_favicon'] != '') { ?>
	<link rel="icon" href="<?php echo $options['mts_favicon']; ?>" type="image/x-icon" />
	<?php } ?>
	
	<!--iOS/android/handheld specific -->	
	<link rel="apple-touch-icon" href="apple-touch-icon.png">			
	<meta name="viewport" content="width=device-width, initial-scale=1.0">						
	<meta name="apple-mobile-web-app-capable" content="yes">
	<meta name="apple-mobile-web-app-status-bar-style" content="black">

	<link rel="stylesheet" type="text/css" media="all" href="<?php bloginfo( 'stylesheet_url' ); ?>" />
	<?php wp_head(); ?>

	<?php if ($options['mts_title_font'] != '') { ?>
		<link href="http://fonts.googleapis.com/css?family=<?php echo $options['mts_title_font']; ?>:400,600,700,300" rel="stylesheet" type="text/css">
		<style type="text/css">
			.title, h1, h2, h3, h4, h5, h6, .sidebar h3, .widget h3, .total-comments, body > footer .footeText {
			font-family: '<?php echo $options['mts_title_font']; ?>', Arial, sans-serif;
			}
		</style>
	<?php } else { ?>
		<link href='http://fonts.googleapis.com/css?family=Signika:400,600,700,300' rel='stylesheet' type='text/css'>
	<?php } ?>
	
	<?php if ($options['mts_content_font'] != '') { ?>
	<link href="http://fonts.googleapis.com/css?family=<?php echo $options['mts_content_font']; ?>:400,400italic,600,700,700italic,300" rel="stylesheet" type="text/css">
		<style type="text/css">
			body {
			font-family: '<?php echo $options['mts_content_font']; ?>', Arial, sans-serif;
			}
		</style>
	<?php } else { ?>
		<link href="http://fonts.googleapis.com/css?family=Droid+Sans:400,400italic,600,700,700italic,300" rel="stylesheet" type="text/css">
	<?php } ?>

		<link rel="stylesheet" href="<?php bloginfo('template_directory'); ?>/css/prettyPhoto.css" type="text/css" media="screen" charset="utf-8" />
		
		<script src="<?php bloginfo( 'template_directory' ); ?>/js/jquery.js"></script>
	<?php if($options['mts_featured_slider'] == '1') { ?>
	<?php if( is_home() ) { ?>
		<script type="text/javascript" src="<?php bloginfo( 'template_directory' ); ?>/js/jquery.carouFredSel.js"></script>
	<script>
				jQuery(function() {
				//	Scrolled by user interaction
				jQuery('#foo2').carouFredSel({
					pagination: "#pager2",
					prev: '#prev2',
					next: '#next2',
					direction: 'left',
					items: 4,
					infinite: false,
					scroll	: {
					items: 4,
					duration: 1000,
					},
					auto: false
				});
				
			});
	</script>
	<?php } ?>
	<?php } ?>
	
	<link rel="pingback" href="<?php bloginfo( 'pingback_url' ); ?>" />

	<?php wp_enqueue_script("jquery"); ?>
	<?php if ( is_singular() ) wp_enqueue_script( 'comment-reply' ); ?>
	<!--[if lt IE 9]>
		<script src="http://html5shim.googlecode.com/svn/trunk/html5.js"></script>
	<![endif]-->
	
	<script src="<?php echo get_template_directory_uri(); ?>/js/modernizr.min.js"></script>
	<script src="<?php echo get_template_directory_uri(); ?>/js/customscript.js" type="text/javascript"></script>
	
	<?php if($options['mts_lightbox'] == '1') { ?>
		<script src="<?php bloginfo('template_directory'); ?>/js/jquery.prettyPhoto.js"></script>
		<script type="text/javascript">  
			jQuery(document).ready(function($) {
				$("a[href$='.jpg'], a[href$='.jpeg'], a[href$='.gif'], a[href$='.png']").prettyPhoto({
				slideshow: 5000, /* false OR interval time in ms */
				autoplay_slideshow: false, /* true/false */
				animationSpeed: 'normal', /* fast/slow/normal */
				padding: 40, /* padding for each side of the picture */
				opacity: 0.35, /* Value betwee 0 and 1 */
				showTitle: true, /* true/false */	
				social_tools: false
				});
			})
		</script>
	<?php } ?>
	
<style type="text/css">
	<?php if ($options['mts_logo'] != '') { ?>
		#header h1, #header h2 {
		text-indent: -999em;
		min-width:211px;
		}
		#header h1 a, #header h2 a{
		background: url(<?php echo $options['mts_logo']; ?>) no-repeat;
		min-width: 211px;
		display: block;
		min-height: 57px;
		line-height: 28px;
		}
	<?php } ?>
		body {
	<?php if ($options['mts_bg_color'] != '') { ?>
		background-color:<?php echo $options['mts_bg_color']; ?>;
	<?php } ?>
		}
	<?php if ($options['mts_bg_pattern_upload'] != '') { ?>
		body {
		background-image: url(<?php echo $options['mts_bg_pattern_upload']; ?>);
		}
	<?php } else { ?>
	<?php if ($options['mts_bg_pattern'] != '') { ?>
		body {
		background-image: url(<?php echo get_template_directory_uri(); ?>/images/<?php echo $options['mts_bg_pattern']; ?>.png);
		}
	<?php } ?>
	<?php } ?>
	
	<?php if ($options['mts_primary_color'] != '') { ?>
			.secondary-navigation, .back-to-top{
			background-color:<?php echo $options['mts_primary_color']; ?>;
			}
	<?php } ?>
	<?php if ($options['mts_secondary_color'] != '') { ?>
			.secondary-navigation, .back-to-top, .secondary-navigation a:hover, body > footer .footeText a{
			border-color:<?php echo $options['mts_secondary_color']; ?>;
			}
			.single_post a, a:hover {
			color:<?php echo $options['mts_secondary_color']; ?>;
			}
	<?php } ?>

	<?php if ($options['mts_header_bg_color'] != '') { ?>
	.main-header, footer .container {
		background-color:<?php echo $options['mts_header_bg_color']; ?>;
	}
	<?php } ?>

	<?php if ($options['mts_header_bg_pattern'] != '') { ?>
		.main-header, footer .container{
		background-image: url(<?php echo get_template_directory_uri(); ?>/images/<?php echo $options['mts_header_bg_pattern']; ?>.png);
		}
	<?php } ?>

	<?php if($options['mts_author_comment'] == '1') { ?>
		.commentlist .bypostauthor {
		background: #F8F8F8!important;
		border: 1px solid #EBEBEB!important;
		padding-left: 20px;
		padding-top: 20px;
		}
		.commentlist .bypostauthor .reply {
		border-bottom:0;
		}
	<?php } ?>
	
	<?php if ($options['mts_body_size'] != '') { ?>
		body {
		font-size:<?php echo $options['mts_body_size']; ?>;
		}
	<?php } ?>

	<?php if($options['mts_floating_social'] == '1') { ?>
		.shareit {
			top: 315px;
			left: auto;
			z-index: 0;
			margin: 0 0 0 -130px;
			width: 90px;
			position: fixed;
			overflow: hidden;
			padding-left: 3px;
			background: #EEEBE4;
			border: 1px solid #CECECE;
			-webkit-border-radius: 6px;
			-moz-border-radius: 6px;
			border-radius: 6px;
		}
		.share-item {
			margin: 2px;
		}
		.pinbtn {
		width: auto;
		}
	<?php } ?>
	
	<?php if ($options['mts_layout'] == 'sclayout') { ?>
		.article {
		float:right;
		}
		.sidebar.c-4-12 {
		float: left;
		}

		<?php if($options['mts_floating_social'] == '1') { ?>
			.shareit {
			margin: 0 0 0 612px;
			border: 1px solid #CECECE;
			-webkit-border-radius: 6px;
			-moz-border-radius: 6px;
			border-radius: 6px;
			}
		<?php } ?>
	<?php } ?>
	<?php echo $options['mts_custom_css']; ?>
	
</style>

<?php echo $options['mts_header_code']; ?>

</head>

<?php flush(); ?>

<body id ="blog" <?php body_class('main'); ?>>

		<header class="main-header">
		<div class="container">
				<div id="header">
				
					<?php if( is_front_page() || is_home() || is_404() ) { ?>
							<h1 id="logo">
								<a href="<?php echo home_url(); ?>"><?php bloginfo( 'name' ); ?></a>
							</h1><!-- END #logo -->
					<?php } else { ?>
						  <h2 id="logo">
								<a href="<?php echo home_url(); ?>"><?php bloginfo( 'name' ); ?></a>
							</h2><!-- END #logo -->
					<?php } ?>
					<?php if ( ! dynamic_sidebar( 'Header' ) ) : ?>
					<?php endif ?>
				</div><!--#header-->
			
			<div class="secondary-navigation">
				<nav id="navigation" >
					<?php if ( has_nav_menu( 'secondary-menu' ) ) { ?>
						<?php wp_nav_menu( array( 'theme_location' => 'secondary-menu', 'menu_class' => 'menu', 'container' => '' ) ); ?>
					<?php } else { ?>
						<ul class="menu">
							<?php wp_list_categories('title_li='); ?>
						</ul>
					<?php } ?>
				</nav>
			</div>
		</div><!--.container-->

        
		</header>