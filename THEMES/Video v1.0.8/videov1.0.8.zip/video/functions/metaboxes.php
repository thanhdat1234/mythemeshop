<?php

/*-----------------------------------------------------------------------------------*/
/*	Sidebar Selection meta box
/*-----------------------------------------------------------------------------------*/
function mts_add_metaboxes() {
    $screens = array('post', 'page');
    foreach ($screens as $screen) {
        add_meta_box(
            'mts_sidebar_metabox',                  // id
            __('Sidebar', 'mythemeshop'),    // title
            'mts_inner_sidebar_metabox',            // callback
            $screen,                                // post_type
            'side',                                 // context (normal, advanced, side)
            'high'                               // priority (high, core, default, low)
                                                    // callback args ($post passed by default)
        );
    }
    add_meta_box(
        'mts_layout_metabox',                  // id
        __('Post Layout', 'mythemeshop'),    // title
        'mts_inner_layout_metabox',            // callback
        'post',                                // post_type
        'side',                                 // context (normal, advanced, side)
        'high'                               // priority (high, core, default, low)
                                                // callback args ($post passed by default)
    );
}
add_action('add_meta_boxes', 'mts_add_metaboxes');


/**
 * Print the box content.
 * 
 * @param WP_Post $post The object for the current post/page.
 */
function mts_inner_sidebar_metabox($post) {
    global $wp_registered_sidebars;
    
    // Add an nonce field so we can check for it later.
    wp_nonce_field('mts_inner_sidebar_metabox', 'mts_inner_sidebar_metabox_nonce');
    
    /*
    * Use get_post_meta() to retrieve an existing value
    * from the database and use the value for the form.
    */
    $custom_sidebar = get_post_meta( $post->ID, '_mts_custom_sidebar', true );
    $sidebar_location = get_post_meta( $post->ID, '_mts_sidebar_location', true );

    // Select custom sidebar from dropdown
    echo '<select name="mts_custom_sidebar" id="mts_custom_sidebar" style="margin-bottom: 10px;">';
    echo '<option value="" '.selected('', $custom_sidebar).'>-- '.__('Default', 'mythemeshop').' --</option>';
    
    // Exclude built-in sidebars
    $hidden_sidebars = array('widget-header', 'sidebar','shop-sidebar', 'product-sidebar', 'footer-top', 'footer-top-2', 'footer-top-3', 'footer-top-4', 'footer-bottom', 'footer-bottom-2', 'footer-bottom-3', 'footer-bottom-4');    
    
    foreach ($wp_registered_sidebars as $sidebar) {
        if (!in_array($sidebar['id'], $hidden_sidebars)) {
            echo '<option value="'.esc_attr($sidebar['id']).'" '.selected($sidebar['id'], $custom_sidebar, false).'>'.$sidebar['name'].'</option>';
        }
    }
    echo '<option value="mts_nosidebar" '.selected('mts_nosidebar', $custom_sidebar).'>-- '.__('No sidebar --', 'mythemeshop').'</option>';    
    echo '</select><br />';
    
    // Select single layout (left/right sidebar)
    echo '<div class="mts_sidebar_location_fields">';
    echo '<label for="mts_sidebar_location_default" style="display: inline-block; margin-right: 20px;"><input type="radio" name="mts_sidebar_location" id="mts_sidebar_location_default" value=""'.checked('', $sidebar_location, false).'>'.__('Default side', 'mythemeshop').'</label>';
    echo '<label for="mts_sidebar_location_left" style="display: inline-block; margin-right: 20px;"><input type="radio" name="mts_sidebar_location" id="mts_sidebar_location_left" value="left"'.checked('left', $sidebar_location, false).'>'.__('Left', 'mythemeshop').'</label>';
    echo '<label for="mts_sidebar_location_right" style="display: inline-block; margin-right: 20px;"><input type="radio" name="mts_sidebar_location" id="mts_sidebar_location_right" value="right"'.checked('right', $sidebar_location, false).'>'.__('Right', 'mythemeshop').'</label>';
    echo '</div>';
    
    ?>
    <script type="text/javascript">
        jQuery(document).ready(function($) {
            function mts_toggle_sidebar_location_fields() {
                $('.mts_sidebar_location_fields').toggle(($('#mts_custom_sidebar').val() != 'mts_nosidebar'));
            }
            mts_toggle_sidebar_location_fields();
            $('#mts_custom_sidebar').change(function() {
                mts_toggle_sidebar_location_fields();
            });
        });
    </script>
    <?php
    //debug
    //global $wp_meta_boxes;
}

/**
 * Print the box content.
 * 
 * @param WP_Post $post The object for the current post/page.
 */
function mts_inner_layout_metabox($post) {
    global $wp_registered_sidebars;
    
    // Add an nonce field so we can check for it later.
    wp_nonce_field('mts_inner_layout_metabox', 'mts_inner_layout_metabox_nonce');
    
    /*
    * Use get_post_meta() to retrieve an existing value
    * from the database and use the value for the form.
    */
    $post_layout = get_post_meta( $post->ID, '_mts_post_layout', true );

    // Select custom sidebar from dropdown
    echo '<select name="mts_post_layout" id="mts_post_layout">';
    echo '<option value="" '.selected('', $post_layout).'>-- '.__('Default', 'mythemeshop').' --</option>';
    echo '<option value="crlayout" '.selected('crlayout', $post_layout).'>'.__('Layout 1', 'mythemeshop').'</option>';
    echo '<option value="rclayout" '.selected('rclayout', $post_layout).'>'.__('Layout 2', 'mythemeshop').'</option>';
    echo '<option value="cbrlayout" '.selected('cbrlayout', $post_layout).'>'.__('Layout 3', 'mythemeshop').'</option>';
      
    echo '</select><br />';
    
}

/**
 * When the post is saved, saves our custom data.
 *
 * @param int $post_id The ID of the post being saved.
 */
function mts_save_custom_sidebar( $post_id ) {
    
    /*
    * We need to verify this came from our screen and with proper authorization,
    * because save_post can be triggered at other times.
    */
    
    // Check if our nonce is set.
    if ( ! isset( $_POST['mts_inner_sidebar_metabox_nonce'] ) )
    return $post_id;
    
    $nonce = $_POST['mts_inner_sidebar_metabox_nonce'];
    
    // Verify that the nonce is valid.
    if ( ! wp_verify_nonce( $nonce, 'mts_inner_sidebar_metabox' ) )
      return $post_id;
    
    // If this is an autosave, our form has not been submitted, so we don't want to do anything.
    if ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) 
      return $post_id;
    
    // Check the user's permissions.
    if ( 'page' == $_POST['post_type'] ) {
    
    if ( ! current_user_can( 'edit_page', $post_id ) )
        return $post_id;
    
    } else {
    
    if ( ! current_user_can( 'edit_post', $post_id ) )
        return $post_id;
    }
    
    /* OK, its safe for us to save the data now. */
    
    // Sanitize user input.
    $sidebar_name = sanitize_text_field( $_POST['mts_custom_sidebar'] );
    $sidebar_location = sanitize_text_field( $_POST['mts_sidebar_location'] );
    
    // Update the meta field in the database.
    update_post_meta( $post_id, '_mts_custom_sidebar', $sidebar_name );
    update_post_meta( $post_id, '_mts_sidebar_location', $sidebar_location );
}
add_action( 'save_post', 'mts_save_custom_sidebar' );


function mts_save_post_layout( $post_id ) {
    
    /*
    * We need to verify this came from our screen and with proper authorization,
    * because save_post can be triggered at other times.
    */
    
    // Check if our nonce is set.
    if ( ! isset( $_POST['mts_inner_layout_metabox_nonce'] ) )
    return $post_id;
    
    $nonce = $_POST['mts_inner_layout_metabox_nonce'];
    
    // Verify that the nonce is valid.
    if ( ! wp_verify_nonce( $nonce, 'mts_inner_layout_metabox' ) )
      return $post_id;
    
    // If this is an autosave, our form has not been submitted, so we don't want to do anything.
    if ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) 
      return $post_id;
    
    // Check the user's permissions.
    if ( 'page' == $_POST['post_type'] ) {
    
    if ( ! current_user_can( 'edit_page', $post_id ) )
        return $post_id;
    
    } else {
    
    if ( ! current_user_can( 'edit_post', $post_id ) )
        return $post_id;
    }
    
    /* OK, its safe for us to save the data now. */
    
    // Sanitize user input.
    $sidebar_name = sanitize_text_field( $_POST['mts_post_layout'] );
    
    // Update the meta field in the database.
    update_post_meta( $post_id, '_mts_post_layout', $sidebar_name );
}
add_action( 'save_post', 'mts_save_post_layout' );

/*-----------------------------------------------------------------------------------*/
/*  YoutTube Playlist Metabox
/*  Shown only when Post Format is Video
/*-----------------------------------------------------------------------------------*/
function mts_custom_meta() {
    add_meta_box( 'mts_meta', __( 'Youtube Player Options', 'mythemeshop' ), 'mts_meta_callback', 'post', 'side' );
}
add_action( 'add_meta_boxes', 'mts_custom_meta' );

function mts_meta_callback( $post ) {
    wp_nonce_field( basename( __FILE__ ), 'mts_nonce' );
    $mts_stored_meta = get_post_meta( $post->ID );
    if (!isset($mts_stored_meta['youtube-select'])) $mts_stored_meta['youtube-select'] = array('');
    ?>

    <p>
        <label for="video-select" class="mts-row-title"><input name="youtube-select" id="video-select" type="radio" value="video-id" <?php checked( $mts_stored_meta['youtube-select'][0], 'video-id' ); ?>><?php _e( 'Video', 'mythemeshop' )?></label>&nbsp;&nbsp;
        <label for="playlist-select" class="mts-row-title"><input name="youtube-select" id="playlist-select" type="radio" value="playlist-id" <?php checked( $mts_stored_meta['youtube-select'][0], 'playlist-id' ); ?>><?php _e( 'Playlist', 'mythemeshop' )?></label>
    </p>
 
    <p>
        <label for="playlist-id" class="mts-row-title"><?php _e( 'YouTube Playlist/Video ID', 'mythemeshop' )?></label>
        <input type="text" name="playlist-id" id="playlist-id" value="<?php if ( isset ( $mts_stored_meta['playlist-id'] ) ) echo $mts_stored_meta['playlist-id'][0]; ?>" />
    </p>

    <p>
        <label for="submitted-by" class="mts-row-title"><?php _e( 'Submitted by', 'mythemeshop' )?></label>
        <input type="text" name="submitted-by" id="submitted-by" value="<?php if ( isset ( $mts_stored_meta['submitted-by'] ) ) echo $mts_stored_meta['submitted-by'][0]; ?>" />
    </p>
    <script type="text/javascript">
    jQuery(window).load(function() {
        jQuery('#post-formats-select').append('<p id="video-help" class="description" style="display: none;"><?php _e('Use the Youtube Player Options metabox to set up the video player.', 'mythemeshop'); ?></p>')
        .find('.post-format').change(function() {
            if (jQuery(this).val() == 'video') {
                jQuery('#video-help').show();
            } else {
                jQuery('#video-help').hide();
            }
        });
    });
    </script>
    <?php
}

/**
 * Saves the custom youtube input
 */
function mts_meta_save( $post_id ) {
 
    // Checks save status
    $is_autosave = wp_is_post_autosave( $post_id );
    $is_revision = wp_is_post_revision( $post_id );
    $is_valid_nonce = ( isset( $_POST[ 'mts_nonce' ] ) && wp_verify_nonce( $_POST[ 'mts_nonce' ], basename( __FILE__ ) ) ) ? 'true' : 'false';
 
    // Exits script depending on save status
    if ( $is_autosave || $is_revision || !$is_valid_nonce ) {
        return;
    }
 
    // Checks for input and sanitizes/saves if needed
    if( isset( $_POST[ 'playlist-id' ] ) ) {
        $video_id = $_POST[ 'playlist-id' ];
        $submitted_by = (!empty($_POST[ 'submitted-by' ]) ? $_POST[ 'submitted-by' ] : '');
        if (substr($video_id, 0, 4) == 'http') {
            if( !empty( $_POST[ 'youtube-select' ] ) && $_POST[ 'youtube-select' ] == 'video-id' ) {
                if (preg_match('/v=([a-z0-9_-]+)/i', $video_id, $matches))
                    $video_id = $matches[1];
            } else {
                if (preg_match('/list=([a-z0-9_-]+)/i', $video_id, $matches))
                    $video_id = $matches[1];
            }
        }

        if ($submitted_by)
            update_post_meta( $post_id, 'submitted-by', sanitize_text_field( $submitted_by ) );

        if (get_post_meta( $post_id, 'playlist-id', true ) != $video_id) {
            update_post_meta( $post_id, 'playlist-id', sanitize_text_field( $video_id ) );
            update_post_meta( $post_id, 'video-length', '' );
            update_post_meta( $post_id, 'video-views', '' );
        }
    }

    // Checks for input and saves if needed
    if( isset( $_POST[ 'youtube-select' ] ) ) {
        update_post_meta( $post_id, 'youtube-select', $_POST[ 'youtube-select' ] );
    }
 
}
add_action( 'save_post', 'mts_meta_save' );

?>