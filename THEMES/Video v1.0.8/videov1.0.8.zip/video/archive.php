<?php 
$mts_options = get_option(MTS_THEME_NAME); 
$query_args = '';
get_header();
?>
<div id="page">
	<div id="content_box">
		<div class="home-posts home-left <?php echo ($mts_options['mts_archive_sidebar'] == 'sidebar') ? 'home-sidebar' : ''; ?>">
			<h1 class="home-title">
				<?php if (is_category()) {
					$obj = get_queried_object();
					$cat_id = $obj->term_id;
					$query_args = '&cat='.$cat_id; ?>
					<span><?php single_cat_title(); ?><?php _e(" Archive", "mythemeshop"); ?></span>
				<?php } elseif (is_tag()) { 
					$obj = get_queried_object();
					$tag_id = $obj->term_id;
					$query_args = '&tag_id='.$tag_id; ?> 
					<span><?php single_tag_title(); ?><?php _e(" Archive", "mythemeshop"); ?></span>
				<?php } elseif (is_author()) { ?>
					<span><?php  $curauth = (isset($_GET['author_name'])) ? get_user_by('slug', $author_name) : get_userdata(intval($author)); echo $curauth->nickname; _e(" Archive", "mythemeshop"); ?></span> 
				<?php } elseif (is_day()) { ?>
					<span><?php _e("Daily Archive:", "mythemeshop"); ?></span> <?php the_time('l, F j, Y'); ?>
				<?php } elseif (is_month()) { ?>
					<span><?php _e("Monthly Archive:", "mythemeshop"); ?>:</span> <?php the_time('F Y'); ?>
				<?php } elseif (is_year()) { ?>
					<span><?php _e("Yearly Archive:", "mythemeshop"); ?>:</span> <?php the_time('Y'); ?>
				<?php } ?>
			</h1>
			<?php $j = 0; if (have_posts()) : while (have_posts()) : the_post(); 
			$mts_youtube_select = get_post_meta( get_the_ID(), 'youtube-select', true ); ?>
				<article class="latestPost excerpt  <?php echo (++$j % 3 == 0) ? 'last' : ''; ?>" itemscope itemtype="http://schema.org/BlogPosting">
					<div class="home-thumb">
                        <a href="<?php the_permalink() ?>" title="<?php the_title_attribute(); ?>" class="featured-thumbnail">
    					   <?php the_post_thumbnail('featured',array('title' => '')); ?>
    					   <?php mts_watch_later_button(); ?>
    					   <?php if ( has_post_format('video') && $mts_youtube_select == 'video-id' ) { ?>
    					   		<span class="duration"><?php mts_video_duration(); ?></span>
    					   <?php } ?>
                        </a>
    				</div>
    				<h2 class="home-post-title"><a href="<?php the_permalink() ?>"><?php the_title(); ?></a></h2>
    				<div class="home-content">
    					<?php echo mts_excerpt(17); ?>
    				</div>
				</article><!--.post excerpt-->
			<?php endwhile; endif; ?>

			<!--Start Pagination-->
            <?php if (isset($mts_options['mts_pagenavigation_type']) && $mts_options['mts_pagenavigation_type'] == '1' ) { ?>
                <?php mts_pagination(); ?> 
			<?php } else { ?>
				<div class="pagination pagination-previous-next">
					<ul>
						<li class="nav-previous"><?php next_posts_link( '<i class="fa fa-angle-left"></i> '. __( 'Previous', 'mythemeshop' ) ); ?></li>
						<li class="nav-next"><?php previous_posts_link( __( 'Next', 'mythemeshop' ).' <i class="fa fa-angle-right"></i>' ); ?></li>
					</ul>
				</div>
			<?php } ?>
			<!--End Pagination-->
		</div><!--.home-left-->
		<?php if ($mts_options['mts_archive_sidebar'] != 'sidebar') { ?>
			<div class="home-posts home-right">
				<h2 class="home-title">
					<?php if ($mts_options['mts_archive_sidebar'] == 'popular') { ?>
						<?php 
							_e('Most Popular','mythemeshop'); 
							$query_params = array(
								'meta_key' => '_mts_view_count',
								'orderby' => 'meta_value_num',
								'order' => 'DESC',
								'ignore_sticky_posts' => '1'
							);
							if (!empty($mts_options['mts_popular_days'])) {
								$popular_days = (int) $mts_options['mts_popular_days'];
								$query_params['date_query'] = array(
									array(
									     'after'     => "$popular_days days ago",
									     'inclusive' => true,
									),
								); 
							}

							$my_query = new WP_Query($query_params);
						?>
					<?php } elseif ($mts_options['mts_archive_sidebar'] == 'random') { ?>
						<?php 
							_e('Random Posts','mythemeshop');
							$my_query = new WP_Query('orderby=rand&ignore_sticky_posts=1'.$query_args);
						?>
					<?php } ?>
				</h2>
				<?php while ($my_query->have_posts()) : $my_query->the_post();
	    			$mts_youtube_select = get_post_meta( get_the_ID(), 'youtube-select', true ); ?>
					<article class="latestPost excerpt  <?php echo (++$j % 3 == 0) ? 'last' : ''; ?>" itemscope itemtype="http://schema.org/BlogPosting">
						<div class="home-thumb">
	                        <a href="<?php the_permalink() ?>" title="<?php the_title_attribute(); ?>" class="featured-thumbnail">
	    					   <?php the_post_thumbnail('featured',array('title' => '')); ?>
	    					   <?php mts_watch_later_button(); ?>
	    					   <?php if ( has_post_format('video') && $mts_youtube_select == 'video-id' ) { ?>
	    					   		<span class="duration"><?php mts_video_duration(); ?></span>
	    					   <?php } ?>
	                        </a>
	    				</div>
	    				<h2 class="home-post-title"><a href="<?php the_permalink() ?>"><?php the_title(); ?></a></h2>
	    				<div class="home-content">
	    					<?php echo mts_excerpt(17); ?>
	    				</div>
					</article><!--.post excerpt-->
	    		<?php endwhile; wp_reset_query(); ?>
			</div><!--.home-right-->
		<?php } else {
			get_sidebar();
		} ?>
	</div>
	<?php get_footer(); ?>