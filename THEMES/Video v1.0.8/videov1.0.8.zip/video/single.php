<?php get_header(); ?>
<?php $mts_options = get_option(MTS_THEME_NAME); 
	$mts_youtube_select = get_post_meta( get_the_ID(), 'youtube-select', true );
	$mts_playlist_id = get_post_meta( get_the_ID(), 'playlist-id', true );
?>
<div id="page" class="single">
	<div class="<?php mts_article_class(); if(empty($mts_options['mts_related_posts'])) { echo " no-related-posts"; } ?>" itemscope itemtype="http://schema.org/BlogPosting">
		<div id="content_box"<?php if ( !empty( $mts_playlist_id ) ) : ?> itemprop="video" itemscope itemtype="http://schema.org/VideoObject"<?php endif; ?>>
			<?php if ( have_posts() ) while ( have_posts() ) : the_post(); ?>
				<?php
					$post_thumbnail_id = get_post_thumbnail_id( get_the_ID() );
					$image_src = wp_get_attachment_image_src( $post_thumbnail_id, 'full' );
				?>
				<div id="post-<?php the_ID(); ?>" <?php post_class('g post'); ?>>
					<div id="popup" class="popup-window">
						<i class="fa fa-times"></i>
						<h3><?php _e('Share','mythemeshop'); ?></h3>
						<ul class="clearfix">
							<?php if($mts_options['mts_facebook'] == '1') { ?>
								<li class="fb">
									<a rel="nofollow" href="http://www.facebook.com/share.php?u=<?php the_permalink(); ?>&amp;title=<?php echo urlencode(get_the_title($id)); ?>" target="_blank" title="Share on Facebook"><i class="fa fa-facebook"></i></a>
								</li>
							<?php } ?>
							<?php if($mts_options['mts_twitter'] == '1') { ?>
								<li class="twitter">
									<a rel="nofollow" href="http://twitter.com/home?status=<?php echo get_the_title($id); ?>+<?php the_permalink() ?> <?php if($mts_options['mts_twitter_username'] != ''){ echo 'via @'.$mts_options['mts_twitter_username']; } ?>" target="_blank" title="Share on Twitter"><i class="fa fa-twitter"></i></a>
								</li>
							<?php } ?>
							<?php if($mts_options['mts_gplus'] == '1') { ?>
								<li class="gplus">
									<a rel="nofollow" href="https://plus.google.com/share?url=<?php the_permalink() ?>" target="_blank" title="Share on Google+"><i class="fa fa-google-plus"></i></a>
								</li>
							<?php } ?>
							<?php if($mts_options['mts_pinterest'] == '1') { ?>
								<li class="pinterest">
									<a href="//pinterest.com/pin/create/button/?url=<?php echo urlencode(get_permalink()); ?>&amp;media=<?php echo $image_src[0]; ?>&amp;description=<?php the_title(); ?>" target="_blank"><i class="fa fa-pinterest"></i></a>
								</li>
							<?php } ?>
							<?php if($mts_options['mts_tumblr'] == '1') { ?>
								<li class="tumblr">
									<a rel="nofollow" href="http://www.tumblr.com/share?v=3&amp;u=<?php the_permalink() ?>&amp;t=<?php echo urlencode(get_the_title($id)); ?>" target="_blank" title="Share on Tumblr"><i class="fa fa-tumblr"></i></a>
								</li>
							<?php } ?>
						</ul>
						<?php if (function_exists('wp_get_shortlink')) { ?>
						<div class="post-shortlink">
							<input type='text' value='<?php echo wp_get_shortlink(get_the_ID()); ?>' onclick='this.focus(); this.select();' />
						</div>
						<?php } ?>
					</div><!--#popup-->
					<?php 
					if( !empty( $mts_playlist_id ) ) { 
						if ( $mts_youtube_select == 'video-id') { ?>
						    <script type="text/javascript">
						    	jQuery(document).ready(function() {
									jQuery('#myList').youtube_video({
										videos: '<?php echo $mts_playlist_id; ?>',
										autoplay: false,
										hide_youtube_logo: false,
										share_control: false,
										continuous: false,
										api_key: 'AIzaSyDcaTYgjaZ1SsJhwLMd5zjTZy8lSAACMnI',
										show_playlist: false
									});
								});
						    </script>
						<?php } else { ?>
						    <script type="text/javascript">
						    	jQuery(document).ready(function() {
									jQuery('#myList').youtube_video({
										playlist: '<?php echo $mts_playlist_id; ?>',
										autoplay: false,
										hide_youtube_logo: false,
										share_control: false,
										api_key: 'AIzaSyDcaTYgjaZ1SsJhwLMd5zjTZy8lSAACMnI'
									});
								});
						    </script>
						<?php }
					} ?>
					<div id="myList"></div>
					<?php if (has_post_thumbnail() && $mts_options['mts_custom_thumbnail'] == '1') { $videoimage = wp_get_attachment_image_src( get_post_thumbnail_id( $post->ID ), 'full' ); ?>
						<style type="text/css">
							#myList .yesp-autoposter { background-image: url(<?php echo $videoimage[0]; ?>)!important; background-repeat: no-repeat; }
						</style>
					<?php } ?>
					<?php 
					// Video Meta
					$meta_thumbnail = '';
					if (has_post_thumbnail() && $mts_options['mts_custom_thumbnail'] == '1') {
						$meta_thumbnail = $videoimage[0];
					} else {
						if ( $mts_youtube_select == 'video-id' && !empty($mts_playlist_id)) {
							$meta_thumbnail = 'http://i.ytimg.com/vi/'.$mts_playlist_id.'/hqdefault.jpg';
						}
					}
					if (!empty($meta_thumbnail)) {
						echo '<meta itemprop="thumbnailURL" content="'.$meta_thumbnail.'" />';
					}

					$meta_embedurl = '';
					if ( $mts_youtube_select == 'video-id' && !empty($mts_playlist_id)) {
						$meta_embedurl = 'https://youtube.googleapis.com/v/'.$mts_playlist_id;
					}
					if (!empty($meta_embedurl)) {
						echo '<meta itemprop="embedURL" content="'.$meta_embedurl.'" />';
					}

					if ( $mts_youtube_select == 'video-id' && !empty($mts_playlist_id)) {
						echo '<meta itemprop="description" content="'.mts_excerpt(20).'" />';
					}
					?>
					<header class="main-post-header">
						<h1 class="title single-title entry-title"><span itemprop="name"><?php the_title(); ?></span><?php if ( has_post_format('video') && $mts_youtube_select == 'video-id' ) { ?><span class="single-duration"><?php mts_video_duration(0, false); ?></span><?php } ?></h1>
						<?php //mts_the_postinfo( 'single' ); ?>
							<div class="single-buttons">
								<ul>
									<li class="single-views"><?php mts_video_views(); ?></li>
									<?php if ( !empty($mts_options['mts_single_share_btn']) ) { ?>
										<li class="share-button"><span><i class="fa fa-send"></i><?php _e('Share','mythemeshop'); ?></span></li>
									<?php } ?>
									<?php if ( !empty($mts_options['mts_like_dislike'])) { 
										mts_like_dislike();
									} ?>
								</ul>
							</div>
					</header><!--.headline_area-->
					
					<?php if ($mts_options['mts_breadcrumb'] == '1') { ?>
						<div class="breadcrumb" xmlns:v="http://rdf.data-vocabulary.org/#"><?php mts_the_breadcrumb(); ?></div>
					<?php } ?>
						
					<div class="main-article-container">
						<article class="single_post">
							<div class="post-single-content box mark-links entry-content">
								<div class="post-top">
									<?php if( !empty( $mts_options["mts_single_headline_meta_info"]['date']) && !empty($mts_options["mts_single_headline_meta"]) ) { ?>
										<div class="publish-date">
											<?php _e('Published on ','mythemeshop'); the_time(get_option( 'date_format' )); ?>
										</div>
									<?php } ?>
									<div class="post-toggle"><i class="fa fa-angle-down"></i></div>
								</div><!--.post-top-->
								<?php if ($mts_options['mts_posttop_adcode'] != '') { ?>
									<?php $toptime = $mts_options['mts_posttop_adcode_time']; if (strcmp( date("Y-m-d", strtotime( "-$toptime day")), get_the_time("Y-m-d") ) >= 0) { ?>
										<div class="topad">
											<?php echo do_shortcode($mts_options['mts_posttop_adcode']); ?>
										</div>
									<?php } ?>
								<?php } ?>
								<div class="togglecontent">
		                            <div class="thecontent"<?php if ( get_post_format() != 'video') { ?> itemprop="articleBody"<?php } ?>>
				                        <?php the_content(); ?>
									</div>
		                            <?php wp_link_pages(array('before' => '<div class="pagination">', 'after' => '</div>', 'link_before'  => '<span class="current"><span class="currenttext">', 'link_after' => '</span></span>', 'next_or_number' => 'next_and_number', 'nextpagelink' => __('Next','mythemeshop'), 'previouspagelink' => __('Previous','mythemeshop'), 'pagelink' => '%','echo' => 1 )); ?>
									
									<?php if(!empty($mts_options["mts_single_headline_meta"])) { ?>
			                            <div class="post-meta">
			                            	<?php if( ! empty( $mts_options["mts_single_headline_meta_info"]['category']) ) { ?>
			                            		<span class="post-cat"><?php _e('Category: ','mythemeshop'); the_category(', '); ?></span>
			                            	<?php } ?>
			                            	<?php if ( ! empty( $mts_options["mts_single_headline_meta_info"]['author']) ) { ?>
			                            		<?php 
			                            		$author = '<a href="'.get_author_posts_url( get_the_author_meta( 'ID' ) ).'">'.get_the_author_meta( 'display_name' ).'</a>'; 
			                            		$meta_author = get_post_meta( get_the_id(), 'submitted-by', true );
			                            		if (!empty($meta_author))
			                            			$author = $meta_author;
			                            		?>
			                            		<span class="post-author"><?php _e('Submitted: ','mythemeshop'); echo $author; ?></span>
			                            	<?php } ?>
			                            </div><!--.post-meta-->
		                            <?php } ?>
		                        </div><!--.togglecontent-->

								<?php if ($mts_options['mts_postend_adcode'] != '') { ?>
									<?php $endtime = $mts_options['mts_postend_adcode_time']; if (strcmp( date("Y-m-d", strtotime( "-$endtime day")), get_the_time("Y-m-d") ) >= 0) { ?>
										<div class="bottomad">
											<?php echo do_shortcode($mts_options['mts_postend_adcode']); ?>
										</div>
									<?php } ?>
								<?php } ?> 
								
								<?php if($mts_options['mts_tags'] == '1') { ?>
									<div class="tags"><?php mts_the_tags('<span class="tagtext">'.__('Tags','mythemeshop').':</span>',', ') ?></div>
								<?php } ?>

								<?php if($mts_options['mts_author_box'] == '1') { ?>
									<div class="postauthor">
										<h4><?php _e('About The Author', 'mythemeshop'); ?></h4>
										<div class="postauthor-box">
											<?php if(function_exists('get_avatar')) { echo get_avatar( get_the_author_meta('email'), '70' );  } ?>
											<h5 class="vcard"><a href="<?php echo get_author_posts_url( get_the_author_meta( 'ID' ) ); ?>" rel="nofollow" class="fn"><?php the_author_meta( 'nickname' ); ?></a></h5>
											<p><?php the_author_meta('description') ?></p>
										</div>
									</div>
								<?php }?>  

								<?php comments_template( '', true ); ?>
								<?php 
								// custom single post layout
								global $post;
					            $post_layout = get_post_meta( $post->ID, '_mts_post_layout', true );
					            if (!empty($post_layout)) $mts_options['mts_single_post_layout'] = $post_layout;
					            
								if ($mts_options['mts_single_post_layout'] == 'crlayout' ) {
									mts_related_posts();
								} ?>
							</div><!--.post-single-content-->
						</article><!--.single_post-->
						<?php if ($mts_options['mts_single_post_layout'] == 'crlayout' ) {
							get_sidebar();
						} ?>
						<?php if ( $mts_options['mts_single_post_layout'] == 'cbrlayout' || $mts_options['mts_single_post_layout'] == 'rclayout' ) {
							mts_related_posts();
						} ?>
					</div>
				</div><!--.g post-->
			<?php endwhile; /* end loop */ ?>
		</div><!--#content_box-->
	</div>
<?php get_footer(); ?>