jQuery.fn.exists = function(callback) {
  var args = [].slice.call(arguments, 1);
  if (this.length) {
    callback.call(this, args);
  }
  return this;
};

/*----------------------------------------------------
/* Tabs
/*---------------------------------------------------*/
jQuery(document).ready(function($){
    var tabItems = $('.cd-tabs-navigation a'),
        tabContentWrapper = $('.cd-tabs-content');

    tabItems.on('click', function(event){
        event.preventDefault();
        var selectedItem = $(this);
        if( !selectedItem.hasClass('selected') ) {
            var selectedTab = selectedItem.data('content'),
                selectedContent = tabContentWrapper.find('li[data-content="'+selectedTab+'"]'),
                slectedContentHeight = selectedContent.innerHeight();
            
            tabItems.removeClass('selected');
            selectedItem.addClass('selected');
            selectedContent.addClass('selected').siblings('li').removeClass('selected');
            //animate tabContentWrapper height when content changes 
            
        }
    });

    //hide the .cd-tabs::after element when tabbed navigation has scrolled to the end (mobile version)
    checkScrolling($('.cd-tabs nav'));
    $(window).on('resize', function(){
        checkScrolling($('.cd-tabs nav'));
        tabContentWrapper.css('height', 'auto');
    });
    $('.cd-tabs nav').on('scroll', function(){ 
        checkScrolling($(this));
    });

    function checkScrolling(tabs){
        var totalTabWidth = parseInt(tabs.children('.cd-tabs-navigation').width()),
            tabsViewport = parseInt(tabs.width());
        if( tabs.scrollLeft() >= totalTabWidth - tabsViewport) {
            tabs.parent('.cd-tabs').addClass('is-ended');
        } else {
            tabs.parent('.cd-tabs').removeClass('is-ended');
        }
    }
});

/*----------------------------------------------------
/* Post Toggle
/*---------------------------------------------------*/
jQuery(document).ready(function() {
    jQuery( ".post-toggle" ).click(function() {
        jQuery( ".togglecontent" ).slideToggle( "slow" );
    });
});

/*----------------------------------------------------
/* Watch Later
/*---------------------------------------------------*/
jQuery(document).ready(function($) {
    $(document).on('click', '.watchlater', function(event) {
        event.preventDefault();
        var $this = $(this),
            postid = $this.data('postid').toString(),
            bookmarked = $.cookie('bookmarked') ? $.cookie('bookmarked').split(',') : [];
        if ( $.inArray(postid, bookmarked) == -1 ) {
            // add it
            bookmarked.push(postid);
            //$this.addClass('active');
            // mark other thumbs of same post on current page
            $('.watchlater-'+postid).addClass('active');
        } else {
            // remove it
            bookmarked = jQuery.grep(bookmarked, function(value) {
              return value.toString() != postid.toString();
            });
            //$this.removeClass('active');
            // unmark other thumbs of same post on current page
            $('.watchlater-'+postid).removeClass('active');
        }
        $('.watchlater-counter').text('(' + bookmarked.length + ')');
        $.cookie('bookmarked', bookmarked, {expires: 30, path: '/'});

    });
    
    // Add 'active' class on document.ready
    // To overcome cache issues
    var bookmarked = $.cookie('bookmarked') ? $.cookie('bookmarked').split(',') : [];
    $.each(bookmarked, function(index, val) {
         $('.watchlater-'+val).addClass('active');
    });

    // Watch later menu item
    // triggered by css class 'menu-watch-later'
    if ($('.menu-watch-later').length) {
        bookmarked = $.cookie('bookmarked') ? $.cookie('bookmarked').split(',') : [];
        $('.menu-watch-later').each(function(index, el) {
            var $this = $(this);
            $this.children('a').append(' <span class="watchlater-counter"></span>');
            $this.find('.watchlater-counter').text('(' + bookmarked.length + ')');
        });
    }
});

/*----------------------------------------------------
/* Like / Dislike
/*---------------------------------------------------*/
if (mts_customscript.like) {
    jQuery(document).ready(function($) {
        if ($('#mts_like').length) {
            $('#mts_like').click(function() {
                var $this = $(this),
                    postid = $this.data('postid');
                if ($this.hasClass('active') || $this.hasClass('inactive')) {
                    return false;
                }
                // ajax
                $.ajax({
                    url: mts_customscript.ajaxurl,
                    type: 'POST',
                    data: {action: 'mts_rate', post_id: postid, rating: '1'},
                })
                .always(function() {
                    $this.addClass('active').find('.like-count').text(function() { return parseInt($(this).text())+1; });
                    $('#mts_dislike').addClass('inactive');
                });
            });
            $('#mts_dislike').click(function() {
                var $this = $(this),
                    postid = $this.data('postid');
                if ($this.hasClass('active') || $this.hasClass('inactive')) {
                    return false;
                }
                // ajax
                $.ajax({
                    url: mts_customscript.ajaxurl,
                    type: 'POST',
                    data: {action: 'mts_rate', post_id: postid, rating: '-1'},
                })
                .always(function() {
                    $this.addClass('active').find('.like-count').text(function() { return parseInt($(this).text())+1; });
                    $('#mts_like').addClass('inactive');
                });
            });

            // Retreive ratings via JS to prevent caching
            $(window).load(function() {
                $.ajax({
                    url: mts_customscript.ajaxurl,
                    type: 'POST',
                    dataType: 'json',
                    data: {action: 'mts_ratings', post_id: $('#mts_like').data('postid')}
                })
                .done(function(data) {
                    var $like = $('#mts_like'),
                        $dislike = $('#mts_dislike');

                    $like.find('.like-count').text(data.likes);
                    $dislike.find('.like-count').text(data.dislikes);
                    var rated = parseInt(data.has_rated);
                    if (rated == 1) {
                        $like.addClass('active').removeClass('inactive');
                        $dislike.removeClass('active').addClass('inactive');
                    } else if (rated == -1) {
                        $dislike.addClass('active').removeClass('inactive');
                        $like.removeClass('active').addClass('inactive');
                    } else { // data.rated == 0
                        $like.removeClass('active inactive');
                        $dislike.removeClass('active inactive');
                    }
                });
            });
        }     
    });
}

/*----------------------------------------------------
/* Modal Window
/*---------------------------------------------------*/
    // Semicolon (;) to ensure closing of earlier scripting
    // Encapsulation
    // $ is assigned to jQuery
    ;(function($) {

         // DOM Ready
        $(function() {

            // Binding a click event
            // From jQuery v.1.7.0 use .on() instead of .bind()
            $('.share-button').bind('click', function(e) {

                // Prevents the default action to be triggered. 
                e.preventDefault();

                // Triggering bPopup when click event is fired
                $('#popup').bPopup({
                  closeClass: "fa-times"
              });

            });

        });

    })(jQuery);

/*----------------------------------------------------
/* Show/hide Scroll to top
/*--------------------------------------------------*/
jQuery(document).ready(function($) {
	//move-to-top arrow
	//jQuery("body").prepend("<div id='move-to-top' class='animate ' href='#blog'><i class='fa fa-angle-up'></i></div>");
    
	var scrollDes = 'html,body';  
	/*Opera does a strange thing if we use 'html' and 'body' together so my solution is to do the UA sniffing thing*/
	if(navigator.userAgent.match(/opera/i)){
		scrollDes = 'html';
	}
	//show ,hide
	jQuery(window).scroll(function () {
		if (jQuery(this).scrollTop() > 160) {
			jQuery('#move-to-top').addClass('filling').removeClass('hiding');
		} else {
			jQuery('#move-to-top').removeClass('filling').addClass('hiding');
		}
	});
});


/*----------------------------------------------------
/* Make all anchor links smooth scrolling
/*--------------------------------------------------*/
jQuery(document).ready(function($) {
 // scroll handler
  var scrollToAnchor = function( id, event ) {
    // grab the element to scroll to based on the name
    var elem = $("a[name='"+ id +"']");
    // if that didn't work, look for an element with our ID
    if ( typeof( elem.offset() ) === "undefined" ) {
      elem = $("#"+id);
    }
    // if the destination element exists
    if ( typeof( elem.offset() ) !== "undefined" ) {
      // cancel default event propagation
      event.preventDefault();

      // do the scroll
      $('html, body').animate({
              scrollTop: elem.offset().top
      }, 600, 'swing', function() { window.location.hash = id; } );
    }
  };
  // bind to click event
  $("a").click(function( event ) {
    // only do this if it's an anchor link
    var href = $(this).attr("href");
    if ( href.match("#") && href !== '#' ) {
      // scroll to the location
      var parts = href.split('#'),
        url = parts[0],
        target = parts[1];
      if ((!url || url == window.location.href.split('#')[0]) && target)
        scrollToAnchor( target, event );
    }
  });
});

/*----------------------------------------------------
/* Responsive Navigation
/*--------------------------------------------------*/
if (mts_customscript.responsive && mts_customscript.nav_menu != 'none') {
    jQuery(document).ready(function($){
        // merge if two menus exist
        if (mts_customscript.nav_menu == 'both') {
            var menu_wrapper = $('.secondary-navigation')
                .clone().attr('class', 'mobile-menu secondary').wrap('<div id="mobile-menu-wrapper" />')
                .parent().hide()
                .appendTo('body');
            $('.footer-navigation').clone().attr('class', 'mobile-menu footer').appendTo(menu_wrapper).find('.mts-cart').remove();
        } else {
            var menu_wrapper = $('.'+mts_customscript.nav_menu+'-navigation')
                .clone().attr('class', 'mobile-menu ' + mts_customscript.nav_menu)
                .wrap('<div id="mobile-menu-wrapper" />').parent().hide()
                .appendTo('body');
        }
    
        $('.toggle-mobile-menu').click(function(e) {
            e.preventDefault();
            e.stopPropagation();
            $('#mobile-menu-wrapper').show();
            $('body').toggleClass('mobile-menu-active');
        });
        
        // prevent propagation of scroll event to parent
        $(document).on('DOMMouseScroll mousewheel', '#mobile-menu-wrapper', function(ev) {
            var $this = $(this),
                scrollTop = this.scrollTop,
                scrollHeight = this.scrollHeight,
                height = $this.height(),
                delta = (ev.type == 'DOMMouseScroll' ?
                    ev.originalEvent.detail * -40 :
                    ev.originalEvent.wheelDelta),
                up = delta > 0;
        
            var prevent = function() {
                ev.stopPropagation();
                ev.preventDefault();
                ev.returnValue = false;
                return false;
            }
        
            if (!up && -delta > scrollHeight - height - scrollTop) {
                // Scrolling down, but this will take us past the bottom.
                $this.scrollTop(scrollHeight);
                return prevent();
            } else if (up && delta > scrollTop) {
                // Scrolling up, but this will take us past the top.
                $this.scrollTop(0);
                return prevent();
            }
        });
    }).click(function() {
        jQuery('body').removeClass('mobile-menu-active');
    });
}
/*----------------------------------------------------
/*  Dropdown menu
/* ------------------------------------------------- */
jQuery(document).ready(function($) { 
	$('#navigation ul.sub-menu, #navigation ul.children').hide(); // hides the submenus in mobile menu too
	$('#navigation li').hover( 
		function() {
			$(this).children('ul.sub-menu, ul.children').slideDown('fast');
		}, 
		function() {
			$(this).children('ul.sub-menu, ul.children').hide();
		}
	);
});    

/*----------------------------------------------------
/* Social button scripts
/*---------------------------------------------------*/
jQuery(document).ready(function($){
	(function(d, s) {
	  var js, fjs = d.getElementsByTagName(s)[0], load = function(url, id) {
		if (d.getElementById(id)) {return;}
		js = d.createElement(s); js.src = url; js.id = id;
		fjs.parentNode.insertBefore(js, fjs);
	  };
	jQuery('.facebook_like, .fb-comments').exists(function() {
	  load('//connect.facebook.net/en_US/all.js#xfbml=1', 'fbjssdk');
	});
	}(document, 'script'));
});