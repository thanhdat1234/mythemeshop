How to Use the TXT(options_panel_settings_MobileApp.txt) File to Import the Demo Options Panel settings

1. Log into your site as an administrator.
2. Make sure you activated your new theme before proceeding.
3. Go to Appearance → Theme Options → Import Export tab in the bottom left.
4. Choose “Import Code” from the Import Options.
5. You could either use Preset Options and click on the Import button.
Or
5.1. Open the TXT file in your favorite text editor like Notepad, Notepad++ or Sublime.
6. Copy the content inside the TXT file and paste it in the 'Import Code' box in theme's Options Panel.
7. Click on 'Import' button below the pasted code section.
8. Enjoy!