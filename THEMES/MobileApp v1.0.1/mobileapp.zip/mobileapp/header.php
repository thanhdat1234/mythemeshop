<!DOCTYPE html>
<?php $mts_options = get_option('simpleapp'); ?>
<html class="no-js" <?php language_attributes(); ?>>
<head>
	<meta charset="<?php bloginfo('charset'); ?>">
	<!-- Always force latest IE rendering engine (even in intranet) & Chrome Frame -->
	<!--[if IE ]>
	<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
	<![endif]-->
	<link rel="profile" href="http://gmpg.org/xfn/11" />
	<title><?php wp_title( '|', true, 'right' ); ?></title>
	<?php mts_meta(); ?>
	<link rel="pingback" href="<?php bloginfo( 'pingback_url' ); ?>" />
	<?php wp_head(); ?>
</head>
<body id="blog" <?php body_class('main'); ?> itemscope itemtype="http://schema.org/WebPage" style="<?php mts_section_css($mts_options['mts_header_bg_color'], $mts_options['mts_header_bg'], $mts_options['mts_header_bg_fixed']); ?>">
	<div class="main-container">
		<?php if ( $mts_options['mts_youtube_link'] != '' || !empty($mts_options['mts_header_nav_menu']) ) { ?>
		    <div class="header-container active<?php echo !empty($mts_options['mts_header_nav_menu']) ? ' with-nav-menu' : '' ?>">
			    <div class="container">
			    <?php if ( $mts_options['mts_youtube_link'] != '' ) { ?>
				    <div class="video-link">
				        <a title="video" class="popup-youtube" href="<?php if ( $mts_options['mts_youtube_link'] != '' ) { echo $mts_options['mts_youtube_link']; } ?>">
				            <i class="fa fa-play"></i>
				        </a>
				    </div><!--.header-->
			    <?php } ?>
		    	<?php if ( $mts_options['mts_header_nav_menu'] != '' ) { ?>
				    <div class="primary-navigation" role="navigation" itemscope itemtype="http://schema.org/SiteNavigationElement">
						<a href="#" id="pull" class="toggle-mobile-menu"><?php _e('Menu','mythemeshop'); ?></a>
						<nav id="navigation" class="clearfix mobile-menu-wrapper">
							<?php if ( has_nav_menu( 'header-menu' ) ) { ?>
								<?php wp_nav_menu( array( 'theme_location' => 'header-menu', 'menu_class' => 'menu clearfix', 'container' => '', 'walker' => new mts_menu_walker ) ); ?>
							<?php }?>
						</nav>
					</div>
		        <?php } ?>
		    	</div><!--.container-->
		    </div><!--.header-container-->
		<?php } ?>