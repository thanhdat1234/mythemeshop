jQuery.fn.exists = function(callback) {
  var args = [].slice.call(arguments, 1);
  if (this.length) {
    callback.call(this, args);
  }
  return this;
};

/*----------------------------------------------------
/* Show/hide Scroll to top
/*--------------------------------------------------*/
jQuery(document).ready(function($) {
  //move-to-top arrow
  jQuery("body").prepend("<a id='move-to-top' class='animate ' href='#blog'><i class='fa fa-angle-up'></i></a>");
    
  var scrollDes = 'html,body';  
  /*Opera does a strange thing if we use 'html' and 'body' together so my solution is to do the UA sniffing thing*/
  if(navigator.userAgent.match(/opera/i)){
    scrollDes = 'html';
  }
  //show ,hide
  jQuery(window).scroll(function () {
    if (jQuery(this).scrollTop() > 160) {
      jQuery('#move-to-top').addClass('filling').removeClass('hiding');
    } else {
      jQuery('#move-to-top').removeClass('filling').addClass('hiding');
    }
  });
});

jQuery(document).ready(function() {
  jQuery('.popup-youtube').magnificPopup({
    disableOn: 700,
    type: 'iframe',
    mainClass: 'mfp-fade',
    removalDelay: 160,
    preloader: false,
    fixedContentPos: false
  });  
});


/*----------------------------------------------------
/* Make all anchor links smooth scrolling
/*--------------------------------------------------*/
jQuery(document).ready(function($) {
 // scroll handler
  var scrollToAnchor = function( id, event ) {
    // grab the element to scroll to based on the name
    var elem = $("a[name='"+ id +"']");
    // if that didn't work, look for an element with our ID
    if ( typeof( elem.offset() ) === "undefined" ) {
      elem = $("#"+id);
    }
    // if the destination element exists
    if ( typeof( elem.offset() ) !== "undefined" ) {
      // cancel default event propagation
      event.preventDefault();
      var elem_offset = elem.offset().top;
      // do the scroll
      $('html, body').animate({
              scrollTop: elem_offset
      }, 600, 'swing', function() { if (elem_offset != 0) window.location.hash = id; } );
    }
  };
  // bind to click event
  $("a").click(function( event ) {
    // only do this if it's an anchor link
    var href = $(this).attr("href");
    if ( href.match("#") && href !== '#' ) {
      // scroll to the location
      var parts = href.split('#'),
        url = parts[0],
        target = parts[1];
      if ((!url || url == window.location.href.split('#')[0]) && target)
        scrollToAnchor( target, event );
    }
  });
});

/*----------------------------------------------------
/* Responsive Navigation
/*--------------------------------------------------*/
    jQuery(document).ready(function($){
    
        $('.toggle-mobile-menu').click(function(e) {
            e.preventDefault();
            e.stopPropagation();
            $('body').toggleClass('mobile-menu-active');
        });
        
        // prevent propagation of scroll event to parent
        $(document).on('DOMMouseScroll mousewheel', '.mobile-menu-wrapper', function(ev) {
            var $this = $(this),
                scrollTop = this.scrollTop,
                scrollHeight = this.scrollHeight,
                height = $this.height(),
                delta = (ev.type == 'DOMMouseScroll' ?
                    ev.originalEvent.detail * -40 :
                    ev.originalEvent.wheelDelta),
                up = delta > 0;
        
            var prevent = function() {
                ev.stopPropagation();
                ev.preventDefault();
                ev.returnValue = false;
                return false;
            }

            if ( $('a#pull').css('display') !== 'none' ) { // if toggle menu button is visible ( small screens )
        
              if (!up && -delta > scrollHeight - height - scrollTop) {
                  // Scrolling down, but this will take us past the bottom.
                  $this.scrollTop(scrollHeight);
                  return prevent();
              } else if (up && delta > scrollTop) {
                  // Scrolling up, but this will take us past the top.
                  $this.scrollTop(0);
                  return prevent();
              }
            }
        });
    }).click(function() {
        jQuery('body').removeClass('mobile-menu-active');
    });

/*----------------------------------------------------
/*  Dropdown menu
/* ------------------------------------------------- */
jQuery(document).ready(function($) { 
  $('#navigation ul.sub-menu, #navigation ul.children').hide(); // hides the submenus in mobile menu too
  $('#navigation li').hover( 
    function() {
      $(this).children('ul.sub-menu, ul.children').slideDown('fast');
    }, 
    function() {
      $(this).children('ul.sub-menu, ul.children').hide();
    }
  );
});

/*----------------------------------------------------
/* Crossbrowser input placeholder fix
/*---------------------------------------------------*/
jQuery(document).ready(function($){
    $(function() {
        $('[placeholder]').focus(function() {
            var input = $(this);
            if (input.val() == input.attr('placeholder')) {
                input.val('');
                input.removeClass('placeholder');
            }
        }).blur(function() {
            var input = $(this);
            if (input.val() == '' || input.val() == input.attr('placeholder')) {
                input.addClass('placeholder');
                input.val(input.attr('placeholder'));
            }
        }).blur();
        $('[placeholder]').parents('form').submit(function() {
            $(this).find('[placeholder]').each(function() {
                var input = $(this);
                if (input.val() == input.attr('placeholder')) {
                    input.val('');
                }
            })
        });
    });
});

jQuery(window).load(function() {
  // YouTube header show/hide
  if (jQuery('.header-container').length) {
    var header_visible = true;

    var scrollshow_treshold = 10, // px to scroll up to show header
        scrollhide_treshold = 50, // px to scroll down to hide header
        always_show_above = 400;   // header won't be hidden above this point

    var scrollval = 0;
    var scrolled_up = 0;
    var scrolled_down = 0;
    jQuery(window).scroll(function(e) {
        var scrolltop = jQuery(this).scrollTop();
        if (scrolltop > scrollval && header_visible && scrolltop > always_show_above) {
          // down
          if (scrolled_down == 0) {
            scrolled_down = scrolltop;
            scrolled_up = 0;
          } else {
            if (scrolltop > scrolled_down + scrollhide_treshold && header_visible) {
              jQuery('.header-container').removeClass('active'); 
              header_visible = false;
              scrolled_up = 0;
              scrolled_down = 0;
            }
          }
        }
        if (scrolltop < scrollval || scrolltop <= 0) {
          // up
          if (scrolled_up == 0) {
            scrolled_up = scrolltop;
            scrolled_down = 0;
          } else {
            if (scrolltop <= Math.max(always_show_above, scrolled_up - scrollshow_treshold) && !header_visible) {
              jQuery('.header-container').addClass('active');
              header_visible = true;
              scrolled_up = 0;
              scrolled_down = 0;
            }
          }
        }
        scrollval = scrolltop;
    });
    jQuery('.header-container').mouseenter(function(event) {
      jQuery(this).addClass('active'); header_visible = true;
    });
  }

});

jQuery(document).ready(function($) {
    var skrollrInstance = null;
    var $mobile_container = $('.mobile-container');
    var is_mobile = !!(/Android|iPhone|iPad|iPod|BlackBerry/i).test(navigator.userAgent || navigator.vendor || window.opera);
    var bottom_reached = false;
    var skrollrOptions = {
      forceHeight: false,
      render: function(data) {
        var wh = $(window).height();
        
        if (data.curTop + wh >= data.maxTop && !bottom_reached) {
          $mobile_container.appendTo('.main-content');
          bottom_reached = true;
        } else if (data.curTop + wh < data.maxTop && bottom_reached) {
          $mobile_container.insertAfter('#skrollr-body');
          bottom_reached = false;
        }
        
      }
    };
    var breakpoint = 767;

    $('.container1_first, .container2_first').css('min-height', $(window).height());
    // initialize skrollr if the window width is large enough
    if ($(window).width() > breakpoint) {
        skrollrInstance = skrollr.init(skrollrOptions);
    }

    // disable skrollr if the window is resized below 768px wide
    $(window).on('resize', function () {
        if ($(window).width() <= breakpoint) {
            if (skrollrInstance) {
                skrollrInstance.destroy();
                skrollrInstance = null;
            }
        } else {
      $('.container1_first, .container2_first').css('min-height', $(window).height());
            if (!skrollrInstance) {
                skrollrInstance = skrollr.init(skrollrOptions);
            }
        }
    });
});