jQuery(document).ready(function($) {
    $('#mtscontact_form').submit(function(e) {
        e.preventDefault();
        var $form = $(this);
        $form.addClass('loading');
        $.post(mtscontact.ajaxurl, $form.serialize(), function(data) {
            $form.removeClass('loading');
            if (data == 'success') {
                $form.remove();
                $('#mtscontact_success').show();
            } else {
                $('.mtscontact_error').remove();
                $.each(data, function(i, v) {
                    if ($('#mtscontact_'+i).length) {
                        $('#mtscontact_form').before('<div class="mtscontact_error"><i class="fa fa-warning"></i> '+v+'</div>');
                    } else {
                        $form.prepend('<div class="mtscontact_error"><i class="fa fa-warning"></i> '+v+'</div>');
                    }
                });
            }
        }, 'json');
    });
});