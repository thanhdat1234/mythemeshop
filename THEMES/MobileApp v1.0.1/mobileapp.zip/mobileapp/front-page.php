<?php
/*
	Template Name: Homepage
*/
$mts_options = get_option('simpleapp');

$mockups = array(
	'i-phone-black.png',
	'i-phone-gold.png',
	'nokia-lumia-625-black.png',
	'nokia-lumia-625-white.png',
	'samsung-black.png',
	'samsung-gold.png'
);
$mockups_responsive = array(
	'mobile-i-phone-black.png',
	'mobile-i-phone-gold.png',
	'mobile-nokia-lumia-625-black.png',
	'mobile-nokia-lumia-625-white.png',
	'mobile-samsung-s5-black.png',
	'mobile-samsung-s5-gold.png'
);
$classes = array(
	'iphone6 iphoneblack',
	'iphone6 iphonegold',
	'nokialumia625 lumiablack',
	'nokialumia625 lumiawhite',
	'galaxys5 galaxyblack',
	'galaxys5 galaxygold'
);
$mobile = isset($mts_options['mts_mobile']) ? (int) $mts_options['mts_mobile'] : 0;

get_header(); ?>
<div id="skrollr-body">
<div class="main-content">
<div class="container1_first">
    <div class="container clearfix">
        <div class="container2_left">
        	<div class="main-section">
        		<?php if ($mts_options['mts_logo'] != '') { ?>
        			<h1 id="logo" class="image-logo" itemprop="headline">
						<a href="<?php echo home_url(); ?>"><img src="<?php echo $mts_options['mts_logo']; ?>" alt="<?php bloginfo( 'name' ); ?>"></a>
					</h1><!-- END #logo -->
				<?php } else { ?>
		        	<?php if ( $mts_options['mts_header_title'] != '' ) { ?>
			            <h1 id="logo" class="text-logo">
			                <a href="<?php echo home_url(); ?>" <?php if( $mts_options['mts_dark_header'] != '0' ) { ?>style="color:#000; ?>"<?php } ?>><?php echo $mts_options[ 'mts_header_title']; ?></a>
			            </h1>
		            <?php } ?>
		        <?php } ?>
	            <?php if ( $mts_options['mts_header_desc'] != '' ) { ?>
		            <p class="tagline" <?php if( $mts_options['mts_dark_header'] != '0' ) { ?>style="color:#000; ?>"<?php } ?>>
		                <?php echo $mts_options[ 'mts_header_desc']; ?>
		            </p>
	            <?php } ?>

	            <?php if (!empty($mts_options['mts_intro_button'])) { ?>
	            	<div class="container2_button">
						<?php $toEnd = count($mts_options['mts_intro_button']);
						foreach ( $mts_options['mts_intro_button'] as $button => $value ) {
							$value['mts_intro_button_label'] = str_replace("\n\r", "\n", $value['mts_intro_button_label']);
							$btn_texts  = explode("\n", $value['mts_intro_button_label']);
							$label      = !empty($btn_texts[0]) ? $btn_texts[0] : '';
							$boldText   = !empty($btn_texts[1]) ? $btn_texts[1] : '';
							$button_url = "#";
							if ( !empty($value['mts_intro_button_url']) ) {
								$button_url = $value['mts_intro_button_url'];
							} ?>
				            <div class="container2_btn1<?php if (0 === --$toEnd) { echo " last"; } ?>">
				            	<?php $button_color = adjustBrightness($value['mts_button_color'],-50); ?>
								<div id="btn1_btn1" <?php if( $value['mts_button_color'] ) { ?>style="background: <?php echo $value['mts_button_color']; ?>; border-color: <?php echo $button_color; ?>;"<?php } ?>>
									<div class="intro-section-buttons-container">
										<a href="<?php echo $button_url; ?>" class="intro-section-buttons" <?php if( $value['mts_button_text_color'] ) { ?>style="color: <?php echo $value['mts_button_text_color']; ?>"<?php } ?>>
											<i class="fa fa-<?php echo $value['mts_intro_button_icon_select']; ?>" <?php if( $value['mts_button_text_color'] ) { ?>style="color: <?php echo $value['mts_button_text_color']; ?>"<?php } ?>></i>
											<?php if (empty($boldText)) { ?>
												<div class="button-bold-text button-bold-text-extra-padding"><?php } else { ?><div class="button-bold-text"><?php } ?><?php echo $label; ?></div><?php if (!empty($boldText)) { ?><div class="button-label"><?php echo $boldText; ?></div>
											<?php } ?>
										</a>
									</div>
								</div>
							</div>
						<?php } ?>
						<div class="responsive-screenshot <?php echo $classes[$mobile]; ?>" style="background-image: url(<?php echo get_template_directory_uri().'/images/'.$mockups_responsive[$mobile]; ?>);"><img src="<?php echo $mts_options['mts_first_screenshot']; ?>"></div>
					</div>
				<?php } ?>
			</div><!--.main-section-->
	    </div><!--.container2_left-->
	</div><!--.container-->  
</div><!--.container1_first-->

<?php
	
	$screenshots_animate_out = false; // setting to true will cause screenshots to animate out before next screenshot comes
	$texts_animate_out = false; // same for texts

	if (!empty($mts_options[ 'mts_home_section'])) {
    	$c = count($mts_options['mts_home_section'])-1;
		foreach ($mts_options[ 'mts_home_section'] as $index => $section) {
			$section_bg_color = $section['mts_section_bg_color'];
			$section_bg = $section['mts_section_bg'];
			$section_bg_fixed = !empty($section['mts_section_bg_fixed']);
			$section_title = $section['mts_section_title'];
			$section_desc = $section['mts_section_desc'];
			$section_image = $section['mts_section_image'];

			$last = ($c == $index);
			$effect_steps = array();
			if (empty($section['mts_section_text_effect'])) $section['mts_section_text_effect'] = 0;
			switch ($section['mts_section_text_effect']) {
				case 0: // none
				default:
					$effect_steps[] = '';
					$effect_steps[] = '';
					$effect_steps[] = '';
					$effect_steps[] = '';
				break;

				case 1: // from top
					$effect_steps[] = 'transform:translate(0px,-100px); opacity:0;';
					$effect_steps[] = 'transform:translate(0px,0px); opacity:1;';
					$effect_steps[] = 'transform:translate(0px,0px); opacity:1;';
					$effect_steps[] = 'transform:translate(0,100px); opacity:0;';
				break;

				case 2: // from right
					$effect_steps[] = 'transform:translate(200px,0px); opacity:0;';
					$effect_steps[] = 'transform:translate(0px,0px); opacity:1;';
					$effect_steps[] = 'transform:translate(0px,0px); opacity:1;';
					$effect_steps[] = 'transform:translate(-200px,0px); opacity:0;';
				break;

				case 3: // from bottom
					$effect_steps[] = 'transform:translate(0px,250px); opacity:0;';
					$effect_steps[] = 'transform:translate(0px,0px); opacity:1;';
					$effect_steps[] = 'transform:translate(0px,0px); opacity:1;';
					$effect_steps[] = 'transform:translate(0px,-250px); opacity:0;';
				break;

				case 4: // from left
					$effect_steps[] = 'transform:translate(-200px,0px); opacity:0;';
					$effect_steps[] = 'transform:translate(0px,0px); opacity:1;';
					$effect_steps[] = 'transform:translate(0px,0px); opacity:1;';
					$effect_steps[] = 'transform:translate(200px,0px); opacity:0;';
				break;

				case 5:  // fade
					$effect_steps[] = 'opacity:0;';
					$effect_steps[] = 'opacity:1;';
					$effect_steps[] = 'opacity:1;';
					$effect_steps[] = 'opacity:0;';
				break;

				case 6:  // zoom
					$effect_steps[] = 'transform:scale(0); opacity:0;';
					$effect_steps[] = 'transform:scale(1); opacity:1;';
					$effect_steps[] = 'transform:scale(1); opacity:1;';
					$effect_steps[] = 'transform:scale(0); opacity:0;';
				break;
			}
			
			$keyframes = array('bottom-top', '100-center-center');
			if ($texts_animate_out) {
				$keyframes[] = '-100-center-center';
				$keyframes[] = 'top-bottom';
			}
			$target = '#info-section-'.$index;
			?>
			<div class="container2_first" id="info-section-<?php echo $index; ?>" style="<?php mts_section_css($section_bg_color, $section_bg, $section_bg_fixed); ?>">
			    <div class="container clearfix">
			        <div class="container2_left">
			        	<?php if( !empty($section_title) ) { ?>
				            <h2 class="p1" <?php foreach ($keyframes as $i => $scrollval) {
    					if ($last && $i == 3) $effect_steps[$i] = 'transform:translate(0%,0%);opacity:1;'; // don't animate out last one
    					echo 'data-'.$scrollval.'="'.$effect_steps[$i].'" ';
    				}
    				//echo 'data-anchor-target="'.$target.'"';
    				?> <?php if( $section['mts_text_color_section'] != '0' ) { ?>style="color:#000;"<?php } ?>>
				                <?php echo $section_title; ?>
				            </h2>
			            <?php } ?>
			            <?php if( !empty($section_desc) ) { ?>
				            <p class="p2" <?php foreach ($keyframes as $i => $scrollval) {
    					if ($last && $i == 3) $effect_steps[$i] = 'transform:translate(0%,0%);opacity:1;'; // don't animate out last one
    					echo 'data-'.$scrollval.'="'.$effect_steps[$i].'" ';
    				}
    				//echo 'data-anchor-target="'.$target.'"';
    				?> <?php if( $section['mts_text_color_section'] != '0' ) { ?>style="color:#000;"<?php } ?>>
				                <?php echo $section_desc; ?>
				            </p>
			            <?php } ?>
			            <div class="responsive-screenshot <?php echo $classes[$mobile]; ?>" style="background-image: url(<?php echo get_template_directory_uri().'/images/'.$mockups_responsive[$mobile]; ?>);"><img src="<?php echo $section_image; ?>"></div>
			        </div>
			    </div>
			</div>
		<?php }
	}
?>

    	
    </div><!-- .main-content -->
<div class="contact-overlay clearfix"  style="<?php mts_section_css($mts_options['mts_contact_bg_color'], $mts_options['mts_contact_bg'], $mts_options['mts_contact_bg_fixed']); ?>">
    <div class="contact-bg">
    	<?php if (!empty($mts_options['mts_contact_section'])) { ?>
        <div class="container">
	        <div class="contact clearfix">
	        	<?php if ( $mts_options['mts_contact_title'] != '' ) { ?>
	        	
	            	<div class="contact-title" <?php if( $mts_options['mts_dark_contact'] != '0' ) { ?>style="color:#000; ?>"<?php } ?>>
                        <?php echo $mts_options['mts_contact_title'];?>
                    </div>

	            <?php } ?>

	            <div class="contact-box">
	            	<?php mts_contact_form(); ?>
	            </div>
	        </div><!--.contact-->
        </div><!--.container-->
        <?php } ?>

		<div class="overlay_CR">
			<div class="container">
				<?php if ( !empty($mts_options['mts_footer_social']) && is_array($mts_options['mts_footer_social'])) { ?>
					<div class="footer-social">
				        <?php foreach( $mts_options['mts_footer_social'] as $footer_icons ) : ?>
				            <?php if( ! empty( $footer_icons['mts_footer_icon'] ) && isset( $footer_icons['mts_footer_icon'] ) ) : ?>
				                <a href="<?php print $footer_icons['mts_footer_icon_link'] ?>" class="footer-<?php print $footer_icons['mts_footer_icon'] ?>"><span class="fa fa-<?php print $footer_icons['mts_footer_icon'] ?>"></span></a>
				            <?php endif; ?>
				        <?php endforeach; ?>
				    </div>
				<?php } ?>
				<p class="CR_1"><?php mts_copyrights_credit(); ?></p>
				<?php if ( $mts_options['mts_footer_email'] ) { ?><p class="CR_2"><a href="mailto:<?php echo $mts_options['mts_footer_email']; ?>"><i class="fa fa-envelope-o"></i><?php echo $mts_options['mts_footer_email']; ?></a></p><?php } ?>
			</div>
		</div> <!--.overlay_CR-->
    </div><!--.contact-bg-->
</div><!--.contact-overlay-->
</div><!-- #skrollr-body -->
<div class="mobile-container <?php echo $classes[$mobile]; ?>" data-0="position:fixed;" data-bottom-bottom="position:absolute;" data-anchor-target=".main-content">
	<div class="mobile-hand">
		<img src="<?php echo get_template_directory_uri(); ?>/images/<?php echo $mockups[$mobile]; ?>" />
	</div>
	<div class="mobile-screen-viewport">
		<div class="screenshot first">
			<img src="<?php echo $mts_options['mts_first_screenshot']; ?>" <?php if ($screenshots_animate_out) : ?>data-100="transform: translate(0%,0%);" data-bottom-bottom="transform: translate(0%,-100%);" data-anchor-target=".container1_first"<?php endif; ?>>
		</div>
		<?php 
		$c = count($mts_options['mts_home_section'])-1;
		foreach ($mts_options['mts_home_section'] as $index => $screenshot) {
			$last = ($c == $index);
			$effect_steps = array();
			if (empty($screenshot['mts_section_effect'])) $screenshot['mts_section_effect'] = 0;
			switch ($screenshot['mts_section_effect']) {
				case 0: // from top
				default:
					$effect_steps[] = 'transform:translate(0%,-100%);';
					$effect_steps[] = 'transform:translate(0%,0%);';
					$effect_steps[] = 'transform:translate(0%,0%);';
					$effect_steps[] = 'transform:translate(0,100%);';
				break;

				case 1: // from right
					$effect_steps[] = 'transform:translate(100%,0%);';
					$effect_steps[] = 'transform:translate(0%,0%);';
					$effect_steps[] = 'transform:translate(0%,0%);';
					$effect_steps[] = 'transform:translate(-100%,0%);';
				break;

				case 2: // from bottom
					$effect_steps[] = 'transform:translate(0%,100%);';
					$effect_steps[] = 'transform:translate(0%,0%);';
					$effect_steps[] = 'transform:translate(0%,0%);';
					$effect_steps[] = 'transform:translate(0%,-100%);';
				break;

				case 3: // from left
					$effect_steps[] = 'transform:translate(-100%,0%);';
					$effect_steps[] = 'transform:translate(0%,0%);';
					$effect_steps[] = 'transform:translate(0%,0%);';
					$effect_steps[] = 'transform:translate(100%,0%);';
				break;

				case 4:  // fade
					$effect_steps[] = 'opacity:0;';
					$effect_steps[] = 'opacity:1;';
					$effect_steps[] = 'opacity:1;';
					$effect_steps[] = 'opacity:0;';
				break;
			}
			
			$keyframes = array('-100-bottom-top', '100-top-top');
			if ($screenshots_animate_out) {
				$keyframes[] = '-100-top-top';
				$keyframes[] = 'top-bottom';
			}
			$target = '#info-section-'.$index;
			
			?>
			<div class="screenshot" <?php foreach ($keyframes as $i => $scrollval) {
				if ($last && $i == 3) $effect_steps[$i] = 'transform:translate(0%,0%);opacity:1;'; // don't animate out last one
				echo 'data-'.$scrollval.'="'.$effect_steps[$i].'" ';
			}
			echo 'data-anchor-target="'.$target.'"';
			?>><img src="<?php echo $screenshot['mts_section_image']; ?>"></div>
		<?php } ?>
	</div>
</div>
</div><!--.main-container-->
<?php mts_footer(); ?>
<?php wp_footer(); ?>
</body>
</html>