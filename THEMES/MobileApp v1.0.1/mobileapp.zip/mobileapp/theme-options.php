<?php

defined('ABSPATH') or die;

/*
 * 
 * Require the framework class before doing anything else, so we can use the defined urls and dirs
 *
 */
require_once( dirname( __FILE__ ) . '/options/options.php' );
/*
 * 
 * Custom function for filtering the sections array given by theme, good for child themes to override or add to the sections.
 * Simply include this function in the child themes functions.php file.
 *
 * NOTE: the defined constansts for urls, and dir will NOT be available at this point in a child theme, so you must use
 * get_template_directory_uri() if you want to use any of the built in icons
 *
 */
function add_another_section($sections){
	
	//$sections = array();
	$sections[] = array(
				'title' => __('A Section added by hook', 'mythemeshop'),
				'desc' => __('<p class="description">This is a section created by adding a filter to the sections array, great to allow child themes, to add/remove sections from the options.</p>', 'mythemeshop'),
				//all the glyphicons are included in the options folder, so you can hook into them, or link to your own custom ones.
				//You dont have to though, leave it blank for default.
				'icon' => trailingslashit(get_template_directory_uri()).'options/img/glyphicons/glyphicons_062_attach.png',
				//Lets leave this as a blank section, no options just some intro text set above.
				'fields' => array()
				);
	
	return $sections;
	
}//function
//add_filter('nhp-opts-sections-twenty_eleven', 'add_another_section');


/*
 * 
 * Custom function for filtering the args array given by theme, good for child themes to override or add to the args array.
 *
 */
function change_framework_args($args){
	
	//$args['dev_mode'] = false;
	
	return $args;
	
}//function
//add_filter('nhp-opts-args-twenty_eleven', 'change_framework_args');

/*
 * This is the meat of creating the optons page
 *
 * Override some of the default values, uncomment the args and change the values
 * - no $args are required, but there there to be over ridden if needed.
 *
 *
 */

function setup_framework_options(){
$args = array();

//Set it to dev mode to view the class settings/info in the form - default is false
$args['dev_mode'] = false;
//Remove the default stylesheet? make sure you enqueue another one all the page will look whack!
//$args['stylesheet_override'] = true;

//Add HTML before the form
//$args['intro_text'] = __('<p>This is the HTML which can be displayed before the form, it isnt required, but more info is always better. Anything goes in terms of markup here, any HTML.</p>', 'mythemeshop');

//Setup custom links in the footer for share icons
$args['share_icons']['twitter'] = array(
										'link' => 'http://twitter.com/mythemeshopteam',
										'title' => 'Follow Us on Twitter', 
										'img' => 'fa fa-twitter-square'
										);
$args['share_icons']['facebook'] = array(
										'link' => 'http://www.facebook.com/mythemeshop',
										'title' => 'Like us on Facebook', 
										'img' => 'fa fa-facebook-square'
										);

//Choose to disable the import/export feature
//$args['show_import_export'] = false;

//Choose a custom option name for your theme options, the default is the theme name in lowercase with spaces replaced by underscores
$args['opt_name'] = "simpleapp";

//Custom menu icon
//$args['menu_icon'] = '';

//Custom menu title for options page - default is "Options"
$args['menu_title'] = __('Theme Options', 'mythemeshop');

//Custom Page Title for options page - default is "Options"
$args['page_title'] = __('Theme Options', 'mythemeshop');

//Custom page slug for options page (wp-admin/themes.php?page=***) - default is "nhp_theme_options"
$args['page_slug'] = 'theme_options';

//Custom page capability - default is set to "manage_options"
//$args['page_cap'] = 'manage_options';

//page type - "menu" (adds a top menu section) or "submenu" (adds a submenu) - default is set to "menu"
//$args['page_type'] = 'submenu';

//parent menu - default is set to "themes.php" (Appearance)
//the list of available parent menus is available here: http://codex.wordpress.org/Function_Reference/add_submenu_page#Parameters
//$args['page_parent'] = 'themes.php';

//custom page location - default 100 - must be unique or will override other items
$args['page_position'] = 62;

//Custom page icon class (used to override the page icon next to heading)
//$args['page_icon'] = 'icon-themes';
		
//Set ANY custom page help tabs - displayed using the new help tab API, show in order of definition		
$args['help_tabs'][] = array(
							'id' => 'nhp-opts-1',
							'title' => __('Support', 'mythemeshop'),
							'content' => __('<p>If you are facing any problem with our theme or theme option panel, head over to our <a href="http://mythemeshop.com/support">Knowledge Base</a></p>', 'mythemeshop')
							);
$args['help_tabs'][] = array(
							'id' => 'nhp-opts-3',
							'title' => __('Credit', 'mythemeshop'),
							'content' => __('<p>Options Panel created using the <a href="http://leemason.github.com/NHP-Theme-Options-Framework/" target="_blank">NHP Theme Options Framework</a> Version 1.0.5</p>', 'mythemeshop')
							);
$args['help_tabs'][] = array(
							'id' => 'nhp-opts-2',
							'title' => __('Earn Money', 'mythemeshop'),
							'content' => __('<p>Earn 70% commision on every sale by refering your friends and readers. Join our <a href="http://mythemeshop.com/affiliate-program/">Affiliate Program</a>.</p>', 'mythemeshop')
							);

//Set the Help Sidebar for the options page - no sidebar by default										
//$args['help_sidebar'] = __('<p>This is the sidebar content, HTML is allowed.</p>', 'mythemeshop');

$mts_patterns = array(
	'nobg' => array('img' => NHP_OPTIONS_URL.'img/patterns/nobg.png'),
	'pattern0' => array('img' => NHP_OPTIONS_URL.'img/patterns/pattern0.png'),
	'pattern1' => array('img' => NHP_OPTIONS_URL.'img/patterns/pattern1.png'),
	'pattern2' => array('img' => NHP_OPTIONS_URL.'img/patterns/pattern2.png'),
	'pattern3' => array('img' => NHP_OPTIONS_URL.'img/patterns/pattern3.png'),
	'pattern4' => array('img' => NHP_OPTIONS_URL.'img/patterns/pattern4.png'),
	'pattern5' => array('img' => NHP_OPTIONS_URL.'img/patterns/pattern5.png'),
	'pattern6' => array('img' => NHP_OPTIONS_URL.'img/patterns/pattern6.png'),
	'pattern7' => array('img' => NHP_OPTIONS_URL.'img/patterns/pattern7.png'),
	'pattern8' => array('img' => NHP_OPTIONS_URL.'img/patterns/pattern8.png'),
	'pattern9' => array('img' => NHP_OPTIONS_URL.'img/patterns/pattern9.png'),
	'pattern10' => array('img' => NHP_OPTIONS_URL.'img/patterns/pattern10.png'),
	'pattern11' => array('img' => NHP_OPTIONS_URL.'img/patterns/pattern11.png'),
	'pattern12' => array('img' => NHP_OPTIONS_URL.'img/patterns/pattern12.png'),
	'pattern13' => array('img' => NHP_OPTIONS_URL.'img/patterns/pattern13.png'),
	'pattern14' => array('img' => NHP_OPTIONS_URL.'img/patterns/pattern14.png'),
	'pattern15' => array('img' => NHP_OPTIONS_URL.'img/patterns/pattern15.png'),
	'pattern16' => array('img' => NHP_OPTIONS_URL.'img/patterns/pattern16.png'),
	'pattern17' => array('img' => NHP_OPTIONS_URL.'img/patterns/pattern17.png'),
	'pattern18' => array('img' => NHP_OPTIONS_URL.'img/patterns/pattern18.png'),
	'pattern19' => array('img' => NHP_OPTIONS_URL.'img/patterns/pattern19.png'),
	'pattern20' => array('img' => NHP_OPTIONS_URL.'img/patterns/pattern20.png'),
	'pattern21' => array('img' => NHP_OPTIONS_URL.'img/patterns/pattern21.png'),
	'pattern22' => array('img' => NHP_OPTIONS_URL.'img/patterns/pattern22.png'),
	'pattern23' => array('img' => NHP_OPTIONS_URL.'img/patterns/pattern23.png'),
	'pattern24' => array('img' => NHP_OPTIONS_URL.'img/patterns/pattern24.png'),
	'pattern25' => array('img' => NHP_OPTIONS_URL.'img/patterns/pattern25.png'),
	'pattern26' => array('img' => NHP_OPTIONS_URL.'img/patterns/pattern26.png'),
	'pattern27' => array('img' => NHP_OPTIONS_URL.'img/patterns/pattern27.png'),
	'pattern28' => array('img' => NHP_OPTIONS_URL.'img/patterns/pattern28.png'),
	'pattern29' => array('img' => NHP_OPTIONS_URL.'img/patterns/pattern29.png'),
	'pattern30' => array('img' => NHP_OPTIONS_URL.'img/patterns/pattern30.png'),
	'pattern31' => array('img' => NHP_OPTIONS_URL.'img/patterns/pattern31.png'),
	'pattern32' => array('img' => NHP_OPTIONS_URL.'img/patterns/pattern32.png'),
	'pattern33' => array('img' => NHP_OPTIONS_URL.'img/patterns/pattern33.png'),
	'pattern34' => array('img' => NHP_OPTIONS_URL.'img/patterns/pattern34.png'),
	'pattern35' => array('img' => NHP_OPTIONS_URL.'img/patterns/pattern35.png'),
	'pattern36' => array('img' => NHP_OPTIONS_URL.'img/patterns/pattern36.png'),
	'pattern37' => array('img' => NHP_OPTIONS_URL.'img/patterns/pattern37.png'),
	'hbg' => array('img' => NHP_OPTIONS_URL.'img/patterns/hbg.png'),
	'hbg2' => array('img' => NHP_OPTIONS_URL.'img/patterns/hbg2.png'),
	'hbg3' => array('img' => NHP_OPTIONS_URL.'img/patterns/hbg3.png'),
	'hbg4' => array('img' => NHP_OPTIONS_URL.'img/patterns/hbg4.png'),
	'hbg5' => array('img' => NHP_OPTIONS_URL.'img/patterns/hbg5.png'),
	'hbg6' => array('img' => NHP_OPTIONS_URL.'img/patterns/hbg6.png'),
	'hbg7' => array('img' => NHP_OPTIONS_URL.'img/patterns/hbg7.png'),
	'hbg8' => array('img' => NHP_OPTIONS_URL.'img/patterns/hbg8.png'),
	'hbg9' => array('img' => NHP_OPTIONS_URL.'img/patterns/hbg9.png'),
	'hbg10' => array('img' => NHP_OPTIONS_URL.'img/patterns/hbg10.png'),
	'hbg11' => array('img' => NHP_OPTIONS_URL.'img/patterns/hbg11.png'),
	'hbg12' => array('img' => NHP_OPTIONS_URL.'img/patterns/hbg12.png'),
	'hbg13' => array('img' => NHP_OPTIONS_URL.'img/patterns/hbg13.png'),
	'hbg14' => array('img' => NHP_OPTIONS_URL.'img/patterns/hbg14.png'),
	'hbg15' => array('img' => NHP_OPTIONS_URL.'img/patterns/hbg15.png'),
	'hbg16' => array('img' => NHP_OPTIONS_URL.'img/patterns/hbg16.png'),
	'hbg17' => array('img' => NHP_OPTIONS_URL.'img/patterns/hbg17.png'),
	'hbg18' => array('img' => NHP_OPTIONS_URL.'img/patterns/hbg18.png'),
	'hbg19' => array('img' => NHP_OPTIONS_URL.'img/patterns/hbg19.png'),
	'hbg20' => array('img' => NHP_OPTIONS_URL.'img/patterns/hbg20.png'),
	'hbg21' => array('img' => NHP_OPTIONS_URL.'img/patterns/hbg21.png'),
	'hbg22' => array('img' => NHP_OPTIONS_URL.'img/patterns/hbg22.png'),
	'hbg23' => array('img' => NHP_OPTIONS_URL.'img/patterns/hbg23.png'),
	'hbg24' => array('img' => NHP_OPTIONS_URL.'img/patterns/hbg24.png'),
	'hbg25' => array('img' => NHP_OPTIONS_URL.'img/patterns/hbg25.png')
);

$sections = array();

$sections[] = array(
				'icon' => 'fa fa-cogs',
				'title' => __('General Settings', 'mythemeshop'),
				'desc' => __('<p class="description">This tab contains common setting options which will be applied to the whole theme.</p>', 'mythemeshop'),
				'fields' => array(
					array(
						'id' => 'mts_logo',
						'type' => 'upload',
						'title' => __('Logo Image', 'mythemeshop'), 
						'sub_desc' => __('Upload your logo using the Upload Button or insert image URL.', 'mythemeshop')
						),
					array(
						'id' => 'mts_favicon',
						'type' => 'upload',
						'title' => __('Favicon', 'mythemeshop'), 
						'sub_desc' => __('Upload a <strong>16 x 16 px</strong> image that will represent your website\'s favicon. You can refer to this link for more information on how to make it: <a href="http://www.favicon.cc/" target="blank" rel="nofollow">http://www.favicon.cc/</a>', 'mythemeshop')
						),
					array(
						'id' => 'mts_header_code',
						'type' => 'textarea',
						'title' => __('Header Code', 'mythemeshop'), 
						'sub_desc' => __('Enter the code which you need to place <strong>before closing </head> tag</strong>. (ex: Google Webmaster Tools verification, Bing Webmaster Center, BuySellAds Script, Alexa verification etc.)', 'mythemeshop')
						),
					array(
						'id' => 'mts_analytics_code',
						'type' => 'textarea',
						'title' => __('Footer Code', 'mythemeshop'), 
						'sub_desc' => __('Enter the codes which you need to place in your footer. <strong>(ex: Google Analytics, Clicky, STATCOUNTER, Woopra, Histats, etc.)</strong>.', 'mythemeshop')
						),
					array(
						'id' => 'mts_copyrights',
						'type' => 'textarea',
						'title' => __('Copyrights Text', 'mythemeshop'), 
						'sub_desc' => __('You can change or remove our link from footer and use your own custom text. (Link back is always appreciated)', 'mythemeshop'),
						'std' => 'Theme by <a href="http://mythemeshop.com/">MyThemeShop</a>'
						),
					array(
						'id' => 'mts_footer_email',
						'type' => 'textarea',
						'title' => __('Footer Email ID', 'mythemeshop'), 
						'sub_desc' => __('You can change or remove email ID for footer here.', 'mythemeshop'),
						'std' => ''
						),
					array(
						'id' => 'mts_header_nav_menu',
						'type' => 'button_set',
						'title' => __('Header Nav Menu', 'mythemeshop'),
						'options' => array('0' => 'Off','1' => 'On'),
						'sub_desc' => __('Add a navigation menu in the header area.', 'mythemeshop'),
						'std' => '0'
						),
					array(
						'id' => 'mts_redirect',
						'type' => 'button_set',
						'title' => __('Redirect all pages', 'mythemeshop'), 
						'options' => array('0' => 'Off','1' => 'On'),
						'sub_desc' => __('Enable this option to redirect all URLs to homepage.', 'mythemeshop'),
						'std' => '1'
						),
					)
				);
$sections[] = array(
				'icon' => 'fa fa-adjust',
				'title' => __('Styling Options', 'mythemeshop'),
				'desc' => __('<p class="description">Control the visual appearance of your theme, such as colors, layout and patterns, from here.</p>', 'mythemeshop'),
				'fields' => array(
					array(
						'id' => 'mts_color_scheme',
						'type' => 'color',
						'title' => __('Color Scheme', 'mythemeshop'), 
						'sub_desc' => __('The theme comes with unlimited color schemes for your theme\'s styling.', 'mythemeshop'),
						'std' => '#ffffff'
						),
					array(
						'id' => 'mts_custom_css',
						'type' => 'textarea',
						'title' => __('Custom CSS', 'mythemeshop'), 
						'sub_desc' => __('You can enter custom CSS code here to further customize your theme. This will override the default CSS used on your site.', 'mythemeshop')
						),
                    array(
                        'id' => 'mts_mobile',
						'type' => 'radio',
						'title' => __('Mobile model', 'mythemeshop'),
						'sub_desc' => '<p>'.__('Recommended screenshot sizes:', 'mythemeshop').'</p>'.
                    		'<ul>'.
                    			'<li>'.'iPhone 6: <span>210x371</span>'.'</li>'.
                    			'<li>'.'Nokia Lumia 625: <span>194x330</span>'.'</li>'.
                    			'<li>'.'Samsung Galaxy S5: <span>207x368</span>'.'</li>'.
                    		'</ul>',
                        'options' => array(0 => __('iPhone 6 - Black', 'mythemeshop'), 1 => __('iPhone 6 - Gold', 'mythemeshop'), 2 => __('Nokia Lumia 625 - Black', 'mythemeshop'), 3 => __('Nokia Lumia 625 - White', 'mythemeshop'), 4 => __('Samsung Galaxy S5 - Black', 'mythemeshop'), 5 => __('Samsung Galaxy S5 - Gold', 'mythemeshop')),
                        'std' => 0
                        ),
					)
				);
$sections[] = array(
				'icon' => 'fa fa-credit-card',
				'title' => __('Main Section', 'mythemeshop'),
				'desc' => __('<p class="description">From here, you can control the elements of the main section.</p>', 'mythemeshop'),
				'fields' => array(
                    array(
                          'id' => 'mts_header_title',
                          'type' => 'text',
            			  'title' => __('Title', 'mythemeshop'), 
            			  'sub_desc' => __('Title of the site (This title will appear if logo image is not set.)', 'mythemeshop'),
                          ),
                    array(
                        'id' => 'mts_header_desc',
                        'type' => 'textarea',
                        'title' => __('Description', 'mythemeshop'), 
                        'sub_desc' => __('Enter site description here.', 'mythemeshop')
                        ),
                    array(
						'id' => 'mts_header_bg_color',
						'type' => 'color',
						'title' => __('Background Color', 'mythemeshop'), 
						'sub_desc' => __('Choose a background color for this section.', 'mythemeshop'),
						'std' => '#ffffff'
						),
                    array(
                        'id' => 'mts_header_bg',
                        'type' => 'upload',
                        'title' => __('Background Image', 'mythemeshop'), 
                        'sub_desc' => __('Upload or select an image for this section', 'mythemeshop'),
                        ),
                    array(
						'id' => 'mts_header_bg_fixed',
						'type' => 'button_set',
						'title' => __('Background Image Type', 'mythemeshop'),
						'class' => 'green',
						'options' => array('0' => 'Normal','1' => 'Fixed'),
						'sub_desc' => __('Use normal (scrolling) background image or fixed (static) for this section.', 'mythemeshop'),
						'std' => '0'
							),
                    array(
                        'id' => 'mts_first_screenshot',
                        'type' => 'upload',
                        'title' => __('First Screenshot', 'mythemeshop'), 
                        'sub_desc' => __('Show a screenshot of your app. ', 'mythemeshop'),
                        ),
					array(
                        'id'        => 'mts_intro_button',
                        'type'      => 'group',
                        'title'     => __('Button', 'mythemeshop'),
                        'sub_desc'  => __('With this option you can set up intro section buttons.', 'mythemeshop'),
                        'groupname' => __('Button', 'mythemeshop'), // Group name
                        'subfields' =>
                            array(
                                array(
                                    'id' => 'mts_intro_button_label',
            						'type' => 'textarea',
            						'title' => __('Label', 'mythemeshop'),
            						'sub_desc' => __('Button label', 'mythemeshop'),
                                    ),
                                array(
									'id' => 'mts_button_color',
									'type' => 'color',
									'title' => __('Background Color', 'mythemeshop'),
									'sub_desc' => __('Pick a background color for the button.', 'mythemeshop'),
									'std' => '#fac759'
									),
                                array(
									'id' => 'mts_button_text_color',
									'type' => 'color',
									'title' => __('Button Text Color', 'mythemeshop'),
									'sub_desc' => __('Pick a text color for the button.', 'mythemeshop'),
									'std' => '#8E5A16'
									),
                                array(
            						'id' => 'mts_intro_button_icon_select',
            						'type' => 'icon_select',
                                    'allow_empty' => 1,
            						'title' => __('Select Icon', 'mythemeshop'),
            						'sub_desc' => __('Select an icon from the vector icon set.', 'mythemeshop'),
            						),
                                array(
									'id' => 'mts_intro_button_url',
									'type' => 'text',
									'title' => __('URL', 'mythemeshop'),
									'sub_desc' => __('Enter button URL.', 'mythemeshop'),
									'std' => '#'
									),
                            ),
                        ),
                    array(
                          'id' => 'mts_youtube_link',
                          'type' => 'text',
            			  'title' => __('YouTube Link', 'mythemeshop'), 
            			  'sub_desc' => __('Enter YouTube video link here to show play button in header', 'mythemeshop'),
                          ),
                    array(
						'id' => 'mts_dark_header',
						'type' => 'button_set',
						'title' => __('Text Color', 'mythemeshop'),
						'class' => 'green',
						'options' => array('0' => 'Light','1' => 'Dark'),
						'sub_desc' => __('Choose dark or light text color.', 'mythemeshop'),
						'std' => '0'
							),
					)
				);	
$sections[] = array(
				'icon' => 'fa fa-info-circle',
				'title' => __('Additional Sections', 'mythemeshop'),
				'desc' => __('<p class="description">Here you can add and remove sections containing text & images.</p>', 'mythemeshop'),
				'fields' => array(
                    array(
                        'id'        => 'mts_home_section',
                        'type'      => 'group',
                        'title'     => __('Info Sections', 'mythemeshop'),
                        'groupname' => __('Section', 'mythemeshop'), // Group name
                        'subfields' => 
                            array(
                               array(
                                    'id' => 'mts_section_title',
                                    'type' => 'text',
                                    'title' => __('Title', 'mythemeshop'),
                                    ), 
                                array(
                                    'id' => 'mts_section_desc',
                                    'type' => 'textarea',
                                    'title' => __('Description', 'mythemeshop'), 
                                    ),
			                    array(
									'id' => 'mts_section_bg_color',
									'type' => 'color',
									'title' => __('Section background color', 'mythemeshop'), 
									'sub_desc' => __('Choose a background color for this section.', 'mythemeshop'),
									'std' => '#ffffff'
									),
                                array(
                                    'id' => 'mts_section_bg',
                                    'type' => 'upload',
                                    'title' => __('Section background image', 'mythemeshop'), 
                                    'sub_desc' => __('Upload your background using the Upload Button or insert image URL.', 'mythemeshop')
                                    ),
                                array(
                                    'id' => 'mts_section_bg_fixed',
                                    'type' => 'checkbox',
                                    'title' => __('Fixed background image', 'mythemeshop'), 
                                    'sub_desc' => __('Select this checkbox to exclude the background from scrolling.', 'mythemeshop')
                                    ),
                                array(
                                    'id' => 'mts_section_image',
                                    'type' => 'upload',
                                    'title' => __('Screenshot', 'mythemeshop'), 
                                    ),
                                array(
                                    'id' => 'mts_section_effect',
            						'type' => 'radio',
            						'title' => __('Screenshot effect', 'mythemeshop'),
                                    'options' => array(0 => __('Slide from top', 'mythemeshop'), 1 => __('Slide from right', 'mythemeshop'), 2 => __('Slide from bottom', 'mythemeshop'), 3 => __('Slide from left', 'mythemeshop'), 4 => __('Fade', 'mythemeshop')),
                                    'std' => 0
                                    ),
                                array(
                                    'id' => 'mts_section_text_effect',
            						'type' => 'radio',
            						'title' => __('Text effect', 'mythemeshop'),
                                    'options' => array(0 => __('None', 'mythemeshop'), 1 => __('Slide from top', 'mythemeshop'), 2 => __('Slide from right', 'mythemeshop'), 3 => __('Slide from bottom', 'mythemeshop'), 4 => __('Slide from left', 'mythemeshop'), 5 => __('Fade', 'mythemeshop'), 6 => __('Grow', 'mythemeshop')),
                                    'std' => 0
                                    ),
                                array(
                                    'id' => 'mts_text_color_section',
                                    'type' => 'radio',
                                    'title' => __('Text Color', 'mythemeshop'),
                                    'options' => array('0' => 'Light','1' => 'Dark'),
                                    'sub_desc' => __('Choose dark or light text color.', 'mythemeshop'),
                                    'std' => '0'
                                        ),
                            ),
            				'std' => array(
            					'1' => array(
            						'group_title' => '',
            						'mts_section_title' => '',
            						'mts_section_desc' => '',
            						'mts_home_button' => '',
            						'mts_home_button_2' => '',
            						'mts_section_bg' => '',
            						'mts_section_image' => '',
            						'group_sort' => '1',
            					)
            				)
                        ),
					)
				);	
$sections[] = array(
				'icon' => 'fa fa-cogs',
				'title' => __('Contact Section', 'mythemeshop'),
				'desc' => __('<p class="description">This tab contains common setting options which will be applied to the whole theme.</p>', 'mythemeshop'),
				'fields' => array(	
                    array(
                          'id' => 'mts_contact_title',
                          'type' => 'text',
            			  'title' => __('Title', 'mythemeshop'), 
            			  'sub_desc' => __('Title of the site', 'mythemeshop'),
                          ),
                    array(
						'id' => 'mts_contact_bg_color',
						'type' => 'color',
						'title' => __('Background Color', 'mythemeshop'), 
						'sub_desc' => __('Choose a background color for this section.', 'mythemeshop'),
						'std' => '#ffffff'
						),
                    array(
						'id' => 'mts_contact_bg',
						'type' => 'upload',
						'title' => __('Contact Background Image', 'mythemeshop'), 
						'sub_desc' => __('Upload your logo using the Upload Button or insert image URL.', 'mythemeshop')
						),
                    array(
						'id' => 'mts_contact_bg_fixed',
						'type' => 'button_set_hide_below',
						'title' => __('Background Image Type', 'mythemeshop'), 
						'sub_desc' => __('Use normal (scrolling) background image or fixed (static) for this section.', 'mythemeshop'),
						'options' => array(
										'0' => 'Normal',
										'1' => 'Fixed'
											),
						'std' => '0',
						'class' => 'green'
						),
                    array(
						'id' => 'mts_dark_contact',
						'type' => 'button_set',
						'title' => __('Text Color', 'mythemeshop'),
						'options' => array('0' => 'Light','1' => 'Dark'),
						'sub_desc' => __('Choose dark or light text color.', 'mythemeshop'),
						'std' => '0'
							),
                    array(
						'id' => 'mts_contact_section',
						'type' => 'button_set_hide_below',
						'title' => __('Show Contact Form', 'mythemeshop'), 
						'sub_desc' => __('Enable or disable contact section with this option.', 'mythemeshop'),
						'options' => array(
										'0' => 'Off',
										'1' => 'On'
											),
						'std' => '0',
						'args' => array('hide' => 1)
						),
	                    array(
	                          'id' => 'mts_contact_email',
	                          'type' => 'text',
	            			  'title' => __('Contact Email', 'mythemeshop'), 
	            			  'sub_desc' => __('Contact forms will be sent to this address', 'mythemeshop'),
	            			  'std' => get_option('admin_email')
	                          ),
                )
);
$sections[] = array(
				'icon' => 'fa fa-group',
				'title' => __('Social Icons', 'mythemeshop'),
				'desc' => __('<p class="description">Add social icons in footer</p>', 'mythemeshop'),
				'fields' => array(
					array(
                     	'id' => 'mts_footer_social',
                     	'title' => __('footer Social Icons', 'mythemeshop'), 
                     	'sub_desc' => __( 'Add Social Media icons in footer.', 'mythemeshop' ),
                     	'type' => 'group',
                     	'groupname' => __('footer Icons', 'mythemeshop'), // Group name
                     	'subfields' => 
                            array(
                                array(
                                    'id' => 'mts_footer_icon_title',
            						'type' => 'text',
            						'title' => __('Title', 'mythemeshop'), 
            						),
								array(
                                    'id' => 'mts_footer_icon',
            						'type' => 'icon_select',
            						'title' => __('Icon', 'mythemeshop')
            						),
								array(
                                    'id' => 'mts_footer_icon_link',
            						'type' => 'text',
            						'title' => __('URL', 'mythemeshop'), 
            						),
			                	),
                    			'std' => array(
	            					'facebook' => array(
	            						'group_title' => 'Facebook',
	            						'group_sort' => '1',
	            						'mts_footer_icon_title' => 'Facebook',
	            						'mts_footer_icon' => 'facebook',
	            						'mts_footer_icon_link' => '#',
	            					),
	            					'twitter' => array(
	            						'group_title' => 'Twitter',
	            						'group_sort' => '2',
	            						'mts_footer_icon_title' => 'Twitter',
	            						'mts_footer_icon' => 'twitter',
	            						'mts_footer_icon_link' => '#',
	            					),
	            					'gplus' => array(
	            						'group_title' => 'Google Plus',
	            						'group_sort' => '3',
	            						'mts_footer_icon_title' => 'Google Plus',
	            						'mts_footer_icon' => 'google-plus',
	            						'mts_footer_icon_link' => '#',
	            					),
            					)
                       		),
						)
					);
				
	$tabs = array();
    
    $args['presets'] = array();
    include('theme-presets.php');
    
	global $NHP_Options;
	$NHP_Options = new NHP_Options($sections, $args, $tabs);

}//function
add_action('init', 'setup_framework_options', 0);

/*
 * 
 * Custom function for the callback referenced above
 *
 */
function my_custom_field($field, $value){
	print_r($field);
	print_r($value);

}//function

/*
 * 
 * Custom function for the callback validation referenced above
 *
 */
function validate_callback_function($field, $value, $existing_value){
	
	$error = false;
	$value =  'just testing';
	/*
	do your validation
	
	if(something){
		$value = $value;
	}elseif(somthing else){
		$error = true;
		$value = $existing_value;
		$field['msg'] = 'your custom error message';
	}
	*/
	$return['value'] = $value;
	if($error == true){
		$return['error'] = $field;
	}
	return $return;
	
}//function

/*--------------------------------------------------------------------
 * 
 * Default Font Settings
 *
 --------------------------------------------------------------------*/
if(function_exists('register_typography')) { 
  register_typography(array(
    'logo_font' => array(
      'preview_text' => 'Logo Font',
      'preview_color' => 'dark',
      'font_family' => 'Pacifico',
      'font_variant' => 'normal',
      'font_size' => '50px',
      'font_color' => '#ffffff',
      'css_selectors' => '#logo a'
    ),
    'navigation_font' => array(
      'preview_text' => 'Navigation Font',
      'preview_color' => 'dark',
      'font_family' => 'Varela Round',
      'font_variant' => 'normal',
      'font_size' => '17px',
      'font_color' => '#ffffff',
      'css_selectors' => '.menu li, .menu li a'
    ),
    'tagline_font' => array(
      'preview_text' => 'Home Section Title Font',
      'preview_color' => 'dark',
      'font_family' => 'Varela Round',
      'font_variant' => 'normal',
      'font_size' => '40px',
      'font_color' => '#ffffff',
      'css_selectors' => '.tagline, .p1, .contact-title'
    ),
    'content_font' => array(
      'preview_text' => 'Content Font',
      'preview_color' => 'light',
      'font_family' => 'Roboto',
      'font_size' => '15px',
	  'font_variant' => 'normal',
      'font_color' => '#ffffff',
      'css_selectors' => 'body'
    ),
  ));
}

?>