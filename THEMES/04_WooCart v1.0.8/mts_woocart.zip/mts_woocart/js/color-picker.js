jQuery(document).ready(function($){
    $('.mts-color-picker-field').wpColorPicker();
});