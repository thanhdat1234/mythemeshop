<?php $mts_options = get_option(MTS_THEME_NAME); ?>
	</div><!--#page-->
	<footer class="footer" role="contentinfo" itemscope itemtype="http://schema.org/WPFooter">
		<div class="container">
            <div class="copyrights">
				<?php mts_copyrights_credit(); ?>
			</div>
		</div><!--.container-->
	</footer><!--footer-->
</div><!--.main-container-->
<?php mts_footer(); ?>
<?php wp_footer();
 if ( is_front_page() && is_home() ) { ?>
<script type="text/javascript">
jQuery(window).load(function() {
  jQuery('a').click(function(e) {
      var url = jQuery(this).attr('href');
      var elementId = '';
      if(url.split('#').length == 2) {
          elementId = '#' + jQuery.trim(url.split('#')[1]);
      }
      if (elementId != '' && jQuery(elementId).length > 0) {
          e.preventDefault();
          jQuery('html, body').animate({
              scrollTop: jQuery( elementId ).offset().top
          }, 1000);
          //return false;
      }
  });
});
</script>
<?php } 
if ( is_front_page() && is_home() && !empty($mts_options['mts_show_contact_map']) && !empty($mts_options['mts_contact_location']) ) { ?>
<script type="text/javascript">

      var mapLoaded = false;
      function initialize() {
        mapLoaded = true;
        
        var geocoder = new google.maps.Geocoder();
        var lat='';
        var lng=''
        geocoder.geocode( { 'address': '<?php echo addslashes($mts_options['mts_contact_location']); ?>'}, function(results, status) {
                if (status == google.maps.GeocoderStatus.OK) {
                    lat = results[0].geometry.location.lat(); //getting the lat
                    lng = results[0].geometry.location.lng(); //getting the lng
                    map.setCenter(results[0].geometry.location);
                    var marker = new google.maps.Marker({
                       map: map,
                       position: results[0].geometry.location
                    });

                    infobox = new InfoBox({
                         content: document.getElementById("contact-section-info-container"),
                         disableAutoPan: false,
                         maxWidth: 150,
                         pixelOffset: new google.maps.Size(-170, -80),
                         zIndex: null,
                         boxStyle: {
                            background: "url('http://google-maps-utility-library-v3.googlecode.com/svn/trunk/infobox/examples/tipbox.gif') no-repeat",
                             width: "320px"
                        },
                        closeBoxMargin: "4px 4px 4px 4px",
                        closeBoxURL: "http://www.google.com/intl/en_us/mapfiles/close.gif",
                        infoBoxClearance: new google.maps.Size(1, 1)
                    });

                    infobox.open(map, marker);
                    map.panTo(latlng);

                    google.maps.event.addListener(marker, 'click', function() {
                        infobox.open(map, this);
                        //map.panTo(latlng);
                    });
                 }
        });

        var latlng = new google.maps.LatLng(lat, lng);

        var mapOptions = {
            zoom: 18,
            center: latlng,
            scrollwheel: false,
            navigationControl: false,
            scaleControl: false,
            streetViewControl: false,
            draggable: true,
            panControl: false,
            mapTypeControl: false,
            zoomControl: false,
            mapTypeId: google.maps.MapTypeId.ROADMAP,
            // How you would like to style the map.
                    // This is where you would paste any style found on Snazzy Maps.
                    styles: [{featureType:"landscape",stylers:[{saturation:-100},{lightness:65},{visibility:"on"}]}]
        };

        var map = new google.maps.Map(document.getElementById("map-canvas"),
            mapOptions);
      }
    //google.maps.event.addDomListener(window, 'load', initialize);

      jQuery(window).load(function() {
        jQuery(window).scroll(function() {
          if (jQuery('.contact_map').isOnScreen() && !mapLoaded) {
            mapLoaded = true;
            jQuery('body').append('<script src="https://maps.googleapis.com/maps/api/js?sensor=false&v=3&callback=initialize"></'+'script>'+'<script src="http://google-maps-utility-library-v3.googlecode.com/svn/trunk/infobox/src/infobox.js"></'+'script>');
          }
        });
      });
</script>
<?php } ?>

</body>
</html>