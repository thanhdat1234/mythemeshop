<?php
    $mts_options     = get_option(MTS_THEME_NAME);
    $homepage_layout = array();
    if ( !empty($mts_options['mts_homepage_layout']['enabled']) && is_array($mts_options['mts_homepage_layout']['enabled']) ) {
        $homepage_layout = array_merge($homepage_layout, $mts_options['mts_homepage_layout']['enabled']);
    }

?>
<?php 

get_header(); 
if ( !empty($homepage_layout) ) {
        foreach ( $homepage_layout as $key => $section ) {
            get_template_part( 'home/front-page', $key );
        }
} 

get_footer(); 

?>