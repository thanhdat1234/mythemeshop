<?php
$mts_options = get_option(MTS_THEME_NAME);
if ( !empty($mts_options['mts_testimonial_title']) || !empty($mts_options['mts_testimonials']) ) {
?>

	<section id="testimonials" class="testimonials-section slider-images-section">
		<h3 data-scroll-reveal="wait .2s and then ease-in-out 100px"><?php echo $mts_options['mts_testimonial_title']; ?></h3>
		<?php
			$extra_margin_class = ' testimonial-extra-margin';
			if ( !empty($mts_options['mts_testimonial_description']) ) {
				$extra_margin_class = ''; ?>
				<div class="testimonial-section-description" data-scroll-reveal="wait .2s and then ease-in-out 100px">
					<?php
						echo nl2br($mts_options['mts_testimonial_description']);
					?>
				</div>
		<?php }

		if ( !empty($mts_options['mts_testimonials']) ) { ?>

		<div class="testimonial-slides-container clearfix loading">
			<div id="testimonial-slider-contents" class="testimonial-slider slides<?php echo $extra_margin_class;?>">
			<?php foreach ( $mts_options['mts_testimonials'] as $testimonial ) { ?>
				<div class="item" data-scroll-reveal="wait .2s and then ease-in-out 100px">
					<div class="testimonial-name">
						<?php echo $testimonial['mts_testimonial_name']?>
					</div>
					<div class="testimonial-description">
						<?php echo $testimonial['mts_testimonial_description']?>
					</div>
					<?php
						$rating = $testimonial['mts_testimonial_rating'];
						$stars  = 5;
						if ($rating > 5) {
							$rating = 5;
						}
						$width = (($rating/$stars)*100)."%";
					?>
					<div class="testimonial-rating">
						<div class="testimonial-rating-div">
							<div class="outer-review-rating">
								<i class="fa fa-star"></i>
								<i class="fa fa-star"></i>
								<i class="fa fa-star"></i>
								<i class="fa fa-star"></i>
								<i class="fa fa-star"></i>
								<div class="cust-review-rating" style="width:<?php echo $width;?>;">
									<i class="fa fa-star"></i>
									<i class="fa fa-star"></i>
									<i class="fa fa-star"></i>
									<i class="fa fa-star"></i>
									<i class="fa fa-star"></i>
								</div>
							</div>
						</div>

					</div>
				</div>
			<?php } ?>
			</div>
		</div>
		<?php } ?>
	</section>
<?php } ?>