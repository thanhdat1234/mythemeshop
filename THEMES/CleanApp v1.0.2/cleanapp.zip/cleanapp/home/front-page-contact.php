<?php
$mts_options = get_option(MTS_THEME_NAME);
if ( !empty($mts_options['mts_contact_title']) || !empty($mts_options['mts_show_contact_map']) || !empty( $mts_options['mts_show_contact_form']) || !empty($mts_options['mts_contact_company_name']) ) {
?>

	<section id="contact" class="contact-section">
		<h3 data-scroll-reveal="wait .2s and then ease-in-out 100px"><?php echo $mts_options['mts_contact_title']; ?></h1>

		<?php $info_container_class = " no-map-contact-info-container";
			$info_main_container = 'no-map-contact-info-main-contanier';
			if ( !empty($mts_options['mts_show_contact_map']) && !empty($mts_options['mts_contact_location']) ) {
				$static_map_url = 'http://maps.googleapis.com/maps/api/staticmap?center='.urlencode($mts_options['mts_contact_location']).'&zoom=13&size=1600x400';
				$info_container_class = "";
				$info_main_container = 'contact-info-main-contanier'; ?>
				<div class="contact_map">
		        	<div id="map-canvas"></div>
       		<?php } ?>
	        <div class="<?php echo $info_main_container;?>">
	        	<?php if ( !empty($mts_options['mts_contact_company_name']) || !empty($mts_options['mts_contact_company_address']) || !empty($mts_options['mts_contact_email']) ) { ?>
			        <div class="contact-info-container<?php echo $info_container_class; ?>" id="contact-section-info-container">
			        	<h4><?php echo $mts_options['mts_contact_company_name']?></h4>
			        	<div class="contact-company-address"><?php echo nl2br($mts_options['mts_contact_company_address'])?></div>
			        	<div class="contact-section-email">
			        		<?php echo $mts_options['mts_contact_email']; ?>
			        	</div>
			        </div>
		        <?php } ?>
	        </div>
		<?php if ( !empty($mts_options['mts_show_contact_map']) && !empty($mts_options['mts_contact_location']) ) { ?>        
	    </div>
		<?php } ?>

		<?php if ( !empty($mts_options['mts_show_contact_form']) ) { ?>
			<div data-scroll-reveal="wait .2s and then ease-in-out 100px"><?php mts_contact_form(); ?></div>
		<?php } ?>
	</section>
<?php } ?>