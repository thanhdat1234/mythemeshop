<?php
	$mts_options = get_option(MTS_THEME_NAME);
?>
<section id="intro">
	<div class="container">
	<?php
		$hasForegroundImage = !empty($mts_options['mts_intro_foreground']);
		$containerClass = "centered";
		if ($hasForegroundImage) {
			$containerClass = "";
		}
	?>

	<div class="info-section-container <?php echo $containerClass ?>">
		<?php if (!empty($mts_options['mts_intro_foreground'])) { ?>
			<div class="header-foreground-image" data-scroll-reveal="wait .2s and then ease-in-out 100px">
				<img src="<?php echo $mts_options['mts_intro_foreground']; ?>" />
			</div>
		<?php } ?>
		<div class="info-section-content <?php echo $containerClass ?>">
			<h3 class="app-title" data-scroll-reveal="wait .2s and then ease-in-out 100px"><?php echo $mts_options['mts_intro_title']; ?></h3>
			<p class="app-description" data-scroll-reveal="wait .2s and then ease-in-out 100px"><?php echo $mts_options['mts_intro_description']; ?></p>

			<?php if (!empty($mts_options['mts_intro_button'])) { ?>
				<div class="info-buttons-container" data-scroll-reveal="wait .2s and then ease-in-out 100px">
					<?php
						foreach ( $mts_options['mts_intro_button'] as $button ) {
						$button['mts_intro_button_label'] = str_replace("\n\r", "\n", $button['mts_intro_button_label']);
						$btn_texts  = explode("\n", $button['mts_intro_button_label']);
						$label      = !empty($btn_texts[0]) ? $btn_texts[0] : '';
						$boldText   = !empty($btn_texts[1]) ? $btn_texts[1] : '';
						$button_url = "#";
						if ( !empty($button['mts_intro_button_url']) ) {
							$button_url = $button['mts_intro_button_url'];
						}

					?>
						<div class="intro-section-buttons-container">
						<?php // Increase brightness of color
							$bright_color = alter_brightness($button['mts_button_color'],15); ?>
						<a href="<?php echo $button_url; ?>" class="intro-section-buttons" style="background-image: -moz-linear-gradient( top, <?php echo $bright_color; ?> 0%, <?php echo $button['mts_button_color']; ?> 100%); background-image: -webkit-linear-gradient( top, <?php echo $bright_color; ?> 0%, <?php echo $button['mts_button_color']; ?> 100%); background-image: -ms-linear-gradient( top, <?php echo $bright_color; ?> 0%, <?php echo $button['mts_button_color']; ?> 100%); color: <?php echo $button['mts_button_text_color']; ?>">
							<div class="icon-section">
								<i class="fa fa-<?php echo $button['mts_intro_button_icon_select']; ?>"></i>
							</div>
							<div class="text-section"><?php if (empty($boldText)) { ?>
									<div class="button-bold-text button-bold-text-extra-padding"><?php } else { ?><div class="button-label"><?php } ?><?php echo $label; ?></div><?php if (!empty($boldText)) { ?><div class="button-bold-text"><?php echo $boldText; ?></div>
								<?php } ?></div>
						</a></div>
					<?php
						}
					?>
				</div>
			<?php } ?>
		</div>
		<div>

		</div>
	</div>
	</div>
</section>
</header>