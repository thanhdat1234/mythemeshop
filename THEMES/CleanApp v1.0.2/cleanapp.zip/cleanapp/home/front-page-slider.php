<?php
	$mts_options = get_option(MTS_THEME_NAME);
	$extra_class = "";
?>
<section id="overview" class="overview-section slider-images-section<?php echo $extra_class;?>">
	<?php if ( !empty($mts_options['mts_overview_title']) ) { ?>
		<h3 data-scroll-reveal="wait .2s and then ease-in-out 100px"><?php echo $mts_options['mts_overview_title']; ?></h3>
	<?php } ?>
	<div class="overview-section-description" data-scroll-reveal="wait .2s and then ease-in-out 100px">
		<?php
			if (!empty($mts_options['mts_overview_description'])) {
				echo nl2br($mts_options['mts_overview_description']);
			}
		?>
	</div>
	<?php if ( !empty($mts_options['mts_overview_slider_images']) ) { ?>
		<div class="slides_container clearfix loading">
			<div id="overview-slider-images" class="slides">
				<?php
					foreach ($mts_options['mts_overview_slider_images'] as $slider_image) {
				?>
					<div class="item">
						<img src="<?php echo $slider_image['mts_overview_image'];?>" />
					</div>
				<?php
					}
				?>
			</div>
		</div>
	<?php } ?>
</section>
