<?php
$mts_options = get_option(MTS_THEME_NAME);
if ( !empty($mts_options['mts_carousel_title']) || !empty($mts_options['mts_carousel_images']) ) {
?>
	<section id="carousel" class="carousel-section slider-images-section">
		<div id="carousel-main-container">
			<h3 data-scroll-reveal="wait .2s and then ease-in-out 100px"><?php echo $mts_options['mts_carousel_title']; ?></h1>
			<div class="carousel-section-description" data-scroll-reveal="wait .2s and then ease-in-out 100px">
				<?php if ( !empty($mts_options['mts_carousel_description']) ) {
					echo nl2br($mts_options['mts_carousel_description']);
				} ?>
			</div>
			<div class="carousel-slides-container clearfix loading">
				<div id="carousel-slider-images" class="carousel-images slides">
					<?php if ( !empty($mts_options['mts_carousel_images']) ) {
						foreach ( $mts_options['mts_carousel_images'] as $carousel_image ) { ?>
						<div class="item" data-scroll-reveal="wait .2s and then ease-in-out 100px">
							<img src="<?php echo $carousel_image['mts_carousel_image']; ?>" />
						</div>
					<?php }} ?>
				</div>
			</div>
		</div>
	</section>
<?php } ?>