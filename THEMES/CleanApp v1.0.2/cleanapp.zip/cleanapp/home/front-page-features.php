<?php
$mts_options = get_option(MTS_THEME_NAME);
if ( !empty($mts_options['mts_features_title']) || !empty($mts_options['mts_features_image']) || !empty($mts_options['mts_features']) ) {
	$feature_image_present = !empty($mts_options['mts_features_image']);
	$features_class = ($feature_image_present) ? "features-section-half" : "features-section-full";
	$section_float = ($feature_image_present) ? "pull-left":"pull-none";
?>

	<section id="features" class="features-section <?php echo $section_float ?>">
		<div id="features-main-container">
			<h3 data-scroll-reveal="wait .2s and then ease-in-out 100px"><?php echo $mts_options['mts_features_title']; ?></h3>
			<div class="features-section-description" data-scroll-reveal="wait .2s and then ease-in-out 100px">
				<?php
					if ( !empty($mts_options['mts_features_description']) ) {
						echo nl2br($mts_options['mts_features_description']);
					}
				?>
			</div>
			<?php if ($feature_image_present) { ?>
				<div class="feature-section-image" data-scroll-reveal="wait .2s and then ease-in-out 100px">
					<div class="feature-image-container">
					<img src="<?php echo $mts_options['mts_features_image']; ?>" />
					</div>
				</div>
			<?php } ?>

			<?php if ( !empty($mts_options['mts_features']) ) { ?>
				<div class="features-list-container <?php echo $features_class;?>">
					<ul>
						<?php foreach ( $mts_options['mts_features'] as $feature ) { ?>
							<li data-scroll-reveal="wait .2s and then ease-in-out 100px">
								<div class="feature-icon-container">
									<span class="fa fa-<?php echo $feature['mts_feature_icon_select']; ?>"></span>
								</div>
								<div class="feature-text-container">
									<h4><?php echo $feature['mts_feature_title'];?></h4>
									<div class="feature-description"><?php echo $feature['mts_feature_description']; ?></div>
								</div>
							</li>
						<?php } ?>
					</ul>
				</div>
			<?php } ?>
		</div>
	</section>
<?php } ?>