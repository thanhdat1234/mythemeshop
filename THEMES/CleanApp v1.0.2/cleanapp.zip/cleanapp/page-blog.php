<?php
/*
Template Name: Blog
*/
$mts_options = get_option(MTS_THEME_NAME);
get_header();
if (get_query_var('page') > 1) {
    $paged = get_query_var('page');
} elseif (get_query_var('paged')) {
    $paged = get_query_var('paged');
} else {
    $paged = 1;
}
$args= array('paged' => $paged, 'post_type' => 'post');
?>
    <div class="main-header-container-cover">
        <div class="single container top-container">
            <span class="title-container">
                <h2 class="text-heading"><?php echo __( 'Blog', 'mythemeshop' ); ?></h2>
            </span>
            <?php if ($mts_options['mts_featured_latest'] == '1') { ?>
                <span class="latest-header-post">
                    <?php query_posts($args.'&posts_per_page=1'); ?>
                    <?php if( have_posts() ) : while ( have_posts() ) : the_post(); ?>
                        <span class="header-date"><?php the_time( get_option( 'date_format' ) ); ?></span>
                        <a href="<?php the_permalink(); ?>" title="<?php the_title_attribute(); ?>" >
                            <?php the_title(); ?>
                        </a>
                    <?php endwhile; wp_reset_query(); endif; ?>
                </span>
            <?php } ?>
            <?php if ($mts_options['mts_breadcrumb'] == '1') { ?>
                <span class="breadcrumb text-right" xmlns:v="http://rdf.data-vocabulary.org/#">
                    <?php mts_the_breadcrumb(); ?>
                </span>
            <?php } ?>
        </div>
    </div>
	<section id="homepage-blog" class="homepage-section homepage-blog blog">
		<div class="inside container">
           <?php if(mts_article_class() != 'ss-full-width') { ?>
                <?php get_sidebar('left'); ?>
            <?php } ?>
            <div id="content_box" class="<?php echo mts_article_class(); ?>">

				<?php query_posts($args); ?>

                    <?php if( have_posts() ) : while ( have_posts() ) : the_post(); ?>

                    <article id="post-<?php the_ID(); ?>" <?php post_class('g post'); ?>>
                        <div class="single_post clearfix">
                            <?php if( has_post_thumbnail() ): ?>
                                <div class="featured-thumbnail">
                                    <a href="<?php the_permalink(); ?>" title="<?php the_title_attribute(); ?>" >
                                        <?php the_post_thumbnail( 'featured' ); ?>
                                        <?php if (function_exists('wp_review_show_total')) wp_review_show_total(true, 'latestPost-review-wrapper'); ?>
                                    </a>
                                </div>
                            <?php endif; ?>
                            <header>
                                <h2 class="single-title">
                                    <a href="<?php the_permalink(); ?>" title="<?php the_title_attribute(); ?>" >
                                        <?php the_title(); ?>
                                    </a>
                                </h2>
                                
                                <?php mts_the_postinfo_custom(); ?>

                            </header><!--.headline_area-->
                            <div class="post-single-content box mark-links">
                                <?php if ( isset($mts_options['mts_homepage_blog_layout']) && $mts_options['mts_homepage_blog_layout'] == '1' ){ ?>
                                    <?php echo mts_excerpt(27); ?>
                                    <a class="reply" href="<?php the_permalink(); ?>"><?php _e("Continue Reading","mythemetop"); ?></a>
                                <?php } else { ?>
                                       <?php if($mts_options['mts_full_posts'] == '0'){ ?>
                                           <?php echo mts_excerpt(50); ?>
                                           <a class="reply" href="<?php the_permalink(); ?>"><?php _e("Read more","mythemetop"); ?></a>
                                       <?php } else { ?>
                                           <?php the_content(); ?>
                                           <?php if (mts_post_has_moretag()){ ?>
                                	       <a class="reply" href="<?php the_permalink() ?>" title="<?php the_title(); ?>" rel="nofollow"><?php _e('Read more','mythemeshop'); ?></a>
                                <?php }}} ?>
                            </div><!--.post-single-content box mark-links-->
                        </div><!--.single_post clearfix-->

                    </article><!--.g post-->

                <?php endwhile; /* end loop */ ?>
				<!--Start Pagination-->
				<?php if (isset($mts_options['mts_pagenavigation_type']) && $mts_options['mts_pagenavigation_type'] == '1' ) { ?>
					<?php $additional_loop = 0; mts_pagination($additional_loop['max_num_pages']); ?>
				<?php } else { ?>
					<div class="pagination pagination-previous-next">
						<ul>
							<li class="nav-previous"><?php next_posts_link( '<i class="fa fa-chevron-left"></i> '. __( 'Previous', 'mythemeshop' ) ); ?></li>
							<li class="nav-next"><?php previous_posts_link( __( 'Next', 'mythemeshop' ).' <i class="fa fa-chevron-right"></i>' ); ?></li>
						</ul>
					</div>
				<?php } ?>
				<!--End Pagination-->
			<?php endif; wp_reset_query(); ?>
            </div>
			<?php get_sidebar(); ?>
		</div>
	</section>
<?php //endif; ?>
<?php get_footer(); ?>