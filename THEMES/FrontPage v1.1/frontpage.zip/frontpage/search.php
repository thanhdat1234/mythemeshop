<?php $mts_options = get_option('frontpage'); ?>
<?php get_header(); ?>
<div id="page" class="home-page">
	<div class="content">
		<div class="article">
			<div class="left-section">	
				<div class="latest-section">
					<h1 class="postsby">
						<span><?php _e("Search Results for:", "mythemeshop"); ?></span> <?php the_search_query(); ?>
					</h1>
					<?php  $j=0; $i =0; if (have_posts()) : while (have_posts()) : the_post(); ?>
						<article class="<?php echo 'pexcerpt'.$i++?> post excerpt <?php echo (++$j % 2 == 0) ? 'last' : ''; ?>">
							<a href="<?php the_permalink() ?>" title="<?php the_title(); ?>" rel="nofollow" id="featured-thumbnail">
								<?php if ( has_post_thumbnail() ) { ?> 
									<?php echo '<div class="featured-thumbnail">'; the_post_thumbnail('featured',array('title' => '')); echo '</div>'; ?>
								<?php } else { ?>
									<div class="featured-thumbnail">
										<img src="<?php echo get_template_directory_uri(); ?>/images/nothumb.png" class="attachment-featured wp-post-image" alt="<?php the_title(); ?>">
									</div>
								<?php } ?>
							</a>
							<header>						
								<h2 class="title">
									<a href="<?php the_permalink() ?>" title="<?php the_title(); ?>" rel="bookmark"><?php the_title(); ?></a>
								</h2>
							</header><!--.header-->
							<div class="post-content image-caption-format-1">
								<p>
									<?php if(isset($mts_options['mts_random_posts']) != '1') { ?>
										<?php echo excerpt(31);?>
									<?php } else { ?>
										<?php echo excerpt(20);?>
									<?php } ?>
								</p>
								<?php if(isset($mts_options['mts_home_headline_meta']) == '1') { ?>
									<div class="post-info"><span class="theauthor"><i class="icon-user"></i> <?php  the_author_posts_link(); ?></span>  <span class="thetime"><i class="icon-calendar"></i> <?php the_time('M j, Y'); ?></span></div>
								<?php } ?>
								<div class="readMore"><a href="<?php the_permalink() ?>" title="<?php the_title(); ?>" rel="bookmark"><?php _e('Read More','mythemeshop'); ?> +</a></div>
							</div>
						</article>
					<?php endwhile; wp_reset_query(); else: ?>
						<div class="no-results">
							<h3><?php _e('We apologize for any inconvenience, please hit back on your browser or use the search form below.', 'mythemeshop'); ?></h3>
							<?php get_search_form(); ?>
						</div><!--noResults-->
					<?php endif; ?>	
				</div>
				<!--Start Pagination-->
				<?php if ( isset($mts_options['mts_pagenavigation']) && $mts_options['mts_pagenavigation'] == '1' ) { ?>
					<?php  $additional_loop = 0; global $additional_loop; pagination($additional_loop['max_num_pages']); ?>           
				<?php } else { ?>
					<div class="pagination">
						<ul>
							<li class="nav-previous"><?php next_posts_link( __( '&larr; '.'Older posts', 'mythemeshop' ) ); ?></li>
							<li class="nav-next"><?php previous_posts_link( __( 'Newer posts'.' &rarr;', 'mythemeshop' ) ); ?></li>
						</ul>
					</div>
				<?php } wp_reset_query(); ?>
				<!--End Pagination-->
			</div>
			
			<?php if($mts_options['mts_layout'] == 'rcslayout' || $mts_options['mts_layout'] == 'crslayout' || $mts_options['mts_layout'] == 'scrlayout' || $mts_options['mts_layout'] == 'srclayout') { ?>
				<div class="random-section">
					<h3 class="frontTitle"><div class="random"><?php _e('Random','mythemeshop'); ?></div></h3>
					<?php  $j=0; $i =0; $my_query = new wp_query( array( 'posts_per_page' => $mts_options['mts_random_posts_no'], 'ignore_sticky_posts' => 1, 'orderby' => 'rand')); ?>
						<?php if ($my_query->have_posts()) : while ($my_query->have_posts()) : $my_query->the_post(); ?>
						<article class="<?php echo 'pexcerpt'.$i++?> post excerpt <?php echo (++$j % 2 == 0) ? 'last' : ''; ?>">
							<a href="<?php the_permalink() ?>" title="<?php the_title(); ?>" rel="nofollow" id="featured-thumbnail">
								<?php if ( has_post_thumbnail() ) { ?> 
									<?php echo '<div class="featured-thumbnail">'; the_post_thumbnail('random',array('title' => '')); echo '</div>'; ?>
								<?php } else { ?>
									<div class="featured-thumbnail">
										<img src="<?php echo get_template_directory_uri(); ?>/images/200x115.png" class="attachment-featured wp-post-image" alt="<?php the_title(); ?>">
									</div>
								<?php } ?>
							</a>
							<header>						
								<h2 class="title">
									<a href="<?php the_permalink() ?>" title="<?php the_title(); ?>" rel="bookmark"><?php the_title(); ?></a>
								</h2>
							</header><!--.header-->
							<?php if(isset($mts_options['mts_headline_meta']) == '1') { ?>
								<div class="post-content image-caption-format-1">
									<div class="post-info"><span class="theauthor"><i class="icon-user"></i> <?php  the_author_posts_link(); ?></span>  <span class="thetime"><i class="icon-calendar"></i> <?php the_time('M j'); ?></span></div>
								</div>
							<?php } ?>
						</article>
					<?php endwhile; wp_reset_query(); endif; ?>
				</div>
			<?php } ?>

		</div>
		<?php get_sidebar('home'); ?>
<?php get_footer(); ?>