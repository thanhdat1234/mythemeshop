<?php
/*-----------------------------------------------------------------------------------*/
/*  Do not remove these lines, sky will fall on your head.
/*-----------------------------------------------------------------------------------*/
require_once( dirname( __FILE__ ) . '/theme-options.php' );
include("functions/tinymce/tinymce.php");
if ( ! isset( $content_width ) ) $content_width = 1060;

/*-----------------------------------------------------------------------------------*/
/*  Load Translation Text Domain
/*-----------------------------------------------------------------------------------*/
load_theme_textdomain( 'mythemeshop', get_template_directory().'/lang' );
if ( function_exists('add_theme_support') ) add_theme_support('automatic-feed-links');

/*-----------------------------------------------------------------------------------*/
/*  Post Thumbnail Support
/*-----------------------------------------------------------------------------------*/
if ( function_exists( 'add_theme_support' ) ) {
	add_theme_support( 'post-thumbnails' );
	set_post_thumbnail_size( 200, 115, true );
	add_image_size( 'featured', 150, 100, true ); //featured
	add_image_size( 'carousel', 116, 104, true ); //carousel
	add_image_size( 'random', 200, 115, true ); //random
	add_image_size( 'widgetthumb', 65, 50, true ); //widget
	add_image_size( 'slider', 730, 320, true ); //slider
}

/*-----------------------------------------------------------------------------------*/
/*	Javascsript
/*-----------------------------------------------------------------------------------*/
function mts_add_scripts() {
	$mts_options = get_option('frontpage');
	global $data; //get theme options

	wp_enqueue_script('jquery');

	if ( is_singular() && comments_open() && get_option( 'thread_comments' ) ) {
		wp_enqueue_script( 'comment-reply' );
	}
	
	// Site wide js
	wp_enqueue_script('modernizr', get_stylesheet_directory_uri() . '/js/modernizr.min.js');
	wp_enqueue_script('customscript', get_stylesheet_directory_uri() . '/js/customscript.js');

	//Slider
	if(isset($mts_options['mts_featured_slider']) == '1' || isset($mts_options['mts_featured_carousel']) == '1') {
			wp_enqueue_script('flexslider', get_stylesheet_directory_uri() . '/js/jquery.flexslider-min.js');
	}	
	//Lightbox
	if($mts_options['mts_lightbox'] == '1') {
		wp_enqueue_script('prettyPhoto', get_stylesheet_directory_uri() . '/js/jquery.prettyPhoto.js');
	}

	//Sticky Nav
	if($mts_options['mts_sticky_nav'] == '1') {
		wp_register_script('StickyNav', get_template_directory_uri() . '/js/sticky.js', true);
		wp_enqueue_script('StickyNav');;
	}

}
add_action('wp_enqueue_scripts','mts_add_scripts');

/*-----------------------------------------------------------------------------------*/
/* Enqueue CSS
/*-----------------------------------------------------------------------------------*/
function mts_enqueue_css() {
    $mts_options = get_option('frontpage');
    global $data;

    //slider
    if(isset($mts_options['mts_featured_slider']) == '1' || isset($mts_options['mts_featured_carousel']) == '1') {
            wp_enqueue_style('flexslider', get_stylesheet_directory_uri() . '/css/flexslider.css', 'style');
    }

    if ( in_array( 'woocommerce/woocommerce.php', apply_filters( 'active_plugins', get_option( 'active_plugins' ) ) ) ) {
		//WooCommerce
		wp_register_style('woocommerce', get_template_directory_uri() . '/css/woocommerce2.css', 'style');
		wp_enqueue_style('woocommerce');
	}

    //lightbox
    if($mts_options['mts_lightbox'] == '1') {
        wp_enqueue_style('prettyPhoto', get_stylesheet_directory_uri() . '/css/prettyPhoto.css', 'style');
    }
    
    //Font Awesome
    wp_enqueue_style('fontawesome', get_stylesheet_directory_uri() . '/css/font-awesome.min.css', 'style');
    wp_enqueue_style('ie7-fontawesome', get_stylesheet_directory_uri() . '/css/font-awesome-ie7.min.css', 'style');
    global $wp_styles;
	$wp_styles->add_data('ie7-fontawesome', 'conditional', 'lte IE 7');
	
	wp_enqueue_style('stylesheet', get_stylesheet_directory_uri() . '/style.css', 'style');
	
	//Responsive
    if($mts_options['mts_responsive'] == '1') {
        wp_enqueue_style('responsive', get_stylesheet_directory_uri() . '/css/responsive.css', 'style');
    }
	
	if ($mts_options['mts_bg_pattern_upload'] != '') {
		$mts_bg = $mts_options['mts_bg_pattern_upload'];
	} else {
		if($mts_options['mts_bg_pattern'] != '') {
			$mts_bg = get_template_directory_uri().'/images/'.$mts_options['mts_bg_pattern'].'.png';
		} 
	}
	$mts_sclayout = ''; 
	$mts_shareit_left = '';
	$mts_shareit_right = '';
	$mts_author = '';
	$mts_single_layout = '';
	$mts_header_section = '';
	if($mts_options['mts_layout'] == 'rcslayout') {
		$mts_sclayout = '
			.left-section { float: right; }
			.random-section { float: left; }';
	}elseif($mts_options['mts_layout'] == 'scrlayout') {
		$mts_sclayout = '
			.article { float: right;}
			.sidebar.c-4-12 { float: left; padding-left: 0; padding-right: 2%; }';
	}elseif($mts_options['mts_layout'] == 'srclayout') {
		$mts_sclayout = '
			.article { float: right;}
			.sidebar.c-4-12 { float: left; padding-left: 0; padding-right: 2%; }
			.left-section { float: right; }
			.random-section { float: left; }';
	}elseif($mts_options['mts_layout'] == 'sclayout') {
		$mts_sclayout = '
			.article { float: right;}
			.sidebar.c-4-12 { float: left; padding-left: 0; padding-right: 2%; }
			.left-section { width: 100%; max-width: 100%; }
			.featured-section #featured-thumbnail, .latest-section #featured-thumbnail { width: 20.6%; }';
	}elseif($mts_options['mts_layout'] == 'cslayout') {
		$mts_sclayout = '
			.left-section { width: 100%; max-width: 100%; }
			.featured-section #featured-thumbnail, .latest-section #featured-thumbnail { width: 20.6%; }';
	}
	if ($mts_options['mts_header_section2'] == '0') {
		$mts_header_section = '#header h1, #header h2, .widget-header { display: none; } #header { padding-top: 0; } .main-header { min-height: 67px; }';
	}
	if($mts_options['mts_floating_social'] == '1') {
		$mts_shareit_left = '
			.shareit { top: 241px; left: auto; z-index: 0; margin: 0 0 0 -108px; width: 90px; position: fixed; overflow: visible; padding: 5px; background: #fff; }
			.share-item {margin: 2px;}';
	}
	if($mts_options['mts_layout'] == 'crslayout' || $mts_options['mts_layout'] == 'rcslayout') {
		if ($mts_options['mts_single_post_layout'] == 'rclayout') {
			$mts_shareit_right = '.shareit { margin: 0 0 0 -282px; }';
		}
	}
	if($mts_options['mts_layout'] == 'scrlayout' || $mts_options['mts_layout'] == 'srclayout' || $mts_options['mts_layout'] == 'sclayout') {
		if ($mts_options['mts_single_post_layout'] == 'rclayout') {
			$mts_shareit_right = '.shareit { margin: 0 0 0 571px; }';
		} elseif ($mts_options['mts_single_post_layout'] == 'crlayuot' || $mts_options['mts_single_post_layout'] == 'cbrlayout' || $mts_options['mts_single_post_layout'] == 'clayout') {
			$mts_shareit_right = '.shareit { margin: 0 0 0 748px; }';
		}
	}
	if($mts_options['mts_author_comment'] == '1') {
		$mts_author = '
			.commentlist .children li.bypostauthor:after { content: "'.__('Author','mythemeshop').'"; position: absolute; right: -1px; top: -1px; padding: 0 14px; color: #fff; }';
	}
	if($mts_options['mts_single_post_layout'] == 'crlayuot') {
		$mts_single_layout = '
			.single_post { float: left; }
			.related-posts { float: right; }';
	}elseif($mts_options['mts_single_post_layout'] == 'clayout' || $mts_options['mts_single_post_layout'] == 'cbrlayout') {
		$mts_single_layout = '
			.single_post { width: 100%; } .related-posts { width: 100%; margin-top: 30px; } .related-posts li { width: 20.5%; margin-right: 6%; } .rpexcerpt2.last { margin-right: 6%; }';
	}
	
	$custom_css = "
		body {background-color:{$mts_options['mts_bg_color']}; }
		body {background-image: url({$mts_bg});}
		input#author:focus, input#email:focus, input#url:focus,#contactForm textarea:focus,#commentform textarea:focus { border-color:{$mts_options['mts_color_scheme']};}
		.menu .current-menu-item > a, .menu .current-menu-item, .current-menu-ancestor > a.sf-with-ul, .current-menu-ancestor, footer .textwidget a, .single_post a, #commentform a, .copyrights a:hover, a, footer .widget li a:hover, .menu > li:hover > a, #navigation [class^='icon-']:hover, #navigation [class*=' icon-']:hover, .title a, .single_post .post-info a, .post-info a, .readMore a, .sidebar.c-4-12 a, .copyrights a, .related-posts a, .postauthor h5, .reply a, .fn a, .woocommerce .woocommerce-breadcrumb a, .woocommerce-page .woocommerce-breadcrumb a { color:{$mts_options['mts_color_scheme']}; }	
		.contact-submit, .nav-previous a, .nav-next a, .header-button, .sub-menu, #commentform input#submit, .tagcloud a, .mts-subscribe .icon-envelope, #searchform .icon-search, .currenttext, .pagination a:hover, .woocommerce a.button, .woocommerce-page a.button, .woocommerce button.button, .woocommerce-page button.button, .woocommerce input.button, .woocommerce-page input.button, .woocommerce #respond input#submit, .woocommerce-page #respond input#submit, .woocommerce #content input.button, .woocommerce-page #content input.button, .commentlist .children li.bypostauthor:after, .woocommerce nav.woocommerce-pagination ul li span.current, .woocommerce-page nav.woocommerce-pagination ul li span.current, .woocommerce #content nav.woocommerce-pagination ul li span.current, .woocommerce-page #content nav.woocommerce-pagination ul li span.current, .woocommerce nav.woocommerce-pagination ul li a:hover, .woocommerce-page nav.woocommerce-pagination ul li a:hover, .woocommerce #content nav.woocommerce-pagination ul li a:hover, .woocommerce-page #content nav.woocommerce-pagination ul li a:hover, .woocommerce nav.woocommerce-pagination ul li a:focus, .woocommerce-page nav.woocommerce-pagination ul li a:focus, .woocommerce #content nav.woocommerce-pagination ul li a:focus, .woocommerce-page #content nav.woocommerce-pagination ul li a:focus, .slidertitle, #tabber ul.tabs li a.selected, .carousel .flex-caption, .carousel .flex-direction-nav a:hover, .flex-control-paging li a.flex-active, .flex-control-paging li a:hover, .woocommerce .bypostauthor:after, #move-to-top { background-color:{$mts_options['mts_color_scheme']}; color: #fff; }
		a:hover, .title a:hover, .sidebar.c-4-12 a:hover, .copyrights a:hover, .single_post .post-info a:hover, .post-info a:hover, .single_post a:hover, .fn a:hover, .menu ul li:hover > a, #navigation ul ul [class^='icon-']:hover, #navigation ul ul [class*=' icon-']:hover, h1, h2, h3, h4, h5, h6, .total-comments { color: {$mts_options['mts_color_scheme_2']};}
		.pagination .nav-previous a:hover, .pagination .nav-next a:hover, .tagcloud a:hover, #commentform input#submit:hover, .woocommerce a.button:hover, .woocommerce-page a.button:hover, .woocommerce button.button:hover, .woocommerce-page button.button:hover, .woocommerce input.button:hover, .woocommerce-page input.button:hover, .woocommerce #respond input#submit:hover, .woocommerce-page #respond input#submit:hover, .woocommerce #content input.button:hover, .woocommerce-page #content input.button:hover, #contactForm #submit:hover, #move-to-top:hover { background-color:{$mts_options['mts_color_scheme_2']}; }
		{$mts_shareit_left}
		{$mts_header_section}
		{$mts_sclayout}
		{$mts_single_layout}
		{$mts_shareit_right}
		{$mts_author}
		{$mts_options['mts_custom_css']}
			";
	wp_add_inline_style( 'stylesheet', $custom_css );
}
add_action('wp_enqueue_scripts', 'mts_enqueue_css', 99);

/*-----------------------------------------------------------------------------------*/
/*  Enable Widgetized sidebar
/*-----------------------------------------------------------------------------------*/
if ( function_exists('register_sidebar') )
	register_sidebar(array(
		'name'=>'Home Sidebar',
		'description'   => __( 'Appears on homepage', 'mythemeshop' ),
		'before_widget' => '<li id="%1$s" class="widget widget-sidebar %2$s">',
		'after_widget' => '</li>',
		'before_title' => '<h3>',
		'after_title' => '</h3>',
	));
	register_sidebar(array(
		'name'=>'Sidebar',
		'description'   => __( 'Appears on posts and pages', 'mythemeshop' ),
		'before_widget' => '<li id="%1$s" class="widget widget-sidebar %2$s">',
		'after_widget' => '</li>',
		'before_title' => '<h3>',
		'after_title' => '</h3>',
	));
	register_sidebar(array(
		'name' => 'Header Ad',
		'description'   => __( 'Appears in Header', 'mythemeshop' ),
		'id' => 'widget-header' ,
		'before_widget' => '<div class="widget-header">',
		'after_widget' => '</div>',
		'before_title' => '',
		'after_title' => ''
	));
	register_sidebar(array(
		'name' => '1st Footer',
		'description'   => __( 'Appears in first column of footer.', 'mythemeshop' ),
		'id' => 'footer-1',
		'before_widget' => '<div class="f-widget f-widget-1"><div id="%1$s" class="widget %2$s">',
		'after_widget' => '</div></div>',
		'before_title' => '<h3 class="widget-title">',
		'after_title' => '</h3>',
	));
	register_sidebar(array(
		'name' => '2nd Footer',
		'description'   => __( 'Appears in second column of footer.', 'mythemeshop' ),
		'id' => 'footer-2',
		'before_widget' => '<div class="f-widget f-widget-2"><div id="%1$s" class="widget %2$s">',
		'after_widget' => '</div></div>',
		'before_title' => '<h3 class="widget-title">',
		'after_title' => '</h3>',
	));
	register_sidebar(array(
		'name' => '3rd Footer',
		'description'   => __( 'Appears in third column of footer.', 'mythemeshop' ),
		'id' => 'footer-3',
		'before_widget' => '<div class="f-widget f-widget-3 last"><div id="%1$s" class="widget %2$s">',
		'after_widget' => '</div></div>',
		'before_title' => '<h3 class="widget-title">',
		'after_title' => '</h3>',
	));

/*-----------------------------------------------------------------------------------*/
/*  Load Widgets & Shortcodes
/*-----------------------------------------------------------------------------------*/
// Add the 125x125 Ad Block Custom Widget
include("functions/widget-ad125.php");

// Add the 300x250 Ad Block Custom Widget
include("functions/widget-ad300.php");

// Add the 728x90 Ad Block Custom Widget
include("functions/widget-ad728.php");

// Add the Tabbed Custom Widget
include("functions/widget-tabs.php");

// Add the Latest Tweets Custom Widget
include("functions/widget-tweets.php");

// Add the Theme Shortcodes
include("functions/theme-shortcodes.php");

// Add Recent Posts Widget
include("functions/widget-recentposts.php");

// Add Popular Posts Widget
include("functions/widget-popular.php");

// Add Related Posts Widget
include("functions/widget-relatedposts.php");

// Add Facebook Like box Widget
include("functions/widget-fblikebox.php");

// Add Google Plus box Widget
include("functions/widget-googleplus.php");

// Add Subscribe Widget
include("functions/widget-subscribe.php");

// Add Social Profile Widget
include("functions/widget-social.php");

// Add Category Posts Widget
include("functions/widget-catposts.php");

// Add Welcome message
include("functions/welcome-message.php");

// Theme Functions
include("functions/theme-actions.php");

if($mts_options['mts_theme_update'] == '1') {
// Update Notification
include("functions/update_notifier.php");
}

/*-----------------------------------------------------------------------------------*/
/*	Filters customize wp_title
/*-----------------------------------------------------------------------------------*/
function mts_wp_title( $title, $sep ) {
	global $paged, $page;

	if ( is_feed() )
		return $title;

	// Add the site name.
	$title .= get_bloginfo( 'name' );

	// Add the site description for the home/front page.
	$site_description = get_bloginfo( 'description', 'display' );
	if ( $site_description && ( is_home() || is_front_page() ) )
		$title = "$title $sep $site_description";

	// Add a page number if necessary.
	if ( $paged >= 2 || $page >= 2 )
		$title = "$title $sep " . sprintf( __( 'Page %s', 'mythemeshop' ), max( $paged, $page ) );

	return $title;
}
add_filter( 'wp_title', 'mts_wp_title', 10, 2 );

/*-----------------------------------------------------------------------------------*/
/*  Filters that allow shortcodes in Text Widgets
/*-----------------------------------------------------------------------------------*/
add_filter('widget_text', 'shortcode_unautop');
add_filter('widget_text', 'do_shortcode');
add_filter('the_content_rss', 'do_shortcode');

/*-----------------------------------------------------------------------------------*/
/*	Custom Gravatar Support
/*-----------------------------------------------------------------------------------*/
if( !function_exists( 'mts_custom_gravatar' ) ) {
    function mts_custom_gravatar( $avatar_defaults ) {
        $mts_avatar = get_template_directory_uri() . '/images/gravatar.png';
        $avatar_defaults[$mts_avatar] = 'Custom Gravatar (/images/gravatar.png)';
        return $avatar_defaults;
    }
    add_filter( 'avatar_defaults', 'mts_custom_gravatar' );
}

/*-----------------------------------------------------------------------------------*/
/*  Custom Comments template
/*-----------------------------------------------------------------------------------*/
function mts_comment($comment, $args, $depth) {
	$GLOBALS['comment'] = $comment; ?>
	<li <?php comment_class(); ?> id="li-comment-<?php comment_ID() ?>">
		<div id="comment-<?php comment_ID(); ?>" style="position:relative;">
			<div class="comment-author vcard">
				<?php echo get_avatar( $comment->comment_author_email, 80 ); ?>
				<?php printf(__('<div class="fn">%s</div>', 'mythemeshop'), get_comment_author_link()) ?> 
				<span class="comment-meta">
					<?php $mts_options = get_option('frontpage'); if($mts_options['mts_comment_date'] == '1') { ?>
						<span class="thetime"><?php comment_date('F j, Y'); ?></span>
					<?php } ?>
				</span>
				<span class="reply">
					 | <?php comment_reply_link(array_merge( $args, array('depth' => $depth, 'max_depth' => $args['max_depth']))) ?>
						 <?php edit_comment_link(__('(Edit)', 'mythemeshop'),'  ','') ?>
				</span>
			</div>
			<?php if ($comment->comment_approved == '0') : ?>
				<em><?php _e('Your comment is awaiting moderation.', 'mythemeshop') ?></em>
				<br />
			<?php endif; ?>
			<div class="commentmetadata">
				<?php comment_text() ?>
			</div>
		</div>
	</li>
<?php }

/*-----------------------------------------------------------------------------------*/
/*  Custom Menu Support
/*-----------------------------------------------------------------------------------*/
add_theme_support( 'menus' );
if ( function_exists( 'register_nav_menus' ) ) {
    register_nav_menus(
        array(
          'primary-menu' => 'Primary Menu'
        )
    );
}

/*-----------------------------------------------------------------------------------*/
/*  excerpt
/*-----------------------------------------------------------------------------------*/
function excerpt($limit) {
  $excerpt = explode(' ', get_the_excerpt(), $limit);
  if (count($excerpt)>=$limit) {
    array_pop($excerpt);
    $excerpt = implode(" ",$excerpt);
  } else {
    $excerpt = implode(" ",$excerpt);
  }
  $excerpt = preg_replace('`[[^]]*]`','',$excerpt);
  return $excerpt;
}

/*-----------------------------------------------------------------------------------*/
/* nofollow to next/previous links
/*-----------------------------------------------------------------------------------*/
function pagination_add_nofollow($content) {
    return 'rel="nofollow"';
}
add_filter('next_posts_link_attributes', 'pagination_add_nofollow' );
add_filter('previous_posts_link_attributes', 'pagination_add_nofollow' );

/*-----------------------------------------------------------------------------------*/
/* Nofollow to category links
/*-----------------------------------------------------------------------------------*/
add_filter( 'the_category', 'add_nofollow_cat' ); 
function add_nofollow_cat( $text ) {
$text = str_replace('rel="category tag"', 'rel="nofollow"', $text); return $text; }

/*-----------------------------------------------------------------------------------*/ 
/* nofollow post author link
/*-----------------------------------------------------------------------------------*/
add_filter('the_author_posts_link', 'mts_nofollow_the_author_posts_link');
function mts_nofollow_the_author_posts_link ($link) {
return str_replace('<a href=', '<a rel="nofollow" href=',$link); }

/*-----------------------------------------------------------------------------------*/ 
/* nofollow to reply links
/*-----------------------------------------------------------------------------------*/
function add_nofollow_to_reply_link( $link ) {
return str_replace( '")\'>', '")\' rel=\'nofollow\'>', $link );
}
add_filter( 'comment_reply_link', 'add_nofollow_to_reply_link' );

/*-----------------------------------------------------------------------------------*/
/* removes detailed login error information for security
/*-----------------------------------------------------------------------------------*/
add_filter('login_errors',create_function('$a', "return null;"));
    
/*-----------------------------------------------------------------------------------*/
/* removes the WordPress version from your header for security
/*-----------------------------------------------------------------------------------*/
function wb_remove_version() {
    return '<!--Theme by MyThemeShop.com-->';
}
add_filter('the_generator', 'wb_remove_version');
    
/*-----------------------------------------------------------------------------------*/
/* Removes Trackbacks from the comment count
/*-----------------------------------------------------------------------------------*/
add_filter('get_comments_number', 'mts_comment_count', 0);
function mts_comment_count( $count ) {
    if ( ! is_admin() ) {
        global $id;
        $comments_by_type = &separate_comments(get_comments('status=approve&post_id=' . $id));
        return count($comments_by_type['comment']);
    } else {
        return $count;
    }
}

/*-----------------------------------------------------------------------------------*/
/* adds a class to the post if there is a thumbnail
/*-----------------------------------------------------------------------------------*/
function has_thumb_class($classes) {
    global $post;
    if( has_post_thumbnail($post->ID) ) { $classes[] = 'has_thumb'; }
        return $classes;
}
add_filter('post_class', 'has_thumb_class');

/*-----------------------------------------------------------------------------------*/	
/* Breadcrumb
/*-----------------------------------------------------------------------------------*/
function mts_the_breadcrumb() {
	echo '<a href="';
	echo home_url();
	echo '" rel="nofollow"><i class="icon-home"></i>&nbsp;'.__('Home','mythemeshop');
	echo "</a>";
	if (is_category() || is_single()) {
		echo "&nbsp;/&nbsp;";
		the_category(' &bull; ');
			if (is_single()) {
				echo "&nbsp;/&nbsp;";
				the_title();
			}
	} elseif (is_page()) {
		echo "&nbsp;/&nbsp;";
		echo the_title();
	} elseif (is_search()) {
		echo "&nbsp;/&nbsp;".__('Search Results for','mythemeshop')."... ";
		echo '"<em>';
		echo the_search_query();
		echo '</em>"';
	}
}

/*-----------------------------------------------------------------------------------*/ 
/* Pagination
/*-----------------------------------------------------------------------------------*/
function pagination($pages = '', $range = 3) { 
    $showitems = ($range * 3)+1;
    global $paged; if(empty($paged)) $paged = 1;
    if($pages == '') {
        global $wp_query; $pages = $wp_query->max_num_pages; 
        if(!$pages){ $pages = 1; } 
    }
    if(1 != $pages) { 
        echo "<div class='pagination'><ul>";
        if($paged > 2 && $paged > $range+1 && $showitems < $pages) 
            echo "<li><a rel='nofollow' href='".get_pagenum_link(1)."'>&laquo; First</a></li>";
        if($paged > 1 && $showitems < $pages) 
            echo "<li><a rel='nofollow' href='".get_pagenum_link($paged - 1)."' class='inactive'>&lsaquo; Previous</a></li>";
        for ($i=1; $i <= $pages; $i++){ 
            if (1 != $pages &&( !($i >= $paged+$range+1 || $i <= $paged-$range-1) || $pages <= $showitems )) { 
                echo ($paged == $i)? "<li class='current'><span class='currenttext'>".$i."</span></li>":"<li><a rel='nofollow' href='".get_pagenum_link($i)."' class='inactive'>".$i."</a></li>";
            } 
        } 
        if ($paged < $pages && $showitems < $pages) 
            echo "<li><a rel='nofollow' href='".get_pagenum_link($paged + 1)."' class='inactive'>Next &rsaquo;</a></li>";
        if ($paged < $pages-1 &&  $paged+$range-1 < $pages && $showitems < $pages) 
            echo "<a rel='nofollow' class='inactive' href='".get_pagenum_link($pages)."'>Last &raquo;</a>";
            echo "</ul></div>"; 
    }
}

/*-----------------------------------------------------------------------------------*/
/* Redirect feed to feedburner
/*-----------------------------------------------------------------------------------*/
$mts_options = get_option('frontpage');
if ( $mts_options['mts_feedburner'] != '') {
function mts_rss_feed_redirect() {
    $mts_options = get_option('frontpage');
    global $feed;
    $new_feed = $mts_options['mts_feedburner'];
    if (!is_feed()) {
            return;
	}
    if (preg_match('/feedburner/i', $_SERVER['HTTP_USER_AGENT'])){
            return;
    }
    if ($feed != 'comments-rss2') {
            if (function_exists('status_header')) status_header( 302 );
            header("Location:" . $new_feed);
            header("HTTP/1.1 302 Temporary Redirect");
            exit();
    }
}
add_action('template_redirect', 'mts_rss_feed_redirect');
}

$mts_options = get_option('frontpage');
if ( $mts_options['mts_admin_style'] == '1') {
function mts_admin_css() {
	wp_enqueue_style( 'admin_css', get_template_directory_uri() . '/css/admin.css' );
}
add_action('admin_print_styles', 'mts_admin_css' );
function mts_remove_footer_admin () {
    echo "Thank you for creating with <a href=\"http://wordpress.org/\">WordPress</a>. Dashboard Customization by <a href=\"http://mythemeshop.com/\">MyThemeShop</a>.";
} 
add_filter('admin_footer_text', 'mts_remove_footer_admin');
}

/*-----------------------------------------------------------------------------------*/
/* WooCommerce
/*-----------------------------------------------------------------------------------*/
if ( in_array( 'woocommerce/woocommerce.php', apply_filters( 'active_plugins', get_option( 'active_plugins' ) ) ) ) {
add_theme_support('woocommerce');

// Register Shop and Single Product Sidebar
register_sidebar(array(
	'name' => 'Shop Page Sidebar',
	'description'   => __( 'Appears on Shop main page and product archive pages.', 'mythemeshop' ),
	'id' => 'shop-sidebar',
	'before_widget' => '<li id="%1$s" class="widget widget-sidebar %2$s">',
	'after_widget' => '</li>',
	'before_title' => '<h3>',
	'after_title' => '</h3>',
));
register_sidebar(array(
	'name' => 'Single Product Sidebar',
	'description'   => __( 'Appears on single product pages.', 'mythemeshop' ),
	'id' => 'product-sidebar',
	'before_widget' => '<li id="%1$s" class="widget widget-sidebar %2$s">',
	'after_widget' => '</li>',
	'before_title' => '<h3>',
	'after_title' => '</h3>',
));

// Change number or products per row to 3
add_filter('loop_shop_columns', 'loop_columns');
if (!function_exists('loop_columns')) {
	function loop_columns() {
		return 3; // 3 products per row
	}
}

// Redefine woocommerce_output_related_products()
function woocommerce_output_related_products() {
woocommerce_related_products(3,1); // Display 3 products in rows of 1
}

/*** Hook in on activation */
global $pagenow;
if ( is_admin() && isset( $_GET['activated'] ) && $pagenow == 'themes.php' ) add_action( 'init', 'mythemeshop_woocommerce_image_dimensions', 1 );
 
/*** Define image sizes */
function mythemeshop_woocommerce_image_dimensions() {
  	$catalog = array(
		'width' 	=> '223',
		'height'	=> '223',
		'crop'		=> 1
	);
	$single = array(
		'width' 	=> '440',
		'height'	=> '600',
		'crop'		=> 1
	);
	$thumbnail = array(
		'width' 	=> '75',
		'height'	=> '75',
		'crop'		=> 1
	); 
	// Image sizes
	update_option( 'shop_catalog_image_size', $catalog ); 		// Product category thumbs
	update_option( 'shop_single_image_size', $single ); 		// Single product image
	update_option( 'shop_thumbnail_image_size', $thumbnail ); 	// Image gallery thumbs
}

add_filter ( 'woocommerce_product_thumbnails_columns', 'mts_thumb_cols' );
 function mts_thumb_cols() {
     return 4; // .last class applied to every 4th thumbnail
 }
}

// Display 24 products per page. Goes in functions.php
$mts_home_producst = $mts_options['mts_shop_products'];
add_filter( 'loop_shop_per_page', create_function( '$cols', 'return '.$mts_home_producst.';' ), 20 );

/*-----------------------------------------------------------------------------------*/
/* Single Post Pagination
/*-----------------------------------------------------------------------------------*/
function wp_link_pages_args_prevnext_add($args)
{
    global $page, $numpages, $more, $pagenow;
    if (!$args['next_or_number'] == 'next_and_number')
        return $args; 
    $args['next_or_number'] = 'number'; 
    if (!$more)
        return $args; 
    if($page-1) 
        $args['before'] .= _wp_link_page($page-1)
        . $args['link_before']. $args['previouspagelink'] . $args['link_after'] . '</a>'
    ;
    if ($page<$numpages) 
    
        $args['after'] = _wp_link_page($page+1)
        . $args['link_before'] . $args['nextpagelink'] . $args['link_after'] . '</a>'
        . $args['after']
    ;
    return $args;
}
add_filter('wp_link_pages_args', 'wp_link_pages_args_prevnext_add');

/*-----------------------------------------------------------------------------------*/
/* add <!-- next-page --> button to tinymce
/*-----------------------------------------------------------------------------------*/
add_filter('mce_buttons','wysiwyg_editor');
function wysiwyg_editor($mce_buttons) {
   $pos = array_search('wp_more',$mce_buttons,true);
   if ($pos !== false) {
       $tmp_buttons = array_slice($mce_buttons, 0, $pos+1);
       $tmp_buttons[] = 'wp_page';
       $mce_buttons = array_merge($tmp_buttons, array_slice($mce_buttons, $pos+1));
   }
   return $mce_buttons;
}

?>