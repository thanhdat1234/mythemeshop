<?php $mts_options = get_option('frontpage'); ?>
		</div><!--.content-->
	</div><!--#page-->
</div><!--.main-container-->
<footer>
	<div class="footer-widgets">
		<div class="footer-widget1 footer-widget"><?php if ( !function_exists('dynamic_sidebar') || !dynamic_sidebar('1st Footer') ) : ?><?php endif; ?></div>
		<div class="footer-widget2 footer-widget"><?php if ( !function_exists('dynamic_sidebar') || !dynamic_sidebar('2nd Footer') ) : ?><?php endif; ?></div>
		<div class="footer-widget3 footer-widget"><?php if ( !function_exists('dynamic_sidebar') || !dynamic_sidebar('3rd Footer') ) : ?><?php endif; ?></div>
	</div><!--.footer-widgets-->
</footer><!--footer-->
<div class="copyrights"><?php mts_copyrights_credit(); ?></div>
<?php mts_footer(); ?>
<?php wp_footer(); ?>
</body>
</html>