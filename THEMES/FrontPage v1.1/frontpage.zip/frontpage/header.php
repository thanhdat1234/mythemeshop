<!DOCTYPE html>
<?php $mts_options = get_option('frontpage'); ?>
<html class="no-js" <?php language_attributes(); ?>>
<head>
	<meta charset="<?php bloginfo('charset'); ?>">
	<!-- Always force latest IE rendering engine (even in intranet) & Chrome Frame -->
	<!--[if IE ]>
	<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
	<![endif]-->
	<link rel="profile" href="http://gmpg.org/xfn/11" />
	<title><?php wp_title( '|', true, 'right' ); ?></title>
	<?php mts_meta(); ?>
	<link rel="pingback" href="<?php bloginfo( 'pingback_url' ); ?>" />
	<?php wp_enqueue_script("jquery"); ?>
	<?php wp_head(); ?>
</head>
<body id ="blog" <?php body_class('main'); ?> itemscope itemtype="http://schema.org/WebPage">
	<div class="main-container">
		<header class="main-header">
			<div id="header">
				<?php if ($mts_options['mts_logo'] != '') { ?>
					<?php if( is_front_page() || is_home() || is_404() ) { ?>
						<h1 id="logo" class="image-logo"><a href="<?php echo home_url(); ?>"><img src="<?php echo $mts_options['mts_logo']; ?>" alt="<?php bloginfo( 'name' ); ?>"></a></h1>
					<?php } else { ?>
						<h2 id="logo" class="image-logo"><a href="<?php echo home_url(); ?>"><img src="<?php echo $mts_options['mts_logo']; ?>" alt="<?php bloginfo( 'name' ); ?>"></a></h2>
					<?php } ?>
				<?php } else { ?>
					<?php if( is_front_page() || is_home() || is_404() ) { ?>
						<h1 id="logo" class="text-logo"><a href="<?php echo home_url(); ?>"><?php bloginfo( 'name' ); ?></a></h1>
					<?php } else { ?>
						<h2 id="logo" class="text-logo"><a href="<?php echo home_url(); ?>"><?php bloginfo( 'name' ); ?></a></h2>
					<?php } ?>
				<?php } ?>
				<?php dynamic_sidebar('Header Ad'); ?>  
				<?php if($mts_options['mts_sticky_nav'] == '1') { ?>
					<div class="clear" id="catcher"></div>
					<div id="sticky" class="secondary-navigation">
				<?php } else { ?>
					<div class="secondary-navigation">
				<?php } ?>
					<nav id="navigation" >
						<?php if ( has_nav_menu( 'primary-menu' ) ) { ?>
							<?php wp_nav_menu( array( 'theme_location' => 'primary-menu', 'menu_class' => 'menu', 'container' => '' ) ); ?>
						<?php } else { ?>
							<ul class="menu">
								<?php wp_list_categories('title_li='); ?>
							</ul>
						<?php } ?>
						<a href="#" id="pull"><?php _e('Menu','mythemeshop'); ?></a>
						<?php if ($mts_options['mts_nav_search'] == '1') { ?>
							<span id="headersearch">
								<?php include("searchform.php"); ?>
							</span>
						<?php } ?>
					</nav>
				</div>
			</div>
		</header>
		<?php if($mts_options['mts_featured_carousel'] == '1') { ?>
			<?php if (is_home() && !is_paged()) { ?>
				<div class="carousel-container loading">
					<div id="slider" class="carousel">
						<ul class="slides">
							<?php $slider_cat = 1; if($mts_options['mts_featured_carousel_cat'] != '') { $slider_cat = implode(",", $mts_options['mts_featured_carousel_cat']); } $my_query = new WP_Query('cat='.$slider_cat.'&posts_per_page=13');
								while ($my_query->have_posts()) : $my_query->the_post();
								$image_id = get_post_thumbnail_id();
								$image_url = wp_get_attachment_image_src($image_id,'carousel');
								$image_url = $image_url[0]; ?>
							<li> 
								<a href="<?php the_permalink() ?>">
									<?php if ( has_post_thumbnail() ) { ?> 
										<?php the_post_thumbnail('carousel',array('title' => '')); ?>
									<?php } else { ?>
										<div class="featured-thumbnail">
											<img src="<?php echo get_template_directory_uri(); ?>/images/116x104.png" class="attachment-featured wp-post-image" alt="<?php the_title(); ?>">
										</div>
									<?php } ?>
									<div class="flex-caption">
										<h2 class="carouseltitle"><?php the_title(); ?></h2>
									</div>
								</a> 
							</li>
							<?php endwhile; wp_reset_query(); ?>
						</ul>
					</div>
				</div>
				<!-- carousel-container -->
			<?php } ?>
		<?php } ?>
		
		<?php if($mts_options['mts_featured_carousel_single'] == '1') { ?>
			<?php if(is_singular()) { ?>
				<?php if(isset($mts_options['mts_featured_carousel'])) { if($mts_options['mts_featured_carousel'] == '1' && $mts_options['mts_featured_carousel'] != '') { ?>
					<div class="carousel-container loading">
						<div id="slider" class="carousel">
							<ul class="slides">
								<?php $slider_cat = 1; if($mts_options['mts_featured_carousel_cat'] != '') { $slider_cat = implode(",", $mts_options['mts_featured_carousel_cat']); } $my_query = new WP_Query('cat='.$slider_cat.'&posts_per_page=13');
									while ($my_query->have_posts()) : $my_query->the_post();
									$image_id = get_post_thumbnail_id();
									$image_url = wp_get_attachment_image_src($image_id,'carousel');
									$image_url = $image_url[0]; ?>
								<li> 
									<a href="<?php the_permalink() ?>">
										<?php if ( has_post_thumbnail() ) { ?> 
											<?php the_post_thumbnail('carousel',array('title' => '')); ?>
										<?php } else { ?>
											<div class="featured-thumbnail">
												<img src="<?php echo get_template_directory_uri(); ?>/images/116x104.png" class="attachment-featured wp-post-image" alt="<?php the_title(); ?>">
											</div>
										<?php } ?>
										<div class="flex-caption">
											<h2 class="carouseltitle"><?php the_title(); ?></h2>
										</div>
									</a> 
								</li>
								<?php endwhile; wp_reset_query(); ?>
							</ul>
						</div>
					</div>
					<!-- carousel-container -->
				<?php }} ?>
			<?php } ?>
		<?php } ?>