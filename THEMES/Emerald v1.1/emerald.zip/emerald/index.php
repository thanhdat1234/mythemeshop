<?php $options = get_option('emerald'); ?>
<?php get_header(); ?>
<div id="page">
	<div class="content">
		<article class="article">
			<div id="content_box">
				<?php if (is_home() && !is_paged()) { ?>
					<?php if($options['mts_featured_slider'] == '1') { ?>
						<div class="slider-container">
							<div class="flex-container">
								<div class="flexslider">
									<ul class="slides">
										<?php $my_query = new WP_Query('cat='.$options['mts_featured_slider_cat'].'&posts_per_page=3'); while ($my_query->have_posts()) : $my_query->the_post(); $image_id = get_post_thumbnail_id(); $image_url = wp_get_attachment_image_src($image_id,'slider'); $image_url = $image_url[0]; ?>
										<li data-thumb="<?php echo $image_url; ?>">
											<a href="<?php the_permalink() ?>">
												<?php the_post_thumbnail('slider',array('title' => '')); ?>
												<p class="flex-caption">
													<span class="sliderAuthor"><span> <?php _e('By:','mythemeshop'); ?></span> <?php the_author(); ?></span>
													<span class="title slidertitle"><?php the_title(); ?></span>
													<span class="slidertext"><?php echo excerpt(30); ?></span>
													<span class="sliderReadMore"><?php _e('Continue Reading ','mythemeshop'); ?>&rarr;</span>
												</p>
											</a>
										</li>
										<?php endwhile; ?>
									</ul>
								</div>
							</div>
						</div>
					<?php } ?> 
				<?php } ?> 
				<?php if (is_home() && !is_paged() ) {?>
					<?php /* Latest News------------------------------------------ */?>
					<div class="post excerpt latest_news_custom">
						<h2 class="title_top"> <span><?php _e('Latest','mythemeshop'); ?></span></h2>
						<?php $ln = 1; $my_query = new WP_Query('posts_per_page=4'); while ($my_query->have_posts()) : $my_query->the_post(); ?>
							<div class=" <?php if($ln_b_p++ ==0){ echo 'big_p_item_left';} else{ echo 'small_p_item';} if($ln_b_p22++ ==3){ echo ' last_small_rn';} else{ echo ' ';} ?>">
								<?php if($ln_b_p_a++ ==1){ echo '<div class="small_p_item">  ';} else{ echo ' ';} ?>
								<?php if($lnptumb_1++ ==0){ } else{ echo '<div class="left">';} ?>
								<?php if ( has_post_thumbnail() ) { 
									if($lnptumb++ ==0){ ?><a href="<?php the_permalink() ?>" title="<?php the_title(); ?>" rel="nofollow" id="featured-thumbnail"><?php
										echo '<div class="featured-thumbnail">';
										the_post_thumbnail('bigthumb',array('title' => ''));
										echo '</div>';
										?> </a> <?php
									} else{
										echo '<div class="left">';
										?><a href="<?php the_permalink() ?>" title="<?php the_title(); ?>" rel="nofollow" id="featured-thumbnail"><?php
										echo '<div class="featured-thumbnail">';											
										the_post_thumbnail('featured',array('title' => ''));
										echo '</div>';
										?> </a>
									<?php echo '</div>'; } ?>
								<?php } ?>
								<?php if($lnptumb_2++ ==0){} else{ echo '</div>';} ?>
									<div class="info_ln">
										<h2 class="title_ln">
											<a href="<?php the_permalink() ?>" title="<?php the_title(); ?>" rel="bookmark"><?php the_title(); ?></a>
										</h2>
										<?php if($lnpexerpt_2++ ==0){ ?>
											<span class="excerpt_ln"><?php echo excerpt(50);?></span>
										<?php } else{ ?>
											<span class="excerpt_ln"><?php echo excerpt(9);?></span>
										<?php } ?>
										<?php if($lnmeta_2++ ==0){} else{ ?>
											<?php if($options['mts_headline_meta'] == '1') { ?>
											<br/><span class="custom_meta"><span><?php the_time('F, d Y'); ?> </span>, <span><a href="<?php comments_link(); ?>"><?php comments_number('No Comments','1 Comment','% Comments'); ?></a></span></span>
											<?php }?>
										<?php }?>                                
									</div><!--.header-->                            
									<?php if($lnreadmore++ ==0){ ?>
										<div class="readMore"><a href="<?php the_permalink() ?>" title="<?php the_title(); ?>" rel="bookmark"><?php _e('Read More','mythemeshop'); ?></a></div>
									<?php } ?>
								<?php if($ln_b_p_b++ ==3){ echo '</div>  ';} else{ echo ' ';} ?>
							</div>
						<?php endwhile; ?>
						<div class="latest_posts"><a href="<?php echo home_url(); ?>/latest"><?php _e('View all latest articles','mythemeshop'); ?></a></div>
					</div>

					<?php /* Popular News------------------------------------------ */?>
					<div class="post excerpt popular_news_custom">
						<?php $featured_cat = $options['mts_popular_news_cat_a'];  ?>
						<h2 class="title_top"><span><?php echo get_cat_name( $featured_cat); ?></span></h2>
						<div class="popular_news_container">
							<?php $my_query = new WP_Query('cat='.$options['mts_popular_news_cat_a'].'&posts_per_page=4'); while ($my_query->have_posts()) : $my_query->the_post(); ?>
							<div class="popular_news_post <?php if($j++ ==0){ echo 'pn_first';} else{ echo 'pn_after'; } if($pncenter++ ==2||$pncenter++ ==4){ echo ' pn_center';}?>">                           
								<?php if ( has_post_thumbnail() ) { 
									if($bfc++ ==0){
										?><a href="<?php the_permalink() ?>" title="<?php the_title(); ?>" rel="nofollow" id="featured-thumbnail"><?php
										echo '<div class="featured-thumbnail">';
										the_post_thumbnail('bigthumb',array('title' => ''));
										echo '</div>';
										?> </a> <?php
									}
									else{
										echo '<div class="left">';
										?><a href="<?php the_permalink() ?>" title="<?php the_title(); ?>" rel="nofollow" id="featured-thumbnail"><?php
										echo '<div class="featured-thumbnail">';											
										the_post_thumbnail('featured',array('title' => ''));
										echo '</div>';
										?> </a> <?php
										echo '</div>';
										}										 
									?>
								<?php } ?>
								<div class="info_pn">
									<h2 class="title_pn"><a href="<?php the_permalink() ?>" title="<?php the_title(); ?>" rel="bookmark"><?php the_title(); ?></a></h2>
									<?php if($bfce++ ==0){ ?> <span class="excerpt_pn"><?php echo excerpt(25);?></span> <?php } else{ ?><span class="excerpt_pn"><?php echo excerpt(9);?></span><?php } ?>    
									<?php if($options['mts_headline_meta'] == '1') { ?>									
										<br/><span class="custom_meta"><span><?php the_time('F, d Y'); ?> </span>, <span><a href="<?php comments_link(); ?>"><?php comments_number('No Comments','1 Comment','% Comments'); ?></a></span></span>  
									<?php } ?>
								</div><!--.header-->
								<div class="readMore"><a href="<?php the_permalink() ?>" title="<?php the_title(); ?>" rel="bookmark"><?php _e('Read More','mythemeshop'); ?></a></div>
							</div>
							<?php endwhile; ?>
						</div>
						
						<?php /* Popular News Part 2*/?>
						<div class="popular_news_container popular_news_container2">
							<?php $my_query = new WP_Query('cat='.$options['mts_popular_news_cat_b'].'&posts_per_page=4'); while ($my_query->have_posts()) : $my_query->the_post(); ?>
							<div class="popular_news_post <?php if($j2++ ==0){ echo 'pn_first';} else{ echo 'pn_after'; } if($pncenter2++ ==2||$pncenter2++ ==4){ echo ' pn_center';}?>">
								<?php if ( has_post_thumbnail() ) { 
									if($bfc2++ ==0){
										?><a href="<?php the_permalink() ?>" title="<?php the_title(); ?>" rel="nofollow" id="featured-thumbnail"><?php
										echo '<div class="featured-thumbnail">';
										the_post_thumbnail('bigthumb',array('title' => ''));
										echo '</div>';
										?> </a> <?php
									}
									else{
										echo '<div class="left">';
										?><a href="<?php the_permalink() ?>" title="<?php the_title(); ?>" rel="nofollow" id="featured-thumbnail"><?php
										echo '<div class="featured-thumbnail">';											
										the_post_thumbnail('featured',array('title' => ''));
										echo '</div>';
										?> </a> <?php
										echo '</div>';
										}										 
									?>
								<?php } ?>
								<div class="info_pn">
									<h2 class="title_pn"> <a href="<?php the_permalink() ?>" title="<?php the_title(); ?>" rel="bookmark"><?php the_title(); ?></a> </h2>
									<?php if($bfce2++ ==0){ ?> <span class="excerpt_pn"><?php echo excerpt(25);?></span> <?php } else{ ?><span class="excerpt_pn"><?php echo excerpt(9);?></span><?php } ?>
									<?php if($options['mts_headline_meta'] == '1') { ?>	
										<br/><span class="custom_meta"><span><?php the_time('F, d Y'); ?> </span>, <span><a href="<?php comments_link(); ?>"><?php comments_number('No Comments','1 Comment','% Comments'); ?></a></span></span>
									<?php } ?>
								</div><!--.header-->
								<div class="readMore"><a href="<?php the_permalink() ?>" title="<?php the_title(); ?>" rel="bookmark"><?php _e('Read More','mythemeshop'); ?></a></div>
							</div>
							<?php endwhile; ?>
						</div>
					</div>          
							
					<?php /* Random Article------------------------------------------ */?>
					<div class="post excerpt random_article">
						<?php $featured_cat = $options['mts_random_articles'];  ?>
						<h2 class="title_top"><span><?php echo get_cat_name( $featured_cat); ?></span></h2>
						<?php $my_query = new WP_Query('cat='.$options['mts_random_articles'].'&posts_per_page=6'); while ($my_query->have_posts()) : $my_query->the_post(); ?>
							<span class="<?php echo (++$raj % 3 == 0) ? 'ra_last' : ''; ?>">
								<div class="random_article_post">
									<a href="<?php the_permalink() ?>" title="<?php the_title(); ?>" rel="nofollow" id="featured-thumbnail">
										<?php if ( has_post_thumbnail() ) { ?> 
											<?php echo '<div class="featured-thumbnail">'; the_post_thumbnail('randthumb',array('title' => '')); echo '</div>'; ?>
										<?php } ?>
									</a>
									<div class="info_ar">
										<h2 class="title_ar"> <a href="<?php the_permalink() ?>" title="<?php the_title(); ?>" rel="bookmark"><?php the_title(); ?></a> </h2>                
										<div class="post-content"><?php echo excerpt(9);?></div>
									</div><!--.header-->
									<div class="readMore"><a href="<?php the_permalink() ?>" title="<?php the_title(); ?>" rel="bookmark"><?php _e('Read More','mythemeshop'); ?></a></div>
								</div>
							</span>
						<?php endwhile; ?>
					</div>
					
					<?php /*Random News ------------------------------------------ */?>
					<div class="post excerpt random_news_custom">
						<?php $featured_cat = $options['mts_random_news'];  ?>
						<h2 class="title_top"><span><?php echo get_cat_name( $featured_cat); ?></span></h2>
						<?php $my_query = new WP_Query('cat='.$options['mts_random_news'].'&posts_per_page=4'); while ($my_query->have_posts()) : $my_query->the_post(); ?>
							<div class=" <?php if($rm_b_p++ ==0){ echo 'big_p_item_left';} else{ echo 'small_p_item';} if($rm_b_p22++ ==3){ echo ' last_small_rn';} else{ echo ' ';} ?>">
								<?php if($rm_b_p_a++ ==1){ echo '<div class="small_p_item">  ';} else{ echo ' ';} ?>
								<?php if($rmptumb_1++ ==0){ } else{ echo '<div class="left">';} ?>
								<?php if ( has_post_thumbnail() ) { 
									if($rmptumb++ ==0){
										?><a href="<?php the_permalink() ?>" title="<?php the_title(); ?>" rel="nofollow" id="featured-thumbnail"><?php
										echo '<div class="featured-thumbnail">';
										the_post_thumbnail('bigthumb',array('title' => ''));
										echo '</div>';
										?> </a> <?php
									}
									else{
										echo '<div class="left">';
										?><a href="<?php the_permalink() ?>" title="<?php the_title(); ?>" rel="nofollow" id="featured-thumbnail"><?php
										echo '<div class="featured-thumbnail">';											
										the_post_thumbnail('featured',array('title' => ''));
										echo '</div>';
										?> </a> <?php
										echo '</div>';
										}										 
									?>
								<?php } ?>
								<?php if($rmptumb_2++ ==0){} else{ echo '</div>';} ?>
									<div class="info_ln">
										<h2 class="title_ln">
											<a href="<?php the_permalink() ?>" title="<?php the_title(); ?>" rel="bookmark"><?php the_title(); ?></a>
										</h2>
										<?php if($rmpexerpt_2++ ==0){ ?>
											<span class="excerpt_ln"><?php echo excerpt(37);?></span>                                    
										<?php } else { ?>
											<span class="excerpt_ln"><?php echo excerpt(9);?></span>
										<?php } ?>                                
										<?php if($rmmeta_2++ ==0){} else{ ?>
											<?php if($options['mts_headline_meta'] == '1') { ?>	
												<br/><span class="custom_meta"><span><?php the_time('F, d Y'); ?> </span>, <span><a href="<?php comments_link(); ?>"><?php comments_number('No Comments','1 Comment','% Comments'); ?></a></span></span>
											<?php }?>
										<?php }?>
									</div><!--.header-->
									<?php if($rmreadmore++ ==0){ ?>
										<div class="readMore"><a href="<?php the_permalink() ?>" title="<?php the_title(); ?>" rel="bookmark"><?php _e('Read More','mythemeshop'); ?></a></div>
									<?php } ?>
								<?php if($rm_b_p_b++ ==3){ echo '</div>  ';} else{ echo ' ';} ?>
							</div>
						<?php endwhile; ?>
					</div>
				<?php }	?>
			</div>
		</article>
		<?php get_sidebar(); ?>
<?php get_footer(); ?>