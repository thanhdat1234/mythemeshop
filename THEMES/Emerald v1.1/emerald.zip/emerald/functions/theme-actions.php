<?php
$options = get_option('emerald');	

/*------------[ Meta ]-------------*/
if ( ! function_exists( 'mts_meta' ) ) {
	function mts_meta() { 
	global $options
?>
<?php if ($options['mts_favicon'] != '') { ?>
<link rel="icon" href="<?php echo $options['mts_favicon']; ?>" type="image/x-icon" />
<?php } ?>
<!--iOS/android/handheld specific -->	
<link rel="apple-touch-icon" href="apple-touch-icon.png">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<meta name="apple-mobile-web-app-capable" content="yes">
<meta name="apple-mobile-web-app-status-bar-style" content="black">
<?php }
}

/*------------[ Head ]-------------*/
if ( ! function_exists( 'mts_head' ) ) {
	function mts_head() { 
	global $options
?>
<!--start fonts-->
<?php if ($options['mts_title_font'] == 'Arial') { ?>
<?php } else { ?>
<?php if ($options['mts_title_font'] != '' || $options['mts_google_title_font'] != '') { ?>
<link href="http://fonts.googleapis.com/css?family=<?php if ($options['mts_google_title_font'] != '') { ?><?php echo $options['mts_google_title_font']; ?><?php } else { ?><?php echo $options['mts_title_font']; ?><?php } ?>:400,700" rel="stylesheet" type="text/css">
<style type="text/css">
.title, h1,h2,h3,h4,h5,h6, #navigation a, .total-comments, #tabber ul.tabs li a { font-family: '<?php if ($options['mts_google_title_font'] != '') { ?><?php echo $options['mts_google_title_font']; ?><?php } else { ?><?php echo $options['mts_title_font']; ?><?php } ?>', sans-serif;}
</style>
<?php } ?>
<?php } ?>
<?php if ($options['mts_content_font'] == 'Arial') { ?>
<?php } else { ?>
<?php if ($options['mts_content_font'] != '' || $options['mts_google_content_font'] != '') { ?>
<link href="http://fonts.googleapis.com/css?family=<?php if ($options['mts_google_content_font'] != '') { ?><?php echo $options['mts_google_content_font']; ?><?php } else { ?><?php echo $options['mts_content_font']; ?><?php } ?>:400,400italic,700,700italic" rel="stylesheet" type="text/css">
<style type="text/css">
body {font-family: '<?php if ($options['mts_google_content_font'] != '') { ?><?php echo $options['mts_google_content_font']; ?><?php } else { ?><?php echo $options['mts_content_font']; ?><?php } ?>', sans-serif;}
</style>
<?php } ?>
<?php } ?>
<!--end fonts-->
<style type="text/css">
<?php if($options['mts_bg_color'] != '') { ?>
body {background-color:<?php echo $options['mts_bg_color']; ?>;}
<?php } ?>
<?php if ($options['mts_bg_pattern_upload'] != '') { ?>
body {background-image: url(<?php echo $options['mts_bg_pattern_upload']; ?>);}
<?php } else { ?>
<?php if($options['mts_bg_pattern'] != '') { ?>
body {background-image:url(<?php echo get_template_directory_uri(); ?>/images/<?php echo $options['mts_bg_pattern']; ?>.png);}
<?php } ?>
<?php } ?>
<?php if ($options['mts_color_scheme'] != '') { ?>
.slider-container .flexslider .flex-direction-nav .flex-next,
.slider-container .flex-direction-nav .flex-prev,#commentform input#submit,.readMore a:hover,.currenttext, .pagination a:hover,#searchform input[type="submit"],.copyrights,.search_li input[type="submit"],#navigation ul ul li a:hover,.secondary-navigation a:hover,.mts-subscribe input[type="submit"], #header::before, .secondary-navigation .sfHover .sf-with-ul, .tagcloud a {background-color:<?php echo $options['mts_color_scheme']; ?>; }
.title_top,.reply a,#tabber .inside li .meta a:hover,#tabber,.single_post a, a:hover, #logo a, .textwidget a, #commentform a, .copyrights a:hover, a, .top-navigation a:hover {color:<?php echo $options['mts_color_scheme']; ?>; }
#navigation ul ul, .currenttext, .pagination a:hover,.search_li #s { border-color: <?php echo $options['mts_color_scheme']; ?>; }
#tabber .tabs a.selected, footer .container { border-top-color:<?php echo $options['mts_color_scheme']; ?>; }
#tabber ul.tabs li a{ border-bottom-color:<?php echo $options['mts_color_scheme']; ?>; }
#navigation ul ul li a:hover, .copyrights { border-right-color: <?php echo $options['mts_color_scheme']; ?>; border-left-color: <?php echo $options['mts_color_scheme']; ?>; }
<?php } ?>
<?php if($options['mts_floating_social'] == '1') { ?>
.shareit { top: 305px; left: auto; z-index: 0; margin: 0 0 0 -125px; width: 90px; position: fixed; overflow: hidden; padding: 5px; background: white; border: 1px solid #ddd; border-bottom-width: 3px; }
.share-item {margin: 2px;}
<?php } ?>
<?php if ($options['mts_layout'] == 'sclayout') { ?>
.article { float: right;}
.sidebar.c-4-12 { float: left; }
<?php if($options['mts_floating_social'] == '1') { ?>
.shareit { margin: 0 675px 0; }
<?php } ?>
<?php } ?>
<?php if($options['mts_author_comment'] == '1') { ?>
.bypostauthor {border: 1px solid #EEE!important; padding: 3%!important; background: #FAFAFA; width: 94%!important;}
.bypostauthor .reply {border-bottom: 0; }
<?php } ?>
<?php echo $options['mts_custom_css']; ?>
</style>
<?php echo $options['mts_header_code']; ?>
<?php }
}

/*------------[ footer ]-------------*/
if ( ! function_exists( 'mts_footer' ) ) {
	function mts_footer() { 
	global $options
?>
<!--Twitter Button Script------>
<script>!function(d,s,id){var js,fjs=d.getElementsByTagName(s)[0];if(!d.getElementById(id)){js=d.createElement(s);js.id=id;js.src="//platform.twitter.com/widgets.js";fjs.parentNode.insertBefore(js,fjs);}}(document,"script","twitter-wjs");</script>
<script type="text/javascript">
  (function() {
    var po = document.createElement('script'); po.type = 'text/javascript'; po.async = true;
    po.src = 'https://apis.google.com/js/plusone.js';
    var s = document.getElementsByTagName('script')[0]; s.parentNode.insertBefore(po, s);
  })();
</script>
<!--Facebook Like Button Script------>
<script>(function(d, s, id) {
  var js, fjs = d.getElementsByTagName(s)[0];
  if (d.getElementById(id)) return;
  js = d.createElement(s); js.id = id;
  js.src = "//connect.facebook.net/en_US/all.js#xfbml=1&appId=136911316406581";
  fjs.parentNode.insertBefore(js, fjs);
}(document, 'script', 'facebook-jssdk'));</script>
<!--start slider-->
<?php if($options['mts_featured_slider'] == '1') { ?>
<?php if( is_home() ) { ?>
<script type="text/javascript">
    $(window).load(function(){
		$('.flexslider').flexslider({ animation: "fade", pauseOnHover: true, directionNav: true, controlNav: false, prevText: "<", nextText: ">" });
    });
</script>
<?php } ?>
<?php } ?>
<!--end slider-->
<!--start lightbox-->
<?php if($options['mts_lightbox'] == '1') { ?>
<script type="text/javascript">  
jQuery(document).ready(function($) {
$("a[href$='.jpg'], a[href$='.jpeg'], a[href$='.gif'], a[href$='.png']").prettyPhoto({
slideshow: 5000,
autoplay_slideshow: false,
animationSpeed: 'normal',
padding: 40,
opacity: 0.35,
showTitle: true,
social_tools: false
});
})
</script>
<?php } ?>
<!--end lightbox-->
<script type="text/javascript">
jQuery(document).ready(function(e) {
    (function($){
		function placholder_text(parm){
			$(parm).attr('placeholder','Search this site...');
			$(parm).focus(function(){
  				$(this).attr('placeholder','');
			});
			$(parm).focusout(function(){
			 	$(this).attr('placeholder','Search this site...');
			});
		}
		/*--------*/
		function placholder_text2(parm,parm2){
			$(parm).attr('placeholder',parm2);
			$(parm).focus(function(){
  				$(this).attr('placeholder','');
			});
			$(parm).focusout(function(){
			 	$(this).attr('placeholder',parm2);
			});
		}
		/*--------*/
		$('#s').each(function(index, element) {
           $(this).attr('placeholder','Search this site...') 
        });
		placholder_text('.sidebar #s');
		var mc = 1;
		var ml = 1;
		$('.secondary-navigation ul').each(function(index, element) { $(this).addClass('menuul'+mc++); });
		$('.secondary-navigation ul li').each(function(index, element) { $(this).addClass('menuli'+ml++); });
		$('.secondary-navigation .menuul1').append('<li class="search_li"> <form method="get" id="searchform" class="search-form" action="<?php echo home_url(); ?>" _lpchecked="1"><fieldset><input type="text" name="s" id="s" value=""><input type="submit" value=" "></fieldset></form> </li>');
		placholder_text2('input#author','Name');
		placholder_text2('input#email','EMail');
		placholder_text2('input#url','Website');
		placholder_text2('.main-header #s','Search this site...');
			
	}(jQuery));
});
</script>
<!--start footer code-->
<?php if ($options['mts_analytics_code'] != '') { ?>
<?php echo $options['mts_analytics_code']; ?>
<?php } ?>
<!--end footer code-->
<?php }
}

/*------------[ Copyrights ]-------------*/
if ( ! function_exists( 'mts_copyrights_credit' ) ) {
	function mts_copyrights_credit() { 
	global $options
?>
<!--start copyrights-->
<div class="row" id="copyright-note">
<span><a href="<?php echo home_url(); ?>/" title="<?php bloginfo('description'); ?>"><?php bloginfo('name'); ?></a> Copyright &copy; <?php echo date("Y") ?>.</span>
<div class="top"><?php echo $options['mts_copyrights']; ?>&nbsp;<a href="#top" class="toplink">Back to Top &uarr;</a></div>
</div>
<!--end copyrights-->
<?php }
}

?>