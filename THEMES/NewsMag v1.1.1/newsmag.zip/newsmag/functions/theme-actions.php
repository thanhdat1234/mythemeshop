<?php
$options = get_option('newsmag');	

/*------------[ Meta ]-------------*/
if ( ! function_exists( 'mts_meta' ) ) {
	function mts_meta() { 
	global $options
?>
<?php if ($options['mts_favicon'] != '') { ?>
<link rel="icon" href="<?php echo $options['mts_favicon']; ?>" type="image/x-icon" />
<?php } ?>
<!--iOS/android/handheld specific -->	
<link rel="apple-touch-icon" href="apple-touch-icon.png">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<meta name="apple-mobile-web-app-capable" content="yes">
<meta name="apple-mobile-web-app-status-bar-style" content="black">
<?php }
}

/*------------[ Head ]-------------*/
if ( ! function_exists( 'mts_head' ) ) {
	function mts_head() { 
	global $options
?>
<!--start fonts-->
<?php if ($options['mts_title_font'] == 'Arial') { ?>
<?php } else { ?>
<?php if ($options['mts_title_font'] != '' || $options['mts_google_title_font'] != '') { ?>
<link href="http://fonts.googleapis.com/css?family=<?php if ($options['mts_google_title_font'] != '') { ?><?php echo $options['mts_google_title_font']; ?><?php } else { ?><?php echo $options['mts_title_font']; ?><?php } ?>:400,700" rel="stylesheet" type="text/css">
<style type="text/css">
.title, h1,h2,h3,h4,h5,h6, #navigation a, #tabber ul.tabs li a { font-family: '<?php if ($options['mts_google_title_font'] != '') { ?><?php echo $options['mts_google_title_font']; ?><?php } else { ?><?php echo $options['mts_title_font']; ?><?php } ?>', sans-serif;}
</style>
<?php } ?>
<?php } ?>
<?php if ($options['mts_content_font'] == 'Arial') { ?>
<?php } else { ?>
<?php if ($options['mts_content_font'] != '' || $options['mts_google_content_font'] != '') { ?>
<link href="http://fonts.googleapis.com/css?family=<?php if ($options['mts_google_content_font'] != '') { ?><?php echo $options['mts_google_content_font']; ?><?php } else { ?><?php echo $options['mts_content_font']; ?><?php } ?>:400,400italic,700,700italic" rel="stylesheet" type="text/css">
<style type="text/css">
body {font-family: '<?php if ($options['mts_google_content_font'] != '') { ?><?php echo $options['mts_google_content_font']; ?><?php } else { ?><?php echo $options['mts_content_font']; ?><?php } ?>', sans-serif;}
</style>
<?php } ?>
<?php } ?>
<!--end fonts-->
<style type="text/css">
<?php if($options['mts_bg_color'] != '') { ?>
body {background-color:<?php echo $options['mts_bg_color']; ?>;}
<?php } ?>
<?php if ($options['mts_bg_pattern_upload'] != '') { ?>
body {background-image: url(<?php echo $options['mts_bg_pattern_upload']; ?>);}
<?php } else { ?>
<?php if($options['mts_bg_pattern'] != '') { ?>
body {background-image:url(<?php echo get_template_directory_uri(); ?>/images/<?php echo $options['mts_bg_pattern']; ?>.png);}
<?php } ?>
<?php } ?>
<?php if ($options['mts_color_scheme'] != '') { ?>
.secondary-navigation #navigation ul li li a:hover, .main-navigation #navigation ul li li a:hover, .mts-subscribe input[type="submit"], .readMore a, .secondary-navigation a:hover, #search-image, #commentform input#submit, .currenttext, .pagination a:hover, .flex-direction-nav li a, .flex-caption .sliderReadMore a, .secondary-navigation .current-menu-item a, .secondary-navigation .current_page_item a {background-color:<?php echo $options['mts_color_scheme']; ?>; }
.frontTitle, .post-info time, .main-navigation a:hover, .post-info a, #tabber .inside li .meta time, .single_post a, a:hover, .textwidget a, #commentform a, #tabber .inside li a:hover, footer .widget li a:hover, .copyrights a:hover, a, .sidebar.c-4-12 a:hover {color:<?php echo $options['mts_color_scheme']; ?>; }
.main-navigation {border-color:<?php echo $options['mts_color_scheme']; ?>; }
.tagcloud a { border-left-color:<?php echo $options['mts_color_scheme']; ?>; }
<?php } ?>
	<?php if($options['mts_floating_social'] == '1') { ?>
		.shareit { top: 280px; left: auto; z-index: 0; margin: 0 0 0 -126px; width: 90px; position: fixed; overflow: hidden; padding: 5px; background: #fff; -webkit-box-shadow: 1px 2px 3px rgba(50, 50, 50, 0.35);
		-moz-box-shadow: 1px 2px 3px rgba(50, 50, 50, 0.35);
		box-shadow: 1px 2px 3px rgba(50, 50, 50, 0.35);}
		.share-item {margin: 2px;}
	<?php } ?>
<?php if ($options['mts_layout'] == 'sclayout') { ?>
.article { float: right;}
.sidebar.c-4-12 { float: left; }
<?php if($options['mts_floating_social'] == '1') { ?>
			.shareit { margin: 0 625px 0;}
		<?php } ?>
<?php } ?>
<?php if($options['mts_author_comment'] == '1') { ?>
.bypostauthor {border: 1px solid #EEE!important; padding: 3% 3% 0 3%!important; background: #FAFAFA; width: 94%!important;}
.bypostauthor .reply {border-bottom: 0; }
<?php } ?>
<?php echo $options['mts_custom_css']; ?>
</style>
<?php echo $options['mts_header_code']; ?>
<?php }
}

/*------------[ footer ]-------------*/
if ( ! function_exists( 'mts_footer' ) ) {
	function mts_footer() { 
	global $options
?>
<!--Twitter Button Script------>
<script>!function(d,s,id){var js,fjs=d.getElementsByTagName(s)[0];if(!d.getElementById(id)){js=d.createElement(s);js.id=id;js.src="//platform.twitter.com/widgets.js";fjs.parentNode.insertBefore(js,fjs);}}(document,"script","twitter-wjs");</script>
<script type="text/javascript">
  (function() {
    var po = document.createElement('script'); po.type = 'text/javascript'; po.async = true;
    po.src = 'https://apis.google.com/js/plusone.js';
    var s = document.getElementsByTagName('script')[0]; s.parentNode.insertBefore(po, s);
  })();
</script>
<!--Facebook Like Button Script------>
<script>(function(d, s, id) {
  var js, fjs = d.getElementsByTagName(s)[0];
  if (d.getElementById(id)) return;
  js = d.createElement(s); js.id = id;
  js.src = "//connect.facebook.net/en_US/all.js#xfbml=1&appId=136911316406581";
  fjs.parentNode.insertBefore(js, fjs);
}(document, 'script', 'facebook-jssdk'));</script>
<!--start footer code-->
<?php if ($options['mts_analytics_code'] != '') { ?>
<?php echo $options['mts_analytics_code']; ?>
<?php } ?>
<!--end footer code-->
<!--start slider-->
<?php if($options['mts_featured_slider'] == '1') { ?>
<?php if( is_home() ) { ?>
<script type="text/javascript">
$(window).load(function(){
  $('.flexslider').flexslider({
	animation: "fade",
	pauseOnHover: true,
  }); 
});
</script>
<?php } ?>
<?php } ?>
<!--end slider-->
<!--start lightbox-->
<?php if($options['mts_lightbox'] == '1') { ?>
<script type="text/javascript">  
jQuery(document).ready(function($) {
$("a[href$='.jpg'], a[href$='.jpeg'], a[href$='.gif'], a[href$='.png']").prettyPhoto({
slideshow: 5000,
autoplay_slideshow: false,
animationSpeed: 'normal',
padding: 40,
opacity: 0.35,
showTitle: true,
social_tools: false
});
})
</script>
<?php } ?>
<!--end lightbox-->
<script type="text/javascript">
jQuery(document).ready(function(e){
    (function($){			
		function auto_hight_max_val(slectortype)
		{
			var excerpt = new Array();
			var i = 0;
			$(slectortype).each(function(index, element) {
				excerpt[i] = $(this).height();
				i++;
			});		
			function max_array_val(array){
				if (array.length < 1) {
					return -1;
				}
				max_array_val = 0;
				for(var i=1; i<array.length;i++ ) {
					if(array[i] > array[max_array_val]) {
						max_array_val = i;
					}
				}
				return max_array_val;
			}
			var mav = max_array_val(excerpt);
			$(slectortype).height(excerpt[mav]);
		}
	}(jQuery));
});
</script>
<?php }
}

/*------------[ Copyrights ]-------------*/
if ( ! function_exists( 'mts_copyrights_credit' ) ) {
	function mts_copyrights_credit() { 
	global $options
?>
<!--start copyrights-->
<div class="row" id="copyright-note">
<span><a href="<?php echo home_url(); ?>/" title="<?php bloginfo('description'); ?>"><?php bloginfo('name'); ?></a> Copyright &copy; <?php echo date("Y") ?>.</span>
<div class="top"><?php echo $options['mts_copyrights']; ?>&nbsp;<a href="#top" class="toplink">Back to Top &uarr;</a></div>
</div>
<!--end copyrights-->
<?php }
}

?>