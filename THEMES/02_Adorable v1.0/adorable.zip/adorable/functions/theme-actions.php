<?php
$options = get_option('adorable');	

/*------------[ Meta ]-------------*/
if ( ! function_exists( 'mts_meta' ) ) {
	function mts_meta() { 
	global $options
?>
<?php if ($options['mts_favicon'] != '') { ?>
<link rel="icon" href="<?php echo $options['mts_favicon']; ?>" type="image/x-icon" />
<?php } ?>
<!--iOS/android/handheld specific -->	
<link rel="apple-touch-icon" href="apple-touch-icon.png">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<meta name="apple-mobile-web-app-capable" content="yes">
<meta name="apple-mobile-web-app-status-bar-style" content="black">
<?php }
}

/*------------[ Head ]-------------*/
if ( ! function_exists( 'mts_head' ) ) {
	function mts_head() { 
	global $options
?>
<!--start fonts-->
<?php if ($options['mts_title_font'] == 'Arial') { ?>
<?php } else { ?>
<?php if ($options['mts_title_font'] != '' || $options['mts_google_title_font'] != '') { ?>
<link href="http://fonts.googleapis.com/css?family=<?php if ($options['mts_google_title_font'] != '') { ?><?php echo $options['mts_google_title_font']; ?><?php } else { ?><?php echo $options['mts_title_font']; ?><?php } ?>:400,700" rel="stylesheet" type="text/css">
<style type="text/css">
.title, h1,h2,h3,h4,h5,h6, .slidertitle { font-family: '<?php if ($options['mts_google_title_font'] != '') { ?><?php echo $options['mts_google_title_font']; ?><?php } else { ?><?php echo $options['mts_title_font']; ?><?php } ?>', sans-serif;}
</style>
<?php } ?>
<?php } ?>
<?php if ($options['mts_content_font'] == 'Arial') { ?>
<?php } else { ?>
<?php if ($options['mts_content_font'] != '' || $options['mts_google_content_font'] != '') { ?>
<link href="http://fonts.googleapis.com/css?family=<?php if ($options['mts_google_content_font'] != '') { ?><?php echo $options['mts_google_content_font']; ?><?php } else { ?><?php echo $options['mts_content_font']; ?><?php } ?>:400,400italic,700,700italic" rel="stylesheet" type="text/css">
<style type="text/css">
body {font-family: '<?php if ($options['mts_google_content_font'] != '') { ?><?php echo $options['mts_google_content_font']; ?><?php } else { ?><?php echo $options['mts_content_font']; ?><?php } ?>', sans-serif;}
</style>
<?php } ?>
<?php } ?>
<!--end fonts-->
<script src="//ajax.googleapis.com/ajax/libs/jquery/1.8.2/jquery.min.js"></script>
<script src="<?php echo get_template_directory_uri(); ?>/js/modernizr.min.js"></script>
<script src="<?php echo get_template_directory_uri(); ?>/js/customscript.js" type="text/javascript"></script>
<style type="text/css">
<?php if ($options['mts_logo'] != '') { ?>
#header h1, #header h2 {text-indent: -999em; min-width:188px; }
#header h1 a, #header h2 a {background: url(<?php echo $options['mts_logo']; ?>) no-repeat; min-width: 188px; display: block; min-height: 70px; line-height: 70px; }
<?php } ?>
<?php if($options['mts_bg_color'] != '') { ?>
body {background-color:<?php echo $options['mts_bg_color']; ?>;}
<?php } ?>
<?php if ($options['mts_bg_pattern_upload'] != '') { ?>
body {background-image: url(<?php echo $options['mts_bg_pattern_upload']; ?>);}
<?php } else { ?>
<?php if($options['mts_bg_pattern'] != '') { ?>
body {background-image:url(<?php echo get_template_directory_uri(); ?>/images/<?php echo $options['mts_bg_pattern']; ?>.png);}
<?php } ?>
<?php } ?>
<?php if ($options['mts_color_scheme'] != '') { ?>
.mts-subscribe input[type="submit"], .main-navigation, .pagination a, #sidebars #searchform .sbutton, #tabber ul.tabs li a.selected, #commentform input#submit, .home article .title a:hover, .secondary-navigation ul li a:hover, .secondary-navigation .sfHover, .secondary-navigation #navigation ul li li, #tabber ul.tabs li.tab-recent-posts a.selected, .main-navigation ul li ul li a:hover, li.cat-item:hover, li.cat-item:hover a, .footer-widgets .sbutton, #sidebars .sbutton, .tagcloud a:hover { background-color:<?php echo $options['mts_color_scheme']; ?>; }
.main-navigation:before, .home article .title a:hover:before { border-right-color:<?php echo $options['mts_color_scheme']; ?>; }
.main-navigation:after, .home article .title a:hover:after { border-left-color:<?php echo $options['mts_color_scheme']; ?>; }
#header, #sidebars .widget, .footer-widgets, .tagcloud a, .related-posts, .postauthor, #commentsAdd, #tabber, .pagination, .single_post, .single_page, #comments, .ss-full-width {border-color:<?php echo $options['mts_border_color_scheme']; ?>; }
a:hover, .copyrights a:hover, .readMore a, .pagination2 a, .sidebar.c-4-12 a:hover, a, #copyright-note a:hover, footer .widget li a:hover {color:<?php echo $options['mts_color_scheme']; ?>; }
<?php } ?>
<?php if($options['mts_floating_social'] == '1') { ?>
.shareit { top: 310px; left: auto; z-index: 0; margin: 0 0 0 -150px; width: 90px; position: fixed; overflow: hidden; padding: 5px; background: #fff; -webkit-box-shadow: 1px 2px 3px rgba(50, 50, 50, 0.35);
-moz-box-shadow: 1px 2px 3px rgba(50, 50, 50, 0.35);
box-shadow: 1px 2px 3px rgba(50, 50, 50, 0.35);}
.share-item {margin: 2px;}
<?php } ?>
<?php if ($options['mts_layout'] == 'sclayout') { ?>
.single_post, .single_page, .related-posts, .postauthor, #commentsAdd, #comments { margin-left: 0; margin-right: 3%; }
.article { float: right;}
.sidebar.c-4-12 { float: left; margin-left: 1.7%;
margin-right: 0; }
.single-title, .page h1.title {
margin: 0 0 0 -5%;
}
<?php if($options['mts_floating_social'] == '1') { ?>
.shareit { margin: 0 630px 0;}
<?php } ?>
<?php } ?>
<?php if($options['mts_author_comment'] == '1') { ?>
.bypostauthor {border: 1px solid #EEE!important; padding: 3%!important; background: #FAFAFA; width: 94%!important;}
.bypostauthor .reply {border-bottom: 0; }
<?php } ?>
<?php echo $options['mts_custom_css']; ?>
</style>
<?php echo $options['mts_header_code']; ?>
<?php }
}

/*------------[ footer ]-------------*/
if ( ! function_exists( 'mts_footer' ) ) {
	function mts_footer() { 
	global $options
?>
<!--Twitter Button Script------>
<script>!function(d,s,id){var js,fjs=d.getElementsByTagName(s)[0];if(!d.getElementById(id)){js=d.createElement(s);js.id=id;js.src="//platform.twitter.com/widgets.js";fjs.parentNode.insertBefore(js,fjs);}}(document,"script","twitter-wjs");</script>
<script type="text/javascript">
  (function() {
    var po = document.createElement('script'); po.type = 'text/javascript'; po.async = true;
    po.src = 'https://apis.google.com/js/plusone.js';
    var s = document.getElementsByTagName('script')[0]; s.parentNode.insertBefore(po, s);
  })();
</script>
<!--Facebook Like Button Script------>
<script>(function(d, s, id) {
  var js, fjs = d.getElementsByTagName(s)[0];
  if (d.getElementById(id)) return;
  js = d.createElement(s); js.id = id;
  js.src = "//connect.facebook.net/en_US/all.js#xfbml=1&appId=136911316406581";
  fjs.parentNode.insertBefore(js, fjs);
}(document, 'script', 'facebook-jssdk'));</script>
<!--start footer code-->
<?php if ($options['mts_analytics_code'] != '') { ?>
<?php echo $options['mts_analytics_code']; ?>
<?php } ?>
<!--end footer code-->
<!--start slider-->
<?php if($options['mts_featured_slider'] == '1') { ?>
<link rel="stylesheet" href="<?php echo get_template_directory_uri(); ?>/css/slider.css" type="text/css">
<script src="<?php echo get_template_directory_uri(); ?>/js/jquery.easing.1.3.min.js"></script>
<script src="<?php echo get_template_directory_uri(); ?>/js/trans-banner.min.js"></script>
<script type="text/javascript">
	jQuery(function($){
		$('.TB_Wrapper').TransBanner({
			
			/*All the below settings are related to responsive behavior:
			IMPORTANT: In order to make limits to work on browser resize, set the last parameter to false	
			
			To enable or disable Responsive behavior */
			responsive : true,
			
			/* To disable autoplay below certain screen size [Ex: 480] */
			responsive_limit_autoplay : '', 
			
			/* To disable caption below certain screen size [Ex: 480]*/
			responsive_limit_caption : 480,
			
			/* To change navigation type below certain screen size [Ex: 480]*/
			responsive_limit_navigation : 480,
			
			/* The navigation type to be used below certain screen size [1: Default, 2: Dot style, 3: Arrow style]*/
			responsive_limit_navigation_type : 2, 
			
			/* The limits can be either screen based or banner container based */
			responsive_screen_based_limits : true 
		});
	});	
  </script>
<?php } ?>
<!--end slider-->
<!--start lightbox-->
<?php if($options['mts_lightbox'] == '1') { ?>
<link rel="stylesheet" href="<?php bloginfo('template_directory'); ?>/css/prettyPhoto.css" type="text/css" media="screen" charset="utf-8" />
<script src="<?php bloginfo('template_directory'); ?>/js/jquery.prettyPhoto.js"></script>
<script type="text/javascript">  
jQuery(document).ready(function($) {
$("a[href$='.jpg'], a[href$='.jpeg'], a[href$='.gif'], a[href$='.png']").prettyPhoto({
slideshow: 5000, /* false OR interval time in ms */
autoplay_slideshow: false, /* true/false */
animationSpeed: 'normal', /* fast/slow/normal */
padding: 40, /* padding for each side of the picture */
opacity: 0.35, /* Value betwee 0 and 1 */
showTitle: true, /* true/false */	
social_tools: false
});
})
</script>
<?php } ?>
<!--end lightbox-->
<?php }
}

/*------------[ Copyrights ]-------------*/
if ( ! function_exists( 'mts_copyrights_credit' ) ) {
	function mts_copyrights_credit() { 
	global $options
?>
<!--start copyrights-->
<div class="row" id="copyright-note">
<span><a href="<?php echo home_url(); ?>/" title="<?php bloginfo('description'); ?>"><?php bloginfo('name'); ?></a> Copyright &copy; <?php echo date("Y") ?>.</span>
<div class="top"><?php echo $options['mts_copyrights']; ?> <a href="#top" class="toplink">Back to Top &uarr;</a></div>
</div>
<!--end copyrights-->
<?php }
}

?>