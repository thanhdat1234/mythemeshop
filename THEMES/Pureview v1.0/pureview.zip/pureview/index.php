<?php $options = get_option('pureview'); ?>
<?php get_header(); ?>
<div id="page">
	<div class="content">
		<article class="article">
			<div id="content_box">
				<?php if (is_home() && !is_paged()) { ?>
					<?php if($options['mts_featured_slider'] == '1') { ?>
						<div class="slider-container">
							<div class="flex-container">
								<div class="flexslider">
									<ul class="slides">
										<?php $my_query = new WP_Query('cat='.$options['mts_featured_slider_cat'].'&posts_per_page=3'); while ($my_query->have_posts()) : $my_query->the_post(); $image_id = get_post_thumbnail_id(); $image_url = wp_get_attachment_image_src($image_id,'slider'); $image_url = $image_url[0]; ?>
										<li data-thumb="<?php echo $image_url; ?>">
											<a href="<?php the_permalink() ?>">
												<?php the_post_thumbnail('slider',array('title' => '')); ?>
											</a>
                                            <span class="flex-caption-top">
												<span class="slidertitle"><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></span>    
												<?php if($options['mts_headline_meta'] == '1') { ?>                                         
													<span class="slider_meta">                                                    
														<div class="theauthor"><?php _e('Post by ','mythemeshop'); ?><span><?php the_author_posts_link(); ?></span></div>
														<div class="thetime"><?php _e(' on ','mythemeshop'); ?><span><?php the_time('d M, Y'); ?></span></div>
														<div class="thecategory"><?php _e(' in ','mythemeshop'); ?><span><?php 
														$category = get_the_category(); if($category[0]){ echo '<a href="'.get_category_link($category[0]->term_id ).'">'.$category[0]->cat_name.'</a>'; } ?></span></div>
														<div class="thecomment"><?php _e(' with ','mythemeshop'); ?><span><?php comments_popup_link(__('No Comments','mythemeshop'), __('1 Comment','mythemeshop'), __('% Comments','mythemeshop'), 'commentslink', __('Comments off','mythemeshop')); ?>	</span></div>
													</span>
												<?php } ?> 
											</span>
											<span class="flex-caption-bottom">
												<span class="slidertext"><?php echo excerpt(20); ?></span>
												<span class="sliderReadMore"><a href="<?php the_permalink(); ?>"><?php _e('Read More... ','mythemeshop'); ?></a></span>
											</span>
										</li>
										<?php endwhile; ?>
									</ul>
								</div>
							</div>
						</div>
					<?php } ?> 
				<?php } ?>
				<?php if (have_posts()) : while (have_posts()) : the_post(); ?>
                    <div class="cpostex post excerpt <?php echo ($j == 0) ? 'first' : ''; $j++; ?>">	
						<?php if ( has_post_thumbnail() ) { ?> 
							<div class="post_excerpt_l">
								<a href="<?php the_permalink() ?>" title="<?php the_title(); ?>" rel="nofollow" id="featured-thumbnail">
									<?php echo '<div class="featured-thumbnail">'; the_post_thumbnail('featured',array('title' => '')); echo '</div>'; ?>
								</a>
							</div>
						<?php } ?>
						<div class="post_excerpt_r">
							<header>
								<h2 class="title">
									<a href="<?php the_permalink() ?>" title="<?php the_title(); ?>" rel="bookmark"><?php the_title(); ?></a>
								</h2>
								<?php if($options['mts_headline_meta'] == '1') { ?>  
									<div class="post-info">                                       
										<span class="theauthor">
											<?php _e('Post by ','mythemeshop'); ?>
											<span><?php the_author_posts_link(); ?></span>
										</span>
										<span class="thetime">
											<?php _e('on ','mythemeshop'); ?>
											<span><?php the_time('d M, Y'); ?></span>										
										</span>
										<span class="thecategory">
											<?php _e('in ','mythemeshop'); ?>
											<span><?php the_category(', ') ?></span>
										</span>
									</div>		
								<?php } ?>
							</header><!--.header-->
							<div class="post-content image-caption-format-1"><?php echo excerpt(30);?></div>
							<a class="pereadore" href="<?php the_permalink() ?>" title="<?php the_title(); ?>" rel="bookmark"><?php _e('Read More...','mythemeshop'); ?></a>						
						</div>
					</div><!--.post excerpt-->
				<?php endwhile; endif; ?>	
				<?php if ($options['mts_pagenavigation'] == '1') { ?>
					<?php pagination($additional_loop->max_num_pages);?>
				<?php } else { ?>
					<div class="pnavigation2">
						<div class="nav-previous"><?php next_posts_link( __( 'Older posts', 'mythemeshop' ) ); ?></div>
						<div class="nav-next"><?php previous_posts_link( __( 'Newer posts', 'mythemeshop' ) ); ?></div>
					</div>
				<?php } ?>
			</div>
		</article>
		<?php get_sidebar(); ?>
<?php get_footer(); ?>