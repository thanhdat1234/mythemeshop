<?php $mts_options = get_option(MTS_THEME_NAME);?>
<?php get_header();?>
<div id="page">
  <div class="article">
    <div id="content_box">
        <?php if (!is_paged()) {
            $m = 1;
        	$featured_categories = array();
        	if (!empty($mts_options['mts_featured_categories'])) {
        		foreach ($mts_options['mts_featured_categories'] as $section) {
        			$category_id = $section['mts_featured_category'];
        			$featured_categories[] = $category_id;
        			$posts_num = $section['mts_featured_category_postsnum'];
                    $intermittent_posts = !empty($section['mts_featured_category_intermittent_posts']);
                    $intermittent_posts_category = $section['mts_featured_category_intermittent_category'];
                    $intermittent_posts_show_after = $section['mts_featured_category_intermittent_show_after'];

        			if ('latest' == $category_id) {
                        $j = 0;
                        if (have_posts()): while (have_posts()): the_post();
                            if ($m == 1 && !empty($mts_options['mts_featured_category_show_hide'])) { ?>
        		                <div class="latestPost-first-row">
        		                    <article class="latestPost excerpt <?php echo (++$j % 3 == 0) ? 'lasts' : '';?>" itemscope itemtype="http://schema.org/BlogPosting">
                                        <header>
                                            <h2 class="title front-view-title" itemprop="headline"><a href="<?php the_permalink()?>" title="<?php the_title();?>"><?php the_title();?></a></h2>
                                            <?php mts_the_postinfo();?>
                                        </header>
                                        <a href="<?php the_permalink()?>" title="<?php the_title();?>" rel="nofollow" class="post-image post-image-left">
                                            <div class="featured-thumbnail"><?php the_post_thumbnail('featured1', array('title' => '','itemprop'=>'image'));?>
                                                <?php if ($mts_options['mts_category_home'] == '1') {?><div class="thecategory" itemprop="articleSection"><?php mts_the_category_no_link(', ')?></div><?php }?>
                                                <?php if (function_exists('wp_review_show_total')) { wp_review_show_total(true, 'latestPost-review-wrapper'); } ?>
            		                        </div>
                                        </a>
                                        <div class="front-view-content">
                                            <?php echo mts_excerpt(40);?>
                                        </div>
                                        <?php mts_readmore_featured();?>
                                    </article>
        		                    <div class="featured-top-news">
                                        <ul class="news">
                                            <li class=""><a href="#" title="latest" class="noclick"><?php _e('Popular', 'mythemeshop');?></a></li>
                                            <li class="">
                                                <div id="featured-dropdown" class="featured-news">
                                                    <span class="alltime"><?php _e('All Time', 'mythemeshop');?></span>
                                                    <ul class="dropdown">
                                                        <li><a href="#" title="<?php esc_attr_e('This Week', 'mythemeshop'); ?>" data-period="this_week"><?php _e('This Week', 'mythemeshop'); ?></a></li>
                                                        <li><a href="#" title="<?php esc_attr_e('This Month', 'mythemeshop'); ?>" data-period="this_month"><?php _e('This Month', 'mythemeshop'); ?></a></li>
                                                        <li><a href="#" title="<?php esc_attr_e('Last 3 Months', 'mythemeshop'); ?>" data-period="3_months"><?php _e('3 Months', 'mythemeshop'); ?></a></li>
                                                        <li><a href="#" title="<?php esc_attr_e('This Year', 'mythemeshop'); ?>" data-period="this_year"><?php _e('This Year', 'mythemeshop'); ?></a></li>
                                                        <li><a href="#" title="<?php esc_attr_e('All Time', 'mythemeshop'); ?>" data-period="all_time"><?php _e('All Time', 'mythemeshop'); ?></a></li>
                                                    </ul>
                                                </div>
                                            </li>
                                        </ul>
                                        <div class="featured-news-lists">
            		                        <ul class="get_posts">
                                                <?php mts_top_post(); ?>
            		                        </ul>
                                        </div>
                                    </div>
                                </div><!-- #END latestPost-first-row -->
                            <?php } else { ?>
                                <article class="latestPost excerpt <?php echo (++$j % 3 == 0) ? 'lasts' : '';?>" itemscope itemtype="http://schema.org/BlogPosting">
                                    <?php mts_archive_post();?>
                                </article>

                                <?php } 
                                if ($intermittent_posts && $j == $intermittent_posts_show_after) { ?>
                                    <article class="latestPost intermittent-posts excerpt <?php echo (++$j % 3 == 0) ? 'lasts' : '';?>">
                                        <?php if ($mts_options['mts_category_home'] == '1') { ?><div class="featured-thumbnail"><div class="thecategory"><?php echo get_cat_name( $intermittent_posts_category ); ?></div></div><?php } ?>
                                        <header>
                                        <?php $intermittent_query = new WP_Query('cat=' . $intermittent_posts_category . '&posts_per_page=4');
                                        $k = 0;
                                        if ($intermittent_query->have_posts()): while ($intermittent_query->have_posts()): $intermittent_query->the_post(); ?>
                                        <h2 class="title front-view-title"><a href="<?php the_permalink() ?>" title="<?php the_title(); ?>"><?php the_title(); ?></a></h2>
                                        <?php $k++; endwhile; endif; //wp_reset_query(); ?>
                                        </header>
                                        <div class="readMore">
                                            <a href="<?php echo get_category_link( $intermittent_posts_category ); ?>" title="<?php esc_attr(get_cat_name( $intermittent_posts_category )); ?>" rel="nofollow"><?php _e( 'More', 'mythemeshop' ); ?><i class="fa fa-angle-double-right"></i></a>
                                        </div>
                                    </article>
                                <?php $m++;}
                            $m++;
                        endwhile; endif; wp_reset_query();
                        if ($j !== 0) {// No pagination if there is no posts
                            mts_pagination();
                        }
                    } else {
        				// if $category_id != 'latest':
                        $j = 0;
        				$cat_query = new WP_Query('cat=' . $category_id . '&posts_per_page=' . $posts_num);
    				    if ($cat_query->have_posts()): while ($cat_query->have_posts()): $cat_query->the_post();?>
    		                <?php if ($m == 1 && !empty($mts_options['mts_featured_category_show_hide'])) { ?>
                                <div class="latestPost-first-row">
                                    <article class="latestPost excerpt <?php echo (++$j % 3 == 0) ? 'lasts' : '';?>" itemscope itemtype="http://schema.org/BlogPosting">
                                        <header>
                                            <h2 class="title front-view-title" itemprop="headline"><a href="<?php the_permalink()?>" title="<?php the_title();?>"><?php the_title();?></a></h2>
                                            <?php mts_the_postinfo();?>
                                        </header>
                                        <a href="<?php the_permalink()?>" title="<?php the_title();?>" rel="nofollow" class="post-image post-image-left">
                                            <div class="featured-thumbnail"><?php the_post_thumbnail('featured1', array('title' => '','itemprop'=>'image'));?>
                                                <?php if ($mts_options['mts_category_home'] == '1') {?><div class="thecategory" itemprop="articleSection"><?php mts_the_category_no_link(', ')?></div><?php }?>
                                                <?php if (function_exists('wp_review_show_total')) { wp_review_show_total(true, 'latestPost-review-wrapper'); } ?>
                                            </div>
                                        </a>
                                        <div class="front-view-content">
                                            <?php echo mts_excerpt(40);?>
                                        </div>
                                        <?php mts_readmore_featured();?>
                                    </article>
                                    <div class="featured-top-news">
                                        <ul class="news">
                                            <li class=""><a href="#" title="latest" class="noclick"><?php _e('Top News', 'mythemeshop');?></a></li>
                                            <li class="">
                                                <div id="featured-dropdown" class="featured-news">
                                                    <span class="alltime"><?php _e('All Time', 'mythemeshop');?></span>
                                                    <ul class="dropdown">
                                                        <li><a href="#" title="<?php esc_attr_e('This Week', 'mythemeshop'); ?>" data-period="this_week"><?php _e('This Week', 'mythemeshop'); ?></a></li>
                                                        <li><a href="#" title="<?php esc_attr_e('This Month', 'mythemeshop'); ?>" data-period="this_month"><?php _e('This Month', 'mythemeshop'); ?></a></li>
                                                        <li><a href="#" title="<?php esc_attr_e('Last 3 Months', 'mythemeshop'); ?>" data-period="3_months"><?php _e('3 Months', 'mythemeshop'); ?></a></li>
                                                        <li><a href="#" title="<?php esc_attr_e('This Year', 'mythemeshop'); ?>" data-period="this_year"><?php _e('This Year', 'mythemeshop'); ?></a></li>
                                                        <li><a href="#" title="<?php esc_attr_e('All Time', 'mythemeshop'); ?>" data-period="all_time"><?php _e('All Time', 'mythemeshop'); ?></a></li>
                                                    </ul>
                                                </div>
                                            </li>
                                        </ul>
                                        <div class="featured-news-lists">
                                            <ul class="get_posts">
                                                <?php mts_top_post(array('cat' => $category_id)); ?>
                                            </ul>
                                        </div>
                                    </div>
                                </div>
                            <?php } else { ?>
                                <article class="latestPost excerpt <?php echo (++$j % 3 == 0) ? 'lasts' : '';?>" itemscope itemtype="http://schema.org/BlogPosting">
                                    <?php mts_archive_post();?>
                                </article>

                                
                            <?php } 
                                if ($intermittent_posts && $j == $intermittent_posts_show_after) { ?>
                                    <article class="latestPost intermittent-posts excerpt <?php echo (++$j % 3 == 0) ? 'lasts' : '';?>">
                                        <?php if ($mts_options['mts_category_home'] == '1') { ?><div class="featured-thumbnail"><div class="thecategory"><?php echo get_cat_name( $intermittent_posts_category ); ?></div></div><?php } ?>
                                        <header>
                                        <?php $intermittent_query = new WP_Query('cat=' . $intermittent_posts_category . '&posts_per_page=4');
                                        $k = 0;
                                        if ($intermittent_query->have_posts()): while ($intermittent_query->have_posts()): $intermittent_query->the_post(); ?>
                                        <h2 class="title front-view-title"><a href="<?php the_permalink() ?>" title="<?php the_title(); ?>"><?php the_title(); ?></a></h2>
                                        <?php $k++; endwhile; endif; //wp_reset_query(); ?>
                                        </header>
                                        <div class="readMore">
                                            <a href="<?php echo get_category_link( $intermittent_posts_category ); ?>" title="<?php esc_attr(get_cat_name( $intermittent_posts_category )); ?>" rel="nofollow"><?php _e( 'More', 'mythemeshop' ); ?><i class="fa fa-angle-double-right"></i></a>
                                        </div>
                                    </article>
                                <?php $m++;}
                            $m++;
                        endwhile; endif; wp_reset_query();
                    }
                }
            }
        } else {//Paged
            $j = 0;
            if (have_posts()): while (have_posts()): the_post(); ?>
                <article class="latestPost excerpt <?php echo (++$j % 3 == 0) ? 'lasts' : '';?>" itemscope itemtype="http://schema.org/BlogPosting">
                    <?php mts_archive_post();?>
                </article>
            <?php endwhile; endif;
            if ($j !== 0) {// No pagination if there is no posts
                mts_pagination();
            }
        } ?>
    </div>
</div>
<?php get_sidebar();?>
<?php get_footer();?>