<?php $mts_options = get_option(MTS_THEME_NAME); ?>
</div><!--#page-->
	<footer class="footer" role="contentinfo" itemscope itemtype="http://schema.org/WPFooter">
		<div class="container">
        <?php if( !empty($mts_options['mts_first_footer']) ) { ?>
           <div id="navigation" class="footer-navigation">
                <div class="footer-logo">
                    <h1 id="logo" class="text-logo" itemprop="headline">
                        <a href="<?php echo home_url(); ?>"><?php bloginfo( 'name' ); ?></a>
                    </h1><!-- END #logo -->
                </div>

                <nav class="third-nav-menu">
                    <?php if ( has_nav_menu( 'third-menu' ) ) { ?>
                        <?php wp_nav_menu( array( 'theme_location' => 'third-menu', 'menu_class' => 'menu clearfix', 'container' => '', 'walker' => new mts_menu_walker ) ); ?>
                    <?php } else { ?>
                        <ul class="menu clearfix">
                            <?php wp_list_pages('title_li='); ?>
                        </ul>
                    <?php } ?>
                </nav>
            </div>
        <?php } ?>

            <div class="footer-disclaimer">
                <?php if(!empty($mts_options['mts_footer_disclaimer'])) { echo $mts_options['mts_footer_disclaimer']; ?><?php } ?>
            </div>   

            <div class="copyrights">
				<?php mts_copyrights_credit(); ?>
			</div> 
		</div><!--.container-->
	</footer><!--footer-->
</div><!--.main-container-->
<?php mts_footer(); ?>
<?php wp_footer(); ?>
</body>
</html>