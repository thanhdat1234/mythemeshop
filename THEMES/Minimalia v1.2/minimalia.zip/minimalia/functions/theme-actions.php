<?php
$options = get_option('minimalia');	

/*------------[ Meta ]-------------*/
if ( ! function_exists( 'mts_meta' ) ) {
	function mts_meta() { 
	global $options
?>
<?php if ($options['mts_favicon'] != '') { ?>
<link rel="icon" href="<?php echo $options['mts_favicon']; ?>" type="image/x-icon" />
<?php } ?>
<!--iOS/android/handheld specific -->	
<link rel="apple-touch-icon" href="apple-touch-icon.png">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<meta name="apple-mobile-web-app-capable" content="yes">
<meta name="apple-mobile-web-app-status-bar-style" content="black">
<?php if($options['mts_prefetching'] == '1') { ?>
<?php if (is_front_page()) { $args = array( 'numberposts' => 1); $myposts = get_posts( $args ); setup_postdata($myposts); ?>
	<link rel="prefetch" href="<?php the_permalink(); ?>">
	<link rel="prerender" href="<?php the_permalink(); ?>">
<?php } elseif (is_singular()) { ?>
	<link rel="prefetch" href="<?php echo home_url(); ?>">
	<link rel="prerender" href="<?php echo home_url(); ?>">
<?php } ?>
<?php } ?>
<?php }
}

/*------------[ Head ]-------------*/
if ( ! function_exists( 'mts_head' ) ) {
	function mts_head() { 
	global $options
?>
<!--start fonts-->
<?php if ($options['mts_title_font'] == 'Arial') { ?>
<?php } else { ?>
<?php if ($options['mts_title_font'] != '' || $options['mts_google_title_font'] != '') { ?>
<link href="http://fonts.googleapis.com/css?family=<?php if ($options['mts_google_title_font'] != '') { ?><?php echo $options['mts_google_title_font']; ?><?php } else { ?><?php echo $options['mts_title_font']; ?><?php } ?>:400,700" rel="stylesheet" type="text/css">
<style type="text/css">
.title, h1,h2,h3,h4,h5,h6, #tabber ul.tabs li a { font-family: '<?php if ($options['mts_google_title_font'] != '') { ?><?php echo $options['mts_google_title_font']; ?><?php } else { ?><?php echo $options['mts_title_font']; ?><?php } ?>', sans-serif;}
</style>
<?php } ?>
<?php } ?>
<?php if ($options['mts_content_font'] == 'Arial') { ?>
<?php } else { ?>
<?php if ($options['mts_content_font'] != '' || $options['mts_google_content_font'] != '') { ?>
<link href="http://fonts.googleapis.com/css?family=<?php if ($options['mts_google_content_font'] != '') { ?><?php echo $options['mts_google_content_font']; ?><?php } else { ?><?php echo $options['mts_content_font']; ?><?php } ?>:400,400italic,700,700italic" rel="stylesheet" type="text/css">
<style type="text/css">
body {font-family: '<?php if ($options['mts_google_content_font'] != '') { ?><?php echo $options['mts_google_content_font']; ?><?php } else { ?><?php echo $options['mts_content_font']; ?><?php } ?>', sans-serif;}
</style>
<?php } ?>
<?php } ?>
<!--end fonts-->
<style type="text/css">
<?php if($options['mts_bg_color'] != '') { ?>
body {background-color:<?php echo $options['mts_bg_color']; ?>;}
<?php } ?>
<?php if ($options['mts_bg_pattern_upload'] != '') { ?>
body {background-image: url(<?php echo $options['mts_bg_pattern_upload']; ?>);}
<?php } else { ?>
<?php if($options['mts_bg_pattern'] != '') { ?>
body {background-image:url(<?php echo get_template_directory_uri(); ?>/images/<?php echo $options['mts_bg_pattern']; ?>.png);}
<?php } ?>
<?php } ?>
<?php if ($options['mts_color_scheme'] != '') { ?>
.current-menu-item a, .menu a:hover, .mts-subscribe input[type="submit"], .sbutton, .currenttext, .pagination a:hover, #commentform input#submit, .tagcloud a, .tags a { background-color:<?php echo $options['mts_color_scheme']; ?>; }
.author_name, a:hover, .textwidget a, #commentform a, .copyrights a:hover, a, .sidebar.c-4-12 a:hover, footer .widget li a:hover, .menu-item-home a, .menu-item-home a:hover {color:<?php echo $options['mts_color_scheme']; ?>; }
<?php } ?>
<?php if($options['mts_floating_social'] == '1') { ?>
.shareit { top: 282px; left: auto; z-index: 0; margin: 0 0 0 -135px; width: 90px; position: fixed; overflow: hidden; padding: 5px; background: white; box-shadow: 0 1px 3px rgba(0, 0, 0, 0.2); -moz-box-shadow: 0px 1px 3px rgba(0, 0, 0, 0.2); -webkit-box-shadow: 0px 1px 3px rgba(0, 0, 0, 0.2);}
.share-item {margin: 2px;}
<?php } ?>
<?php if ($options['mts_layout'] == 'sclayout') { ?>
.article { float: right;}
.sidebar.c-4-12 { float: left; padding-right: 0; }
.sidebar { display:block; float:right; padding-right:3%;}
<?php if($options['mts_floating_social'] == '1') { ?>
.shareit { margin: 0 638px 0; border-left: 0; border-right: 1px solid #E2E2E2; }
<?php } ?>
<?php } ?>
<?php if($options['mts_author_comment'] == '1') { ?>
.bypostauthor {padding: 3% 3% 0 3%!important; background: #EEE; width: 94%!important;}
.bypostauthor .reply {border-bottom: 0; }
<?php } ?>
<?php echo $options['mts_custom_css']; ?>
</style>
<?php echo $options['mts_header_code']; ?>
<?php }
}

/*------------[ Copyrights ]-------------*/
if ( ! function_exists( 'mts_copyrights_credit' ) ) {
	function mts_copyrights_credit() { 
	global $options
?>
<!--start copyrights-->
<span><a href="<?php echo home_url(); ?>/" title="<?php bloginfo('description'); ?>"><?php bloginfo('name'); ?></a> Copyright &copy; <?php echo date("Y") ?>.</span>
<span><?php echo $options['mts_copyrights']; ?>&nbsp;</span>
<span class="top"><a href="#top" class="toplink"></a></span>
<!--end copyrights-->
<?php }
}

/*------------[ footer ]-------------*/
if ( ! function_exists( 'mts_footer' ) ) {
	function mts_footer() { 
	global $options
?>
<!--Twitter Button Script------>
<script>!function(d,s,id){var js,fjs=d.getElementsByTagName(s)[0];if(!d.getElementById(id)){js=d.createElement(s);js.id=id;js.src="//platform.twitter.com/widgets.js";fjs.parentNode.insertBefore(js,fjs);}}(document,"script","twitter-wjs");</script>
<script type="text/javascript">
  (function() {
    var po = document.createElement('script'); po.type = 'text/javascript'; po.async = true;
    po.src = 'https://apis.google.com/js/plusone.js';
    var s = document.getElementsByTagName('script')[0]; s.parentNode.insertBefore(po, s);
  })();
</script>
<!--Facebook Like Button Script------>
<script>(function(d, s, id) {
  var js, fjs = d.getElementsByTagName(s)[0];
  if (d.getElementById(id)) return;
  js = d.createElement(s); js.id = id;
  js.src = "//connect.facebook.net/en_US/all.js#xfbml=1&appId=136911316406581";
  fjs.parentNode.insertBefore(js, fjs);
}(document, 'script', 'facebook-jssdk'));</script>
<?php if($options['mts_featured_slider'] == '1') { ?>
<!--start slider-->
<?php if( is_home() ) { ?>
<script type="text/javascript">
    $(window).load(function(){
      $('.flexslider').flexslider({ animation: "fade", pauseOnHover: true, });  
    });
</script>
<?php } ?>
<!--end slider-->
<?php } ?>
<?php if($options['mts_lightbox'] == '1') { ?>
<!--start lightbox-->
<script type="text/javascript">  
jQuery(document).ready(function($) {
$("a[href$='.jpg'], a[href$='.jpeg'], a[href$='.gif'], a[href$='.png']").prettyPhoto({
slideshow: 5000,
autoplay_slideshow: false,
animationSpeed: 'normal',
padding: 40,
opacity: 0.35,
showTitle: true,
social_tools: false
});
})
</script>
<!--end lightbox-->
<?php } ?>
<?php if ($options['mts_analytics_code'] != '') { ?>
<!--start footer code-->
<?php echo $options['mts_analytics_code']; ?>
<!--end footer code-->
<?php } ?>
<?php }
}
?>