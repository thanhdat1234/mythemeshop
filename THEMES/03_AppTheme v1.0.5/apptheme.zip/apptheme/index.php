<?php $mts_options = get_option(MTS_THEME_NAME); ?>
<?php get_header(); ?>

<?php
	if(is_array($mts_options['mts_homepage_layout'])){
		$layout = $mts_options['mts_homepage_layout']['enabled'];
	}
	if(empty($layout)) {
		$layout = array('enabled'  => array('slider' => 'Slider'));
		$layout = $layout['enabled'];
	}
	
	if ($layout): foreach ($layout as $key=>$value) {
 
		switch($key) {
	 
			case 'slider':
			if(array_key_exists('slider',$layout) && !empty($mts_options['mts_custom_slider'])): ?>
				<div id="slider" class="section clearfix">
					<?php if($mts_options['mts_home_section_bg_video'] != '') { ?>
						<div class="video-bg">
							<video loop="loop" autoplay="autoplay">
								<source src="<?php echo $mts_options['mts_home_section_bg_video']; ?>"></source>
							</video>
						</div>
					<?php } ?>
					<div class="container">
						<div class="slider-container">
							<div class="flex-container loading">
								<div id="slider" class="flexslider">
									<ul class="slides">
										<?php foreach($mts_options['mts_custom_slider'] as $slide) : ?>
											<li>
												<?php
													$image_id = $slide['mts_custom_slider_image'];
													$home_button_one = $slide['mts_button_one_text'];
													$home_button_one_url = $slide['mts_button_one_url'];
													$home_button_one_icon = $slide['mts_button_one_icon'];
													$home_button_two = $slide['mts_button_two_text'];
													$home_button_two_url = $slide['mts_button_two_url'];
													$home_button_two_icon = $slide['mts_button_two_icon'];
												?>
												<?php echo wp_get_attachment_image($image_id, 'full', false, array('title' => '')); ?>
												<div class="flex-caption">
													<h2 class="slidertitle"><?php echo $slide['mts_custom_slider_title']; ?></h2>
													<p class="slidertext"><?php echo $slide['mts_custom_slider_text']; ?></p>
													<?php if(!empty($home_button_one_url)) { ?>
														<?php if(!empty($home_button_one)) { ?>
															<a href="<?php echo $home_button_one_url; ?>"><span class="button-home"><?php if(!empty($home_button_one_icon)) { ?><i class="fa fa-<?php echo $home_button_one_icon; ?>"></i><?php } ?> <?php echo $home_button_one; ?></span></a>
														<?php }
													} else { ?>
														<?php if(!empty($home_button_one)) { ?>
															<span class="button-home"><?php if(!empty($home_button_one_icon)) { ?><i class="fa fa-<?php echo $home_button_one_icon; ?>"></i><?php } ?> <?php echo $home_button_one; ?></span>
														<?php }
													} ?>
													
													<?php if(!empty($home_button_two_url)) { ?>
														<?php if(!empty($home_button_two)) { ?>
															<a href="<?php echo $home_button_two_url; ?>"><span class="button-home"><?php if(!empty($home_button_two_icon)) { ?><i class="fa fa-<?php echo $home_button_two_icon; ?>"></i><?php } ?> <?php echo $home_button_two; ?></span></a>
														<?php }
													} else { ?>
														<?php if(!empty($home_button_two)) { ?>
															<span class="button-home"><?php if(!empty($home_button_two_icon)) { ?><i class="fa fa-<?php echo $home_button_two_icon; ?>"></i><?php } ?> <?php echo $home_button_two; ?></span>
														<?php }
													} ?>
												</div>
										</li>
										<?php endforeach; ?>
									</ul>
								</div>
							</div>
						</div>
						<!-- slider-container -->	
					</div>
				</div>
			
			<?php
			endif;
			break;
	 
			case 'features': ?>
			
				<div id="features" class="section clearfix">
					<?php if($mts_options['mts_features_section_bg_video'] != '') { ?>
						<div class="video-bg">
							<video loop="loop" autoplay="autoplay">
								<source src="<?php echo $mts_options['mts_features_section_bg_video']; ?>"></source>
							</video>
						</div>
					<?php } ?>
					<div class="container">
						<?php
							$section_title = $mts_options['mts_features_title'];
							$section_sub_title = $mts_options['mts_features_sub_title'];			
						?>
						<div class="section-title-wrap" data-scroll-reveal="enter top move 50px">
							<h3 class="section-title"><?php echo $section_title ?></h3>
							<div class="section-sub-title"><?php echo $section_sub_title ?></div>			
						</div>
						<div class="features-box">
							<?php
								$section_features = array();
								if (!empty($mts_options['mts_home_features'])) {
									foreach ($mts_options['mts_home_features'] as $key => $section) {
										$features_block_title = $section['mts_features_block_title'];
										$features_block_description = $section['mts_features_block_description'];
										$features_icon_select = $section['mts_features_icon_select'];
										?>
										<div class="feature <?php if( $key == ( count( $mts_options['mts_home_features'] ) ) ) echo 'last'; ?>" data-scroll-reveal="wait .2s and then ease-in-out 100px">
										
											<?php if (!empty($features_icon_select)) { ?>
												<div class="feature-icon">
													<i class="fa fa-<?php echo $features_icon_select ?>" <?php if (!empty($section['mts_features_icon_bg_color'])) { echo 'style="background:' . $section['mts_features_icon_bg_color'] . '"'; } ?>></i>
												</div>
											<?php } ?>
											<h5 class="feature-title"><?php echo $features_block_title ?></h5>
											<div class="feature-desc"><?php echo $features_block_description ?></div>
										
										</div>
							<?php } } ?>
						</div>
					</div>
				</div><!-- #features -->
			
			<?php
			break;
	 
			case 'video': ?>
			
				<div id="video" class="section clearfix">
					<?php if($mts_options['mts_video_section_bg_video'] != '') { ?>
						<div class="video-bg">
							<video loop="loop" autoplay="autoplay">
								<source src="<?php echo $mts_options['mts_video_section_bg_video']; ?>"></source>
							</video>
						</div>
					<?php } ?>
					<div class="container">
						<div class="video-container">
							<?php
								$section_title = $mts_options['mts_video_title'];
								$section_sub_title = $mts_options['mts_video_sub_title'];	
								
								if (!empty($section_title)) {		
							?>
							<h3 class="section-title-two" data-scroll-reveal="enter top move 50px"><?php echo $section_title ?></h3>
							<div class="section-desc" data-scroll-reveal="enter bottom move 50px"><?php echo $section_sub_title ?></div>	
							<?php } ?>
							<?php $section_features = array();
							if (!empty($mts_options['mts_home_video'])) {
								foreach ($mts_options['mts_home_video'] as $section) {
									$video_button_title = $section['mts_video_button_title'];
									$video_button_icon = $section['mts_button_video_icon'];
						
									if (!empty($section['mts_video_button_url'])) { ?>				
										<a href="<?php echo $section['mts_video_button_url']; ?>" rel="prettyPhoto">
											<span class="video-button">
												<?php if(!empty($video_button_icon)) { ?><i class="fa fa-<?php echo $video_button_icon; ?>"></i><?php } ?>
												<?php echo $video_button_title; ?>
											</span>
										</a>
									<?php } else {
										?>
										<span class="video-button">
											<?php echo $video_button_title; ?>
										</span>
									<?php }
								}
							} ?>
						</div>
					</div>
				</div><!-- #video -->
			
			<?php
			break;
	 
			case 'screenshots': ?>
			
				<div id="screenshots" class="section clearfix">
					<?php if($mts_options['mts_screenshots_section_bg_video'] != '') { ?>
						<div class="video-bg">
							<video loop="loop" autoplay="autoplay">
								<source src="<?php echo $mts_options['mts_screenshots_section_bg_video']; ?>"></source>
							</video>
						</div>
					<?php } ?>
					<div class="container">
						<?php
							$section_title = $mts_options['mts_screenshots_title'];
							$section_sub_title = $mts_options['mts_screenshots_sub_title'];	
							
							if (!empty($section_title)) {		
						?>
						<div class="section-title-wrap" data-scroll-reveal="enter top move 100px">
							<h3 class="section-title"><?php echo $section_title ?></h3>
							<div class="section-sub-title"><?php echo $section_sub_title ?></div>			
						</div>
						<?php } ?>
						<div id="screenslider" class="screenslider">
							<ul class="slides">
								<?php
									if (!empty($mts_options['mts_screenshots'])) {
										foreach ($mts_options['mts_screenshots'] as $section) {
											$ss_img_id = $section['mts_screenshots_image'];
											?>
											<li>	
												<div class="ss-image">
													<?php echo wp_get_attachment_image($ss_img_id, 'full', false, array('title' => '')); ?>
												</div>
												<div class="clear"></div>
											</li>								
								<?php } } ?>
							</ul>
						</div>
					</div>
				</div><!-- #screenshots -->
			
			<?php
			break;
	 
			case 'reviews': ?>

				<div id="reviews" class="section clearfix">
					<?php if($mts_options['mts_reviews_section_bg_video'] != '') { ?>
						<div class="video-bg">
							<video loop="loop" autoplay="autoplay">
								<source src="<?php echo $mts_options['mts_reviews_section_bg_video']; ?>"></source>
							</video>
						</div>
					<?php } ?>
					<div class="container">
						<?php
							$section_title = $mts_options['mts_reviews_title'];
							$section_sub_title = $mts_options['mts_reviews_sub_title'];	
							
							if (!empty($section_title)) {		
						?>
						<div class="section-title-wrap" data-scroll-reveal="enter top move 100px">
							<h3 class="section-title"><?php echo $section_title ?></h3>
							<div class="section-sub-title"><?php echo $section_sub_title ?></div>			
						</div>
						<?php } ?>
					</div><!-- container -->
					<div class="slider-container">
						<div class="reviews-container">
							<div id="reviewslider" class="reviewlider" data-scroll-reveal="enter bottom move 50px">
								<ul class="slides">
									<?php
										if (!empty($mts_options['mts_home_reviews'])) {
											foreach ($mts_options['mts_home_reviews'] as $section) {
												$user_review_name_detail = $section['mts_review_name'];
												$user_review_desc_detail = $section['mts_review_description'];
												$user_review_loc_detail = $section['mts_review_loc'];
												$user_review_img_id_detail = $section['mts_cust_review_image'];
												?>
												<li>	
													<div class="cust-review-image">
														<?php echo wp_get_attachment_image($user_review_img_id_detail, 'profile', false, array('title' => '')); ?>
													</div>							
													<h4 class="cust-review-title"><?php echo $user_review_name_detail; ?></h4>
													<div class="cust-review-location cust-review-location-main"><?php echo $user_review_loc_detail; ?></div>
													<div class="cust-review-desc cust-review-desc-main">
														<p><?php echo $user_review_desc_detail; ?></p>
													</div>
													<?php
														if ($section['mts_review_rating'] != '') {
															$opt_rating = $section['mts_review_rating'];
															if ($opt_rating > 5) {
																$orig_rating = 5;
																$rating = 20 * 5;
															} else {
																$orig_rating = $opt_rating;			
																$rating = 20 * $opt_rating;		
															}
															?>
															<div class="cust-review-rating">
																<i class="fa fa-star"></i>
																<i class="fa fa-star"></i>
																<i class="fa fa-star"></i>
																<i class="fa fa-star"></i>
																<i class="fa fa-star"></i>
																<div class="cust-review-result" style="width: <?php echo $rating; ?>%;">
																	<i class="fa fa-star"></i>
																	<i class="fa fa-star"></i>
																	<i class="fa fa-star"></i>
																	<i class="fa fa-star"></i>
																	<i class="fa fa-star"></i>
																</div>
																<div class="final-rating">
																	<?php echo $orig_rating; _e(' / 5','mythemeshop'); ?>
																</div>
															</div>
													<?php } ?>
													<div class="clear"></div>
												</li>								
									<?php } } ?>
								</ul>
							</div>
							<div id="carousel" class="reviewlider" data-scroll-reveal="enter left move 50px">
							  <ol class="flex-review-nav">
									<?php
										if (!empty($mts_options['mts_home_reviews'])) {
											foreach ($mts_options['mts_home_reviews'] as $section_detail) {
												$user_review_name = $section_detail['mts_review_name'];
												$user_review_loc = $section_detail['mts_review_loc'];
												$user_review_img_id = $section_detail['mts_cust_review_image'];
												?>
												<li <?php if (!empty($section_detail['mts_cust_reviews_bg_color'])) { echo 'style="background:' . $section_detail['mts_cust_reviews_bg_color'] . '"'; } ?>>	
													<div class="cust-review">
														<div class="cust-review-image">
															<?php echo wp_get_attachment_image($user_review_img_id, 'profile', false, array('title' => '')); ?>
														</div>
														<h4 class="cust-review-title"><?php echo $user_review_name; ?></h4>
														<div class="cust-review-location"><?php echo $user_review_loc; ?></div>
														<div class="clear"></div>
													</div>
												</li>
									<?php } } ?>
							  </ol>
							</div>
						</div>
					</div>
					<!-- slider-container -->
				</div><!-- #reviews -->
			
			<?php
			break;
	 
			case 'buttons': ?>
			
				<div id="button-section" class="section clearfix">
					<?php if($mts_options['mts_buttons_section_bg_video'] != '') { ?>
						<div class="video-bg">
							<video loop="loop" autoplay="autoplay">
								<source src="<?php echo $mts_options['mts_buttons_section_bg_video']; ?>"></source>
							</video>
						</div>
					<?php } ?>
					<div class="container">
						<div class="buttons-container">
							<?php
								$section_buttons_title = $mts_options['mts_buttons_title'];
								$section_buttons_sub_title = $mts_options['mts_buttons_sub_title'];	
								
								if (!empty($section_buttons_title)) {		
							?>
							<div data-scroll-reveal="enter top move 100px">
								<h3 class="section-title-two"><?php echo $section_buttons_title ?></h3>
								<div class="section-desc"><?php echo $section_buttons_sub_title ?></div>
							</div>
							<?php } ?>
							<?php
								if (!empty($mts_options['mts_home_buttons'])) {
									foreach ($mts_options['mts_home_buttons'] as $section_button) {
										$button_title = $section_button['mts_buttons_block_title'];
										$buttons_icon_select = $section_button['mts_buttons_icon_select'];
										$buttons_bg_type = $section_button['mts_buttons_bg_type'];
									?>	
										<?php if (!empty($section_button['mts_buttons_block_link'])) { ?>
										<?php
											if ($buttons_bg_type == 2) {
												$buttons_text_color = $section_button['mts_buttons_icon_text_color'];
												$buttons_bg_color = $section_button['mts_buttons_icon_bg_color'];
												$buttons_border_color = $section_button['mts_buttons_icon_bg_color'];
											} else {
												$buttons_text_color = $section_button['mts_buttons_icon_text_color'];
												$buttons_bg_color = 'transparent';
												$buttons_border_color = $section_button['mts_buttons_icon_text_color'];
											}
										?>
										<a href="<?php echo $section_button['mts_buttons_block_link']; ?>" data-scroll-reveal="enter bottom move 100px">
											<span class="button-home" <?php echo 'style="background:' . $buttons_bg_color . '; border-color: ' . $buttons_border_color . '; color: ' . $buttons_text_color . '"'; ?>>
												<?php if (!empty($buttons_icon_select)) { ?>
													<i class="fa fa-<?php echo $buttons_icon_select ?>"></i>
												<?php } ?>
												<?php echo $button_title; ?>
											</span>
										</a>
									<?php } else {
										?>
										<span class="button-home" <?php echo 'style="background:' . $buttons_bg_color . '; border-color: ' . $buttons_border_color . '; color: ' . $buttons_text_color . '"'; ?>  data-scroll-reveal="enter bottom move 100px">
											<?php if (!empty($buttons_icon_select)) { ?>
												<i class="fa fa-<?php echo $buttons_icon_select ?>"></i>
											<?php } ?>
											<?php echo $button_title; ?>
										</span>
									<?php }
							} } ?>
						</div>
					</div>
				</div><!-- #buttons -->
			
			<?php
			break;
	 
			case 'contact': ?>
			
				<div id="contact" class="section clearfix">
					<?php if($mts_options['mts_contact_section_bg_video'] != '') { ?>
						<div class="video-bg">
							<video loop="loop" autoplay="autoplay">
								<source src="<?php echo $mts_options['mts_contact_section_bg_video']; ?>" type="video/mp4"></source>
							</video>
						</div>
					<?php } ?>
					<div class="container">
						<?php
							$section_title = $mts_options['mts_contact_title'];
							$section_sub_title = $mts_options['mts_contact_sub_title'];	
							
							if (!empty($section_title)) {		
						?>
						<div class="section-title-wrap" data-scroll-reveal="enter top move 100px">
							<h3 class="section-title"><?php echo $section_title ?></h3>
							<div class="section-sub-title"><?php echo $section_sub_title ?></div>
						</div>
						
						<div class="form-address">
							<?php if ($mts_options['mts_contact_form'] != '0') { ?>
								<div class="contact-form-wrap" data-scroll-reveal="wait .2s and then ease-in-out 100px">
									<?php mts_contact_form(); ?>
								</div>
							<?php } ?>
							<div class="address-wrap" data-scroll-reveal="wait .2s and then ease-in-out 100px">
								<?php
									$contact_logo = $mts_options['mts_contact_logo'];
									$contact_address = $mts_options['mts_contact_address'];
									$contact_email = $mts_options['mts_contact_email'];
									$contact_phone = $mts_options['mts_contact_phone'];
								?>
								<?php if(!empty($contact_logo)) { ?><p class="contact-logo"><img src="<?php echo $contact_logo; ?>"></p><?php } ?>
								<?php if(!empty($contact_address)) { ?><p class="contact-address"><?php echo $contact_address; ?></p><?php } ?>
								<?php if(!empty($contact_email)) { ?><a href="mailto:<?php echo $contact_email; ?>"><span class="contact-email"><?php echo $contact_email; ?> <i class="fa fa-envelope-o"></i></span></a><?php } ?>
								<?php if(!empty($contact_phone)) { ?><a href="tel:<?php echo $contact_phone; ?>"><span class="contact-phone"><?php echo $contact_phone; ?> <i class="fa fa-mobile"></i></span></a><?php } ?>
							</div>
						</div>
						
						<?php } ?>
					</div>
				</div><!-- #contact -->
			
			<?php
			break;
	 
		}
	 
	}
 
	endif;
?>
<?php get_footer(); ?>