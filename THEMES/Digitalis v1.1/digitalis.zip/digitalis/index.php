<?php $mts_options = get_option('digitalis'); ?>
<?php get_header(); ?>
<div id="page">
	<div class="content">
		<article class="article">
			<div id="content_box">
				<?php if(is_home() && !is_paged()) { ?>
					<?php if ($mts_options['mts_featured_section'] == '1') { ?>
						<div class="featuredBox">
							<?php $i = 1; if(isset($mts_options['mts_featured_section_cat'])) { $slider_cat = implode(",", $mts_options['mts_featured_section_cat']); } $my_query = new WP_Query('cat='.$slider_cat.'&posts_per_page=3'); ?>
							<?php if ($my_query->have_posts()) : while ($my_query->have_posts()) : $my_query->the_post(); ?>
								<?php if($i == 1){ ?> 
									<div class="firstpost excerpt">
										<a href="<?php the_permalink() ?>" title="<?php the_title(); ?>" rel="nofollow" id="first-thumbnail">
											<?php if ( has_post_thumbnail() ) { ?> 
												<?php the_post_thumbnail('featured-first',array('title' => '')); ?>
											<?php } else { ?>
												<img width="610" height="400" src="<?php echo get_template_directory_uri(); ?>/images/nothumb1.png" class="attachment-featured wp-post-image" alt="<?php the_title(); ?>">
											<?php } ?>
											<p class="featured-excerpt">
												<span class="featured-title"><?php the_title(); ?></span>
												<span class="f-excerpt"><?php echo excerpt(24);?></span>
											</p>
										</a>
									</div>
								<?php } elseif($i == 2) { ?>
									<div class="secondpost yellow excerpt">
										<a href="<?php the_permalink() ?>" title="<?php the_title(); ?>" rel="nofollow" id="second-thumbnail">
											<?php if ( has_post_thumbnail() ) { ?> 
												<?php the_post_thumbnail('featured-second',array('title' => '')); ?>
											<?php } else { ?>
												<img width="350" height="200" src="<?php echo get_template_directory_uri(); ?>/images/nothumb2.png" class="attachment-featured wp-post-image" alt="<?php the_title(); ?>">
											<?php } ?>
											<p class="featured-excerpt">
												<span class="featured-title"><?php the_title(); ?></span>
												<span class="f-excerpt"><?php echo excerpt(6);?></span>
											</p>
										</a>
									</div>
								<?php } elseif($i == 3) { ?>
									<div class="secondpost pink excerpt">
										<a href="<?php the_permalink() ?>" title="<?php the_title(); ?>" rel="nofollow" id="second-thumbnail">
											<?php if ( has_post_thumbnail() ) { ?> 
												<?php the_post_thumbnail('featured-second',array('title' => '')); ?>
											<?php } else { ?>
												<img width="350" height="200" src="<?php echo get_template_directory_uri(); ?>/images/nothumb2.png" class="attachment-featured wp-post-image" alt="<?php the_title(); ?>">
											<?php } ?>
											<p class="featured-excerpt">
												<span class="featured-title"><?php the_title(); ?></span>
												<span class="f-excerpt"><?php echo excerpt(6);?></span>
											</p>
										</a>
									</div>
								<?php } ?>                  
							<?php $i++; endwhile; endif;?> 
						</div>
					<?php } ?>
				<?php } ?>

				<?php if (is_home() & !is_paged()) { ?>
					<?php if ($mts_options['mts_home_section_1'] == '1') { ?>
						<div class="home-section home-section-1">
							<?php $i = 1; if ($mts_options['mts_homepage_adcode'] != '') { $catnum = 5; } else { $catnum = 6; }
							$my_query = new wp_query( 'cat='.$mts_options['mts_home_section_1_cat'].'&posts_per_page='.$catnum ); ?>
							<?php $categoryID = $mts_options['mts_home_section_1_cat']; ?>
							<h4 class="frontTitle"><?php if ($mts_options['mts_home_section_1_cat']!='') { echo get_the_category_by_ID( $categoryID ); } ?></h4>
							<?php $count = '0'; if ($my_query->have_posts()) : while ($my_query->have_posts()) : $my_query->the_post(); ?>
								<div class="post300 excerpt <?php if ($mts_options['mts_homepage_adcode'] != '') { if($i % 5 == 0) {echo 'last';} } else { if($i % 3 == 0) {echo 'last';} } ?>">
									<?php if ( has_post_thumbnail() ) { ?> 
										<a id="featured-thumbnail" href="<?php the_permalink() ?>" title="<?php the_title(); ?>" rel="bookmark"><?php the_post_thumbnail('featured',array('title' => '')); ?></a>
									<?php } else { ?>
										<a id="featured-thumbnail" href="<?php the_permalink() ?>" title="<?php the_title(); ?>" rel="bookmark"><img width="300" height="249" src="<?php echo get_template_directory_uri(); ?>/images/nothumb3.png" class="attachment-featured wp-post-image" alt="<?php the_title(); ?>"></a>
									<?php } ?>
									<div class="post-hover-content">
										<h2 class="front-view-title"><a href="<?php the_permalink() ?>" title="<?php the_title(); ?>" rel="bookmark"><?php the_title(); ?></a></h2>
										<div class="front-view-content">
											<?php echo excerpt(18); ?>
										</div>
										<div class="readMore">
											<a href="<?php the_permalink() ?>" title="<?php the_title(); ?>" rel="bookmark"><?php _e('Read More','mythemeshop'); ?></a>
										</div>
									</div>
								</div>
								<?php if ($count == 1) : ?>
									<?php if ($mts_options['mts_homepage_adcode'] != '') { ?>
										<div class="homead">
											<?php echo $mts_options['mts_homepage_adcode']; ?>
										</div><!-- .homead -->
									<?php } ?>
								<?php endif; $count++; ?>
							<?php $i++; endwhile; endif;?>
						</div>
					<?php } ?>
				<?php } ?>
				
				<?php if (is_home() & !is_paged()) { ?>
					<?php if ($mts_options['mts_home_section_2'] == '1') { ?>
						<div class="home-section home-section-2">
							<?php $i = 1; $my_query = new wp_query( 'cat='.$mts_options['mts_home_section_2_cat'].'&posts_per_page=3' ); ?>
							<?php $categoryID = $mts_options['mts_home_section_2_cat']; ?>
							<h4 class="frontTitle"><?php if ($mts_options['mts_home_section_2_cat']!='') { echo get_the_category_by_ID( $categoryID ); } ?></h4>
							<?php if ($my_query->have_posts()) : while ($my_query->have_posts()) : $my_query->the_post(); ?>
								<div class="post excerpt <?php echo (++$i % 3 == 0) ? 'last' : ''; ?>">
									<a href="<?php the_permalink() ?>" title="<?php the_title(); ?>" rel="nofollow" id="featured-thumbnail">
										<?php if ( has_post_thumbnail() ) { ?> 
											<?php echo '<div class="featured-thumbnail">'; the_post_thumbnail('related',array('title' => '')); echo '</div>'; ?>
										<?php } else { ?>
											<div class="featured-thumbnail">
												<img width="100" height="100" src="<?php echo get_template_directory_uri(); ?>/images/relthumb.png" class="attachment-featured wp-post-image" alt="<?php the_title(); ?>">
											</div>
										<?php } ?>
									</a>
									<header>						
										<h2 class="title">
											<a href="<?php the_permalink() ?>" title="<?php the_title(); ?>" rel="bookmark"><?php the_title(); ?></a>
										</h2>
									</header>
									<div class="post-content image-caption-format-1">
										<?php echo excerpt(9);?>
									</div>
								</div>     
							<?php $i++; endwhile; endif;?>
						</div>
					<?php } ?>
				<?php } ?>
				
				<?php if (is_home() & !is_paged()) { ?>
					<?php if ($mts_options['mts_home_section_3'] == '1') { ?>
						<div class="home-section home-section-3">
							<?php $i = 1; $my_query = new wp_query( 'cat='.$mts_options['mts_home_section_3_cat'].'&posts_per_page=2' ); ?>
							<?php $categoryID = $mts_options['mts_home_section_3_cat']; ?>
							<h4 class="frontTitle"><?php if ($mts_options['mts_home_section_3_cat']!='') { echo get_the_category_by_ID( $categoryID ); } ?></h4>
							<?php if ($my_query->have_posts()) : while ($my_query->have_posts()) : $my_query->the_post(); ?>
								<div class="post465 excerpt <?php if($i % 2 == 0){echo 'last pink';} ?>">
									<?php if ( has_post_thumbnail() ) { ?> 
										<a id="featured-thumbnail-3" href="<?php the_permalink() ?>" title="<?php the_title(); ?>" rel="bookmark"><?php the_post_thumbnail('featured-third',array('title' => '')); ?></a>
									<?php } else { ?>
										<div class="featured-thumbnail">
											<a id="featured-thumbnail-3" href="<?php the_permalink() ?>" title="<?php the_title(); ?>" rel="bookmark"><img width="465" height="300" src="<?php echo get_template_directory_uri(); ?>/images/nothumb4.png" class="attachment-featured wp-post-image" alt="<?php the_title(); ?>"></a>
										</div>
									<?php } ?>
									<div class="post-content-2">
										<h2 class="front-view-title"><a href="<?php the_permalink() ?>" title="<?php the_title(); ?>" rel="bookmark"><?php the_title(); ?></a></h2>
										<div class="front-view-content">
											<?php echo excerpt(8); ?>
										</div>
									</div>
								</div>                   
							<?php $i++; endwhile; endif;?>
						</div>
					<?php } ?>
				<?php } ?>
				
				<div class="home-section">
					<h4 class="frontTitle"><?php _e('Latest Posts','mythemeshop'); ?></h4>
					<?php $j = 1; if (have_posts()) : while (have_posts()) : the_post(); ?>
						<div class="post excerpt <?php echo (++$j % 3 == 0) ? 'last' : ''; ?>">
							<a href="<?php the_permalink() ?>" title="<?php the_title(); ?>" rel="nofollow" id="featured-thumbnail">
								<?php if ( has_post_thumbnail() ) { ?> 
									<?php echo '<div class="featured-thumbnail">'; the_post_thumbnail('related',array('title' => '')); echo '</div>'; ?>
								<?php } else { ?>
									<div class="featured-thumbnail">
										<img width="100" height="100" src="<?php echo get_template_directory_uri(); ?>/images/relthumb.png" class="attachment-featured wp-post-image" alt="<?php the_title(); ?>">
									</div>
								<?php } ?>
							</a>
							<header>						
								<h2 class="title">
									<a href="<?php the_permalink() ?>" title="<?php the_title(); ?>" rel="bookmark"><?php the_title(); ?></a>
								</h2>
							</header>
							<div class="post-content image-caption-format-1">
								<?php echo excerpt(9);?>
							</div>
						</div>
					<?php $j++; endwhile; endif; ?>	
				</div>
				
				<!--Start Pagination-->
				<?php if ( isset($mts_options['mts_pagenavigation']) == '1' ) { ?>
					<?php  $additional_loop = 0; pagination($additional_loop['max_num_pages']); ?>           
				<?php } else { ?>
					<div class="pagination">
						<ul>
							<li class="nav-previous"><?php next_posts_link( __( '&larr; '.'Older posts', 'mythemeshop' ) ); ?></li>
							<li class="nav-next"><?php previous_posts_link( __( 'Newer posts'.' &rarr;', 'mythemeshop' ) ); ?></li>
						</ul>
					</div>
				<?php } ?>
				<!--End Pagination-->
				
			</div>
		</article>
<?php get_footer(); ?>