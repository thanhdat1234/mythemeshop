<?php
$mts_options = get_option('digitalis');	

/*------------[ Meta ]-------------*/
if ( ! function_exists( 'mts_meta' ) ) {
	function mts_meta() { 
	global $mts_options
?>
<?php if ($mts_options['mts_favicon'] != '') { ?>
<link rel="icon" href="<?php echo $mts_options['mts_favicon']; ?>" type="image/x-icon" />
<?php } ?>
<!--iOS/android/handheld specific -->
<link rel="apple-touch-icon" href="<?php echo get_template_directory_uri(); ?>/apple-touch-icon.png" />
<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
<meta name="apple-mobile-web-app-capable" content="yes">
<meta name="apple-mobile-web-app-status-bar-style" content="black">
<?php if(isset($mts_options['mts_prefetching']) == '1') { ?>
<?php if (is_front_page()) { ?>
	<?php $my_query = new WP_Query('posts_per_page=1'); while ($my_query->have_posts()) : $my_query->the_post(); ?>
	<link rel="prefetch" href="<?php the_permalink(); ?>">
	<link rel="prerender" href="<?php the_permalink(); ?>">
	<?php endwhile; wp_reset_query(); ?>
<?php } elseif (is_singular()) { ?>
	<link rel="prefetch" href="<?php echo home_url(); ?>">
	<link rel="prerender" href="<?php echo home_url(); ?>">
<?php } ?>
<?php } ?>
<?php }
}

/*------------[ Head ]-------------*/
if ( ! function_exists( 'mts_head' ) ) {
	function mts_head() { 
	global $mts_options
?>
<style type="text/css">
<?php if($mts_options['mts_bg_color'] != '') { ?>
body {background-color:<?php echo $mts_options['mts_bg_color']; ?>;}
<?php } ?>
<?php if ($mts_options['mts_bg_pattern_upload'] != '') { ?>
body {background-image: url(<?php echo $mts_options['mts_bg_pattern_upload']; ?>);}
<?php } else { ?>
<?php if($mts_options['mts_bg_pattern'] != '') { ?>
body {background-image:url(<?php echo get_template_directory_uri(); ?>/images/<?php echo $mts_options['mts_bg_pattern']; ?>.png);}
<?php } ?>
<?php } ?>
<?php if ($mts_options['mts_color_scheme'] != '') { ?>
.featured-excerpt, .mts-subscribe input[type="submit"], .sbutton, #commentform input#submit, .tagcloud a, .advanced-recent-posts li:hover, .popular-posts li:hover, .category-posts li:hover, #move-to-top:hover, #wp-calendar thead th, #wp-calendar td:hover, #wp-calendar td a:hover, #wp-calendar td:hover a, #commentform input#submit, .contactform #submit, .woocommerce a.button, .woocommerce-page a.button, .woocommerce button.button, .woocommerce-page button.button, .woocommerce input.button, .woocommerce-page input.button, .woocommerce #respond input#submit, .woocommerce-page #respond input#submit, .woocommerce #content input.button, .woocommerce-page #content input.button {background-color:<?php echo $mts_options['mts_color_scheme']; ?>; }
a:hover, .post300.green a, .single_post a, .textwidget a, #commentform a, .copyrights a:hover, a, .sidebar.c-4-12 a:hover, #tabber .inside li a:hover, footer .widget li a:hover, .woocommerce .woocommerce-breadcrumb a, .woocommerce-page .woocommerce-breadcrumb a, .sidebar .widget_text a {color:<?php echo $mts_options['mts_color_scheme']; ?>; }
<?php } ?>
<?php if ($mts_options['mts_sec_1_color_scheme'] != '') { ?>
.featuredBox .yellow .featured-excerpt, .post-content-2, .commentlist .children li.bypostauthor .commentmetadata:after {background-color:<?php echo $mts_options['mts_sec_1_color_scheme']; ?>; }
.post300.yellow a, .post-info .thetime {color:<?php echo $mts_options['mts_sec_1_color_scheme']; ?>; }
<?php } ?>
<?php if ($mts_options['mts_sec_2_color_scheme'] != '') { ?>
.featuredBox .pink .featured-excerpt, .post465.pink .post-content-2 {background-color:<?php echo $mts_options['mts_sec_2_color_scheme']; ?>; }
.post300.pink a, .post-info .theauthor a {color:<?php echo $mts_options['mts_sec_2_color_scheme']; ?>; }
<?php } ?>
<?php if($mts_options['mts_floating_social'] == '1') { ?>
.shareit { top: 282px; left: auto; z-index: 0; margin: 0 0 0 -118px; width: 90px; position: fixed; overflow: hidden; padding: 5px; background: white; }
.share-item {margin: 2px;}
<?php } ?>
<?php if ($mts_options['mts_layout'] == 'sclayout') { ?>
.article { float: right;}
.sidebar.c-4-12 { float: left; padding-right: 0; padding-left: 0; }
<?php if($mts_options['mts_floating_social'] == '1') { ?>
.shareit { margin: 0 644px 0; border-left: 0; border-right: 1px solid #E2E2E2; }
<?php } ?>
<?php } ?>
<?php if($mts_options['mts_author_comment'] == '1') { ?>
.commentlist .children li.bypostauthor .commentmetadata:after { content: "<?php _e('Author','mythemeshop'); ?>"; position: absolute; left: 0; top: 0; padding: 0 14px; color: #fff; text-indent: 0; border-radius: 3px; font-size: 13px; line-height: 1.6;}
.bypostauthor .commentmetadata p:first-child { text-indent: 90px;}
.bypostauthor {background: #FAFAFA;}
<?php } ?>
<?php echo $mts_options['mts_custom_css']; ?>
</style>
<?php echo $mts_options['mts_header_code']; ?>
<?php }
}
add_action('wp_head', 'mts_head');

/*------------[ Copyrights ]-------------*/
if ( ! function_exists( 'mts_copyrights_credit' ) ) {
	function mts_copyrights_credit() { 
	global $mts_options
?>
<!--start copyrights-->
<div class="row" id="copyright-note">
<span><a href="<?php echo home_url(); ?>/" title="<?php bloginfo('description'); ?>"><?php bloginfo('name'); ?></a> Copyright &copy; <?php echo date("Y") ?>.</span>
<div class="top"><?php echo $mts_options['mts_copyrights']; ?></div>
</div>
<!--end copyrights-->
<?php }
}

/*------------[ footer ]-------------*/
if ( ! function_exists( 'mts_footer' ) ) {
	function mts_footer() { 
	global $mts_options
?>
<?php if($mts_options['mts_lightbox'] == '1') { ?>
<!--start lightbox-->
<script type="text/javascript">  
jQuery(document).ready(function() {
	jQuery("a[href$='.jpg'], a[href$='.jpeg'], a[href$='.gif'], a[href$='.png'], a[rel^='prettyPhoto']").prettyPhoto({
		slideshow: 5000,
		autoplay_slideshow: false,
		animationSpeed: 'normal',
		padding: 40,
		opacity: 0.35,
		showTitle: true,
		social_tools: false
	});
})
</script>
<!--end lightbox-->
<?php } ?>
<!--start multicolor-->
<script type="text/javascript">
	var classNames = ['green','yellow','pink'];
	jQuery('.home-section-1').children('.post300').addClass(function(i){
		return classNames[ i % classNames.length ];
	});
	jQuery('.home-section-1').children('.post300').addClass(function(i){
		return classNames[ i % classNames.length ];
	});
</script>
<!--end multicolor-->
<?php if ($mts_options['mts_analytics_code'] != '') { ?>
<!--start footer code-->
<?php echo $mts_options['mts_analytics_code']; ?>
<!--end footer code-->
<?php } ?>
<?php }
}
?>