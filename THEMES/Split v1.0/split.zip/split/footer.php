<?php $options = get_option('split'); ?>
		</div>
	</div><!--#page-->
</div><!--.main-container-->
<footer>
	<div class="container">
		<div class="footer-widgets">
			<?php widgetized_footer(); ?>
		</div><!--.footer-widgets-->
	</div><!--.container-->
	<div class="copyrights">
		<?php mts_copyrights_credit(); ?>
	</div> 
</footer><!--footer-->
<?php mts_footer(); ?>
<?php wp_footer(); ?>
</body>
</html>