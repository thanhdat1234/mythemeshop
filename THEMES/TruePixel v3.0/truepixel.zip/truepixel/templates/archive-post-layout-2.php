<?php $mts_options = get_option(MTS_THEME_NAME); ?>
<header>
	<h2 class="title front-view-title" itemprop="headline"><a href="<?php the_permalink() ?>" title="<?php the_title(); ?>"><?php the_title(); ?></a></h2>
	<?php mts_the_postinfo(); ?>
</header>
<?php if(has_post_thumbnail() && empty($mts_options['mts_full_posts'])) { ?>
	<a href="<?php the_permalink() ?>" title="<?php the_title(); ?>" rel="nofollow" class="post-image post-image-fullwidth">
		<?php echo '<div class="featured-thumbnail">'; the_post_thumbnail('slider',array('title' => '')); echo '</div>'; ?>
		<?php if (function_exists('wp_review_show_total')) wp_review_show_total(true, 'latestPost-review-wrapper'); ?>
	</a>
<?php } ?>
<?php if (empty($mts_options['mts_full_posts'])) : ?>
	<div class="front-view-content">
		<?php echo mts_excerpt(43); ?>
	</div>
	<?php mts_readmore(); ?>
<?php else : ?>
	<div class="front-view-content full-post">
		<?php the_content(); ?>
	</div>
	<?php if (mts_post_has_moretag()) : ?>
		<?php mts_readmore(); ?>
	<?php endif; ?>
<?php endif; ?>