<?php $options = get_option('top'); ?>
<?php get_header(); ?>
<div id="page">
	<div class="content">
		<article class="article">
			<div id="content_box">
					<h1 class="postsby">
						<?php if (is_category()) { ?>
							<span><?php single_cat_title(); ?><?php _e(" Archive", "mythemeshop"); ?></span>
						<?php } elseif (is_tag()) { ?> 
							<span><?php single_tag_title(); ?><?php _e(" Archive", "mythemeshop"); ?></span>
						<?php } elseif (is_search()) { ?> 
							<span><?php _e("Search Results for:", "mythemeshop"); ?></span> <?php the_search_query(); ?>
						<?php } elseif (is_author()) { ?>
							<span><?php _e("Author Archive", "mythemeshop"); ?></span> 

						<?php } elseif (is_day()) { ?>
							<span><?php _e("Daily Archive:", "mythemeshop"); ?></span> <?php the_time('l, F j, Y'); ?>
						<?php } elseif (is_month()) { ?>
							<span><?php _e("Monthly Archive:", "mythemeshop"); ?>:</span> <?php the_time('F Y'); ?>
						<?php } elseif (is_year()) { ?>
							<span><?php _e("Yearly Archive:", "mythemeshop"); ?>:</span> <?php the_time('Y'); ?>
						<?php } ?>
					</h1>
					<?php if (have_posts()) : while (have_posts()) : the_post(); ?>
						<div class="post excerpt">
							<header>
							<div class="featured-thumbnail">
								<a href="<?php the_permalink() ?>" title="<?php the_title(); ?>" rel="nofollow" id="featured-thumbnail">
								<?php if ( has_post_thumbnail() ) { ?> 
								<?php the_post_thumbnail('featured', array('title' => '')); ?>
								<?php } else { ?>
								<img width="125" height="125" src="<?php echo get_template_directory_uri(); ?>/images/nothumb.png" class="attachment-featured wp-post-image" alt="<?php the_title(); ?>">
								<?php } ?>
								</a>
								<?php if($options['mts_home_social'] == '1') { ?>
								<div class="home-share">
								<span class="share-item twitterbtn">
									<a href="https://twitter.com/share" class="twitter-share-button" data-text="<?php the_title(); ?>" data-url="<?php the_permalink() ?>" data-via="<?php echo $options['mts_twitter_username']; ?>" data-count="vertical">Tweet</a>
								</span>
								<span class="share-item facebookbtn">
									<div id="fb-root"></div>
									<div class="fb-like" data-href="<?php the_permalink() ?>" data-send="false" data-layout="box_count" data-width="150" data-show-faces="false"></div>
								</span>
								</div>
								<?php } ?>
								</div>
								<h2 class="title">
									<a href="<?php the_permalink() ?>" title="<?php the_title(); ?>" rel="bookmark"><?php the_title(); ?></a>
								</h2>
							<?php if($options['mts_headline_meta'] == '1') { ?>
								<div class="post-info">
									<span class="theauthor"><?php _e('Posted by ', 'mythemeshop'); the_author_posts_link(); ?></span>
									<time><?php _e('On ', 'mythemeshop'); the_time('F j, Y'); ?></time>
									<span class="thecategory"><?php _e('In ', 'mythemeshop'); the_category(', ') ?></span>
									<span class="thecomments"><a href="<?php comments_link(); ?>"><?php comments_number('No comments','1 Comment','% Comments'); ?></a></span>
								</div>
							<?php } ?>
							</header><!--.header-->
							<div class="post-content image-caption-format-1">
								<?php the_excerpt();?>
<p class="more"><a href="<?php the_permalink() ?>" rel="nofollow">Read More...</a></p>
							</div>
						</div><!--.post excerpt-->
					<?php endwhile; else: ?>
						<div class="post excerpt">
							<div class="no-results">
								<p><strong><?php _e('There has been an error.', 'mythemeshop'); ?></strong></p>
								<p><?php _e('We apologize for any inconvenience, please hit back on your browser or use the search form below.', 'mythemeshop'); ?></p>
								<?php get_search_form(); ?>
							</div><!--noResults-->
						</div>
					<?php endif; ?>
						<?php if ($options['mts_pagenavigation'] == '1') { ?>
							<?php pagination($additional_loop->max_num_pages);?>
						<?php } else { ?>
							<div class="pnavigation2">
								<div class="nav-previous left"><?php next_posts_link( __( '<span class="meta-nav">&larr;</span> '.'Older posts', 'twentyten' ) ); ?></div>
								<div class="nav-next right"><?php previous_posts_link( __( 'Newer posts'.' <span class="meta-nav">&rarr;</span>', 'twentyten' ) ); ?></div>
							</div>
						<?php } ?>
			</div>
		</article>
<?php get_sidebar(); ?>
<?php get_footer(); ?>