<!DOCTYPE html>
<?php $options = get_option('top'); ?>
<html class="no-js" dir="ltr" <?php language_attributes(); ?>>

<head>
	<meta charset="UTF-8">
	
	<title><?php wp_title(''); ?></title>
	
	<?php if ($options['mts_favicon'] != '') { ?>
	<link rel="icon" href="<?php echo $options['mts_favicon']; ?>" type="image/x-icon" />
	<?php } ?>
	
<!--iOS/android/handheld specific -->	
	<link rel="apple-touch-icon" href="apple-touch-icon.png">			
	<meta name="viewport" content="width=device-width, initial-scale=1.0">						
	<meta name="apple-mobile-web-app-capable" content="yes">
	<meta name="apple-mobile-web-app-status-bar-style" content="black">

	<link rel="stylesheet" type="text/css" media="all" href="<?php bloginfo( 'stylesheet_url' ); ?>" />

	<?php if ($options['mts_title_font'] != '') { ?>
		<?php if ($options['mts_title_font'] == 'georgia') { ?>
		<?php } else { ?>
			<link href="http://fonts.googleapis.com/css?family=<?php echo $options['mts_title_font']; ?>:400,400italic,700,700italic" rel="stylesheet" type="text/css">
			<style type="text/css">
				.title, h1,h2,h3,h4,h5,h6, #header-logo h1, #header-logo h2, .secondary-navigation a, .widget h3, .total-comments {
					font-family: '<?php echo $options['mts_title_font']; ?>', sans-serif;
				}
			</style>
		<?php } ?>
	<?php } ?>
	<?php if($options['mts_lightbox'] == '1') { ?>
		<link rel="stylesheet" href="<?php bloginfo('template_directory'); ?>/css/prettyPhoto.css" type="text/css" media="screen" charset="utf-8" />
<script src="http://ajax.googleapis.com/ajax/libs/jquery/1.6.2/jquery.min.js"></script>
		<script src="<?php bloginfo('template_directory'); ?>/js/jquery.prettyPhoto.js"></script>
		<script type="text/javascript">  
			jQuery(document).ready(function($) {
				$("a[href$='.jpg'], a[href$='.jpeg'], a[href$='.gif'], a[href$='.png']").prettyPhoto({
				slideshow: 5000, /* false OR interval time in ms */
				autoplay_slideshow: false, /* true/false */
				animationSpeed: 'normal', /* fast/slow/normal */
				padding: 40, /* padding for each side of the picture */
				opacity: 0.35, /* Value betwee 0 and 1 */
				showTitle: true, /* true/false */	
				social_tools: false
				});
			})
		</script>
	<?php } ?>
	<?php if ($options['mts_content_font'] != '') { ?>
		<?php if ($options['mts_content_font'] == 'corbel') { ?>
		<?php } else { ?>
			<link href="http://fonts.googleapis.com/css?family=<?php echo $options['mts_content_font']; ?>:400,400italic,700,700italic" rel="stylesheet" type="text/css">
			<style type="text/css">
				body {
					font-family: '<?php echo $options['mts_content_font']; ?>', sans-serif;
				}
			</style>
		<?php } ?>
	<?php } ?>

	<link rel="pingback" href="<?php bloginfo( 'pingback_url' ); ?>" />

	<?php wp_enqueue_script("jquery"); ?>
	<?php if ( is_singular() ) wp_enqueue_script( 'comment-reply' ); ?>
	<!--[if lt IE 9]>
		<script src="http://html5shim.googlecode.com/svn/trunk/html5.js"></script>
	<![endif]-->
	
	<?php wp_head(); ?>
	<script src="http://ajax.googleapis.com/ajax/libs/jquery/1.6.2/jquery.min.js"></script>
	<script src="<?php echo get_template_directory_uri(); ?>/js/modernizr.min.js"></script>
	<script src="<?php echo get_template_directory_uri(); ?>/js/customscript.js" type="text/javascript"></script>
	<link rel="stylesheet" href="<?php echo get_template_directory_uri(); ?>/css/flexslider.css" type="text/css">
	<script src="<?php echo get_template_directory_uri(); ?>/js/jquery.flexslider.js"></script>
	<script type="text/javascript">
  $(window).load(function() {
    $('.flexslider').flexslider({
          animation: "fade",
		  pauseOnHover: true,
          controlsContainer: ".flex-container"
    });
  });

</script>
	
	<style type="text/css">
		body {
			<?php if ($options['mts_bg_pattern_upload'] != '') { ?>
				background-image: url(<?php echo $options['mts_bg_pattern_upload']; ?>);
			<?php } else { ?>
			<?php if($options['mts_bg_pattern'] != '') { ?>
				background: <?php if($options['mts_bg_color'] != '') { ?><?php echo $options['mts_bg_color']; ?><?php } ?> url(<?php echo get_template_directory_uri(); ?>/images/<?php echo $options['mts_bg_pattern']; ?>.png) repeat;
			<?php } ?>
			<?php } ?>
			<?php if ($options['mts_body_font_color'] != '') { ?>
				color: <?php echo $options['mts_body_font_color']; ?>;
			<?php } ?>
			}
		
			
		<?php if ($options['mts_logo'] != '') { ?>
			#header h1, #header h2 {
			text-indent: -999em;
			min-width:211px;
			margin: 0;
			margin-bottom:10px;
			}
			#header h1 a, #header h2 a{
			background: url(<?php echo $options['mts_logo']; ?>) no-repeat;
			min-width: 211px;
			display: block;
			min-height: 65px;
			line-height: 28px;
			}
		<?php } ?>
		<?php if($options['mts_color_scheme'] != '') { ?>
		.currenttext, .pagination a:hover, #commentform input#submit, #navigation ul li li:hover > a {
				background-color: <?php echo $options['mts_color_scheme']; ?>;
			}
		.footer-widgets .widget h3 {
			border-left:0;
			}
		.widget h3 {
			border-left:3px solid <?php echo $options['mts_color_scheme']; ?>;
			}
		a, .title a:hover {
			color:<?php echo $options['mts_color_scheme']; ?>;
			}
		.currenttext, .pagination a:hover {
			border-color:<?php echo $options['mts_color_scheme']; ?>;
			}
			<?php } ?>
		<?php if($options['mts_title_size'] != '') { ?>
			.title {
				font-size:<?php echo $options['mts_title_size']; ?>px;
				line-height:120%;
			}
		<?php } ?>
		<?php if ($options['mts_body_size'] != '') { ?>
			body, .post-content {
				font-size:<?php echo $options['mts_body_size']; ?>px;
				line-height:150%;
			}
		<?php } ?>
		<?php if($options['mts_author_comment'] == '1') { ?>
			.bypostauthor {
				border: 1px solid #E7E7E7!important;
				padding: 15px 15px 0!important;
				background: #F8F8F8;
			}
			.bypostauthor .reply { border-bottom:0; }
		<?php } ?>
		<?php if($options['mts_floating_social'] == '1') { ?>
			.shareit {
				top: 335px;
				left: auto;
				z-index: 0;
				margin: 0 0 0 -95px;
				width: 90px;
				position: fixed;
				overflow: hidden;
				border-radius: 6px;
				-moz-border-radius: 6px;
				-webkit-border-radius: 6px;
				padding: 3px;
				background: #fff;
				border: 1px solid #DDD;
				padding-top: 3px;
			}
			.share-item {
				margin: 2px;
			}
		<?php } ?>

			<?php if($options['mts_bg_pattern'] != '') { ?>
			<?php if($options['mts_layout'] == 'cslayout') { ?>
			<?php if($options['mts_floating_social'] == '1') { ?>
			.shareit {
			margin:0 0 0 -135px;
			}
			<?php } ?>
			<?php } ?>
			<?php } ?>

		<?php if($options['mts_layout'] == 'sclayout') { ?>
			.article {
				float: right;
				}
			#content_box {
				padding-right: 0;
				padding-left: 30px;
			}
			<?php if($options['mts_floating_social'] == '1') { ?>
				.shareit {
					margin: 0 0 0 660px;
				}
			<?php } ?>
		<?php } ?>
	<?php echo $options['mts_custom_css']; ?>
	</style>

	<?php echo $options['mts_header_code']; ?>
</head>
<?php flush(); ?>
<body id ="blog" <?php body_class('main'); ?>>
<div id="top-line"></div>
<div class="navigation">
	<div class="container">
				<div class="main-navigation">
			<nav id="navigation">
<div class="white-fix-left"></div>
				<?php if ( has_nav_menu( 'primary-menu' ) ) { ?>
					<?php wp_nav_menu( array( 'theme_location' => 'primary-menu', 'menu_class' => 'menu', 'container' => '' ) ); ?>
				<?php } else { ?>
					<ul class="menu">
						<li class="home-tab"><a href="<?php echo home_url(); ?>">Home</a></li>
						<?php wp_list_pages('title_li='); ?>
					</ul>
				<?php } ?><!--#nav-primary-->
			</nav>
			</div>
	</div>
</div>

		<header class="main-header">
		<div class="container">
				<div id="header">
					<?php if( is_front_page() || is_home() || is_404() ) { ?>
							<h1 id="logo">
								<a href="<?php echo home_url(); ?>"><?php bloginfo( 'name' ); ?></a>
							</h1><!-- END #logo -->
					<?php } else { ?>
							<h2 id="logo">
								<a href="<?php echo home_url(); ?>"><?php bloginfo( 'name' ); ?></a>
							</h2><!-- END #logo -->
					<?php } ?>
					<?php if ( ! dynamic_sidebar( 'Header' ) ) : ?>
					<?php endif ?>
				</div><!--#header-->
		</div><!--.container-->
		</header>
<div class="main-container">