<?php $options = get_option('style'); ?>
<?php get_header(); ?>
<div id="page">
	<div class="content">
		<article class="article">
			<div id="content_box">
				<h1 class="postsby">
					<?php if (is_category()) { ?>
						<span><?php single_cat_title(); ?><?php _e(" Archive", "mythemeshop"); ?></span>
					<?php } elseif (is_tag()) { ?> 
						<span><?php single_tag_title(); ?><?php _e(" Archive", "mythemeshop"); ?></span>
					<?php } elseif (is_search()) { ?> 
						<span><?php _e("Search Results for:", "mythemeshop"); ?></span> <?php the_search_query(); ?>
					<?php } elseif (is_author()) { ?>
						<span><?php _e("Author Archive", "mythemeshop"); ?></span> 
					<?php } elseif (is_day()) { ?>
						<span><?php _e("Daily Archive:", "mythemeshop"); ?></span> <?php the_time('l, F j, Y'); ?>
					<?php } elseif (is_month()) { ?>
						<span><?php _e("Monthly Archive:", "mythemeshop"); ?>:</span> <?php the_time('F Y'); ?>
					<?php } elseif (is_year()) { ?>
						<span><?php _e("Yearly Archive:", "mythemeshop"); ?>:</span> <?php the_time('Y'); ?>
					<?php } ?>
				</h1>
				<?php if (have_posts()) : while (have_posts()) : the_post(); ?>
					<div class="post excerpt <?php echo (++$j % 3 == 0) ? 'last ' : ''; echo (++$k % 4 == 0) ? 'flast' : ''; ?>">
						<a href="<?php the_permalink() ?>" title="<?php the_title(); ?>" rel="nofollow" id="featured-thumbnail">
							<?php if ( has_post_thumbnail() ) { ?> 
								<?php echo '<div class="featured-thumbnail">'; the_post_thumbnail('featured',array('title' => '')); echo '</div>'; ?>
							<?php } else { ?>
								<div class="featured-thumbnail">
									<img width="200" height="150" src="<?php echo get_template_directory_uri(); ?>/images/nothumb.png" class="attachment-featured wp-post-image" alt="<?php the_title(); ?>">
								</div>
							<?php } ?>
						</a>
                        <header>						
							<h2 class="title">
								<a href="<?php the_permalink() ?>" title="<?php the_title(); ?>" rel="bookmark"><?php the_title(); ?></a>
							</h2>
							<?php if($options['mts_headline_meta'] == '1') { ?>
								<div class="post_date">
									<span class="theauthor"><?php the_author_posts_link(); ?>,</span>
									<?php echo ''.get_the_time('d').' '.get_the_time('F').' '.get_the_time('Y').''; ?>
								</div>
							<?php } ?>
							<div class="post-info">
								<div class="headline_meta">
									<div class="first_meta">
										<div class="icon_container">
											<?php if(function_exists('the_ratings')) { the_ratings(); } ?>
											<span class="social">
												<div id="sharebuttons">
													<div id="twitter"><a href="https://twitter.com/share" class="twitter-share-button" data-url="<?php the_permalink(); ?>" data-text="<?php the_title(); ?>"
							 data-via="<?php echo $options['mts_twitter_username']; ?>" data-count="vertical">Tweet</a></div>
													<div id="facebook"><div id="fb-root"></div>
							<div class="fb-like" data-send="false" data-href="<?php the_permalink(); ?>" data-layout="box_count" data-show-faces="false"></div></div>
													<div id="googleplus"><div class="g-plusone" data-size="tall" data-href="<?php the_permalink(); ?>"></div></div>
												</div>
											</span>
											<a href="<?php comments_link(); ?>" class="commentbubble_wrap" rel="nofollow"><span class="commentbubble"><?php comments_number('0','1','%'); ?></span></a>
										</div>
									</div>
								</div>
                            </div>
						</header><!--.header-->
					</div><!--.post excerpt-->
				<?php endwhile; else: ?>
					<div>
						<div class="no-results">
							<p><strong><?php _e('There has been an error.', 'mythemeshop'); ?></strong></p>
							<p><?php _e('We apologize for any inconvenience, please hit back on your browser or use the search form below.', 'mythemeshop'); ?></p>
							<?php get_search_form(); ?>
						</div><!--noResults-->
					</div>
				<?php endif; ?>	
				<?php if ($options['mts_pagenavigation'] == '1') { ?>
					<?php pagination($additional_loop->max_num_pages);?>
				<?php } else { ?>
					<div class="pnavigation2">
						<div class="nav-previous"><?php next_posts_link( __( '&larr; '.'Older posts', 'mythemeshop' ) ); ?></div>
						<div class="nav-next"><?php previous_posts_link( __( 'Newer posts'.' &rarr;', 'mythemeshop' ) ); ?></div>
					</div>
				<?php } ?>
			</div>
		</article>
		<?php if($options['mts_home_sidebar'] == '1') { ?>
			<?php get_sidebar(); ?>
		<?php } ?>
<?php get_footer(); ?>