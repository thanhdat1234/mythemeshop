<?php $mts_options = get_option(MTS_THEME_NAME); ?>
<?php get_header(); ?>
<div id="page">
    <div class="home-article">
        <div id="content_box">
            <?php
            if ( !empty( $mts_options['mts_featured_categories'] ) ) {
                foreach ( $mts_options['mts_featured_categories'] as $section ) {
                    $category_id = $section['mts_featured_category'];
                    $trending_post_num = $section['mts_featured_trending_category_post_num'];
                    
                    $post_count = get_option('posts_per_page');

                    if ( $section['mts_featured_layout'] == 3 ) {
                        $layout = 'grid';
                        $posts_num = 5;
                    } elseif ( $section['mts_featured_layout'] == 2 ) {
                        $layout = 'featured';
                        $posts_num = 7;
                    } else {
                        $layout = 'vertical';
                        $posts_num = get_option('posts_per_page');
                    }

                    if ( ( is_home() && !is_paged() ) || ( is_home() && is_paged() && 'latest' == $category_id ) ) {
                    echo '<div class="layout-'.$layout.' clearfix">';
                        echo '<div class="layout-'.$layout.'-inner vertical">';
                    }
                        	
                        	global $wp_query;
                            if ( 'latest' == $category_id ) {

                                $post_count = $wp_query->post_count;

                                if('vertical' == $layout){
                                    if ( is_home() && !is_paged() ) echo '<h2 class="main-title">'. __('Recent', 'mythemeshop') .'</h2>';
                                }

                                $j = 0;

                                if ( have_posts() ) :
                                	echo '<div class="archive-posts">';
                                	while ( have_posts() ) : the_post();
	                                    if('vertical' == $layout){
	                                        echo '<div class="latestPost excerpt">';
	                                    }
	                                    mts_archive_post( $layout, $category_id );
	                                    if('vertical' == $layout) {
	                                        echo '</div>';
	                                    }
	                                $j++;
	                                endwhile;
                                	echo '</div>';
                                	mts_pagination();
                                endif;

                            } else { // if $category_id != 'latest':

                            	if ( is_home() && !is_paged() ) {

	                                $j = 0;

	                                $paged = (get_query_var('paged')) ? get_query_var('paged') : 1;

	                                $args = array(
	                                    'cat' => $category_id,
	                                    'posts_per_page' => $posts_num,
	                                    'paged' => $paged
	                                );
	                                $featured_query = new WP_Query( $args );

	                                $post_count = $featured_query->post_count;

	                                if('vertical' == $layout){
	                                    if ( is_home() && !is_paged() ) echo '<h2 class="main-title">'. esc_html( get_cat_name( $category_id ) ) .'</h2>';
	                                }
	                                if ( $featured_query->have_posts() ) : while ( $featured_query->have_posts() ) : $featured_query->the_post();
	                                    mts_archive_post( $layout, $category_id );
	                                $j++; endwhile;
	                                endif;
	                                wp_reset_postdata();
	                            }
                            }
                        if ( ( is_home() && !is_paged() ) || ( is_home() && is_paged() && 'latest' == $category_id ) ) echo '</div>';    

                        if ( 'vertical' == $layout ) {

                    		// prevent implode error
                            if ( empty( $section['mts_featured_trending_category'] ) || !is_array( $section['mts_featured_trending_category'] ) ) {
                                $section['mts_featured_trending_category'] = array('0');
                            }

                            $trending_cat_id = implode( ",", $section['mts_featured_trending_category'] );
                            $trending_query = new WP_Query('cat='.$trending_cat_id.'&posts_per_page='. $trending_post_num);

                            echo '<div class="trending">';
                                echo '<h2 class="main-title">'. __('Trending', 'mythemeshop') .'</h2>';
                                echo '<div class="">';
                                    if ( $trending_query->have_posts() ) : while ( $trending_query->have_posts() ) : $trending_query->the_post();

                                        mts_archive_post( 'trending', $category_id );

                                    endwhile; endif; wp_reset_postdata();
                                echo '</div>';
                            echo '</div>';
                    	}

                    if ( ( is_home() && !is_paged() ) || ( is_home() && is_paged() && 'latest' == $category_id ) ) echo '</div>';
                }
            } ?>
        </div>
    </div>
<?php get_footer(); ?>