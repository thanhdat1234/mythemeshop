<?php $sidebar = mts_custom_sidebar();
if ( $sidebar != 'mts_nosidebar' ) { ?>
<aside id="sidebar" class="sidebar c-4-12" role="complementary" itemscope="" itemtype="http://schema.org/WPSideBar">
    <div id="sidebars" class="g">
        <div class="sidebar">
            <div class="sidebar-author">
                <div class="author-image-wrap">  
                    <?php if(function_exists('get_avatar')) { echo get_avatar( get_the_author_meta('email'), '250' );  } ?>
                </div>    
                <div class="author_wrap">
                    <h5 class="vcard"><?php the_author_meta( 'display_name' ); ?></h5>
                    <div class="post-info">
                        <span class="theauthor"><?php _e('Author', 'blogging'); ?></span>
                    </div>
                </div>    
            </div>
                <div class="author-post"><span><?php echo count_user_posts( get_current_user_id() ); ?></span><span><?php _e('Posts', 'blogging'); ?></span></div>
                <div class="active-in widget">
                    <h3 class="widget-title"><?php _e('Active In', 'blogging'); ?></h3>
                    <div class="post-info">
                        <?php global $wp_query;
                        $cats = get_categories();
                        $postAuthor = $wp_query->post->post_author;
                        $catlist = "";
                        foreach ( $cats as $c ) {
                            $catlist .= '<a href="'.esc_url( get_category_link( $c->term_id ) ).'" ><span class="thecategory">'.esc_html( $c->name ).'</span></a>';
                        }
                        echo $catlist; ?>
                    </div>
                </div>

                <div id="text-6" class="widget widget_text">
                    <h3 class="widget-title"><?php _e('About Me', 'blogging'); ?></h3>     
                    <div class="textwidget">
                        <?php the_author_meta('description') ?>
                    </div>  
                </div>
                <?php 
                $userID = get_current_user_id();
                $facebook = get_the_author_meta( 'facebook_profile', $userID );
                $twitter = get_the_author_meta( 'twitter_profile', $userID );
                $google = get_the_author_meta( 'google_profile', $userID );
                $pinterest = get_the_author_meta( 'pinterest', $userID );
                $instagram = get_the_author_meta( 'instagram', $userID );
                $linkedin = get_the_author_meta( 'linkedin', $userID );
                $youTube = get_the_author_meta( 'youTube', $userID );
                $email = get_the_author_meta( 'email_profile', $userID );

                if($facebook !='' || $twitter !='' || $google !='' || $pinterest !='' || $instagram !='' || $linkedin !='' ||$youTube !='' || $email !='')
                  { ?>
                    <div id="social-profile-icons-2" class="widget social-profile-icons">
                        <h3 class="widget-title"><?php _e('Connect With Me', 'blogging'); ?></h3>
                        <div class="social-profile-icons">
    					    <ul>
                                <?php if($facebook !='') { ?>
        						    <li class="social-facebook"><a href="<?php echo esc_url( $facebook ); ?>"><i class="fa fa-facebook"></i></a></li>
                                <?php }
                                if($twitter  { ?>
                                    <li class="social-twitter"><a href="<?php echo esc_url( $twitter ); ?>"><i class="fa fa-twitter"></i></a></li>
                                <?php }
                                if($google !='') { ?>
                                    <li class="social-gplus"><a href="<?php echo esc_url( $google ); ?>"><i class="fa fa-google-plus"></i></a></li>
                                <?php }
                                if($pinterest !='') { ?>
                                    <li class="social-pinterest"><a href="<?php echo esc_url( $pinterest ); ?>"><i class="fa fa-pinterest"></i></a></li>
                                <?php }
                                if($instagram !='') { ?>
                                    <li class="social-instagram"><a href="<?php echo esc_url( $instagram ); ?>"><i class="fa fa-instagram"></i></a></li>
                                <?php }
                                if($linkedin !='') { ?>
                                    <li class="social-linkedin"><a href="<?php echo esc_url( $linkedin ); ?>"><i class="fa fa-linkedin"></i></a></li>
                                <?php }
                                if($youTube !='') { ?>
                                    <li class="social-youTube"><a href="<?php echo esc_url( $youTube ); ?>"><i class="fa fa-youtube-play"></i></a></li>
                                <?php }
                                if($email !='') { ?>
                                    <li class="social-email"><a href="<?php echo esc_url( $email ); ?>"><i class="fa fa-envelope"></i></a></li>
                                <?php } ?>
    					   </ul>
                        </div>
                    </div>
                <?php } ?>
            </div><!--sidebars-->
        </div>
    </aside>
<?php } ?>