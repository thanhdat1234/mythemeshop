<?php get_header(); 
$mts_options = get_option(MTS_THEME_NAME);
$avatar_user = get_user_by('email', get_the_author_meta('email'));
$banner = get_the_author_meta('author_profile_picture2', $avatar_user->ID);

if(!empty($banner)) { ?>
  <div class="full-header-image">
      <div style="background:url('<?php echo get_the_author_meta('author_profile_picture2', $avatar_user->ID); ?>') no-repeat; background-size: cover;"></div>
      <div class="image-overlay"></div>    
  </div>
<?php } ?>

<div id="page">
    <div class="<?php mts_article_class(); ?>">
        <div id="content_box">
            <?php $j = 0; if (have_posts()) : while (have_posts()) : the_post(); ?>
            <article class="latestPost excerpt  <?php echo (++$j % 3 == 0) ? 'last' : ''; ?>" itemscope itemtype="http://schema.org/BlogPosting">
              <?php mts_archive_post(); ?>
            </article><!--.post excerpt-->
            <?php endwhile; endif; ?>

            <?php if ( $j !== 0 ) { // No pagination if there is no posts ?>
            <?php mts_pagination(); ?>
            <?php } ?>
        </div>
    </div>
    <?php get_sidebar('author'); ?>
</div><!--#page-->

<?php get_footer(); ?>