<?php
/**
 * The template for displaying search results pages.
 */
?>
<?php $mts_options = get_option(MTS_THEME_NAME); ?>
<?php $sidebar_type = isset( $mts_options['mts_sidebar_layout'] ) ? $mts_options['mts_sidebar_layout'] : '0' ?>
<?php $latest_posts_class = ( '0' === $sidebar_type ) ? 'latest-posts-full-width' : 'latest-posts-left'; ?>
<?php get_header(); ?>
<div id="page" class="clearfix">
	<div class="article">
		<div id="content_box">
			<h1 class="postsby">
				<span><?php _e("Search Results for:", 'blogging' ); ?></span> <?php the_search_query(); ?>
			</h1>
			<div class="latest-posts clearfix <?php echo $latest_posts_class; ?>">
				<?php  $number=1; ?>
				<?php $j = 0; if (have_posts()) : while (have_posts()) : the_post(); ?>
					<?php if( $number ==3 && '0' === $sidebar_type ) {
							get_sidebar();
						} ?>
					<article class="latestPost excerpt  <?php echo (++$j % 3 == 0) ? 'last' : ''; ?>">
						<?php mts_archive_post(); ?>
					</article><!--.post excerpt-->
					<?php $number++; ?>
				<?php endwhile; else: ?>
					<div class="no-results">
						<h2><?php _e('We apologize for any inconvenience, please hit back on your browser or use the search form below.', 'blogging' ); ?></h2>
						<?php get_search_form(); ?>
					</div><!--noResults-->
				<?php endif; ?>

				<?php if ( $j !== 0 ) { // No pagination if there is no posts ?>
					<?php mts_pagination(); ?>
				<?php } ?>
			</div>
			<?php if ( '0' !== $sidebar_type ) get_sidebar(); ?>
		</div>
	</div>
	<?php get_sidebar(); ?>
<?php get_footer(); ?>