<?php
/**
 * The template for displaying archive pages.
 *
 * Used for displaying archive-type pages. These views can be further customized by
 * creating a separate template for each one.
 *
 * - author.php (Author archive)
 * - category.php (Category archive)
 * - date.php (Date archive)
 * - tag.php (Tag archive)
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/
 */
?>
<?php $mts_options = get_option(MTS_THEME_NAME); ?>
<?php $sidebar_type = isset( $mts_options['mts_sidebar_layout'] ) ? $mts_options['mts_sidebar_layout'] : '0' ?>
<?php $latest_posts_class = ( '0' === $sidebar_type ) ? 'latest-posts-full-width' : 'latest-posts-left'; ?>
<?php get_header(); ?>
<div id="page" class="clearfix">
	<div class="<?php mts_article_class(); ?>">
		<div id="content_box">
			<h1 class="postsby">
				<span><?php the_archive_title(); ?></span>
			</h1>
			<div class="latest-posts clearfix <?php echo $latest_posts_class; ?>">
				<?php  $number=1; ?>
				<?php $j = 0; if (have_posts()) : while (have_posts()) : the_post(); ?>
					<?php if( $number ==3 && '0' === $sidebar_type ) {
							get_sidebar();
						} ?>
					<article class="latestPost excerpt  <?php echo (++$j % 3 == 0) ? 'last' : ''; ?>">
						<?php mts_archive_post(); ?>
					</article><!--.post excerpt-->
					<?php $number++; ?>
				<?php endwhile; endif; ?>

				<?php if ( $j !== 0 ) { // No pagination if there is no posts ?>
					<?php mts_pagination(); ?>
				<?php } ?>
			</div>
			<?php if ( '0' !== $sidebar_type ) get_sidebar(); ?>
		</div>
	</div>
<?php get_footer(); ?>