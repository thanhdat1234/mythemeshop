<?php get_header(); 
$mts_options = get_option(MTS_THEME_NAME); 

if($mts_options['mts_show_single_header_posts']){ ?>
	<div class="header-post-wrap"><?php mts_header_posts(); ?></div>
<?php } ?>
<div class="main-container">
	<div id="page" class="<?php mts_single_page_class(); ?> clearfix">
		<article class="<?php mts_article_class(); ?>" itemscope itemtype="http://schema.org/BlogPosting">
			<?php if (mts_get_thumbnail_url()) : ?>
				<meta itemprop="image" content="<?php echo mts_get_thumbnail_url(); ?>" />
			<?php endif; ?>
			<div id="content_box" >
				<?php if ( have_posts() ) while ( have_posts() ) : the_post(); ?>
					<div id="post-<?php the_ID(); ?>" <?php post_class('g post'); ?>>
						<?php
						// Single post parts ordering
						if ( isset( $mts_options['mts_single_post_layout'] ) && is_array( $mts_options['mts_single_post_layout'] ) && array_key_exists( 'enabled', $mts_options['mts_single_post_layout'] ) ) {
							$single_post_parts = $mts_options['mts_single_post_layout']['enabled'];
						} else {
							$single_post_parts = array( 'content' => 'content', 'related' => 'related', 'author' => 'author' );
						}
						foreach( $single_post_parts as $part => $label ) { 
							switch ($part) {
								case 'content':
									
									$header_animation = mts_get_post_header_effect(); ?>

									<div class="single_post">
										<?php 
										$sidebar = mts_custom_sidebar();
										if ( $sidebar != 'mts_nosidebar' ) {
	    									if ( 'parallax' != $header_animation && 'zoomout' != $header_animation && !empty($mts_options['mts_single_featured_image']) ) {?>
												<div class="post-image post-image-left">
												    <?php echo '<div class="featured-thumbnail">'; the_post_thumbnail('featuredfull',array('title' => '')); echo '</div>'; ?>
												    <?php if (function_exists('wp_review_show_total')) wp_review_show_total(true, 'latestPost-review-wrapper'); ?>
												</div>
											<?php } else if ( 'parallax' === $header_animation ) {?>
												<?php if (mts_get_thumbnail_url()) : ?>
											        <div id="parallax" <?php echo 'style="background-image: url('.mts_get_thumbnail_url().');"'; ?>></div>
											    <?php endif; ?>
											<?php } else if ( 'zoomout' === $header_animation ) {?>
												 <?php if (mts_get_thumbnail_url()) : ?>
											        <div id="zoom-out-effect"><div id="zoom-out-bg" <?php echo 'style="background-image: url('.mts_get_thumbnail_url().');"'; ?>></div></div>
											    <?php endif; ?>
											<?php }
										} ?>
										<div class="post-single-content-wrap">
											<div id="left-share">
												<div id="left-share-inner">
													<div class="left-comment"><?php echo comments_number('<span>no</span> comments', '<span>1</span> comments', '<span>%</span> comments');?></div>
													<?php mts_social_buttons(); ?>
												</div>
											</div>
											<div class="post-single-content box mark-links entry-content">
												<?php if ($mts_options['mts_breadcrumb'] == '1') { ?>
												<div class="breadcrumb" xmlns:v="http://rdf.data-vocabulary.org/#"><?php mts_the_breadcrumb(); ?></div>
												<?php } ?>
												<header>
													<h1 class="title single-title entry-title" itemprop="headline"><?php the_title(); ?></h1>
													<?php mts_the_postinfo( 'single' ); ?>
												</header><!--.headline_area-->
												<?php if ($mts_options['mts_posttop_adcode'] != '') { ?>
													<?php $toptime = $mts_options['mts_posttop_adcode_time']; if (strcmp( date("Y-m-d", strtotime( "-$toptime day")), get_the_time("Y-m-d") ) >= 0) { ?>
														<div class="topad">
															<?php echo do_shortcode($mts_options['mts_posttop_adcode']); ?>
														</div>
													<?php } ?>
												<?php } ?>
												<div class="thecontent" itemprop="articleBody">
													<?php the_content(); ?>
												</div>
												<?php wp_link_pages(array('before' => '<div class="pagination">', 'after' => '</div>', 'link_before'  => '<span class="current"><span class="currenttext">', 'link_after' => '</span></span>', 'next_or_number' => 'next_and_number', 'nextpagelink' => __('Next','mythemeshop'), 'previouspagelink' => __('Previous','mythemeshop'), 'pagelink' => '%','echo' => 1 )); ?>
												<?php if ($mts_options['mts_postend_adcode'] != '') { ?>
													<?php $endtime = $mts_options['mts_postend_adcode_time']; if (strcmp( date("Y-m-d", strtotime( "-$endtime day")), get_the_time("Y-m-d") ) >= 0) { ?>
														<div class="bottomad">
															<?php echo do_shortcode($mts_options['mts_postend_adcode']); ?>
														</div>
													<?php } ?>
												<?php } ?>
												<!--Recommended for you -->
												<?php
												if($mts_options['mts_show_single_recommended']){
													mts_recommended_post();
												} ?>
												
												<!--Author Box -->
												<?php if(!empty($mts_options['mts_show_single_author_box'])) { ?>
													<div class="postauthor">
														<?php if(function_exists('get_avatar')) { echo get_avatar( get_the_author_meta('email'), '100' );  } ?>
														<h5 class="vcard"><a href="<?php echo get_author_posts_url( get_the_author_meta( 'ID' ) ); ?>" rel="nofollow"><?php the_author_meta( 'nickname' ); ?></a></h5>

														<?php
															$userID = get_current_user_id();
															$facebook = get_the_author_meta( 'facebook', $userID );
															$twitter = get_the_author_meta( 'twitter', $userID );
															$google = get_the_author_meta( 'google', $userID );
															$pinterest = get_the_author_meta( 'pinterest', $userID );
															$stumbleupon = get_the_author_meta( 'stumbleupon', $userID );
															$linkedin = get_the_author_meta( 'linkedin', $userID );

															if(!empty($facebook) || !empty($twitter) || !empty($google) || !empty($pinterest) || !empty($stumbleupon) || !empty($linkedin)){
																echo '<div class="author-social">';
																	if(!empty($facebook)){
																		echo '<a href="'.$facebook.'" class="facebook"><i class="fa fa-facebook"></i></a>';
																	}
																	if(!empty($twitter)){
																		echo '<a href="'.$twitter.'" class="twitter"><i class="fa fa-twitter"></i></a>';
																	}
																	if(!empty($google)){
																		echo '<a href="'.$google.'" class="google"><i class="fa fa-google-plus"></i></a>';
																	}
																	if(!empty($pinterest)){
																		echo '<a href="'.$pinterest.'" class="pinterest"><i class="fa fa-pinterest"></i></a>';
																	}
																	if(!empty($stumbleupon)){
																		echo '<a href="'.$stumbleupon.'" class="stumbleupon"><i class="fa fa-stumbleupon"></i></a>';
																	}
																	if(!empty($linkedin)){
																		echo '<a href="'.$linkedin.'" class="linkedin"><i class="fa fa-linkedin"></i></a>';
																	}
																echo '</div>';
															}
														?>
														
														<p><?php the_author_meta('description') ?></p>
														<?php $author_btn_text = !empty( $mts_options['mts_show_single_author_btn_text'] ) ? $mts_options['mts_show_single_author_btn_text'] : 'Write For Us';
														if($mts_options['mts_show_single_author_btn'] && !empty($mts_options['mts_show_single_author_btn_link'])){
															echo '<div class="write-for-us"><a href="'.$mts_options['mts_show_single_author_btn_link'].'">'.$author_btn_text.'</a></div>';
														} ?>
														
													</div> 
												<?php } ?>
											</div><!--.post-single-content-->
										</div><!--.post-single-content-wrap-->
									</div><!--.single_post-->
									<?php
								break;

								case 'tags':
									?>
									<div class="tags">
										<?php mts_the_tags('<span class="tagtext">'.__('Tags','mythemeshop').':</span>',', ') ?>
									</div>
									<?php
								break;

								case 'related': ?>
									<div class="related-wrap">
										<div class="related-left">
											<?php mts_related_posts(); ?>
										</div>
										<div class="related-ads">
											<?php dynamic_sidebar('single-post-ad'); ?>
										</div>
									</div>
								<?php break;
							}
						}
						?>
					</div><!--.g post-->
					<?php comments_template( '', true ); ?>
				<?php endwhile; /* end loop */ ?>
			</div>
		</article>
		<?php get_sidebar(); ?>
	<?php get_footer(); ?>