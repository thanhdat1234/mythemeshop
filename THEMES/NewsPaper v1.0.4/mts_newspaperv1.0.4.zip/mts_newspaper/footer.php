<?php $mts_options = get_option(MTS_THEME_NAME);
// default = 3
$first_footer_num  = 3;
?>
	</div><!--#page-->
</div><!--.main-container-->
<footer class="footer" role="contentinfo" itemscope itemtype="http://schema.org/WPFooter">
	<div class="container">
        <?php if (!empty($mts_options['mts_show_footer_sponsers']) && !empty($mts_options['mts_footer_sponsers'])) { ?>
            <div class="sponsers-images">
                <h4><?php echo $mts_options['mts_show_footer_sponsers_title']; ?> <i class="fa fa-angle-right"></i></h4>
                <?php $footer_sponsers = !empty ( $mts_options['mts_footer_sponsers'] ) ? $mts_options['mts_footer_sponsers'] : array();
                    foreach ($footer_sponsers as $key => $value) {
                        $sponsers_url = !empty( $value['mts_footer_sponsers_url'] ) ? $value['mts_footer_sponsers_url'] : '';
                        $sponsers_image = !empty( $value['mts_footer_sponsers_image'] ) ? $value['mts_footer_sponsers_image'] : '';
                        
                        if( $sponsers_url && $sponsers_image ){
                            echo '<a href="'.$sponsers_url.'" class="sponsor-image-link">';
                                echo '<img src="'.$sponsers_image.'" class="sponsers-image">';
                            echo '</a>';
                         }else{
                            echo '<div class="sponsor-image-link">';
                                echo '<img src="'.$sponsers_image.'" class="sponsers-image">';
                            echo '</div>';
                         }
                    } ?>
            </div>
        <?php } ?>

        <?php if ($mts_options['mts_first_footer']) { ?>
            <div class="footer-widgets first-footer-widgets widgets-num-<?php echo $first_footer_num; ?>">
                <?php for ( $i = 1; $i <= 3; $i++ ) {
                    $sidebar = ( $i == 1 ) ? 'footer-first' : 'footer-first-'.$i;
                    $class = ( $i == $first_footer_num ) ? 'f-widget last f-widget-'.$i : 'f-widget f-widget-'.$i; ?>
                    <div class="<?php echo $class; ?>">
                        <?php if ( !function_exists('dynamic_sidebar') || !dynamic_sidebar( $sidebar ) ) : ?><?php endif; ?>
                    </div>
                <?php } ?>
            </div><!--.first-footer-widgets-->
        <?php } ?>      
       
        <?php 
        if ($mts_options['mts_first_footer']) {
            $copyright_class = "";
        }else{
            $copyright_class = "footer-disable";
        }
        ?>

        <div class="copyrights <?php echo $copyright_class ?>">
            <?php if ($mts_options['mts_footer_social_buttons']) { ?>
                <div class="footer-social">
                    <?php 
                        $footer_social = $mts_options['mts_footer_social_links'];

                        foreach ($footer_social as $key => $value) {

                            $social_url = !empty( $value['mts_footer_social_url'] ) ? $value['mts_footer_social_url'] : '#';
                            $social_icon = $value['mts_footer_social_icon'];
                            $social_color = !empty( $value['mts_footer_social_bgcolor'] ) ? $value['mts_footer_social_bgcolor'] : '';
                            
                            echo '<a href="'.$social_url.'" style="background:'. $social_color.'">';
                                echo '<i class="fa fa-'.$social_icon.'"></i>';
                            echo '</a>';
                        }

                    ?>
                </div>
            <?php } ?>
			<?php mts_copyrights_credit(); ?>
		</div> 
	</div><!--.container-->
</footer><!--footer-->
<?php mts_footer(); ?>
<?php wp_footer(); ?>
</body>
</html>