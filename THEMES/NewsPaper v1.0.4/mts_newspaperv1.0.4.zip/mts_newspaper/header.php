<!DOCTYPE html>
<?php $mts_options = get_option(MTS_THEME_NAME); ?>
<html class="no-js" <?php language_attributes(); ?>>
<head itemscope itemtype="http://schema.org/WebSite">
	<meta charset="<?php bloginfo('charset'); ?>">
	<!-- Always force latest IE rendering engine (even in intranet) & Chrome Frame -->
	<!--[if IE ]>
	<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
	<![endif]-->
	<link rel="profile" href="http://gmpg.org/xfn/11" />
	<?php mts_meta(); ?>
	<link rel="pingback" href="<?php bloginfo( 'pingback_url' ); ?>" />
	<?php wp_head(); ?>
</head>
<body id="blog" <?php body_class('main'); ?> itemscope itemtype="http://schema.org/WebPage">       
	<?php if( $mts_options['mts_sticky_nav'] == '1' ) { ?>
		<div class="clear" id="catcher"></div>
		<div id="sticky" class="" role="navigation" itemscope itemtype="http://schema.org/SiteNavigationElement">
	<?php } ?>
		<header class="main-header" role="banner" itemscope itemtype="http://schema.org/WPHeader">
			<div class="container">
				<div id="header">
					<div class="logo-wrap">
						<?php if ($mts_options['mts_logo'] != '') { ?>
							<?php if( is_front_page() || is_home() || is_404() ) { ?>
								<h1 id="logo" class="image-logo" itemprop="headline">
									<a href="<?php echo home_url(); ?>"><img src="<?php echo $mts_options['mts_logo']; ?>" alt="<?php bloginfo( 'name' ); ?>"></a>
								</h1><!-- END #logo -->
							<?php } else { ?>
								<h2 id="logo" class="image-logo" itemprop="headline">
									<a href="<?php echo home_url(); ?>"><img src="<?php echo $mts_options['mts_logo']; ?>" alt="<?php bloginfo( 'name' ); ?>"></a>
								</h2><!-- END #logo -->
							<?php } ?>
						<?php } else { ?>
							<?php if( is_front_page() || is_home() || is_404() ) { ?>
								<h1 id="logo" class="text-logo" itemprop="headline">
									<a href="<?php echo home_url(); ?>"><?php bloginfo( 'name' ); ?></a>
								</h1><!-- END #logo -->
							<?php } else { ?>
								<h2 id="logo" class="text-logo" itemprop="headline">
									<a href="<?php echo home_url(); ?>"><?php bloginfo( 'name' ); ?></a>
								</h2><!-- END #logo -->
							<?php } ?>
						<?php } ?>
					</div>
					
					<?php if ( $mts_options['mts_show_secondary_nav'] == '1' ) { ?>		
						<div class="secondary-navigation" role="navigation" itemscope itemtype="http://schema.org/SiteNavigationElement">
							<a href="#" id="pull" class="toggle-mobile-menu"><?php _e('Menu','mythemeshop'); ?></a>
							<nav id="navigation" class="clearfix mobile-menu-wrapper">
								<?php if ( has_nav_menu( 'secondary-menu' ) ) { ?>
									<?php wp_nav_menu( array( 'theme_location' => 'secondary-menu', 'menu_class' => 'menu clearfix', 'container' => '', 'walker' => new mts_menu_walker ) ); ?>
								<?php } else { ?>
									<ul class="menu clearfix">
										<?php wp_list_categories('title_li='); ?>
									</ul>
								<?php } ?>
							</nav>
						</div>  
					<?php } ?>  

					<?php if ($mts_options['mts_header_search'] == 1) { ?>
						<div class="head-search">
							<i class="fa fa-search search-trigger"></i>
							<?php get_search_form(); ?>
						</div>
					<?php } ?>
					
					<?php if(!empty($mts_options['mts_header_social_buttons'])) { ?>
						<div class="header-social-icon">   
							<ul>
								<?php if($mts_options['mts_twitter_username'] != '') { ?>
									<li class="mts-twitter-icon">
										<span class="share-item twitterbtn">
											<a href="https://twitter.com/<?php echo $mts_options['mts_twitter_username']; ?>" class="twitter-follow-button" data-show-count="true" data-show-screen-name="false">Follow</a>
										</span>
									</li>
								<?php } ?>
								<?php if($mts_options['mts_facebook_username'] != '') { ?>
									<li class="mts-fb-icon">
										<span class="share-item facebookbtn">
											<div id="fb-root"></div>
											<div class="fb-like" data-send="false" data-layout="button_count" data-width="150" data-show-faces="false" data-href="<?php echo $mts_options['mts_facebook_username']; ?>"></div>
										</span>
									</li>
								<?php } ?>    
							</ul>
						</div>
					<?php } ?>

				</div><!--#header-->
			</div><!--.container-->
		</header>				       
	<?php if( $mts_options['mts_sticky_nav'] == '1' ) { ?>
		</div>
	<?php } ?>
	<?php if(is_home() && is_active_sidebar('widget-header')){ ?>
		<div class="banner-ads">
			<div class="container">
				<?php dynamic_sidebar('Header Ad'); ?>
			</div>
		</div>
	<?php } ?>