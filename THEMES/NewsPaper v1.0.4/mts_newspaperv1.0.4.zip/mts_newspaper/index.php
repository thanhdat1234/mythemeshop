<?php $mts_options = get_option(MTS_THEME_NAME); ?>
<?php get_header(); ?>
<?php if($mts_options['mts_show_home_header_posts']){ ?>
    <div class="header-post-wrap"><?php mts_header_posts(); ?></div>
<?php } ?>
<div class="main-container">
    <div id="page" class="clearfix">
        <div class="article">
            <div id="content_box">
                <?php if ( !is_paged() ) { ?>
                    <!-- Featured Posts  -->
                    <?php if ( is_home() ) { ?>
                        <?php if($mts_options['mts_featured_post'] == '1') { ?>
                            <div class="featured-wrap clearfix">
                                <?php 
                                    // prevent implode error
                                    if (empty($mts_options['mts_featured_post_cat']) || !is_array($mts_options['mts_featured_post_cat'])) {
                                        $mts_options['mts_featured_post_cat'] = array('0');
                                    }
                                    $i = 1;
                                    $post_cat = implode(",", $mts_options['mts_featured_post_cat']); $my_query = new WP_Query('cat='.$post_cat.'&posts_per_page=3');
                                    while ($my_query->have_posts()) : $my_query->the_post();

                                    $featured_class = isset($i) ? ' class="featured-post-'.$i.' featured-post-wrap excerpt"' : 'excerpt';
                                    
                                    if( $i == 1 ) {
                                        $featured_thumb = "featuredfull";
                                    } else {
                                        $featured_thumb = "featured";
                                    }
                                ?>
                                 <div<?php echo $featured_class ?>> 
                                        <a href="<?php the_permalink() ?>" title="<?php the_title(); ?>" rel="nofollow" id="thumbnail-<?php echo $i; ?>">
                                            <div class="featured-img-wrap">
                                            <?php if ( has_post_thumbnail() ) { ?> 
                                                <?php the_post_thumbnail($featured_thumb,array('title' => '')); ?>
                                            <?php } ?>
                                            <div class="featured-bg"></div>
                                            </div>
                                            <div class="featured-excerpt">
                                                <h3 class="featured-title"><?php the_title(); ?></h3>
                                                <span class="category-head"><?php $category = get_the_category(); echo $category[0]->cat_name; ?></span>
                                            </div>
                                        </a>
                                </div><!--.post excerpt-->
                                <?php $i++; endwhile; wp_reset_query(); ?>
                            </div>
                            <!-- Featured Posts -->
                        <?php }
                    } ?>
                        <?php if (!empty($mts_options['mts_homepage_tabs'])) { ?>
                        <!-- Popular / Latest Post Tabs -->
                         <div id="tab-group-wrap">
                            <ul id="tab-group">
                                <?php
                                $tabs_order = empty($mts_options['mts_homepage_tabs_order']) ? array('enabled' => array('popular' => 'Popular', 'latest' => 'Latest')) : $mts_options['mts_homepage_tabs_order'];
                                foreach ($tabs_order['enabled'] as $tab => $s) {
                                    if ($tab == 'popular') { ?>
                                    <li>
                                        <a href="#popular-tab">
                                            <?php 
                                                if ( !empty( $mts_options['mts_trending_icon'] ) )
                                                    echo '<i class="fa fa-'. $mts_options['mts_trending_icon'] .'"></i> ';
                                                echo $mts_options['mts_trending_title']; 
                                            ?>
                                        </a>
                                    </li>
                                    <?php } elseif ($tab == 'latest') { ?>
                                    <li>
                                        <a href="#latest-tab">
                                            <?php 
                                                if ( !empty( $mts_options['mts_latest_icon'] ) )
                                                    echo '<i class="fa fa-'. $mts_options['mts_latest_icon'] .'"></i> ';
                                                echo $mts_options['mts_latest_title'];
                                            ?>
                                        </a>
                                    </li>
                                    <?php }
                                }
                                ?>
                            </ul>
                        </div>

                        <div id="tab-content">
                            <!-- Popular Tabs Contents -->
                            <div id="popular-tab-content" class="popular-post-wrap"></div>

                            <!-- Latest Tabs Contents -->
                            <div id="latest-tab-content"></div>
                        </div>
                    <?php } else { ?>
                        <div class="home-latest">
                        <?php $j = 0; if ( have_posts() ) : while ( have_posts() ) : the_post(); ?>
                        <article class="latestPost excerpt <?php echo (++$j % 3 == 0) ? 'last' : ''; ?>" itemscope itemtype="http://schema.org/BlogPosting">
                            <?php mts_archive_post(); ?>
                        </article>
                        <?php endwhile; endif; ?>

                        <?php if ( $j !== 0 ) { // No pagination if there is no posts ?>
                            <?php mts_pagination(); ?>
                        <?php } ?>
                        </div>
                    <?php } ?>
                <?php } else { //Paged ?>
                    <div class="home-latest">
                    <?php $j = 0; if ( have_posts() ) : while ( have_posts() ) : the_post(); ?>
                    <article class="latestPost excerpt <?php echo (++$j % 3 == 0) ? 'last' : ''; ?>" itemscope itemtype="http://schema.org/BlogPosting">
                        <?php mts_archive_post(); ?>
                    </article>
                    <?php endwhile; endif; ?>

                    <?php if ( $j !== 0 ) { // No pagination if there is no posts ?>
                        <?php mts_pagination(); ?>
                    <?php } ?>
                    </div>
                <?php } ?>

                <?php
                    //Popular Categories
                    if( $mts_options['mts_show_popular_category'] && isset( $mts_options['mts_popular_categories'] ) && !empty($mts_options['mts_popular_categories']) ){ ?>
                        <div id="popular-categories">                        
                            <h4><?php echo $mts_options['mts_popular_category_title']; ?></h4>
                            <ul>
                            <?php
                                $j = 0;
                                foreach ( $mts_options['mts_popular_categories'] as $section ) {
                                    $category_id = $section['mts_cc_category'];?>
                                   
                                   <li class="popular-category home-popular-category-<?php echo $category_id; echo (++$j % 4 == 0) ? ' last' : ''; ?>">
                                       <a href="<?php echo esc_url( get_category_link( $category_id ) ); ?>" title="<?php echo esc_attr( get_cat_name( $category_id ) ); ?>"><span><?php echo get_cat_name( $category_id ); ?></span></a> 
                                   </li>                              
                                    
                            <?php } ?>
                            </ul>
                        </div>
                <?php } ?>
            </div>
        </div>
        <?php //get_sidebar(); ?>
    <?php get_footer(); ?>