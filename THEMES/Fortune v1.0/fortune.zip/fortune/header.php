<!DOCTYPE html>
<?php $options = get_option('fortune'); ?>
<html class="no-js" <?php language_attributes(); ?>>
<head>
	<meta charset="<?php bloginfo('charset'); ?>">
	<title><?php wp_title(''); ?></title>
	<?php mts_meta(); ?>
	<link rel="stylesheet" type="text/css" media="all" href="<?php bloginfo( 'stylesheet_url' ); ?>" />
	<link rel="pingback" href="<?php bloginfo( 'pingback_url' ); ?>" />
	<?php wp_enqueue_script("jquery"); ?>
	<?php if ( is_singular() ) wp_enqueue_script( 'comment-reply' ); ?>
	<!--[if lt IE 9]>
	<script src="http://html5shim.googlecode.com/svn/trunk/html5.js"></script>
	<![endif]-->
	<?php mts_head(); ?>
	<?php wp_enqueue_script( 'jquery' ); wp_head(); ?>
</head>

<?php flush(); ?>

<body id ="blog" <?php body_class('main'); ?>>
<div id="header">
<div id="top-head">
<div class="top-head-align">
				<?php if( is_front_page() || is_home() || is_404() ) { ?>
						<h1 id="logo">
							<a href="<?php echo home_url(); ?>"><?php bloginfo( 'name' ); ?></a>
                            <div class="logoEnd"></div>
						</h1><!-- END #logo -->
				<?php } else { ?>
					  <h2 id="logo">
							<a href="<?php echo home_url(); ?>"><?php bloginfo( 'name' ); ?></a>
                            <div class="logoEnd"></div>
						</h2><!-- END #logo -->
				<?php } ?> 
                
				<div class="secondary-navigation">
					<nav id="navigation" >
						<?php if ( has_nav_menu( 'secondary-menu' ) ) { ?>
						  <?php $walker = new My_Walker; wp_nav_menu( array( 'theme_location' => 'secondary-menu', 'menu_class' => 'menu', 'container' => '', 'walker' => $walker ) ); ?>
						<?php } else { ?>
							<ul class="menu">
								<?php wp_list_categories('title_li='); ?>
							</ul>
						<?php } ?>
					</nav>
				</div> 
</div>      
</div>
</div>                
	<header class="main-header">
		<div class="container">
			<div id="header">
<div class="widget-header"><?php dynamic_sidebar('home_banner'); ?></div>
             <div class="searchBox">
             <div class="searchTitle">SEARCH</div>
             <form method="get" id="searchform" class="search-form" action="<?php echo home_url(); ?>" _lpchecked="1">
             <input type="text" name="s" id="s" value="Type your search and hit enter" onFocus="if(this.value=='Type your search and hit enter')this.value='';" x-webkit-speech onwebkitspeechchange="transcribe(this.value)">
             </form>
             <?php if($options['mts_twitter_username'] != '' || $options['mts_facebook_username'] != '' || $options['mts_feedburner'] != '' || $options['mts_email_username'] != ''){?>
             <div class="searchComIcons">
             <div class="searchComIconsInside">
             <?php if($options['mts_facebook_username'] != '') { ?>
             <a href="<?php echo $options['mts_facebook_username']; ?>" class="socialite facebook-like" rel="nofollow" target="_blank"><div class="iFb"></div></a>
             <?php } ?>
             <?php if($options['mts_feedburner'] != '') { ?>
             <a href="<?php echo $options['mts_feedburner']?>"><div class="iRss"></div></a>
             <?php } ?>
             <?php if($options['mts_twitter_username'] != '') { ?>
             <a href="http://twitter.com/<?php echo $options['mts_twitter_username']; ?>" class="socialite twitter-share" rel="nofollow" target="_blank"><div class="iTw"></div></a>
             <?php } ?>
             <?php if($options['mts_email_username'] != '') { ?>
             <a href="mail:<?php echo $options['mts_email_username']?>"><div class="iEmail"></div></a>
             <?php } ?> 
             </div>         
             </div>
             <?php } ?>
             </div> 
			</div><!--#header-->

<?php if( is_front_page() || is_404() || is_archive()) { ?>
<div id="content-top">
<div class="blueEnd">FOLLOW US!</div>
<?php if( is_archive()) { ?>
<div class="content-top-blue">Archive Posts</div>
<div class="content-top-grey">Latest Posts Published in this Archive</div>
<?php } else {?>
<div class="content-top-blue">Recent Posts</div>
<div class="content-top-grey">Latest Posts Published on <?php bloginfo( 'name' ); ?></div>
<?php } ?>
<div class="content-top-grey-step"></div>
<div class="content-top-grey-small">
			<div class="main-navigation">
			<nav id="navigation">
				<?php if ( has_nav_menu( 'primary-menu' ) ) { ?>
					<?php wp_nav_menu( array( 'theme_location' => 'primary-menu', 'menu_class' => 'menu', 'container' => '' ) ); ?>
				<?php } else { ?>
					<ul class="menu">
						<li class="home-tab"><a href="<?php echo home_url(); ?>">Home</a></li>
						<?php wp_list_pages('title_li='); ?>
					</ul>
				<?php } ?><!--#nav-primary-->
			</nav>
			</div>
</div>
</div>
<?php } else {?>
<div id="content-top-single">
<div class="blueEnd">FOLLOW US!</div>
<div class="content-top-single-grey">
	<?php if ($options['mts_breadcrumb'] == '1') { ?>
		<div class="breadcrumb"><?php the_breadcrumb(); ?></div>
	<?php } ?>
</div>
<div class="content-top-grey-single-step"></div>
<div class="content-top-grey-small-single">
			<div class="main-navigation">
			<nav id="navigation">
				<?php if ( has_nav_menu( 'primary-menu' ) ) { ?>
					<?php wp_nav_menu( array( 'theme_location' => 'primary-menu', 'menu_class' => 'menu', 'container' => '' ) ); ?>
				<?php } else { ?>
					<ul class="menu">
						<li class="home-tab"><a href="<?php echo home_url(); ?>">Home</a></li>
						<?php wp_list_pages('title_li='); ?>
					</ul>
				<?php } ?><!--#nav-primary-->
			</nav>
		</div>
</div>
</div>
<?php } ?>
	</div><!--.container-->        
</header>
<div class="main-container">