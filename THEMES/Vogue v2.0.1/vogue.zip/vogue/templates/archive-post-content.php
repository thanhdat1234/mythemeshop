<?php Global $post_count; $mts_options = get_option(MTS_THEME_NAME); ?>
<a href="<?php the_permalink() ?>" title="<?php the_title(); ?>" rel="nofollow" id="featured-thumbnail">
	<?php 
	if(has_post_thumbnail()){
		if($post_count == 1 || $post_count == 2){
	    	echo '<div class="featured-thumbnail">'; 
	    	the_post_thumbnail('featured',array('title' => '')); 
	    	echo '</div>';
	    }else{
	       echo '<div class="featured-thumbnail">'; 
	       the_post_thumbnail('featured-small',array('title' => '')); 
	       echo '</div>';
	    }
	}else{
		if($post_count == 1 || $post_count == 2){
	    	echo '<div class="featured-thumbnail">'; 
	    	echo '<img width="250" height="250" src="'. get_template_directory_uri() .'/images/nothumb-big.png" class="attachment-featured wp-post-image" alt="'. get_the_title() .'">';
	    	echo '</div>';
	    }else{
	    	echo '<div class="featured-thumbnail">'; 
	    	echo '<img width="100" height="100" src="'. get_template_directory_uri() .'/images/nothumb.png" class="attachment-featured wp-post-image" alt="'. get_the_title() .'">';
	    	echo '</div>';
	    }
	}

	 ?>
	<?php if (function_exists('wp_review_show_total')) wp_review_show_total(true, 'latestPost-review-wrapper'); ?>
</a>
<div class="blog-content">
<header>
	<h2 class="title front-view-title" itemprop="headline"><a href="<?php the_permalink() ?>" title="<?php the_title(); ?>"><?php the_title(); ?></a></h2>
</header>
<div class="front-view-content">
	<?php 
	if($post_count == 1 || $post_count == 2){
		echo mts_excerpt(15);
	}else{
		echo mts_excerpt(12);
	} ?>
</div>
</div>