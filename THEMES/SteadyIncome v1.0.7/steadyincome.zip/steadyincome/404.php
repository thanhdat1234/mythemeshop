<?php get_header(); ?>
 <div class="main-container"> 
  	<div id="page">
	    <div class="article">
		    <div id="content_box">
	            <div id="post-935" class="post-935 post type-post status-publish format-standard has-post-thumbnail hentry category-featured category-mobiles tag-featured tag-tag-2 g has_thumb photoshoot_single">
	                <div class="single_post">
	                    <div class="post-single-content box mark-links entry-content">
	                        <div class="thecontent" itemprop="articleBody">
		                        <article class="latestPost latestarticle excerpt" itemscope itemtype="http://schema.org/BlogPosting"> <!--article-1, first content-->
									<header>
										<div class="title">
											<h1><?php _e('Error 404 Not Found', 'mythemeshop'); ?></h1>
										</div>
									</header>
									<div class="post-content">
										<p><?php _e('Oops! We couldn\'t find this Page.', 'mythemeshop'); ?></p>
										<p><?php _e('Please check your URL or use the search form below.', 'mythemeshop'); ?></p>
										<?php get_search_form();?>
									</div><!--.post-content--><!--#error404 .post-->
		
								</article>
							</div>
                     	</div>
            		</div>
                </div>
        	</div>
		</div>
		<?php get_sidebar(); ?>
	</div>
</div>
<?php get_footer(); ?>