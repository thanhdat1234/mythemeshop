<?php
$options = get_option('metro');	

/*------------[ Meta ]-------------*/
if ( ! function_exists( 'mts_meta' ) ) {
	function mts_meta() { 
	global $options
?>
<?php if ($options['mts_favicon'] != '') { ?>
<link rel="icon" href="<?php echo $options['mts_favicon']; ?>" type="image/x-icon" />
<?php } ?>
<!--iOS/android/handheld specific -->	
<link rel="apple-touch-icon" href="apple-touch-icon.png">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<meta name="apple-mobile-web-app-capable" content="yes">
<meta name="apple-mobile-web-app-status-bar-style" content="black">
<?php }
}

/*------------[ Head ]-------------*/
if ( ! function_exists( 'mts_head' ) ) {
	function mts_head() { 
	global $options
?>
<!--start fonts-->
<?php if ($options['mts_title_font'] == 'Arial') { ?>
<?php } else { ?>
<?php if ($options['mts_title_font'] != '' || $options['mts_google_title_font'] != '') { ?>
<link href="http://fonts.googleapis.com/css?family=<?php if ($options['mts_google_title_font'] != '') { ?><?php echo $options['mts_google_title_font']; ?><?php } else { ?><?php echo $options['mts_title_font']; ?><?php } ?>:400,700" rel="stylesheet" type="text/css">
<style type="text/css">
#header_area, .headline_area h1, .headline_area h2, h1, h2, h3, h4, h5, h6, .sidebar h3, #footer_setup h3, .total-comments, .flex-caption .slidertitle, .title, .main-navigation li a, .secondary-navigation a, #tabber ul.tabs li a, #tabber .inside li div.info .entry-title, #gallery-slider-header span, .category-head { font-family: '<?php if ($options['mts_google_title_font'] != '') { ?><?php echo $options['mts_google_title_font']; ?><?php } else { ?><?php echo $options['mts_title_font']; ?><?php } ?>', Arial, sans-serif!important; }
</style>
<?php } ?>
<?php } ?>	
<?php if ($options['mts_content_font'] == 'Arial') { ?>
<?php } else { ?>
<?php if ($options['mts_content_font'] != '' || $options['mts_google_content_font'] != '') { ?>
<link href="http://fonts.googleapis.com/css?family=<?php if ($options['mts_google_content_font'] != '') { ?><?php echo $options['mts_google_content_font']; ?><?php } else { ?><?php echo $options['mts_content_font']; ?><?php } ?>:400,400italic,700,700italic" rel="stylesheet" type="text/css">
<style type="text/css">
body {font-family: '<?php if ($options['mts_google_content_font'] != '') { ?><?php echo $options['mts_google_content_font']; ?><?php } else { ?><?php echo $options['mts_content_font']; ?><?php } ?>', sans-serif;}
</style>
<?php } ?>
<?php } ?>
<!--end fonts-->
<script src="<?php bloginfo( 'template_directory' ); ?>/js/jquery.js"></script>
<script src="<?php echo get_template_directory_uri(); ?>/js/modernizr.min.js"></script>
<script src="<?php echo get_template_directory_uri(); ?>/js/customscript.js" type="text/javascript"></script>
<!--start slider-->
<?php if($options['mts_featured_slider'] == '1') { ?>
<?php if( is_home() ) { ?>
<link rel="stylesheet" href="<?php echo get_template_directory_uri(); ?>/css/flexslider.css" type="text/css">
<script src="<?php echo get_template_directory_uri(); ?>/js/jquery.flexslider.js"></script>
<script type="text/javascript">
$(window).load(function() {
	$('.flexslider').flexslider({
          animation: "fade",
	  pauseOnHover: true,
          controlsContainer: ".flex-container"
	});
});
</script>
<?php } ?>
<?php } ?>
<!--end slider-->
<style type="text/css">
		body {
	<?php if ($options['mts_bg_color'] != '') { ?>
		background-color:<?php echo $options['mts_bg_color']; ?>;
	<?php } ?>
		}
	<?php if ($options['mts_bg_pattern_upload'] != '') { ?>
		body {
		background-image: url(<?php echo $options['mts_bg_pattern_upload']; ?>);
		}
	<?php } else { ?>
	<?php if ($options['mts_bg_pattern'] != '') { ?>
		body {
		background-image: url(<?php echo get_template_directory_uri(); ?>/images/<?php echo $options['mts_bg_pattern']; ?>.png);
		}
	<?php } ?>
	<?php } ?>
	
	<?php if ($options['mts_primary_color'] != '') { ?>
			.secondary-navigation a:hover, #navigation ul li li:hover > a, .popular-posts li:hover, .category-head-odd, .currenttext, .pagination a:hover, #commentform input#submit, .flex-control-nav li a:hover, .flex-control-nav li .active {
			background:<?php echo $options['mts_primary_color']; ?>;
			}
			a:hover, #single-post-wrapper a, .title a:hover, #navigation ul li a:hover {
			color:<?php echo $options['mts_primary_color']; ?>;
			}
			.currenttext, .pagination a:hover, .secondary-navigation ul li a:hover { border-color:<?php echo $options['mts_primary_color']; ?>; }
	<?php } ?>
	<?php if ($options['mts_secondary_color'] != '') { ?>
			.category-head-even{
			background:<?php echo $options['mts_secondary_color']; ?>;
			}
	<?php } ?>

	<?php if($options['mts_author_comment'] == '1') { ?>
		.commentlist .bypostauthor {
		background: #F8F8F8!important;
		border: 1px solid #EBEBEB!important;
		padding-left: 20px;
		padding-top: 20px;
		}
		.commentlist .bypostauthor .reply {
		border-bottom:0;
		}
	<?php } ?>
	<?php if ($options['mts_content_font'] != '') { ?>
		body {
		font-family: '<?php echo $options['mts_content_font']; ?>', Arial, sans-serif;
		}
	<?php } ?>
	<?php if ($options['mts_body_size'] != '') { ?>
		body {
		font-size:<?php echo $options['mts_body_size']; ?>;
		}
	<?php } ?>

	<?php if($options['mts_floating_social'] == '1') { ?>
		.shareit {
			top: 335px;
			left: auto;
			z-index: 0;
			margin: 0 0 0 -140px;
			width: 90px;
			position: fixed;
			overflow: hidden;
			background: white;
			border: 1px solid #EEE;
			-webkit-border-radius: 6px;
			-moz-border-radius: 6px;
			border-radius: 6px;
		}
		.share-item {
			margin: 2px;
		}
		.pinbtn {
		width: auto;
		}
	<?php } ?>
	
	<?php if ($options['mts_layout'] == 'sclayout') { ?>
		.article {
		float:right;
		}
		.sidebar.c-4-12 {
		float: left;
		}

		<?php if($options['mts_floating_social'] == '1') { ?>
			.shareit {
			margin: 0 0 0 575px;
			border: 1px solid #EEE;
			-webkit-border-radius: 6px;
			-moz-border-radius: 6px;
			border-radius: 6px;
			}
		<?php } ?>
	<?php } ?>
<?php echo $options['mts_custom_css']; ?>
</style>
<?php echo $options['mts_header_code']; ?>
<?php }
}

/*------------[ footer ]-------------*/
if ( ! function_exists( 'mts_footer' ) ) {
	function mts_footer() { 
	global $options
?>
<?php if($options['mts_home_gallery'] == '1') { ?>
<?php if (is_home() && !is_archive()) { ?>
<script type="text/javascript" src="<?php echo get_template_directory_uri(); ?>/js/jquery.carouFredSel.js"></script>
<script>
jQuery(function() {
	jQuery('#foo2').carouFredSel({
		pagination: "#pager2",
		direction: "right",
		auto: false
	});
});
</script>
<?php } ?>
<?php } ?>
<!--Twitter Button Script------>
<script>!function(d,s,id){var js,fjs=d.getElementsByTagName(s)[0];if(!d.getElementById(id)){js=d.createElement(s);js.id=id;js.src="//platform.twitter.com/widgets.js";fjs.parentNode.insertBefore(js,fjs);}}(document,"script","twitter-wjs");</script>
<script type="text/javascript">
  (function() {
    var po = document.createElement('script'); po.type = 'text/javascript'; po.async = true;
    po.src = 'https://apis.google.com/js/plusone.js';
    var s = document.getElementsByTagName('script')[0]; s.parentNode.insertBefore(po, s);
  })();
</script>
<!--Facebook Like Button Script------>
<script>(function(d, s, id) {
  var js, fjs = d.getElementsByTagName(s)[0];
  if (d.getElementById(id)) return;
  js = d.createElement(s); js.id = id;
  js.src = "//connect.facebook.net/en_US/all.js#xfbml=1&appId=136911316406581";
  fjs.parentNode.insertBefore(js, fjs);
}(document, 'script', 'facebook-jssdk'));</script>
<!--start lightbox-->
<?php if($options['mts_lightbox'] == '1') { ?>
<link rel="stylesheet" href="<?php bloginfo('template_directory'); ?>/css/prettyPhoto.css" type="text/css" media="screen" charset="utf-8" />
<script src="<?php bloginfo('template_directory'); ?>/js/jquery.prettyPhoto.js"></script>
<script type="text/javascript">  
jQuery(document).ready(function($) {
$("a[href$='.jpg'], a[href$='.jpeg'], a[href$='.gif'], a[href$='.png']").prettyPhoto({
slideshow: 5000,
autoplay_slideshow: false, 
animationSpeed: 'normal', 
padding: 40, 
opacity: 0.35,
showTitle: true,
social_tools: false
});
})
</script>
<?php } ?>
<!--end lightbox-->
<!--start footer code-->
<?php if ($options['mts_analytics_code'] != '') { ?>
<?php echo $options['mts_analytics_code']; ?>
<?php } ?>
<!--end footer code-->
<?php }
}

/*------------[ Copyrights ]-------------*/
if ( ! function_exists( 'mts_copyrights_credit' ) ) {
	function mts_copyrights_credit() { 
	global $options
?>
<!--start copyrights-->
<div class="copyrights">
	<div class="row" id="copyright-note">
<?php if ($options['mts_copyrights'] != '') { ?>
		<?php echo $options['mts_copyrights']; ?>
<?php } else { ?>
	<span>Copyright 2012 <a href="http://mythemeshop.com">MyThemeShop</a>.</span>
<?php } ?>
<div class="top"><a href="#top"><?php _e('Back to Top','mythemeshop'); ?> &uarr;</a></div>
	</div>
</div>
<?php }
}

?>