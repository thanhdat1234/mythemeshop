<?php $mts_options = get_option(MTS_THEME_NAME);
get_header();
if ( !is_paged() && $mts_options['mts_featured_slider'] == '1' ) { ?>
    <div class="featuredBox">
        <?php $i = 1;
        // prevent implode error
        if ( empty( $mts_options['mts_featured_slider_cat'] ) || !is_array( $mts_options['mts_featured_slider_cat'] ) ) {
            $mts_options['mts_featured_slider_cat'] = array('0');
        }
        $slider_cat = implode( ",", $mts_options['mts_featured_slider_cat'] );
        $slider_query = new WP_Query('cat='.$slider_cat.'&posts_per_page=4&ignore_sticky_posts=1'); 
        while ($slider_query->have_posts()) : $slider_query->the_post();
            if($i == 1){ ?> 
                <div class="firstpost excerpt">
                    <a href="<?php the_permalink() ?>" title="<?php the_title(); ?>" rel="nofollow" id="first-thumbnail">
                        <?php if ( has_post_thumbnail() ) { ?> 
                            <?php the_post_thumbnail('bigthumb',array('title' => '')); ?>
                        <?php } else { ?>
                            <div class="featured-thumbnail">
                                <img src="<?php echo get_template_directory_uri(); ?>/images/bigthumb.png" class="attachment-featured wp-post-image" alt="<?php the_title(); ?>">
                            </div>
                        <?php } ?>
                        <p class="featured-excerpt">
                            <span class="featured-title"><?php the_title(); ?></span>
                            <span class="f-excerpt"><?php echo mts_excerpt(10);?></span>
                        </p>
                    </a>
                </div><!--.post excerpt-->
            <?php } elseif($i == 2) { ?>
                <div class="secondpost excerpt">
                    <a href="<?php the_permalink() ?>" title="<?php the_title(); ?>" rel="nofollow" id="second-thumbnail">
                        <?php if ( has_post_thumbnail() ) { ?> 
                            <?php the_post_thumbnail('mediumthumb',array('title' => '')); ?>
                        <?php } else { ?>
                            <div class="featured-thumbnail">
                                <img src="<?php echo get_template_directory_uri(); ?>/images/mediumthumb.png" class="attachment-featured wp-post-image" alt="<?php the_title(); ?>">
                            </div>
                        <?php } ?>
                        <p class="featured-excerpt">
                            <span class="featured-title"><?php the_title(); ?></span>
                        </p>
                    </a>
                </div><!--.post excerpt-->
            <?php } elseif($i == 3 || $i == 4) { ?>
                <div class="thirdpost excerpt">
                    <a href="<?php the_permalink() ?>" title="<?php the_title(); ?>" rel="nofollow" id="third-thumbnail">
                        <?php if ( has_post_thumbnail() ) { ?> 
                            <?php the_post_thumbnail('smallthumb',array('title' => '')); ?>
                        <?php } else { ?>
                            <div class="featured-thumbnail">
                                <img src="<?php echo get_template_directory_uri(); ?>/images/smallfthumb.png" class="attachment-featured wp-post-image" alt="<?php the_title(); ?>">
                            </div>
                        <?php } ?>
                        <p class="featured-excerpt">
                            <span class="featured-title"><?php the_title(); ?></span>
                        </p>
                    </a>
                </div><!--.post excerpt-->
            <?php }
        $i++; endwhile; wp_reset_query(); ?> 
    </div>
<?php } ?>
<div id="page">
    <div class="article">
        <div id="content_box">
            <?php if ( !is_paged() ) {
                $featured_categories = array();
                if ( !empty( $mts_options['mts_featured_categories'] ) ) {
                    foreach ( $mts_options['mts_featured_categories'] as $section ) {
                        $category_id = $section['mts_featured_category'];
                        $featured_categories[] = $category_id;
                        $posts_num = $section['mts_featured_category_postsnum'];
                        if ( 'latest' == $category_id ) { ?>
                            <h3 class="featured-category-title"><?php _e('Latest', MTS_THEME_TEXTDOMAIN ); ?></h3>
                            <?php $j = 0; if ( have_posts() ) : while ( have_posts() ) : the_post(); ?>
                                <article class="latestPost excerpt <?php echo (++$j % 3 == 0) ? 'last' : ''; ?>" itemscope itemtype="http://schema.org/BlogPosting">
                                    <?php mts_archive_post(); ?>
                                </article>
                            <?php endwhile; endif; ?>
                            
                            <?php if ( $j !== 0 ) { // No pagination if there is no posts
                                mts_pagination();
                            } ?>
                            
                        <?php } else { // if $category_id != 'latest': ?>
                            <h3 class="featured-category-title"><a href="<?php echo esc_url( get_category_link( $category_id ) ); ?>" title="<?php echo esc_attr( get_cat_name( $category_id ) ); ?>"><?php echo esc_html( get_cat_name( $category_id ) ); ?></a></h3>
                            <?php
                            $j = 0;
                            $cat_query = new WP_Query('cat='.$category_id.'&posts_per_page='.$posts_num);
                            if ( $cat_query->have_posts() ) : while ( $cat_query->have_posts() ) : $cat_query->the_post(); ?>
                                <article class="latestPost excerpt <?php echo (++$j % 3 == 0) ? 'last' : ''; ?>" itemscope itemtype="http://schema.org/BlogPosting">
                                    <?php mts_archive_post(); ?>
                                </article>
                            <?php endwhile; endif; wp_reset_postdata();
                        }
                    }
                }
            } else { //Paged
                $j = 0; if ( have_posts() ) : while ( have_posts() ) : the_post(); ?>
                <article class="latestPost excerpt <?php echo (++$j % 3 == 0) ? 'last' : ''; ?>" itemscope itemtype="http://schema.org/BlogPosting">
                    <?php mts_archive_post(); ?>
                </article>
                <?php endwhile; endif; ?>

                <?php if ( $j !== 0 ) { // No pagination if there is no posts
                    mts_pagination();
                }
            } ?>
        </div>
    </div>
    <?php get_sidebar(); ?>
<?php get_footer(); ?>