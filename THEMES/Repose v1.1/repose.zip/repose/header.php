<!DOCTYPE html>
<?php $mts_options = get_option('repose'); ?>
<html class="no-js" <?php language_attributes(); ?>>
<head>
	<meta charset="<?php bloginfo('charset'); ?>">
	<!-- Always force latest IE rendering engine (even in intranet) & Chrome Frame -->
	<!--[if IE ]>
	<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
	<![endif]-->
	<link rel="profile" href="http://gmpg.org/xfn/11" />
	<title><?php wp_title( '|', true, 'right' ); ?></title>
	<?php mts_meta(); ?>
	<link rel="pingback" href="<?php bloginfo( 'pingback_url' ); ?>" />
	<?php wp_head(); ?>
</head>
<body id ="blog" <?php body_class('main'); ?> itemscope itemtype="http://schema.org/WebPage">
	<div class="secondary-navigation mobile">
		<nav id="navigation" class="clearfix">
			<?php if ( has_nav_menu( 'primary-menu' ) ) { ?>
				<?php wp_nav_menu( array( 'theme_location' => 'primary-menu', 'menu_class' => 'menu clearfix', 'container' => '' ) ); ?>
			<?php } else { ?>
				<ul class="menu clearfix">
					<?php wp_list_categories('title_li='); ?>
				</ul>
			<?php } ?>
		</nav>
	</div>
	<div class="main-container-wrap">
		<a href="#" id="pull"><?php _e('Menu','mythemeshop'); ?></a>
		<?php if($mts_options['mts_sticky_nav'] == '1') { ?>
		<div class="clear" id="catcher"></div>
		<header id="sticky" class="main-header">
		<?php } else { ?>
		<header class="main-header">
		<?php } ?>
			<div class="container">
				<div id="header">
					<div class="logo-wrap">
						<?php if ($mts_options['mts_logo'] != '') { ?>
							<?php if( is_front_page() || is_home() || is_404() ) { ?>
									<h1 id="logo" class="image-logo">
										<a href="<?php echo home_url(); ?>"><img src="<?php echo $mts_options['mts_logo']; ?>" alt="<?php bloginfo( 'name' ); ?>"></a>
									</h1><!-- END #logo -->
							<?php } else { ?>
								  <h2 id="logo" class="image-logo">
										<a href="<?php echo home_url(); ?>"><img src="<?php echo $mts_options['mts_logo']; ?>" alt="<?php bloginfo( 'name' ); ?>"></a>
									</h2><!-- END #logo -->
							<?php } ?>
						<?php } else { ?>
							<?php if( is_front_page() || is_home() || is_404() ) { ?>
									<h1 id="logo" class="text-logo">
										<a href="<?php echo home_url(); ?>"><?php bloginfo( 'name' ); ?></a>
									</h1><!-- END #logo -->
							<?php } else { ?>
								  <h2 id="logo" class="text-logo">
										<a href="<?php echo home_url(); ?>"><?php bloginfo( 'name' ); ?></a>
									</h2><!-- END #logo -->
							<?php } ?>
						<?php } ?>
					</div>
					<?php if ($mts_options['mts_header_search'] == '1') { ?>
						<div id="headersearch">
							<?php get_search_form();?>
						</div>
					<?php } ?>
					<div class="secondary-navigation">
						<nav id="navigation" class="clearfix">
							<?php if ( has_nav_menu( 'primary-menu' ) ) { ?>
								<?php wp_nav_menu( array( 'theme_location' => 'primary-menu', 'menu_class' => 'menu clearfix', 'container' => '' ) ); ?>
							<?php } else { ?>
								<ul class="menu clearfix">
									<?php wp_list_categories('title_li='); ?>
								</ul>
							<?php } ?>
							<a href="#" id="pull"><?php _e('Menu','mythemeshop'); ?></a>  
						</nav>
					</div>              
				</div><!--#header-->
			</div><!--.container-->        
		</header>
		<div class="header-bottom">
			<?php if (is_home() && !is_paged()) { ?>
				<?php if($mts_options['mts_featured_slider'] == '1') { ?>
					<div class="slider-container">
						<div class="flex-container loading">
							<div id="slider" class="flexslider">
								<ul class="slides">
									<?php $slider_cat = implode(",", $mts_options['mts_featured_slider_cat']); $my_query = new WP_Query('cat='.$slider_cat.'&posts_per_page=4');
										while ($my_query->have_posts()) : $my_query->the_post();
										$image_id = get_post_thumbnail_id();
										$image_url = wp_get_attachment_image_src($image_id,'related');
										$image_url = $image_url[0]; ?>
									<li data-thumb="<?php echo $image_url; ?>"> 
										<a href="<?php the_permalink() ?>">
											<?php if ( has_post_thumbnail() ) { ?> 
												<?php the_post_thumbnail('slider',array('title' => '')); ?>
											<?php } else { ?>
												<img src="<?php echo get_template_directory_uri(); ?>/images/sliderthumb.png" class="attachment-featured wp-post-image" alt="<?php the_title(); ?>">
											<?php } ?>
											<div class="flex-caption">
												<h2 class="slidertitle"><?php the_title(); ?></h2>
											</div>
										</a> 
									</li>
									<?php endwhile; wp_reset_query(); ?>
								</ul>
							</div>
							<div id="carousel" class="flexslider">
								<ul class="slides">
									<?php $my_query = new WP_Query('cat='.$slider_cat.'&posts_per_page=4');
										while ($my_query->have_posts()) : $my_query->the_post();
										$image_id = get_post_thumbnail_id();
										$image_url = wp_get_attachment_image_src($image_id,'related');
										$image_url = $image_url[0];
									 ?>
									<li>
										<a href="<?php the_permalink() ?>" title="<?php the_title(); ?>" rel="bookmark">
											<div class="left">
												<?php if(has_post_thumbnail()): $image = wp_get_attachment_image_src(get_post_thumbnail_id($post->ID), 'widgetthumb'); ?>
													<img src="<?php echo $image[0]; ?>" alt="<?php the_title(); ?>" class="wp-post-image" />
												<?php else: ?>
													<img src="<?php echo get_template_directory_uri(); ?>/images/smallthumb.png" alt="<?php the_title(); ?>"  class="wp-post-image" />
												<?php endif; ?>
												<div class="clear"></div>
											</div>
											<div class="info"> 
												<span class="entry-title">
													<?php the_title(); ?>
													<div class="meta">
														<?php if($mts_options['mts_home_headline_meta'] == '1') { ?>
															<?php if(isset($mts_options['mts_home_headline_meta_info']['a']) == '1') { ?> 
																<i class="icon-calendar"></i>
																<?php the_time('F j, Y'); ?>
															<?php } ?>
														<?php } ?>
														<div class="readMore">+</div>
													</div>
												</span>
											</div>
										</a>
										<!--end .info-->
										<div class="clear"></div>
									</li>
									<?php endwhile; wp_reset_query(); ?>
								</ul>
							</div>
						</div>
					</div>
					<!-- slider-container -->
				<?php } ?>
			<?php } else {
				if (in_array( 'woocommerce/woocommerce.php', apply_filters( 'active_plugins', get_option( 'active_plugins' ) ) ) && is_woocommerce()) { ?>
					<div class="breadcrumb"><span><?php _e('You are Here','mythemeshop'); ?>: </span><?php do_action('woo_custom_breadcrumb'); ?><?php mts_cart(); ?></div>
				<?php } elseif ($mts_options['mts_breadcrumb'] == '1' && is_singular()) { ?>
					<div class="breadcrumb"><span><?php _e('You are Here','mythemeshop'); ?>: </span><?php mts_the_breadcrumb(); ?></div>
				<?php } 
			}?>
		</div>
		<?php if (is_home() && !is_paged()) { ?>
			<?php if($mts_options['mts_featured_home_cat'] == '1') { ?>
				<div class="header-bottom-second">
					<div class="rp_container_home">
						<?php $home_cat = implode(",", $mts_options['mts_home_cat']); $my_query = new WP_Query('cat='.$home_cat.'&posts_per_page=4');
							while ($my_query->have_posts()) : $my_query->the_post(); ?>
							<div class="excerpt_two post <?php echo (++$j % 4 == 0) ? 'last' : ''; ?>">
								<?php if ( has_post_thumbnail()){
									echo '<div class="featured-thumbnail">'; the_post_thumbnail('featured',array('title' => ''.get_the_title().'')); echo '</div>';
								}
								else{ ?>
									<div class="featured-thumbnail"> 
										<img src="<?php echo get_template_directory_uri(); ?>/images/featuredthumb.png" class="attachment-featured wp-post-image" alt="<?php the_title(); ?>" title="<?php the_title(); ?>">
									</div>
								<?php } ?>
								<div class="extwotitle" onclick="location.href='<?php the_permalink() ?>'"> <span><?php the_title(); ?> </span>
									<div class="readMore"><a href="<?php the_permalink() ?>" title="<?php the_title(); ?>" rel="bookmark">+</a></div>
								</div>
							</div>
							<!--.post excerpt-->    
						<?php endwhile; wp_reset_query(); ?>
					</div>
				</div>
			<?php } ?>
		<?php } else { ?>
			<?php if ($mts_options['mts_header_adcode'] != '') { ?>
				<div class="header-bottom-second">
					<?php echo '<div id="header-widget-container">';
					if ($mts_options['mts_header_adcode'] != ''){
						echo '<div class="widget-header">';
						echo $mts_options['mts_header_adcode'];
						echo '</div>';
					}
					?>
					<?php if ($mts_options['mts_posttopleft_adcode'] != ''){ ?>
						<div class="widget-header-bottom-right">
							<div class="textwidget">
								<div class="topad"><?php echo $mts_options['mts_posttopleft_adcode']; ?> </div>
							</div>
						</div> 
					<?php } ?>
			<?php echo '</div></div>'; } ?>
		<?php } ?>
		<div class="main-container">