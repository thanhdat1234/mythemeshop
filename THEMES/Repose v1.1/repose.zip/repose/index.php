<?php $mts_options = get_option('repose'); ?>
<?php get_header(); ?>

<?php if (is_home() && !is_paged()) { ?>
	<?php if($mts_options['mts_random_posts'] == '1') { ?>
	<!--Start Random Posts-->
		<div id="three_cat_home">
			<?php $my_query = new WP_Query('posts_per_page=3&orderby=rand&ignore_sticky_posts=1'); 
			while ($my_query->have_posts()) : $my_query->the_post(); $category = get_the_category(); ?>
				<div class="cat_home">
					<span class="cat_name"><?php echo $category[0]->cat_name; ?></span>
					<a href="<?php the_permalink(); ?>">
						<?php if ( has_post_thumbnail() ) { ?> 
							<?php the_post_thumbnail('homecat',array('title' => '')); ?>
						<?php } else { ?>
							<img src="<?php echo get_template_directory_uri(); ?>/images/randhumb.png" class="attachment-featured wp-post-image" alt="<?php the_title(); ?>">
						<?php } ?>
					</a> 
					<h2 class="title hcattitle"><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h2>
					<span class="hm_cat_exp" >
						<?php echo mts_excerpt(14); ?>
					</span>
					<div class="post-info">
						<?php if($mts_options['mts_home_headline_meta'] == '1') { ?>
							<?php if(isset($mts_options['mts_home_headline_meta_info']['a']) == '1') { ?>
								<span class="thetime"><i class="icon-calendar"></i> <?php  the_time('F j, Y'); ?></span>
							<?php } ?>
							<?php if(isset($mts_options['mts_home_headline_meta_info']['b']) == '1') { ?>
								<span class="theauthor"><i class="icon-user"></i> <?php the_author_posts_link(); ?></span>
							<?php } ?>
						<?php } ?>
						<div class="readMore"><a href="<?php the_permalink() ?>" title="<?php the_title(); ?>" rel="bookmark">+</a></div>
					</div>
				</div>
			<?php endwhile; wp_reset_query(); ?>
		</div>
	<!--End Random Posts-->
	<?php } ?>
<?php } ?>

<div id="page">
	<div class="article">
		<?php if (is_home() && !is_paged()) { ?>
			<?php if($mts_options['mts_featured_video'] == '1') { ?>
			<!--Start Featured Video-->
				<div class="featured_video">
					<label><?php _e('Featured Video','mythemeshop'); ?></label>
					<?php $my_query = new WP_Query(array(
						'post_type'=> 'post',
						'showposts' => 1,
						'post_status' => 'publish',
						'order' => 'DESC',
						'tax_query' => array(
								array(
									'taxonomy' => 'post_format',
									'field' => 'slug',
									'terms' => array( 'post-format-video' )
								)
							)
						));
					while ($my_query->have_posts()) : $my_query->the_post();
						$embed = get_post_meta($post->ID, 'mts_video_embed', true);
						if( !empty($embed) ) {
							echo "<div class='video-frame'>";
							echo stripslashes(htmlspecialchars_decode($embed));
							echo "</div>";
						}
					?>
						<h2 class="title hcattitle"> <a href="<?php the_permalink(); ?>"><?php the_title(); ?></a> </h2>
						<span class="hm_cat_exp" >
							<?php echo mts_excerpt(26); ?>
						</span>
					<?php endwhile; wp_reset_query(); ?>
				</div>
			<!--End Featured Video-->
			<?php } ?>
		<?php } ?>
		
		<?php if($mts_options['mts_grid_layout'] == '0'){ ?>
			<div id="content_box">		
				<?php $j = 0; if ( get_query_var('paged') ) { $paged = get_query_var('paged'); } elseif ( get_query_var('page') ) { $paged = get_query_var('page'); } else { $paged = 1; }
					query_posts( array( 'post_type' => 'post', 'paged' => $paged ) );
					if (have_posts()) : while (have_posts()) : the_post();
					?>
					<article class="latestPost excerpt  <?php echo (++$j % 2 == 0) ? 'last' : ''; ?>">
						<a href="<?php the_permalink() ?>" title="<?php the_title(); ?>" rel="nofollow" id="featured-thumbnail">
							<?php if ( has_post_thumbnail() ) { ?>
								<?php echo '<div class="featured-thumbnail">'; the_post_thumbnail('widgetthumb',array('title' => '')); echo '</div>'; ?>
							<?php } else { ?>
								<div class="featured-thumbnail">
									<img width="61" height="61" src="<?php echo get_template_directory_uri(); ?>/images/smallthumb.png" class="attachment-featured wp-post-image" alt="<?php the_title(); ?>">
								</div>
							<?php } ?>
						</a>
						<header>
							<h2 class="title front-view-title"><a href="<?php the_permalink() ?>" title="<?php the_title(); ?>"><?php the_title(); ?></a></h2>
							<?php if($mts_options['mts_home_headline_meta'] == '1') { ?>
								<div class="post-info">
									<?php if($mts_options['mts_home_headline_meta'] == '1') { ?>
										<?php if(isset($mts_options['mts_home_headline_meta_info']['a']) == '1') { ?> 
											<span class="thetime"><i class="icon-calendar"></i> <?php the_time( get_option( 'date_format' ) ); ?></span>
										<?php } ?>
									<?php } ?>
									<div class="readMore"><a href="<?php the_permalink() ?>" title="<?php the_title(); ?>" rel="nofollow"><?php _e('+','mythemeshop'); ?></a></div>
								</div>
							<?php } ?>
						</header>
					</article><!--.post excerpt-->
				<?php endwhile; endif; ?>
			</div>
		<?php } elseif($mts_options['mts_grid_layout'] == '1'){ ?>
			<?php if (is_home() && !is_paged()) { ?>				
				<?php if ( get_query_var('paged') ) { $paged = get_query_var('paged'); } elseif ( get_query_var('page') ) { $paged = get_query_var('page'); } else { $paged = 1; }
				query_posts( array( 'post_type' => 'post', 'paged' => $paged ) );
				if (have_posts()) : while (have_posts()) : the_post();
				?>
					<div class="featured_video latest-big">
						<?php if ( has_post_thumbnail() ) { ?>
							<a href="<?php the_permalink(); ?>">
								<?php echo '<div class="featured-thumbnail">'; the_post_thumbnail('slider',array('title' => '')); echo '</div>'; ?>
							</a>
						<?php } ?>
						<h2 class="title hcattitle"> <a href="<?php the_permalink(); ?>"><?php the_title(); ?></a> </h2>
						<span class="hm_cat_exp" >
							<?php echo mts_excerpt(34); ?>
						</span>
						<div class="post-info">
						<?php if($mts_options['mts_home_headline_meta'] == '1') { ?>
							<?php if(isset($mts_options['mts_home_headline_meta_info']['a']) == '1') { ?>
								<span class="thetime"><i class="icon-calendar"></i> <?php  the_time('F j, Y'); ?></span>
							<?php } ?>
							<?php if(isset($mts_options['mts_home_headline_meta_info']['b']) == '1') { ?>
								<span class="theauthor"><i class="icon-user"></i> <?php the_author_posts_link(); ?></span>
							<?php } ?>
						<?php } ?>
						<div class="readMore"><a href="<?php the_permalink() ?>" title="<?php the_title(); ?>" rel="bookmark">+</a></div>
					</div>
					</div>
				<?php endwhile; endif; ?>
				<!--End Featured Video-->
			<?php } ?>
		<?php } ?>
		<!--Start Pagination-->
		<?php if ($mts_options['mts_pagenavigation'] == '1' ) { ?>
			<?php if ($mts_options['mts_pagenavigation_type'] == '1' ) { ?>
				<?php  $additional_loop = 0; mts_pagination($additional_loop['max_num_pages']); ?>
			<?php } else { ?>
				<div class="pagination">
					<ul>
						<li class="nav-previous"><?php next_posts_link( __( '&larr; '.'Older posts', 'mythemeshop' ) ); ?></li>
						<li class="nav-next"><?php previous_posts_link( __( 'Newer posts'.' &rarr;', 'mythemeshop' ) ); ?></li>
					</ul>
				</div>
			<?php } ?>
		<?php } ?>
		<!--End Pagination-->
	</div>
	<?php get_sidebar(); ?>
<?php get_footer(); ?>