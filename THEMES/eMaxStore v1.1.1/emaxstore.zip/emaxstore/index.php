<?php $mts_options = get_option(MTS_THEME_NAME); ?>
<?php get_header(); ?>
<div id="page">
    <div class="<?php echo mts_article_class(); ?>">
        <div id="content_box">
            <?php if ( is_home() && mts_isWooCommerce() ) {
                if (!empty($mts_options['mts_featured_product_categories'])) {
                    foreach ($mts_options['mts_featured_product_categories'] as $section) {
                        $featured_title = $section['mts_featured_product_title'];
                        $category_id = $section['mts_featured_product_category'];
                        $posts_num = $section['mts_featured_product_category_postsnum'];
                        $wide_first_thumb = !empty($section['mts_featured_product_category_widethumb']);

                        if ( 'featured' == $category_id ) {

                            $args = array(
                                'post_type'             => 'product',
                                'post_status'           => 'publish',
                                'ignore_sticky_posts'   => 1,
                                'posts_per_page'        => $posts_num,
                                'orderby'               => 'date',
                                'order'                 => 'desc',
                                'meta_query'            => array(
                                    array(
                                        'key'       => '_visibility',
                                        'value'     => array('catalog', 'visible'),
                                        'compare'   => 'IN'
                                    ),
                                    array(
                                        'key'       => '_featured',
                                        'value'     => 'yes'
                                    )
                                )
                            );

                        } elseif ( 'latest' == $category_id ) {

                            $args = array(
                                'post_type' => 'product',
                                'posts_per_page' => $posts_num
                            );

                        } else {

                            $term = get_term( $category_id, 'product_cat' );
                            $slug = $term->slug;

                            $args = array(
                                'post_type' => 'product',
                                'posts_per_page' => $posts_num,
                                'product_cat' => $slug
                            );
                        }

                        $loop = new WP_Query( $args );
                        if ( $loop->have_posts() ) : ?>
                        <div class="featured-section products clearfix">
                            <header class="carousel-header">
                                <div class="carousel-controls">
                                    <div class="owl-pagination"></div>
                                    <div class="owl-buttons"></div>
                                </div>
                                <h3 class="carousel-title"><span><?php echo $featured_title; ?></span></h3>
                            </header>
                            <?php woocommerce_product_carousel_loop_start(); ?>
                            <?php while ( $loop->have_posts() ) : $loop->the_post(); ?>
                                <?php wc_get_template_part( 'content', 'product-carousel' ); ?>
                            <?php endwhile; ?>
                            <?php woocommerce_product_carousel_loop_end(); ?>
                        </div>
                        <?php

                        endif;

                        wp_reset_postdata();
                    }
                }
            } ?>
        </div>
    </div>
<?php get_footer(); ?>