<?php $mts_options = get_option(MTS_THEME_NAME); ?>
<?php
    // default = 3
    $footer_num = !empty( $mts_options['mts_footer_num'] ) ? (int) $mts_options['mts_footer_num'] : 3;
?>
        </div><!--#page-->
    </div><!--.main-container-->
    <footer class="footer" role="contentinfo" itemscope itemtype="http://schema.org/WPFooter">
        <div class="container">
            <?php if ($mts_options['mts_footer']) : ?>
                <div class="footer-widgets widgets-num-<?php echo $footer_num; ?>">
                    <div class="f-widget f-widget-1">
                        <?php if ( !function_exists('dynamic_sidebar') || !dynamic_sidebar('footer') ) : ?><?php endif; ?>
                    </div>
                    <div class="f-widget f-widget-2">
                        <?php if ( !function_exists('dynamic_sidebar') || !dynamic_sidebar('footer-2') ) : ?><?php endif; ?>
                    </div>
                    <div class="f-widget f-widget-3 <?php echo ($footer_num == 3) ? 'last' : ''; ?>">
                        <?php if ( !function_exists('dynamic_sidebar') || !dynamic_sidebar('footer-3') ) : ?><?php endif; ?>
                    </div>
                    <?php if ($footer_num == 4) : ?>
                    <div class="f-widget f-widget-4 last">
                        <?php if ( !function_exists('dynamic_sidebar') || !dynamic_sidebar('footer-4') ) : ?><?php endif; ?>
                    </div>
                    <?php endif; ?>
                    <?php if ($footer_num == 5) : ?>
                    <div class="f-widget f-widget-4">
                        <?php if ( !function_exists('dynamic_sidebar') || !dynamic_sidebar('footer-4') ) : ?><?php endif; ?>
                    </div>
                    <div class="f-widget f-widget-5 last">
                        <?php if ( !function_exists('dynamic_sidebar') || !dynamic_sidebar('footer-5') ) : ?><?php endif; ?>
                    </div>
                    <?php endif; ?>
                </div><!--.footer-widgets-->
            <?php endif; ?>
            <div id="footer-separator">
                <div class="left-border"><span></span></div>
                <a href="#" id="footer-to-top" class="to-top"><i class="fa fa-angle-double-up"></i></a>
                <div class="right-border"><span></span></div>
            </div>
            <div id="footer">
                <div class="copyrights">
                    <?php echo $mts_options['mts_copyrights']; ?>
                </div>
                <div class="footer-navigation">
                    <nav id="footer-navigation" class="clearfix">
                        <?php if ( has_nav_menu( 'footer-menu' ) ) { ?>
                            <?php wp_nav_menu( array( 'theme_location' => 'footer-menu', 'menu_class' => 'footer-menu clearfix', 'container' => '' ) ); ?>
                        <?php } else { ?>
                            <ul class="footer-menu clearfix">
                                <?php wp_list_pages('title_li='); ?>
                            </ul>
                        <?php } ?>
                    </nav>
                </div>
                <div class="footer-right">
                    <?php mts_credit_cards(); ?>
                </div>
            </div><!--#footer-->
        </div><!--.container-->
    </footer><!--footer-->
</div><!--.main-container-wrap-->
<?php mts_footer(); ?>
<?php wp_footer(); ?>
</body>
</html>