<?php get_header(); ?>
<?php $mts_options = get_option(MTS_THEME_NAME); ?>
<div id="page" class="blog_page" itemscope itemtype="http://schema.org/BlogPosting">
	<div id="content_box">
		<h1 class="postsby">
			<?php if (is_category()) { ?>
				<span><?php single_cat_title(); ?><?php _e(" Archive", "mythemeshop"); ?></span>
			<?php } elseif (is_tag()) { ?> 
				<span><?php single_tag_title(); ?><?php _e(" Archive", "mythemeshop"); ?></span>
			<?php } elseif (is_author()) { ?>
				<span><?php  $curauth = (isset($_GET['author_name'])) ? get_user_by('slug', $author_name) : get_userdata(intval($author)); echo $curauth->nickname; _e(" Archive", "mythemeshop"); ?></span> 
			<?php } elseif (is_day()) { ?>
				<span><?php _e("Daily Archive:", "mythemeshop"); ?></span> <?php the_time('l, F j, Y'); ?>
			<?php } elseif (is_month()) { ?>
				<span><?php _e("Monthly Archive:", "mythemeshop"); ?></span> <?php the_time('F Y'); ?>
			<?php } elseif (is_year()) { ?>
				<span><?php _e("Yearly Archive:", "mythemeshop"); ?></span> <?php the_time('Y'); ?>
			<?php } ?>
		</h1>
		<div class="article">
			<?php if( have_posts() ) : while ( have_posts() ) : the_post(); ?>
				<article id="post-<?php the_ID(); ?>" <?php post_class('g post'); ?>>
	                <div class="single_post clearfix">
	                    <?php if( has_post_thumbnail() ): ?>
	                        <div class="featured-thumbnail">
	                            <a href="<?php the_permalink(); ?>" title="<?php the_title_attribute(); ?>" >
	                                <?php the_post_thumbnail( 'emaxcontent' ); ?>
	                                <?php if (function_exists('wp_review_show_total')) wp_review_show_total(true, 'latestPost-review-wrapper'); ?>
	                            </a>
	                        </div>
	                    <?php endif; ?>
	                    <header>
	                        <h2 class="single-title">
	                            <a href="<?php the_permalink(); ?>" title="<?php the_title_attribute(); ?>" ><?php the_title(); ?></a>
	                        </h2>
	                        <?php mts_the_postinfo('home'); ?>
	                    </header><!--.headline_area-->
	                    <div class="box mark-links">
							<?php if($mts_options['mts_full_posts'] == '0'){ ?>
								<?php echo mts_excerpt(50); ?>
								<div class="reply">
									<a class="button" href="<?php the_permalink(); ?>"><?php _e("Read more","mythemetop"); ?></a>
								</div>
							<?php } else { ?>
								<?php the_content(); ?>
								<?php if (mts_post_has_moretag()){ ?>
									<div class="reply">
										<a class="button" href="<?php the_permalink(); ?>"><?php _e("Read more","mythemetop"); ?></a>
									</div>
	                        	<?php }
	                        } ?>
	                    </div><!--.box mark-links-->
	                </div><!--.single_post clearfix-->

	            </article><!--.g post-->
		        <?php endwhile; /* end loop */ ?>
				<!--Start Pagination-->
				<?php if (isset($mts_options['mts_pagenavigation_type']) && $mts_options['mts_pagenavigation_type'] == '1' ) { ?>
					<?php $additional_loop = 0; mts_pagination($additional_loop['max_num_pages']); ?>
				<?php } else { ?>
					<div class="pagination pagination-previous-next">
						<ul>
							<li class="nav-previous button"><?php next_posts_link( '<i class="fa fa-angle-left"></i> '. __( 'Previous', 'mythemeshop' ) ); ?></li>
							<li class="nav-next button"><?php previous_posts_link( __( 'Next', 'mythemeshop' ).' <i class="fa fa-angle-right"></i>' ); ?></li>
						</ul>
					</div>
				<?php } ?>
				<!--End Pagination-->
			<?php endif; wp_reset_query(); ?>
		</div>

		<?php get_sidebar(); ?>
	</div>

<?php get_footer(); ?>