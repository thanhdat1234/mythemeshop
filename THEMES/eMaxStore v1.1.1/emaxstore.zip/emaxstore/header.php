<!DOCTYPE html>
<?php $mts_options = get_option(MTS_THEME_NAME); ?>
<html class="no-js" <?php language_attributes(); ?>>
<head itemscope itemtype="http://schema.org/WebSite">
	<meta charset="<?php bloginfo('charset'); ?>">
	<!-- Always force latest IE rendering engine (even in intranet) & Chrome Frame -->
	<!--[if IE ]>
	<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
	<![endif]-->
	<link rel="profile" href="http://gmpg.org/xfn/11" />
	<?php mts_meta(); ?>
	<link rel="pingback" href="<?php bloginfo( 'pingback_url' ); ?>" />
	<?php wp_head(); ?>
</head>
<body id ="blog" <?php body_class('main'); ?> itemscope itemtype="http://schema.org/WebPage">       
	<div class="main-container-wrap">
		<header class="main-header" role="banner" itemscope itemtype="http://schema.org/WPHeader">
		<?php
		$spacer_class = '';
		if ( is_home() && $mts_options['mts_featured_slider'] == '1' ) {
			$spacer_class = ' homepage-slider-spacer';
		?>
			<div id="homepage-slider" class="flexslider">
				<ul class="slides">
					<?php if ( !empty( $mts_options['mts_custom_slider'] ) ) { ?>
						<?php
						$count = 0;
						foreach( $mts_options['mts_custom_slider'] as $slide ) :
							++$count;
							$image_url = wp_get_attachment_image_src( $slide['mts_custom_slider_image'], 'full' );
							$image_url = $image_url[0];

							$slide_link        = $slide['mts_custom_slider_link'];
							$slide_title       = $slide['mts_custom_slider_title'];
							$slide_heading     = $slide['mts_custom_slider_heading'];
							$slide_subheading  = $slide['mts_custom_slider_subheading'];
							$slide_bottom_text = $slide['mts_custom_slider_bottom_text'];
						?>
							<li style="background-image: url(<?php echo $image_url;?>);">
								<a href="<?php echo $slide_link; ?>">
									<div class="container homepage-slider-inner-spacer">
									<?php if ( !empty($slide_title) || !empty($slide_subheading) ) { ?>
										<div class="flex-caption">
											<div class="slide-header lined-text clearfix"><span><?php echo $slide_title; ?></span></div>
											<?php if ( !empty( $slide_heading ) ) { ?><h2 class="slide-heading"><?php echo $slide_heading; ?></h2><?php } ?>
											<?php if ( !empty( $slide_subheading ) ) { ?><h3 class="slide-subheading"><?php echo $slide_subheading; ?></h3><?php } ?>
											<?php if ( !empty( $slide_subheading ) ) { ?><div class="slide-footer lined-text clearfix"><span><?php echo $slide_bottom_text; ?></span></div><?php } ?>
										</div>
									<?php } ?>
									</div>
								</a>
							</li>
						<?php
						if ( $count === 3 ) break;
						endforeach; ?>
					<?php } ?>
				</ul>
			</div><!-- #homepage-slider -->
		<?php } ?>
			<div class="container<?php echo $spacer_class;?>">
				<div id="header">
					<div class="header-inner clearfix">
						<?php if ( mts_isWooCommerce() ) { ?>
						<div class="header-left-wrap">
							<div class="header-left">
								<?php mts_account_links(); ?>
							</div>
						</div>
						<?php } ?>
						<div class="logo-wrap">
							<?php if ( $mts_options['mts_logo'] != '' ) { ?>
								<?php if ( is_front_page() || is_home() || is_404() ) { ?>
									<h1 id="logo" class="image-logo" itemprop="headline">
										<a href="<?php echo home_url(); ?>"><img src="<?php echo $mts_options['mts_logo']; ?>" alt="<?php bloginfo( 'name' ); ?>"></a>
									</h1><!-- #logo -->
								<?php } else { ?>
									<h2 id="logo" class="image-logo" itemprop="headline">
										<a href="<?php echo home_url(); ?>"><img src="<?php echo $mts_options['mts_logo']; ?>" alt="<?php bloginfo( 'name' ); ?>"></a>
									</h2><!-- #logo -->
								<?php } ?>
							<?php } else { ?>
								<?php if ( is_front_page() || is_home() || is_404() ) { ?>
									<h1 id="logo" class="text-logo" itemprop="headline">
										<a href="<?php echo home_url(); ?>"><?php bloginfo( 'name' ); ?></a>
									</h1><!-- #logo -->
								<?php } else { ?>
									<h2 id="logo" class="text-logo" itemprop="headline">
										<a href="<?php echo home_url(); ?>"><?php bloginfo( 'name' ); ?></a>
									</h2><!-- #logo -->
								<?php } ?>
								<div class="site-description" itemprop="description">
									<?php bloginfo( 'description' ); ?>
								</div>
							<?php } ?>
						</div>
						<?php if ( mts_isWooCommerce() ) { ?>
						<div class="header-right-wrap">
							<div class="header-right">
								<?php mts_wishlist_link(); ?>
								<?php mts_cart_button(); ?>
							</div>
						</div>
						<?php } ?>
					</div>
					<?php if ( $mts_options['mts_show_primary_nav'] == '1' ) { ?>
					<?php if ( $mts_options['mts_sticky_nav'] == '1' ) { ?>
					<div class="clear" id="catcher"></div>
					<div id="sticky" class="primary-navigation" role="navigation" itemscope itemtype="http://schema.org/SiteNavigationElement">
					<?php } else { ?>
					<div class="primary-navigation" role="navigation" itemscope itemtype="http://schema.org/SiteNavigationElement">
					<?php } ?>
						<nav id="navigation" class="clearfix">
							<a href="#" id="pull" class="toggle-mobile-menu"><i class="fa fa-bars toggle-mobile-menu-icon"></i><?php _e('Menu','mythemeshop'); ?></a>
							<?php if ( has_nav_menu( 'primary-menu' ) ) { ?>
								<?php $nav_menu_walker = mts_is_wp_mega_menu_active() ? new wpmm_menu_walker : new mts_menu_walker; ?>
								<?php wp_nav_menu( array( 'theme_location' => 'primary-menu', 'menu_class' => 'menu', 'container' => '', 'walker' => $nav_menu_walker ) ); ?>
							<?php } else { ?>
								<ul class="menu">
									<?php wp_list_pages('title_li='); ?>
								</ul>
							<?php } ?>
							<?php mts_navigation_extras(); ?>
						</nav>
					</div><!--.primary-navigation-->
					<?php } ?>
				</div><!--#header-->
				<?php if ( !is_home() && $mts_options['mts_breadcrumb'] == '1' ) { ?>
					<div class="breadcrumb" xmlns:v="http://rdf.data-vocabulary.org/#"><?php mts_the_breadcrumb(); ?></div>
				<?php } ?>
			</div><!--.container-->
			<?php if ( is_home() && $mts_options['mts_featured_slider'] == '1' ) { ?>
				<div class="container">
					<div class="homepage-slider-controls-wrap">
						<div id="homepage-slider-controls" class="flexslider">
							<ul class="slides">
								<?php if ( !empty( $mts_options['mts_custom_slider'] ) ) {

									$count = 0; foreach ( $mts_options['mts_custom_slider'] as $slide ) : ++$count;
									$slide_title = $slide['mts_custom_slider_title'];
									?>
										<li>
											<a href="<?php echo $slide['mts_custom_slider_link']; ?>">
												<?php echo wp_get_attachment_image( $slide['mts_custom_slider_image'], 'emaxsliderthumb', false, array( 'title' => '' ) ); ?>
												<div class="image-overlay"><div class="slide-title-container"><h4 class="slide-title"><?php echo $slide_title; ?></h4></div></div>
											</a>
										</li>
									<?php if ( $count === 3 ) break; endforeach; ?>
								<?php } ?>
							</ul>
						</div><!-- #homepage-slider-controls -->
					</div><!-- .homepage-slider-controls-wrap -->
				</div>
				<?php } ?>
		</header>
		<div class="main-container">