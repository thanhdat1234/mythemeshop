<?php
/*-----------------------------------------------------------------------------------*/
/*  Do not remove these lines, sky will fall on your head.
/*-----------------------------------------------------------------------------------*/
define( 'MTS_THEME_NAME', 'emaxstore' );
require_once( dirname( __FILE__ ) . '/theme-options.php' );
if ( ! isset( $content_width ) ) $content_width = 1060;

/*-----------------------------------------------------------------------------------*/
/*  Load Options
/*-----------------------------------------------------------------------------------*/
$mts_options = get_option( MTS_THEME_NAME );
add_theme_support( 'title-tag' );

/*-----------------------------------------------------------------------------------*/
/*  Load Translation Text Domain
/*-----------------------------------------------------------------------------------*/
load_theme_textdomain( 'mythemeshop', get_template_directory().'/lang' );

// Custom translations
if ( !empty( $mts_options['translate'] )) {
    $mts_translations = get_option( 'mts_translations_'.MTS_THEME_NAME );//$mts_options['translations'];
    function mts_custom_translate( $translated_text, $text, $domain ) {
        if ( $domain == 'mythemeshop' || $domain == 'nhp-opts' ) {

            global $mts_translations;

            if ( !empty( $mts_translations[$text] )) {
                $translated_text = $mts_translations[$text];
            }
        }
        return $translated_text;
        
    }
    add_filter( 'gettext', 'mts_custom_translate', 20, 3 );
}

if ( function_exists( 'add_theme_support' ) ) add_theme_support( 'automatic-feed-links' );

/*-----------------------------------------------------------------------------------*/
/*  Disable theme updates from WordPress.org theme repository
/*-----------------------------------------------------------------------------------*/
// Check if MTS Connect plugin already done this
if ( !class_exists('mts_connection') ) {
    // If wrong updates are already shown, delete transient so that we can run our workaround
    add_action('init', 'mts_hide_themes_plugins');
    function mts_hide_themes_plugins() {
        if ( !is_admin() ) return;
        if ( false === get_site_transient( 'mts_wp_org_check_disabled' ) ) { // run only once
            delete_site_transient('update_themes' );
            delete_site_transient('update_plugins' );

            add_action('current_screen', 'mts_remove_themes_plugins_from_update' );
        }
    }
    // Hide mts themes/plugins
    function mts_remove_themes_plugins_from_update( $screen ) {
        $run_on_screens = array( 'themes', 'themes-network', 'plugins', 'plugins-network', 'update-core', 'network-update-core' );
        if ( in_array( $screen->base, $run_on_screens ) ) {
            //Themes
            if ( $themes_transient = get_site_transient( 'update_themes' ) ) {
                if ( property_exists( $themes_transient, 'response' ) && is_array( $themes_transient->response ) ) {
                    foreach ( $themes_transient->response as $key => $value ) {
                        $theme = wp_get_theme( $value['theme'] );
                        $theme_uri = $theme->get( 'ThemeURI' );
                        if ( 0 !== strpos( $theme_uri, 'mythemeshop.com' ) ) {
                            unset( $themes_transient->response[$key] );
                        }
                    }
                    set_site_transient( 'update_themes', $themes_transient );
                }
            }
            //Plugins
            if ( $plugins_transient = get_site_transient( 'update_plugins' ) ) {
                if ( property_exists( $plugins_transient, 'response' ) && is_array( $plugins_transient->response ) ) {
                    foreach ( $plugins_transient->response as $key => $value ) {
                        $plugin = get_plugin_data( WP_PLUGIN_DIR.'/'.$key, false, false );
                        $plugin_uri = $plugin['PluginURI'];
                        if ( 0 !== strpos( $plugin_uri, 'mythemeshop.com' ) ) {
                            unset( $plugins_transient->response[$key] );
                        }
                    }
                    set_site_transient( 'update_plugins', $plugins_transient );
                }
            }
            set_site_transient( 'mts_wp_org_check_disabled', time() );
        }
    }
    add_action( 'load-themes.php', 'mts_clear_check_transient' );
    add_action( 'load-plugins.php', 'mts_clear_check_transient' );
    add_action( 'upgrader_process_complete', 'mts_clear_check_transient' );
    function mts_clear_check_transient(){
        delete_site_transient( 'mts_wp_org_check_disabled');
    }
}
// Disable auto update
add_filter( 'auto_update_theme', '__return_false' );


/*-----------------------------------------------------------------------------------*/
/* a shortcut function
/*-----------------------------------------------------------------------------------*/
function mts_isWooCommerce() {
    return in_array( 'woocommerce/woocommerce.php', apply_filters( 'active_plugins', get_option( 'active_plugins' ) ) );
}

/*-----------------------------------------------------------------------------------*/
/* a shortcut function for wp mega menu plugin
/*-----------------------------------------------------------------------------------*/
function mts_is_wp_mega_menu_active() {
    return in_array( 'wp-mega-menu/wp-mega-menu.php', apply_filters( 'active_plugins', get_option( 'active_plugins' ) ) );
}

/*-----------------------------------------------------------------------------------*/
/*  Create pages on Theme Activation
/*-----------------------------------------------------------------------------------*/
if ( isset( $_GET['activated'] ) && is_admin() ) {
    $pages_to_add = array(
        array(
            'post_type' => 'page',
            'page_title' => 'Blog',
            'page_content' => '',
            'page_template' => 'page-blog.php',
            'post_status' => 'publish',
            'post_author' => 1,
        ),
        array(
            'post_type' => 'page',
            'page_title' => 'Wishlist',
            'page_content' => '',
            'page_template' => 'page-wishlist.php',
            'post_status' => 'publish',
            'post_author' => 1,
        )
    );

    foreach ( $pages_to_add as $page_settings ) {
        $page_check = get_page_by_title( $page_settings['page_title'] );
        if ( !isset( $page_check->ID ) ) {
            $new_page_id = wp_insert_post( $page_settings );
            if ( !empty( $page_settings['page_template'] ) ) {
                update_post_meta( $new_page_id, '_wp_page_template', $page_settings['page_template'] );
            }
            $page_id = $new_page_id;
        } else {
            $page_id = $page_check->ID;
        }
    }
}

/*-----------------------------------------------------------------------------------*/
/*  Post Thumbnail Support
/*-----------------------------------------------------------------------------------*/
if ( function_exists( 'add_theme_support' ) ) { 
    add_theme_support( 'post-thumbnails' );
    set_post_thumbnail_size( 192, 120, true );
    add_image_size( 'featured', 192, 120, true ); //featured
    add_image_size( 'widgetthumb', 80, 75, true ); //widget
    add_image_size( 'widgetfull', 254, 402, true ); //sidebar full width
    add_image_size( 'emaxsliderthumb', 348, 183, true ); // homepage slider controls
    add_image_size( 'emaxcontent', 807, 323, true ); // content width with active sidebar
    add_image_size( 'emaxcarouselwide', 530, 402, true ); // first image on homepage carousels
}

function mts_get_thumbnail_url( $size = 'full' ) {
    global $post;
    if (has_post_thumbnail( $post->ID ) ) {
        $image = wp_get_attachment_image_src( get_post_thumbnail_id( $post->ID ), $size );
        return $image[0];
    }
    
    // use first attached image
    $images =& get_children( 'post_type=attachment&post_mime_type=image&post_parent=' . $post->ID );
    if (!empty($images)) {
        $image = reset($images);
        $image_data = wp_get_attachment_image_src( $image->ID, $size );
        return $image_data[0];
    }
        
    // use no preview fallback
    if ( file_exists( get_template_directory().'/images/nothumb-'.$size.'.png' ) )
        return get_template_directory_uri().'/images/nothumb-'.$size.'.png';
    else
        return '';
}

/*-----------------------------------------------------------------------------------*/
/*  Use first attached image as post thumbnail (fallback)
/*-----------------------------------------------------------------------------------*/
//add_filter( 'post_thumbnail_html', 'mts_post_image_html', 10, 5 );
function mts_post_image_html( $html, $post_id, $post_image_id, $size, $attr ) {
    if ( has_post_thumbnail() )
        return $html;
    
    // use first attached image
    $images =& get_children( 'post_type=attachment&post_mime_type=image&post_parent=' . $post_id );
    if (!empty($images)) {
        $image = reset($images);
        return wp_get_attachment_image( $image->ID, $size, false, $attr );
    }
        
    // use no preview fallback
    if ( file_exists( get_template_directory().'/images/nothumb-'.$size.'.png' ) )
        return '<img src="'.get_template_directory_uri().'/images/nothumb-'.$size.'.png" class="attachment-'.$size.' wp-post-image" alt="'.get_the_title().'">';
    else
        return '';
    
}

/*-----------------------------------------------------------------------------------*/
/*  Custom Menu Support
/*-----------------------------------------------------------------------------------*/
add_theme_support( 'menus' );
if ( function_exists( 'register_nav_menus' ) ) {
    register_nav_menus(
        array(
            'primary-menu' => __( 'Header Menu', 'mythemeshop' ),
            'footer-menu' => __( 'Footer Menu', 'mythemeshop' )
        )
    );
}

/*-----------------------------------------------------------------------------------*/
/*  Enable Widgetized sidebar and Footer
/*-----------------------------------------------------------------------------------*/
if ( function_exists( 'register_sidebar' ) ) {   
    function mts_register_sidebars() {
        $mts_options = get_option( MTS_THEME_NAME );
        
        // Default sidebar
        register_sidebar( array(
            'name' => 'Sidebar',
            'description'   => __( 'Default sidebar.', 'mythemeshop' ),
            'id' => 'sidebar',
            'before_widget' => '<div id="%1$s" class="widget %2$s">',
            'after_widget' => '</div>',
            'before_title' => '<h3 class="widget-title"><span>',
            'after_title' => '</span></h3>',
        ) );

        // Footer widget areas
        if ( !empty( $mts_options['mts_footer'] )) {
            if ( empty( $mts_options['mts_footer_num'] )) $mts_options['mts_footer_num'] = 3;
            register_sidebars( $mts_options['mts_footer_num'], array(
                'name' => __( 'Footer %d', 'mythemeshop' ),
                'description'   => __( 'Appears in the footer.', 'mythemeshop' ),
                'id' => 'footer',
                'before_widget' => '<div id="%1$s" class="widget %2$s">',
                'after_widget' => '</div>',
                'before_title' => '<h3 class="widget-title"><span>',
                'after_title' => '</span></h3>',
            ) );
        }
        
        // Custom sidebars
        if ( !empty( $mts_options['mts_custom_sidebars'] ) && is_array( $mts_options['mts_custom_sidebars'] )) {
            foreach( $mts_options['mts_custom_sidebars'] as $sidebar ) {
                if ( !empty( $sidebar['mts_custom_sidebar_id'] ) && !empty( $sidebar['mts_custom_sidebar_id'] ) && $sidebar['mts_custom_sidebar_id'] != 'sidebar-' ) {
                    register_sidebar( array( 'name' => ''.$sidebar['mts_custom_sidebar_name'].'', 'id' => ''.sanitize_title( strtolower( $sidebar['mts_custom_sidebar_id'] )).'', 'before_widget' => '<div id="%1$s" class="widget %2$s">', 'after_widget' => '</div>', 'before_title' => '<h3><span>', 'after_title' => '</span></h3>' ));
                }
            }
        }

        if ( mts_isWooCommerce() ) {
            // Register WooCommerce Shop and Single Product Sidebar
            register_sidebar( array(
                'name' => __('Shop Page Sidebar', 'mythemeshop'),
                'description'   => __( 'Appears on Shop main page and product archive pages.', 'mythemeshop' ),
                'id' => 'shop-sidebar',
                'before_widget' => '<div id="%1$s" class="widget %2$s">',
                'after_widget' => '</div>',
                'before_title' => '<h3 class="widget-title"><span>',
                'after_title' => '</span></h3>',
            ) );
            register_sidebar( array(
                'name' => __('Single Product Sidebar', 'mythemeshop'),
                'description'   => __( 'Appears on single product pages.', 'mythemeshop' ),
                'id' => 'product-sidebar',
                'before_widget' => '<div id="%1$s" class="widget %2$s">',
                'after_widget' => '</div>',
                'before_title' => '<h3 class="widget-title"><span>',
                'after_title' => '</span></h3>',
            ) );
        }
    }
    
    add_action( 'widgets_init', 'mts_register_sidebars' );
}

function mts_custom_sidebar() {
    $mts_options = get_option( MTS_THEME_NAME );
    
    // Default sidebar
    $sidebar = 'Sidebar';

    //if ( is_home() && !empty( $mts_options['mts_sidebar_for_home'] )) $sidebar = $mts_options['mts_sidebar_for_home'];
    if ( is_home() ) $sidebar= 'mts_nosidebar';
    if ( is_single() && !empty( $mts_options['mts_sidebar_for_post'] )) $sidebar = $mts_options['mts_sidebar_for_post'];
    if ( is_page() && !empty( $mts_options['mts_sidebar_for_page'] )) $sidebar = $mts_options['mts_sidebar_for_page'];
    
    // Archives
    if ( is_archive() && !empty( $mts_options['mts_sidebar_for_archive'] )) $sidebar = $mts_options['mts_sidebar_for_archive'];
    if ( is_category() && !empty( $mts_options['mts_sidebar_for_category'] )) $sidebar = $mts_options['mts_sidebar_for_category'];
    if ( is_tag() && !empty( $mts_options['mts_sidebar_for_tag'] )) $sidebar = $mts_options['mts_sidebar_for_tag'];
    if ( is_date() && !empty( $mts_options['mts_sidebar_for_date'] )) $sidebar = $mts_options['mts_sidebar_for_date'];
    if ( is_author() && !empty( $mts_options['mts_sidebar_for_author'] )) $sidebar = $mts_options['mts_sidebar_for_author'];
    
    // Other
    if ( is_search() && !empty( $mts_options['mts_sidebar_for_search'] )) $sidebar = $mts_options['mts_sidebar_for_search'];
    if ( is_404() && !empty( $mts_options['mts_sidebar_for_notfound'] )) $sidebar = $mts_options['mts_sidebar_for_notfound'];
    
    // Woo
    if ( mts_isWooCommerce() ) {
        if ( is_shop() || is_product_category() ) {
            if ( !empty( $mts_options['mts_sidebar_for_shop'] ))
                $sidebar = $mts_options['mts_sidebar_for_shop'];
            else
                $sidebar = 'shop-sidebar'; // default
        }
        if ( is_product() ) {
            if ( !empty( $mts_options['mts_sidebar_for_product'] ))
                $sidebar = $mts_options['mts_sidebar_for_product'];
            else
                $sidebar = 'product-sidebar'; // default
        }
    }
    
    // Page/post specific custom sidebar
    if ( is_page() || is_single() ) {
        wp_reset_postdata();
        global $post;
        $custom = get_post_meta( $post->ID, '_mts_custom_sidebar', true );
        if ( !empty( $custom )) $sidebar = $custom;
    }

    return $sidebar;
}

/*-----------------------------------------------------------------------------------*/
/*  Load Widgets, Actions and Libraries
/*-----------------------------------------------------------------------------------*/

// Add the 125x125 Ad Block Custom Widget
include( "functions/widget-ad125.php" );

// Add the Latest Tweets Custom Widget
include( "functions/widget-tweets.php" );

// Add Recent Posts Widget
include( "functions/widget-recentposts.php" );

// Add Related Posts Widget
include( "functions/widget-relatedposts.php" );

// Add Author Posts Widget
include( "functions/widget-authorposts.php" );

// Add Popular Posts Widget
include( "functions/widget-popular.php" );

// Add Facebook Like box Widget
include( "functions/widget-fblikebox.php" );

// Add Google Plus box Widget
include( "functions/widget-googleplus.php" );

// Add Subscribe Widget
include( "functions/widget-subscribe.php" );

// Add Social Profile Widget
include( "functions/widget-social.php" );

// Add Category Posts Widget
include( "functions/widget-catposts.php" );

// Add Category Posts Widget
include( "functions/widget-postslider.php" );

// Add Category Posts Widget
include( "functions/widget-accordion.php" );

if ( mts_isWooCommerce() ) {
    // Add Product Slider Widget
    include( "functions/widget-productslider.php" );

    // Add Ajax filter widget
    include( "functions/widget-ajax-layered-nav.php" );
}

// Add Welcome message
include( "functions/welcome-message.php" );

// Template Functions
include( "functions/theme-actions.php" );

// Post/page editor meta boxes
include( "functions/metaboxes.php" );

// TGM Plugin Activation
include( "functions/plugin-activation.php" );

// AJAX Contact Form - mts_contact_form()
include( 'functions/contact-form.php' );

if ( mts_is_wp_mega_menu_active() ) {
    // disable mega menu on all locations ( mega menu walker is called in header.php on primary menu )
    add_filter( 'wpmm_exclude_menu', '__return_true', 10, 2 ); 
    add_filter( 'wpmm_container_selector', 'emax_megamenu_parent_element' );
} else {
    // Custom menu walker
    include( 'functions/nav-menu.php' );
}

function emax_megamenu_parent_element( $selector ) {
    return '.primary-navigation';
}

/*-----------------------------------------------------------------------------------*/
/*  Javascript
/*-----------------------------------------------------------------------------------*/
function mts_nojs_js_class() {
    echo '<script type="text/javascript">document.documentElement.className = document.documentElement.className.replace( /\bno-js\b/,\'js\' );</script>';
}
add_action( 'wp_head', 'mts_nojs_js_class', 1 );

function mts_add_scripts() {
    $mts_options = get_option( MTS_THEME_NAME );

    wp_enqueue_script( 'jquery' );

    if ( is_singular() && comments_open() && get_option( 'thread_comments' ) ) {
        wp_enqueue_script( 'comment-reply' );
    }
    
    wp_register_script( 'customscript', get_template_directory_uri() . '/js/customscript.js', true );
    
    if ( ! empty( $mts_options['mts_show_primary_nav'] ) ) {
        $nav_menu = 'primary';
    } else {
        $nav_menu = 'none';
    }
    wp_localize_script(
        'customscript',
        'mts_customscript',
        array(
            'responsive' => true,
            'nav_menu' => $nav_menu,
            'compare_autopopup' => class_exists( 'YITH_Woocompare' ) && 'yes' == get_option( 'yith_woocompare_auto_open' ) ? true : false,
         )
    );
    wp_enqueue_script( 'customscript' );    
    
    // Slider
    wp_register_script( 'flexslider', get_template_directory_uri() . '/js/jquery.flexslider-min.js' );
    if ( ( ! empty( $mts_options['mts_featured_slider'] ) && ! is_singular() ) || ( mts_isWooCommerce() && is_product() ) ) {
        wp_enqueue_script ( 'flexslider' );
    }

    wp_register_script( 'owlcarousel', get_template_directory_uri() . '/js/owl.carousel.min.js' );
    wp_enqueue_script ( 'owlcarousel' );

    // Ajax nav for widget
    wp_register_script( 'wc-ajax-attr-filters', get_template_directory_uri() . '/js/wc-ajax-attr-filters.js' );
    
    // Parallax pages and posts
    if (is_singular()) {
        if ( basename( mts_get_post_template() ) == 'singlepost-parallax.php' || basename( get_page_template() ) == 'page-parallax.php' ) {
            wp_register_script ( 'jquery-parallax', get_template_directory_uri() . '/js/parallax.js' );
            wp_enqueue_script ( 'jquery-parallax' );
        }
    }
    if ( is_home() && $mts_options['mts_featured_slider'] == '1' ) {
        wp_register_script ( 'jquery-parallax', get_template_directory_uri() . '/js/parallax.js' );
            wp_enqueue_script ( 'jquery-parallax' );
    }

    global $is_IE;
    if ( $is_IE ) {
        wp_register_script ( 'html5shim', "http://html5shim.googlecode.com/svn/trunk/html5.js" );
        wp_enqueue_script ( 'html5shim' );
    }
}
add_action( 'wp_enqueue_scripts', 'mts_add_scripts' );
   
function mts_load_footer_scripts() {  
    $mts_options = get_option( MTS_THEME_NAME );
    
    // Lightbox
    wp_register_script( 'prettyPhoto', get_template_directory_uri() . '/js/jquery.prettyPhoto.js', true );

    if ( ! empty( $mts_options['mts_lightbox'] ) ) {
        if ( mts_isWooCommerce() ) {
            // Single product gallery slider lightbox is enabled or disabled inside woocommerce settings pages
            if ( ! is_product() ) {
                if ( ! empty( $mts_options['mts_lightbox'] ) ) { wp_enqueue_script( 'prettyPhoto' ); }
            }
        } else {
            if ( ! empty( $mts_options['mts_lightbox'] ) ) { wp_enqueue_script( 'prettyPhoto' ); }
        }
    }

    // Sticky Nav
    if ( !empty( $mts_options['mts_sticky_nav']) && !empty( $mts_options['mts_show_primary_nav']) ) {
        wp_register_script( 'StickyNav', get_template_directory_uri() . '/js/sticky.js', true );
        wp_enqueue_script( 'StickyNav' );
    }
    
    // Ajax Load More, Search Results and Wishlist
    wp_register_script( 'mts_cookie', get_template_directory_uri() . '/js/jquery.cookie.js', true );
    wp_register_script( 'mts_ajax', get_template_directory_uri() . '/js/ajax.js', true );
    if( ! empty( $mts_options['mts_pagenavigation_type'] ) && $mts_options['mts_pagenavigation_type'] >= 2 && !is_singular('post') ) {
        wp_enqueue_script( 'mts_ajax' );
        
        wp_register_script( 'historyjs', get_template_directory_uri() . '/js/history.js', true );
        wp_enqueue_script( 'historyjs' );
        
        // Add parameters for the JS
        global $wp_query;
        $max = $wp_query->max_num_pages;
        $paged = ( get_query_var( 'paged' ) > 1 ) ? get_query_var( 'paged' ) : 1;
        $autoload = ( $mts_options['mts_pagenavigation_type'] == 3 );
        wp_localize_script(
            'mts_ajax',
            'mts_ajax_loadposts',
            array(
                'startPage' => $paged,
                'maxPages' => $max,
                'nextLink' => next_posts( $max, false ),
                'autoLoad' => $autoload,
                'i18n_loadmore' => __( 'Load More Posts', 'mythemeshop' ),
                'i18n_nomore' => __( 'No more posts', 'mythemeshop' ),
                'i18n_loading' => __( 'Loading posts...', 'mythemeshop' )
             )
        );
    }
    if ( ! empty( $mts_options['mts_ajax_search'] ) ) {
        wp_enqueue_script( 'mts_ajax' );
        wp_localize_script(
            'mts_ajax',
            'mts_ajax_search',
            array(
                'url' => admin_url( 'admin-ajax.php' ),
                'ajax_search' => '1'
             )
        );
    }

    if ( mts_isWooCommerce() && isset( $mts_options['mts_wishlist'] ) && !empty( $mts_options['mts_wishlist'] ) ) {
        wp_enqueue_script( 'mts_cookie' );
        wp_enqueue_script( 'mts_ajax' );
        wp_localize_script(
            'mts_ajax',
            'mts_ajax_wishlist',
            array(
                'url' => admin_url( 'admin-ajax.php' ),
            )
        );
    }
    
}  
add_action( 'wp_footer', 'mts_load_footer_scripts' );

if( !empty( $mts_options['mts_ajax_search'] )) {
    add_action( 'wp_ajax_mts_search', 'ajax_mts_search' );
    add_action( 'wp_ajax_nopriv_mts_search', 'ajax_mts_search' );
}

/*-----------------------------------------------------------------------------------*/
/* Enqueue CSS
/*-----------------------------------------------------------------------------------*/
function mts_enqueue_css() {
    $mts_options = get_option( MTS_THEME_NAME );

    // Slider
    wp_register_style( 'flexslider', get_template_directory_uri() . '/css/flexslider.css', 'style' );
    if ( ( ! empty( $mts_options['mts_featured_slider'] ) && ! is_singular() ) || ( mts_isWooCommerce() && is_product() ) ) {
        wp_enqueue_style( 'flexslider' );
    }
    // also enqueued in slider widget

    wp_register_style( 'owlcarousel', get_template_directory_uri() . '/css/owl.carousel.css', 'style' );
    wp_enqueue_style( 'owlcarousel' );
    
    // Lightbox
    if ( ! empty( $mts_options['mts_lightbox'] ) ) {
        wp_register_style( 'prettyPhoto', get_template_directory_uri() . '/css/prettyPhoto.css', 'style' );
        wp_enqueue_style( 'prettyPhoto' );
    }
    
    //Font Awesome
    wp_register_style( 'fontawesome', get_template_directory_uri() . '/css/font-awesome.min.css', 'style' );
    wp_enqueue_style( 'fontawesome' );
    
    wp_enqueue_style( 'stylesheet', get_stylesheet_directory_uri() . '/style.css', 'style' );

    // WooCommerce
    if ( mts_isWooCommerce() ) {
        wp_enqueue_style( 'woocommerce', get_template_directory_uri() . '/css/woocommerce.css' );
    }
    
    //Responsive
    wp_enqueue_style( 'responsive', get_template_directory_uri() . '/css/responsive.css', 'style' );
    
    $mts_header_bg = '';
    if ($mts_options['mts_header_bg_pattern_upload'] != '') {
        $mts_header_bg = $mts_options['mts_header_bg_pattern_upload'];
    } else {
        if($mts_options['mts_header_bg_pattern'] != '') {
            $mts_header_bg = get_template_directory_uri().'/images/'.$mts_options['mts_header_bg_pattern'].'.png';
        }
    }
    $mts_header_nav_bg = '';
    if ($mts_options['mts_header_nav_bg_pattern_upload'] != '') {
        $mts_header_nav_bg = $mts_options['mts_header_nav_bg_pattern_upload'];
    } else {
        if($mts_options['mts_header_nav_bg_pattern'] != '') {
            $mts_header_nav_bg = get_template_directory_uri().'/images/'.$mts_options['mts_header_nav_bg_pattern'].'.png';
        }
    }
    
    $mts_bg = '';
    if ($mts_options['mts_bg_pattern_upload'] != '') {
        $mts_bg = $mts_options['mts_bg_pattern_upload'];
    } else {
        if(!empty($mts_options['mts_bg_pattern'])) {
            $mts_bg = get_template_directory_uri().'/images/'.$mts_options['mts_bg_pattern'].'.png';
        }
    }

    $mts_footer_bg = '';
    if ($mts_options['mts_footer_bg_pattern_upload'] != '') {
        $mts_footer_bg = $mts_options['mts_footer_bg_pattern_upload'];
    } else {
        if($mts_options['mts_footer_bg_pattern'] != '') {
            $mts_footer_bg = get_template_directory_uri().'/images/'.$mts_options['mts_footer_bg_pattern'].'.png';
        }
    }

    $mts_sclayout = '';
    $mts_catalog_sclayout = '';
    $mts_shareit_left = '';
    $mts_shareit_right = '';
    $mts_author = '';
    $mts_header_section = '';
    if ( is_page() || is_single() ) {
        $mts_sidebar_location = get_post_meta( get_the_ID(), '_mts_sidebar_location', true );
    } else {
        $mts_sidebar_location = '';
    }
    if ( $mts_sidebar_location != 'right' && ( $mts_options['mts_layout'] == 'sclayout' || $mts_sidebar_location == 'left' )) {
        $mts_sclayout = '.article { float: right;}
        .sidebar.c-4-12 { float: left; padding-right: 0; }';
    }
    if($mts_options['mts_catalog_layout'] == 'sclayout') {
        $mts_catalog_sclayout = '.archive.woocommerce-page .article { float: right; } .archive.woocommerce-page .sidebar.c-4-12 { float: left; padding-right: 0; }';
    }
    if ( $mts_sidebar_location != 'right' && ( $mts_options['mts_layout'] == 'sclayout' || $mts_sidebar_location == 'left' )) {
        $mts_sclayout = '.article { float: right;}
        .sidebar.c-4-12 { float: left; padding-right: 0; }';
        if( isset( $mts_options['mts_social_button_position'] ) && $mts_options['mts_social_button_position'] == 'floating' ) {
            $mts_shareit_right = '.shareit { margin: 0 810px 0; border-left: 0; }';
        }
    }
    if ( empty( $mts_options['mts_header_section2'] ) ) {
        $mts_header_section = '.logo-wrap { display: none; }.header-left-wrap, .header-right-wrap { width: 50%; } .header-inner { padding: 10px 20px;}';
    }
    if ( ! empty( $mts_options['mts_author_comment'] ) ) {
        $mts_author = '.bypostauthor {padding: 3%!important; background: #FAFAFA; width: 94%!important;}
        .bypostauthor:after { content: "'.__( 'Author', 'mythemeshop' ).'"; position: absolute; right: -1px; top: -1px; padding: 1px 10px; background: #818181; color: #FFF; }';
    }
    if ( isset( $mts_options['mts_social_button_position'] ) && $mts_options['mts_social_button_position'] == 'floating' ) {
        $mts_shareit_left = '.shareit { top: 310px; left: auto; z-index: 0; margin: 0 0 0 -100px; width: 90px; position: fixed; overflow: hidden; padding: 5px; border:none; border-right: 0;}
        .share-item {margin: 2px;}';
    }
    $custom_css = "
        body {background-color:{$mts_options['mts_bg_color']}; background-image: url( {$mts_bg} );}
        .main-header {background-color:{$mts_options['mts_header_bg_color']}; background-image: url({$mts_header_bg});}
        #homepage-slider-controls .flex-active-slide:after { border-color: {$mts_options['mts_header_bg_color']} rgba(0, 0, 0, 0); }
        #navigation, #navigation ul ul, .header-search #s, .header-search .ajax-search-results-container, .wpmm-megamenu-container {background-color:{$mts_options['mts_header_nav_bg_color']}; background-image: url({$mts_header_nav_bg});}
        footer {background-color:{$mts_options['mts_footer_bg_color']}; background-image: url({$mts_footer_bg});}
        
        .pace .pace-progress, .to-top i, .tagcloud a, #commentform input#submit, .contact-form input[type='submit'], .pagination ul li a:focus, .pagination ul li a:hover, .pagination ul li span.current, .pagination ul li span.currenttext, #load-posts a:hover, #load-posts a.loading, #respond input#submit, a.button, button.button, input.button, .product-data a.button:hover, .product-data .mts-add-to-wishlist:hover, .product-data a.button.mts-add-to-wishlist.added, .product-data a.button.mts-add-to-wishlist.loading, .product-data a.button.compare.added, .product-data a.button.compare.loading, .product-data a.button.add_to_cart_button.loading, .product-data a.button.add_to_cart_button.added, .mts-cart-content-footer a.button.mts-cart-button:hover, .woocommerce table.cart a.remove:hover, .mts-cart-product a.remove:hover, ul#checkout-progress li.active span.step, #searchform #searchsubmit, .mts-subscribe input[type='submit'], #product-img-nav .flex-direction-nav a:hover, #product-img-nav .lightbox-icon:hover, .carousel-controls .owl-dot span, .toggle-menu .toggle-caret:hover .fa, .woocommerce .widget_layered_nav > ul.mts-ajax-filter-type-label > li a, .pagination ul li a, .pagination ul li span {
            background: {$mts_options['mts_color_scheme']}; }

        #mobile-menu-wrapper, #mobile-menu-wrapper #navigation ul li a, #mobile-menu-wrapper #navigation a#pull, .flex-control-paging li a:hover, .flex-control-paging li a.flex-active { background: {$mts_options['mts_color_scheme']} !important }

        #header h1, #header h2, .breadcrumb a, .message-big.completed .shopping-cart-stack .fa.shopping-cart-stack-base, .woocommerce div.product div.summary .mts-add-to-wishlist:hover,.woocommerce div.product div.summary .mts-add-to-wishlist.added, .woocommerce div.product div.summary a.compare:hover, .woocommerce div.product div.summary a.compare.added, .woocommerce div.product div.summary a.share-link:hover, .woocommerce div.product div.summary a.share-link.active, .woocommerce .product-data a.button, .product-data .mts-add-to-wishlist, .woocommerce .quantity .minus, .woocommerce .quantity .plus, .woocommerce table.cart a.remove, .mts-cart-product a.remove, .woocommerce .widget_price_filter .ui-slider .ui-slider-handle:before, .mts-cart-button .fa-shopping-cart, .mts-cart-content-footer a.button.mts-cart-button, .flex-direction-nav a, #product-img-nav .lightbox-icon, .carousel-controls .owl-buttons div, .wishlist_table tr td.product-stock-status span.wishlist-in-stock, .post-single-content a, .textwidget a { color: {$mts_options['mts_color_scheme']}; }

        #navigation ul.menu a, #navigation, ul#checkout-progress li.active span.step, .product-wrap:hover, .wpmm-post:hover .wpmm-thumbnail, #product-img-slider:hover, #product-img-nav .slides li:hover, #product-img-nav .slides li.flex-active-slide, .widget-slider:hover {
            border-color: {$mts_options['mts_color_scheme']}; }

        #navigation ul.menu > li:hover > a, #navigation ul.menu > li.current-menu-item > a {     color: {$mts_options['mts_color_scheme2']}!important;
            border-top-color: {$mts_options['mts_color_scheme2']};
        }

        .wpmm-megamenu-container {border-top-color: {$mts_options['mts_color_scheme2']};}

        .tagcloud a:hover, #commentform input#submit:hover, .contactform #submit:hover, .mts-subscribe input[type='submit']:hover, p.demo_store, .woocommerce .products .product .ribbon, .woocommerce span.ribbon, .products .product span.ribbon, #respond input#submit:hover, a.button:hover, button.button:hover, input.button:hover, #respond input#submit:active, a.button:active, button.button:active, input.button:active, #searchform #searchsubmit:hover { background: {$mts_options['mts_color_scheme2']}; }

        #mobile-menu-wrapper #navigation ul li a:hover, #mobile-menu-wrapper #navigation ul li a:active, #mobile-menu-wrapper #navigation .current_menu_item > a, #mobile-menu-wrapper #navigation .current_page_item > a, .woocommerce .widget_layered_nav > ul.mts-ajax-filter-type-label > li a:hover, .woocommerce .widget_layered_nav > ul.mts-ajax-filter-type-label > li.chosen a { background: {$mts_options['mts_color_scheme2']} !important } 

        #navigation ul ul, .header-search #s { border-color:  {$mts_options['mts_color_scheme2']}; }

        a:hover, #navigation ul ul a:hover, .header-search .fa-search.active, .header-search .ajax-search-box-open #s, .readMore a, #cancel-comment-reply-link, .fn a, .comment-meta a, .order-total .amount, .product_list_widget .amount, .product_list_widget del .amount, .shop_table .product-subtotal .amount, .mts-cart-total .amount, .woocommerce div.product p.price, .woocommerce div.product span.price, .woocommerce .products .product .price, .woocommerce .star-rating, .woocommerce .widget_layered_nav ul li.chosen a:after, .woocommerce .widget_layered_nav_filters ul li a:after, .wishlist_table tr td.product-stock-status span.wishlist-out-of-stock, .widget .menu li a:hover, .widget .menu li.current-menu-item a, .widget .current-cat a, .widget .current_page_item a { color: {$mts_options['mts_color_scheme2']}; }

        {$mts_sclayout}
        {$mts_catalog_sclayout}
        {$mts_shareit_left}
        {$mts_shareit_right}
        {$mts_author}
        {$mts_header_section}
        {$mts_options['mts_custom_css']}
        ";

    $inline_style_target = 'stylesheet';
    if ( wp_style_is( 'woocommerce', 'enqueued' ) ) { $inline_style_target = 'woocommerce'; }

    wp_add_inline_style( $inline_style_target, $custom_css );
}
add_action( 'wp_enqueue_scripts', 'mts_enqueue_css', 99 );

/*-----------------------------------------------------------------------------------*/
/*  Wrap videos in .responsive-video div
/*-----------------------------------------------------------------------------------*/
function mts_responsive_video( $data ) {
    return '<div class="flex-video">' . $data . '</div>';
}
add_filter( 'embed_oembed_html', 'mts_responsive_video' );

/*-----------------------------------------------------------------------------------*/
/*  Filters that allow shortcodes in Text Widgets
/*-----------------------------------------------------------------------------------*/
add_filter( 'widget_text', 'shortcode_unautop' );
add_filter( 'widget_text', 'do_shortcode' );
add_filter( 'the_content_rss', 'do_shortcode' );

/*-----------------------------------------------------------------------------------*/
/*  Custom Comments template
/*-----------------------------------------------------------------------------------*/
function mts_comments( $comment, $args, $depth ) {
    $GLOBALS['comment'] = $comment; 
    $mts_options = get_option( MTS_THEME_NAME ); ?>
    <li <?php comment_class(); ?> id="li-comment-<?php comment_ID() ?>">
        <div id="comment-<?php comment_ID(); ?>" itemprop="comment" itemscope itemtype="http://schema.org/UserComments">
            <div class="comment-author vcard">
                <?php echo get_avatar( $comment->comment_author_email, 50 ); ?>
                <?php printf( '<span class="fn" itemprop="creator" itemscope itemtype="http://schema.org/Person"><span itemprop="name">%s</span></span>', get_comment_author_link() ) ?> 
                <?php if ( ! empty( $mts_options['mts_comment_date'] ) ) { ?>
                    <span class="ago"><?php comment_date( get_option( 'date_format' ) ); ?></span>
                <?php } ?>
                <span class="comment-meta">
                    <?php edit_comment_link( __( '( Edit )', 'mythemeshop' ), '  ', '' ) ?>
                </span>
            </div>
            <?php if ( $comment->comment_approved == '0' ) : ?>
                <em><?php _e( 'Your comment is awaiting moderation.', 'mythemeshop' ) ?></em>
                <br />
            <?php endif; ?>
            <div class="commentmetadata">
                <div class="commenttext" itemprop="commentText">
                    <?php comment_text() ?>
                </div>
                <div class="reply">
                    <?php comment_reply_link( array_merge( $args, array( 'depth' => $depth, 'max_depth' => $args['max_depth'] )) ) ?>
                </div>
            </div>
        </div>
    </li>
<?php }

/*-----------------------------------------------------------------------------------*/
/*  Excerpt
/*-----------------------------------------------------------------------------------*/

// Increase max length
function mts_excerpt_length( $length ) {
    return 100;
}
add_filter( 'excerpt_length', 'mts_excerpt_length', 20 );

// Remove [...] and shortcodes
function mts_custom_excerpt( $output ) {
  return preg_replace( '/\[[^\]]*]/', '', $output );
}
add_filter( 'get_the_excerpt', 'mts_custom_excerpt' );

// Truncate string to x letters/words
function mts_truncate( $str, $length = 40, $units = 'letters', $ellipsis = '&nbsp;&hellip;' ) {
    if ( $units == 'letters' ) {
        if ( mb_strlen( $str ) > $length ) {
            return mb_substr( $str, 0, $length ) . $ellipsis;
        } else {
            return $str;
        }
    } else {
        $words = explode( ' ', $str );
        if ( count( $words ) > $length ) {
            return implode( " ", array_slice( $words, 0, $length ) ) . $ellipsis;
        } else {
            return $str;
        }
    }
}

if ( ! function_exists( 'mts_excerpt' ) ) {
    function mts_excerpt( $limit = 40 ) {
      return mts_truncate( get_the_excerpt(), $limit, 'words' );
    }
}

/*-----------------------------------------------------------------------------------*/
/*  Remove more link from the_content and use custom read more
/*-----------------------------------------------------------------------------------*/
add_filter( 'the_content_more_link', 'mts_remove_more_link', 10, 2 );
function mts_remove_more_link( $more_link, $more_link_text ) {
    return '';
}
// shorthand function to check for more tag in post
function mts_post_has_moretag() {
    global $post;
    return strpos( $post->post_content, '<!--more-->' );
}

if ( ! function_exists( 'mts_readmore' ) ) {
    function mts_readmore() {
        ?>
        <div class="readMore">
            <div class="reply">
                <a class="button" href="<?php the_permalink(); ?>"><?php _e("Read more","mythemetop"); ?></a>
            </div>
        </div>
        <?php 
    }
}

/*-----------------------------------------------------------------------------------*/
/* nofollow to next/previous links
/*-----------------------------------------------------------------------------------*/
function mts_pagination_add_nofollow( $content ) {
    return 'rel="nofollow"';
}
add_filter( 'next_posts_link_attributes', 'mts_pagination_add_nofollow' );
add_filter( 'previous_posts_link_attributes', 'mts_pagination_add_nofollow' );

/*-----------------------------------------------------------------------------------*/
/* Nofollow to category links
/*-----------------------------------------------------------------------------------*/
add_filter( 'the_category', 'mts_add_nofollow_cat' ); 
function mts_add_nofollow_cat( $text ) {
    $text = str_replace( 'rel="category tag"', 'rel="nofollow"', $text ); return $text;
}

/*-----------------------------------------------------------------------------------*/ 
/* nofollow post author link
/*-----------------------------------------------------------------------------------*/
add_filter( 'the_author_posts_link', 'mts_nofollow_the_author_posts_link' );
function mts_nofollow_the_author_posts_link ( $link ) {
    return str_replace( '<a href=', '<a rel="nofollow" href=', $link ); 
}

/*-----------------------------------------------------------------------------------*/ 
/* nofollow to reply links
/*-----------------------------------------------------------------------------------*/
function mts_add_nofollow_to_reply_link( $link ) {
    return str_replace( '" )\'>', '" )\' rel=\'nofollow\'>', $link );
}
add_filter( 'comment_reply_link', 'mts_add_nofollow_to_reply_link' );

/*-----------------------------------------------------------------------------------*/
/* removes the WordPress version from your header for security
/*-----------------------------------------------------------------------------------*/
function mts_remove_wpversion() {
    return '<!--Theme by MyThemeShop.com-->';
}
add_filter( 'the_generator', 'mts_remove_wpversion' );
    
/*-----------------------------------------------------------------------------------*/
/* Removes Trackbacks from the comment count
/*-----------------------------------------------------------------------------------*/
add_filter( 'get_comments_number', 'mts_comment_count', 0 );
function mts_comment_count( $count ) {
    if ( ! is_admin() ) {
        global $id;
        // Gettin' warning on php 5
        //$comments_by_type = &separate_comments(get_comments('status=approve&post_id=' . $id));
        $comments = get_comments('status=approve&post_id=' . $id);
        $comments_by_type = separate_comments($comments);
        return count($comments_by_type['comment']);
    } else {
        return $count;
    }
}

/*-----------------------------------------------------------------------------------*/
/* adds a class to the post if there is a thumbnail
/*-----------------------------------------------------------------------------------*/
function has_thumb_class( $classes ) {
    global $post;
    if( has_post_thumbnail( $post->ID ) ) { $classes[] = 'has_thumb'; }
        return $classes;
}
add_filter( 'post_class', 'has_thumb_class' );

/*-----------------------------------------------------------------------------------*/
/*  Site Title backwards compatibility
/*-----------------------------------------------------------------------------------*/
add_theme_support( 'title-tag' );
if ( ! function_exists( '_wp_render_title_tag' ) ) {
    function theme_slug_render_title() { ?>
       <title><?php wp_title( '|', true, 'right' ); ?></title>
   <?php }
    add_action( 'wp_head', 'theme_slug_render_title' );
}

/*-----------------------------------------------------------------------------------*/ 
/* AJAX Search results
/*-----------------------------------------------------------------------------------*/
function ajax_mts_search() {
    $query = $_REQUEST['q']; // It goes through esc_sql() in WP_Query
    $search_query = new WP_Query( array( 's' => $query, 'posts_per_page' => 3 )); 
    $search_count = new WP_Query( array( 's' => $query, 'posts_per_page' => -1 ));
    $search_count = $search_count->post_count;
    if ( !empty( $query ) && $search_query->have_posts() ) : 
        //echo '<h5>Results for: '. $query.'</h5>';
        echo '<ul class="ajax-search-results clearfix">';
        while ( $search_query->have_posts() ) : $search_query->the_post();
            ?><li>
                <a href="<?php the_permalink(); ?>">
                    <?php the_post_thumbnail( 'widgetthumb', array( 'title' => '' )); ?>
                    <?php the_title(); ?>   
                </a>
            </li>   
            <?php
        endwhile;
        echo '</ul>';
        echo '<div class="ajax-search-meta"><span class="results-count">'.$search_count.' '.__( 'Results', 'mythemeshop' ).'</span><a href="'.get_search_link( $query ).'" class="results-link">Show all results</a></div>';
    else:
        echo '<div class="no-results">'.__( 'No results found.', 'mythemeshop' ).'</div>';
    endif;
        
    exit; // required for AJAX in WP
}
/*-----------------------------------------------------------------------------------*/
/* Redirect feed to feedburner
/*-----------------------------------------------------------------------------------*/

if ( $mts_options['mts_feedburner'] != '' ) {
function mts_rss_feed_redirect() {
    $mts_options = get_option( MTS_THEME_NAME );
    global $feed;
    $new_feed = $mts_options['mts_feedburner'];
    if ( !is_feed() ) {
            return;
    }
    if ( preg_match( '/feedburner/i', $_SERVER['HTTP_USER_AGENT'] )){
            return;
    }
    if ( $feed != 'comments-rss2' ) {
            if ( function_exists( 'status_header' )) status_header( 302 );
            header( "Location:" . $new_feed );
            header( "HTTP/1.1 302 Temporary Redirect" );
            exit();
    }
}
add_action( 'template_redirect', 'mts_rss_feed_redirect' );
}

/*-----------------------------------------------------------------------------------*/
/* Single Post Pagination - Numbers + Previous/Next
/*-----------------------------------------------------------------------------------*/
function mts_wp_link_pages_args( $args ) {
    global $page, $numpages, $more, $pagenow;
    if ( !$args['next_or_number'] == 'next_and_number' )
        return $args; 
    $args['next_or_number'] = 'number'; 
    if ( !$more )
        return $args; 
    if( $page-1 ) 
        $args['before'] .= _wp_link_page( $page-1 )
        . $args['link_before']. $args['previouspagelink'] . $args['link_after'] . '</a>'
    ;
    if ( $page<$numpages ) 
    
        $args['after'] = _wp_link_page( $page+1 )
        . $args['link_before'] . $args['nextpagelink'] . $args['link_after'] . '</a>'
        . $args['after']
    ;
    return $args;
}
add_filter( 'wp_link_pages_args', 'mts_wp_link_pages_args' );

/*-----------------------------------------------------------------------------------*/
/* WooCommerce
/*-----------------------------------------------------------------------------------*/
if ( mts_isWooCommerce() ) {
    
    add_theme_support( 'woocommerce' );

    // Disable default woocommerce styles
    add_filter( 'woocommerce_enqueue_styles', '__return_false' );

    // Redefine woocommerce_output_related_products()
    function woocommerce_output_related_products() {
        $mts_options = get_option( MTS_THEME_NAME );
        $args = array(
            'posts_per_page' => $mts_options['mts_related_products_num'],
        );
        woocommerce_related_products($args);
    }
    
    /*** Hook in on activation */
    global $pagenow;
    if ( is_admin() && isset( $_GET['activated'] ) && $pagenow == 'themes.php' ) add_action( 'init', 'mythemeshop_woocommerce_image_dimensions', 1 );
     
    /*** Define image sizes */
    function mythemeshop_woocommerce_image_dimensions() {
        $catalog = array(
            'width'     => '254',   // px
            'height'    => '402',   // px
            'crop'      => 1        // true
         );
        $single = array(
            'width'     => '440',   // px
            'height'    => '520',   // px
            'crop'      => 1        // true
         );
        $thumbnail = array(
            'width'     => '93',    // px
            'height'    => '93',    // px
            'crop'      => 1        // false
         ); 
        // Image sizes
        update_option( 'shop_catalog_image_size', $catalog );       // Product category thumbs
        update_option( 'shop_single_image_size', $single );         // Single product image
        update_option( 'shop_thumbnail_image_size', $thumbnail );   // Image gallery thumbs
    }
    
    add_filter( 'loop_shop_per_page', 'mts_products_per_page', 20 );
    function mts_products_per_page() {
        $mts_options = get_option( MTS_THEME_NAME );
        return $mts_options['mts_shop_products'];
    }

    // Ensure cart contents update when products are added to the cart via AJAX
    add_filter( 'add_to_cart_fragments', 'mts_header_add_to_cart_fragment' );
    function mts_header_add_to_cart_fragment( $fragments ) {

        global $woocommerce;

        ob_start();

        $cart_contents_count = $woocommerce->cart->cart_contents_count;
        ?>
        
        <div class="mts-cart-button-wrap">
            <a href="<?php echo $woocommerce->cart->get_cart_url(); ?>" class="mts-cart-button cart-contents">
                <i class="fa fa-shopping-cart"></i><?php echo __( 'Cart (', 'mythemeshop') . $cart_contents_count . ')'; ?><i class="fa dropdown-caret"></i>
            </a>
            <div class="mts-cart-content">
            <?php if ( $cart_contents_count != '0' ) { ?>
                <div class="mts-cart-content-body">
                <?php
                foreach ( $woocommerce->cart->cart_contents as $cart_item_key => $cart_item ) {
                
                    $cart_item_data = $cart_item['data'];
                                                               
                    if ( $cart_item_data->exists() && $cart_item['quantity'] > 0 ) {

                        $product_title     = $cart_item_data->get_title();
                        $product_permalink = get_permalink( $cart_item['product_id'] );
                        ?>

                        <div class="mts-cart-product clearfix">
                            <a class="mts-cart-product-image" href="<?php echo $product_permalink; ?>"><?php echo $cart_item_data->get_image(); ?></a>
                            <?php echo apply_filters( 'woocommerce_cart_item_remove_link', sprintf( '<a href="%s" class="remove" title="%s">&times;</a>', esc_url( $woocommerce->cart->get_remove_url( $cart_item_key ) ), __( 'Remove this item', 'woocommerce' ) ), $cart_item_key ); ?>
                            <div class="mts-cart-product-data">
                                <div class="mts-cart-product-title">
                                    <a href="<?php echo $product_permalink; ?>"><?php echo $product_title; ?></a>
                                </div>
                                <div class="mts-cart-product-price">
                                    <?php echo woocommerce_price( $cart_item_data->get_price() ); ?>
                                    <?php if ( $cart_item['quantity'] > 1 ) echo ' &times; ' . $cart_item['quantity']; ?>
                                </div>
                                
                            </div>
                        </div>
                <?php
                    }
                }
                ?>
                </div>
                <div class="mts-cart-content-footer clearfix">
                    <span class="mts-cart-total"><?php _e( 'Total:', 'mythemeshop' ); ?> <?php echo $woocommerce->cart->get_cart_total(); ?></span>
                    <a href="<?php echo esc_url( $woocommerce->cart->get_checkout_url() ) ?>" class="button mts-cart-button"><?php _e( 'Checkout', 'mythemeshop' ); ?></a>
                </div>
            <?php } else { ?>
                <div class="mts-cart-content-footer clearfix">
                    <span class="mts-cart-total"><?php _e( 'Total:', 'mythemeshop' ); ?> <?php echo $woocommerce->cart->get_cart_total(); ?></span>
                    <a href="<?php echo get_permalink( wc_get_page_id( 'shop' ) ); ?>" class="button mts-cart-button"><?php _e( 'Go to Shop', 'mythemeshop' ); ?></a>
                </div>
            <?php } ?>
            </div>
        </div>
        
        <?php

        $fragments['.mts-cart-button-wrap'] = ob_get_clean();

        return $fragments;
    }

    add_action( 'init', 'mts_custom_wc_placeholder' );
 
    function mts_custom_wc_placeholder() {
      add_filter('woocommerce_placeholder_img_src', 'mts_woocommerce_placeholder_img_src');
       
        function mts_woocommerce_placeholder_img_src() {
             
            return get_template_directory_uri().'/images/nothumb-shop.png';
        }
    }

    // Add product category image to products archives
    add_action( 'woocommerce_before_main_content', 'mts_product_category_image', 2 );
    function mts_product_category_image() {
        if ( is_product_category() ){
            global $wp_query;
            $cat = $wp_query->get_queried_object();
            $thumbnail_id = get_woocommerce_term_meta( $cat->term_id, 'thumbnail_id', true );
            $image = wp_get_attachment_url( $thumbnail_id );
            if ( $image ) {
                echo '<div class="product-category-image">' . wp_get_attachment_image( $thumbnail_id, 'emaxcontent', false, array('title' => '')) . '</div>';
            }
        }
    }

    // Display wider image on first item in homepage carousels
    function woocommerce_template_loop_product_thumbnail() {

        global $woocommerce_loop, $wide_first_thumb;

        if ( is_home() && 0 == ( $woocommerce_loop['loop'] - 1 ) && $wide_first_thumb ) {
            if ( has_post_thumbnail() ) {
                echo woocommerce_get_product_thumbnail('emaxcarouselwide');
            } else {
                echo '<img src="'.get_template_directory_uri().'/images/nothumb-emaxcarouselwide.png" />';
            }
        } else {
            echo woocommerce_get_product_thumbnail();
        } 
    }

    // Remove WooCommerce breadcrumb from default place, it's called within mts_the_breadcrumb() and placed in the header.php
    remove_action( 'woocommerce_before_main_content', 'woocommerce_breadcrumb', 20);

    // Customize WooCommerce breadcrumb defaults
    add_filter('woocommerce_breadcrumb_defaults', 'mts_wc_breadcrumb_defaults');
    function mts_wc_breadcrumb_defaults() {
        $defaults = array(
            'delimiter'   => '<span class="delimiter fa fa-angle-right"></span>',
            'wrap_before' => '',
            'wrap_after'  => '',
            'before'      => '<span typeof="v:Breadcrumb"><span property="v:title">',
            'after'       => '</span></span>',
            'home'        => _x( 'Home', 'breadcrumb', 'mythemeshop' ),
        );

        return $defaults;
    }

    // Remove "add to cart" button from default location in shop archives, it's called from "woocommerce/content-product.php" instead
    remove_action( 'woocommerce_after_shop_loop_item', 'woocommerce_template_loop_add_to_cart', 10);
    // Remove product ordering form from default location in shop archives, it's called from "woocommerce/archive-product.php" instead
    remove_action( 'woocommerce_before_shop_loop', 'woocommerce_catalog_ordering', 30 );

    // Remove "related products" from default location in single product view, and display them before footer instead
    remove_action( 'woocommerce_after_single_product_summary', 'woocommerce_output_related_products', 20 );
    add_action( 'mts_before_product_footer', 'mts_product_related_products', 10 );
    function mts_product_related_products() {
        $mts_options = get_option( MTS_THEME_NAME );
        if ( $mts_options['mts_related_products'] == '1' ) {
            woocommerce_output_related_products();
        }
    }

    // Add woocomerce class to body on homepage
    add_filter( 'body_class', 'emax_body_classes' );
    function emax_body_classes( $classes ) {

        if ( is_home() ) {
            $classes[] = 'woocommerce';
        }

        return $classes;
    }

    // Display the "new" badge
    if ( $mts_options['mts_mark_new_products'] ) {
        add_action( 'woocommerce_before_shop_loop_item_title', 'mts_show_product_loop_new_badge', 30 );
    }
    function mts_show_product_loop_new_badge() {

        $mts_options   = get_option( MTS_THEME_NAME );
        $postdate      = get_the_time( 'Y-m-d' );
        $postdatestamp = strtotime( $postdate );
        $newness       = $mts_options['mts_new_products_time'];

        // If the product was published within the newness time frame display the new badge
        if ( ( time() - ( 60 * 60 * 24 * $newness ) ) < $postdatestamp ) {

            echo '<span class="new-badge ribbon">' . __( 'New', 'mythemeshop' ) . '</span>';
        }
    }

    // Featured Products
    // before single page footer
    add_action( 'mts_before_single_page_footer', 'mts_page_featured_products', 10 );
    function mts_page_featured_products() {

        $mts_options = get_option( MTS_THEME_NAME );
        $show_featured_products = false;

        if ( $mts_options['mts_featured_products'] == '1' ) {

            if ( is_order_received_page() && isset( $mts_options['mts_featured_products_locations']['thankyou'] ) ) { // order completed

                $show_featured_products = true;

            } elseif ( !is_order_received_page() && is_checkout() && isset( $mts_options['mts_featured_products_locations']['checkout'] ) ) { // checkout
 
                $show_featured_products = true;

            } elseif ( is_cart() && isset( $mts_options['mts_featured_products_locations']['cart'] ) ) { // cart

                $show_featured_products = true;
            }
        }

        if ( $show_featured_products ) {

            wc_get_template( 'featured-products.php' );
        }
    }
    // before single product footer
    add_action( 'mts_before_product_footer', 'mts_product_featured_products', 20 );
    function mts_product_featured_products() {
        $mts_options = get_option( MTS_THEME_NAME );
        if ( $mts_options['mts_featured_products'] == '1' && isset( $mts_options['mts_featured_products_locations']['product'] ) ) {
            wc_get_template( 'featured-products.php' );
        }
    }

    // Checkout
    remove_action( 'woocommerce_before_checkout_form', 'woocommerce_checkout_login_form', 10 );
    add_action( 'woocommerce_before_checkout_form', 'woocommerce_checkout_login_form', 11 );

    // Disable headings in product tabs
    add_filter( 'woocommerce_product_description_heading', '__return_false' );
    add_filter( 'woocommerce_product_additional_information_heading', '__return_false' );

    // Replace default woocommerce_default_product_tabs function ( just to mark review count )
    function woocommerce_default_product_tabs( $tabs = array() ) {
        global $product, $post;

        // Description tab - shows product content
        if ( $post->post_content ) {
            $tabs['description'] = array(
                'title'    => __( 'Description', 'woocommerce' ),
                'priority' => 10,
                'callback' => 'woocommerce_product_description_tab'
            );
        }

        // Additional information tab - shows attributes
        if ( $product && ( $product->has_attributes() || ( $product->enable_dimensions_display() && ( $product->has_dimensions() || $product->has_weight() ) ) ) ) {
            $tabs['additional_information'] = array(
                'title'    => __( 'Additional Information', 'woocommerce' ),
                'priority' => 20,
                'callback' => 'woocommerce_product_additional_information_tab'
            );
        }

        // Reviews tab - shows comments
        if ( comments_open() ) {
            $tabs['reviews'] = array(
                'title'    => sprintf( __( 'Reviews <mark>%d</mark>', 'mythemeshop' ), get_comments_number( $post->ID ) ),
                'priority' => 30,
                'callback' => 'comments_template'
            );
        }

        return $tabs;
    }

    /**
     * Output placeholders for the single variation.
     */
    function woocommerce_single_variation() {
        echo '<div class="single_variation clear"></div>';
    }

    /**
     * Output the add to cart button for variations.
     */
    function woocommerce_single_variation_add_to_cart_button() {
        global $product;
        ?>
        <div class="variations_button">
            <div class="single_quantity_label"><?php _e( 'Quantity:', 'mythemeshop' ); ?></div>
            <?php woocommerce_quantity_input( array( 'input_value' => isset( $_POST['quantity'] ) ? wc_stock_amount( $_POST['quantity'] ) : 1 ) ); ?>
            <button type="submit" class="single_add_to_cart_button button alt"><?php echo $product->single_add_to_cart_text(); ?></button>
            <input type="hidden" name="add-to-cart" value="<?php echo absint( $product->id ); ?>" />
            <input type="hidden" name="product_id" value="<?php echo absint( $product->id ); ?>" />
            <input type="hidden" name="variation_id" class="variation_id" value="" />
        </div>
        <?php
    }

    // Wishlist
    add_action( 'woocommerce_single_product_summary', 'mts_wc_single_product_bottom_divider', 33 );
    function mts_wc_single_product_bottom_divider() {
        echo '<hr />';
    }

    add_action( 'woocommerce_single_product_summary', 'mts_wc_single_product_wishlist', 34 );
    function mts_wc_single_product_wishlist() {
        echo mts_wishlist_button();
    }

    remove_action( 'woocommerce_single_product_summary', 'woocommerce_template_single_meta', 40 );
    add_action( 'woocommerce_single_product_summary', 'woocommerce_template_single_meta', 31 );

    function mts_get_wishlist_page_url() {
    $wishlist_page = get_page_by_title( 'Wishlist' );
        return get_page_link( $wishlist_page->ID );
    }

    function mts_product_in_wishlist( $id ) {
        $wishlist_items = !empty( $_COOKIE['mts_wishlist'] ) ? explode(',', $_COOKIE['mts_wishlist']) : array();

        return in_array( $id, $wishlist_items );
    }

    add_action('wp_ajax_mts_wishlist_page_loop', 'mts_wishlist_page_loop');
    add_action('wp_ajax_nopriv_mts_wishlist_page_loop', 'mts_wishlist_page_loop');
    function mts_wishlist_page_loop() {
        global $mts_options;
        if ( !isset( $mts_options['mts_wishlist'] ) || empty( $mts_options['mts_wishlist'] ) ) {
            echo '<p>'.__( 'Wishlist feature is disabled', 'mythemeshop' ).'</p>';
            return;
        }

        echo '<table class="shop_table cart mts-wishlist-table" cellspacing="0">';
            echo '<tbody>';
            $wishlist_items = !empty( $_COOKIE['mts_wishlist'] ) ? explode(',', $_COOKIE['mts_wishlist']) : array();
            if ( !empty( $wishlist_items ) ) {
                $args = array(
                    'post_type'           => 'product',
                    'post_status'         => 'publish',
                    'ignore_sticky_posts' => 1,
                    'posts_per_page'      => -1,
                    'post__in'            => $wishlist_items
                );

                $wishlist_query = new WP_Query( apply_filters( 'mts_wishlist_query', $args ) );
                ?>
                <?php
                while ( $wishlist_query->have_posts() ) : $wishlist_query->the_post();
                    global $product;
                    $pr_id = get_the_ID();
                ?>
                        <tr class="mts-wishlist-table-row">
                            <td class="product-remove">
                                <a href="#" data-product-id="<?php echo $pr_id; ?>" class="mts-remove-from-wishlist remove" title="<?php _e( 'Remove this product', 'mythemeshop' ) ?>">&times;</a>
                            </td>
                            <td class="product-thumbnail">
                                <?php
                                    $thumbnail = apply_filters( 'woocommerce_cart_item_thumbnail', $product->get_image() );

                                    if ( ! $product->is_visible() )
                                        echo $thumbnail;
                                    else
                                        printf( '<a href="%s">%s</a>', $product->get_permalink(), $thumbnail );
                                ?>
                            </td>
                            <td class="product-data">
                                <div class="product-name">
                                    <a href="<?php echo esc_url( get_permalink( apply_filters( 'woocommerce_in_cart_product', $pr_id ) ) ) ?>"><?php echo apply_filters( 'woocommerce_in_cartproduct_obj_title', $product->get_title(), $product ) ?></a>
                                </div>
                                <dl>
                                    <dt><?php _e('Unit Price:', 'mythemeshop' ); ?></dt>
                                    <dd>
                                    <?php woocommerce_template_loop_price(); ?>
                                    </dd>
                                </dl>
                            </td>
                            <td class="product-add-to-cart">
                                <?php woocommerce_template_loop_add_to_cart(); ?>
                            </td>
                        </tr>
                <?php
                endwhile; wp_reset_query();

            } else {
                echo '<tr><td colspan="6" class="mts-wishlist-empty">'.__( 'Your wishlist is empty', 'mythemeshop' ).'</td></tr>';
            }
            echo '</tbody>';
        echo '</table>';

        if ( defined( 'DOING_AJAX' ) && DOING_AJAX ) die();
    }

    add_action('wp_ajax_mts_wishlist_count', 'mts_wishlist_count');
    add_action('wp_ajax_nopriv_mts_wishlist_count', 'mts_wishlist_count');
    function mts_wishlist_count() {

        $wishlist_items = !empty( $_COOKIE['mts_wishlist'] ) ? explode(',', $_COOKIE['mts_wishlist']) : array();

        echo '('.count( $wishlist_items ).')';
        
        if ( defined( 'DOING_AJAX' ) && DOING_AJAX ) die();
    }

    // Share
    add_action( 'woocommerce_share', 'single_product_share', 10 );
    function single_product_share() {
        global $mts_options;
        if ( $mts_options['mts_product_social_buttons'] == '1' ) {
            printf( '<a href="#" class="share-link"><i class="fa fa-group"></i>%s</a>', __( 'Share', 'mythemeshop' ) );
            echo '<div class="product-share-buttons">';
                mts_social_buttons();
            echo '</div>';
        }
    }
    
    // Compare
    if ( class_exists( 'YITH_Woocompare' ) ) {
        update_option( 'yith_woocompare_is_button', 'link' );
        global $yith_woocompare;

        // remove compare button from default place on product listings
        if ( $yith_woocompare->is_frontend() ) {
            remove_action( 'woocommerce_after_shop_loop_item', array( $yith_woocompare->obj, 'add_compare_link' ), 20 );
        }
    }

    // Add color picker option to attribute taxonomies edit screens

    $attribute_taxonomies = wc_get_attribute_taxonomies();
    if ( $attribute_taxonomies ) {
        foreach ( $attribute_taxonomies as $tax ) {
            $attribute = sanitize_title( $tax->attribute_name );

            $taxonomy = wc_attribute_taxonomy_name( $attribute );
            
            add_action( $taxonomy.'_add_form_fields', 'mts_attribute_tax_add_form_fields' );
            add_action( $taxonomy.'_edit_form_fields', 'mts_attribute_tax_edit_form_fields', 10, 2 );
        }

        // Handle creating/editing/deleting of color attribute color
        add_action( 'created_term', 'mts_create_update_attribute_tax_color', 10, 3 );
        add_action( 'edited_term', 'mts_create_update_attribute_tax_color', 10, 3 );
        add_action( 'delete_term', 'mts_delete_attribute_tax_color', 10, 3 );

        // Enqueue color picker
        add_action('admin_enqueue_scripts', 'mts_attribute_tax_picker');
    }

    function mts_attribute_tax_add_form_fields() {
        ?>
        <div class="form-field">
            <label for="ps_color_hex_code">
                <?php _e( 'Choose color: ', 'mythemeshop' ); ?>
            </label>
            <input type="text" id="ps_color_hex_code" name="ps_color_hex_code" class="mts-color-picker-field" value="">
        </div>

        <?php
    }
    function mts_attribute_tax_edit_form_fields( $tag, $taxonomy ) {
        // clear value.
        $color_code = '';

        // tag id
        $id = $tag->term_id;

        $opt_array = get_option('mts_tax_color_codes');

        if ( $opt_array && array_key_exists( $taxonomy, $opt_array ) ) {

            if ( array_key_exists( $id, $opt_array[ $taxonomy ] ) ) {

                $color_code = $opt_array[ $taxonomy ][ $id ];
            }
        }
        ?>
        <tr class="form-field">
            <th scope="row" valign="top">
                <label for="ps_color_hex_code"><?php _e( 'Choose color:', 'mythemeshop' ); ?></label>
            </th>
            <td>
                <input type="text" id="ps_color_hex_code" name="ps_color_hex_code"  class="mts-color-picker-field" value="<?php echo $color_code; ?>">
            </td>
        </tr>
        <?php
    }
    function mts_create_update_attribute_tax_color( $term_id, $tt_id, $taxonomy ) {
        $opt_array = get_option('mts_tax_color_codes');

        if ( isset( $_POST['ps_color_hex_code'] ) ) {

            $opt_array[ $taxonomy ][ $term_id ] = $_POST['ps_color_hex_code'];
        }

        if ( isset( $opt_array ) ) {

            update_option( 'mts_tax_color_codes' , $opt_array );
        }
    }
    function mts_delete_attribute_tax_color( $term_id, $tt_id, $taxonomy ) {
        $opt_array = get_option('mts_tax_color_codes');
        if ( $opt_array && isset( $opt_array[ $taxonomy ][ $term_id ] ) ) {

            unset( $opt_array[ $taxonomy ][ $term_id ] );
            update_option('mts_tax_color_codes', $opt_array);
        }
    }
    function mts_attribute_tax_picker() {
        $taxonomy_screens = array();
        $attribute_taxonomies = wc_get_attribute_taxonomies();
        foreach ( $attribute_taxonomies as $tax ) {
            $attribute = sanitize_title( $tax->attribute_name );

            $taxonomy = wc_attribute_taxonomy_name( $attribute );
            
            $taxonomy_screens[] = 'edit-'.$taxonomy;
        }

        $screen = get_current_screen();
        $screen_id = $screen->id;

        if ( in_array( $screen_id, $taxonomy_screens ) ) {
            wp_enqueue_style('wp-color-picker');
            wp_enqueue_script('wp-color-picker');
            wp_enqueue_script( 'mts-color-picker-script', get_template_directory_uri() . '/js/color-picker.js', array('wp-color-picker') );
        }
    }

    // Create an array of product attribute taxonomies for use in ajax nav widget
    add_action( 'init', 'mts_wc_ajax_layered_nav_init', 99 );
    function mts_wc_ajax_layered_nav_init() {
        if ( is_active_widget( false, false, 'mts_wc_ajax_filter_widget', true ) && ! is_admin() ) {

            global $_chosen_attributes, $woocommerce, $_mts_attributes_array;

            $_chosen_attributes = $_mts_attributes_array = array();

            $attribute_taxonomies = wc_get_attribute_taxonomies();

            if ( $attribute_taxonomies ) {
                foreach ( $attribute_taxonomies as $tax ) {

                    $attribute = sanitize_title( $tax->attribute_name );

                    $taxonomy = wc_attribute_taxonomy_name($attribute);

                    // create an array of product attribute taxonomies
                    $_mts_attributes_array[] = $taxonomy;

                    $name = 'filter_' . $attribute;
                    $query_type_name = 'query_type_' . $attribute;

                    if ( ! empty( $_GET[ $name ] ) && taxonomy_exists( $taxonomy ) ) {

                        $_chosen_attributes[ $taxonomy ]['terms'] = explode( ',', $_GET[ $name ] );

                        if ( empty( $_GET[ $query_type_name ] ) || ! in_array( strtolower( $_GET[ $query_type_name ] ), array( 'and', 'or' ) ) )
                            $_chosen_attributes[ $taxonomy ]['query_type'] = apply_filters( 'woocommerce_layered_nav_default_query_type', 'and' );
                        else
                            $_chosen_attributes[ $taxonomy ]['query_type'] = strtolower( $_GET[ $query_type_name ] );

                    }
                }
            }

            add_filter('loop_shop_post_in', array( WC()->query, 'layered_nav_query' ));
        }
    }

}

/*-----------------------------------------------------------------------------------*/
/* add <!-- next-page --> button to tinymce
/*-----------------------------------------------------------------------------------*/
add_filter( 'mce_buttons', 'wysiwyg_editor' );
function wysiwyg_editor( $mce_buttons ) {
   $pos = array_search( 'wp_more', $mce_buttons, true );
   if ( $pos !== false ) {
       $tmp_buttons = array_slice( $mce_buttons, 0, $pos+1 );
       $tmp_buttons[] = 'wp_page';
       $mce_buttons = array_merge( $tmp_buttons, array_slice( $mce_buttons, $pos+1 ));
   }
   return $mce_buttons;
}

/*-----------------------------------------------------------------------------------*/
/*  Alternative post templates
/*-----------------------------------------------------------------------------------*/
function mts_get_post_template( $default = 'default' ) {
    global $post;
    $single_template = $default;
    $posttemplate = get_post_meta( $post->ID, '_mts_posttemplate', true );
    
    if ( empty( $posttemplate ) || ! is_string( $posttemplate ) )
        return $single_template;
    
    if ( file_exists( dirname( __FILE__ ) . '/singlepost-'.$posttemplate.'.php' ) ) {
        $single_template = dirname( __FILE__ ) . '/singlepost-'.$posttemplate.'.php';
    }
    
    return $single_template;
}
function mts_set_post_template( $single_template ) {
     return mts_get_post_template( $single_template );
}
add_filter( 'single_template', 'mts_set_post_template' );

/*-----------------------------------------------------------------------------------*/
/*  CREATE AND SHOW COLUMN FOR FEATURED IN PORTFOLIO ITEMS LIST ADMIN PAGE
/*-----------------------------------------------------------------------------------*/

//Get Featured image
function mts_get_featured_image($post_ID) {  
    $post_thumbnail_id = get_post_thumbnail_id($post_ID);  
    if ($post_thumbnail_id) {  
        $post_thumbnail_img = wp_get_attachment_image_src($post_thumbnail_id, 'widgetthumb');  
        return $post_thumbnail_img[0];  
    }  
} 
function mts_columns_head($defaults) {  
    $defaults['featured_image'] = 'Featured Image';
    return $defaults;  
}  
function mts_columns_content($column_name, $post_ID) {  
    if ($column_name == 'featured_image') {  
        $post_featured_image = mts_get_featured_image($post_ID);  
        if ($post_featured_image) {  
            echo '<img width="50" height="42" src="' . $post_featured_image . '" />';  
        }  
    }  
} 
add_filter('manage_posts_columns', 'mts_columns_head');  
add_action('manage_posts_custom_column', 'mts_columns_content', 10, 2);

/*-----------------------------------------------------------------------------------*/
/*  Custom Gravatar Support
/*-----------------------------------------------------------------------------------*/
function mts_custom_gravatar( $avatar_defaults ) {
    $mts_avatar = get_template_directory_uri() . '/images/gravatar.png';
    $avatar_defaults[$mts_avatar] = 'Custom Gravatar ( /images/gravatar.png )';
    return $avatar_defaults;
}
add_filter( 'avatar_defaults', 'mts_custom_gravatar' );

/*-----------------------------------------------------------------------------------*/
/*  WP Review Support
/*-----------------------------------------------------------------------------------*/
// Set the review options in theme
// These will be set as the global options for the plugin upon theme activation
$new_options = array(
  'colors' => array(
    'color' => '#80a6ae',
    'fontcolor' => '#8a8585',
    'bgcolor1' => '#ffffff',
    'bgcolor2' => '#ffffff',
    'bordercolor' => '#eff5f7'
  )
);
if ( function_exists( 'wp_review_theme_defaults' )) wp_review_theme_defaults( $new_options );

/*-----------------------------------------------------------------------------------*/
/*  WP Mega Menu Thumb Size
/*-----------------------------------------------------------------------------------*/
function megamenu_thumbnails( $thumbnail_html, $post_id ) {
    $thumbnail_html = '<div class="wpmm-thumbnail">';
    $thumbnail_html .= '<a title="'.get_the_title( $post_id ).'" href="'.get_permalink( $post_id ).'">';
    if(has_post_thumbnail($post_id)):
        $thumbnail_html .= get_the_post_thumbnail($post_id, 'widgetfull', array('title' => ''));
    else:
        $thumbnail_html .= '<img src="'.plugins_url().'/wp-mega-menu/images/nothumb-widgetfull.png" alt="'.__('No Preview', 'wpmm').'"  class="wp-post-image" />';
    endif;
    $thumbnail_html .= '</a>';
    
    // WP Review
    $thumbnail_html .= (function_exists('wp_review_show_total') ? wp_review_show_total(false) : '');
    
    $thumbnail_html .= '</div>';

    return $thumbnail_html;
}
add_filter( 'wpmm_thumbnail_html', 'megamenu_thumbnails', 10, 2 );
?>