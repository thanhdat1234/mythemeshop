<?php
/**
 * Empty cart page
 *
 * @author 		WooThemes
 * @package 	WooCommerce/Templates
 * @version     2.0.0
 */

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

$mts_options = get_option( MTS_THEME_NAME );

wc_print_notices();

?>

<div class="message-big cart-empty">

	<span class="fa-stack shopping-cart-stack">
		<i class="fa fa-shopping-cart shopping-cart-stack-base"></i>
		<i class="fa fa-times-circle"></i>
	</span>

	<h1><?php _e( 'Your cart is currently empty', 'woocommerce' ) ?></h1>

	<p><?php _e( 'Return to the shop to Add Items', 'mythemeshop' ) ?></p>

	<?php do_action( 'woocommerce_cart_is_empty' ); ?>

	<p class="return-to-shop"><a class="button wc-backward" href="<?php echo apply_filters( 'woocommerce_return_to_shop_redirect', get_permalink( wc_get_page_id( 'shop' ) ) ); ?>"><?php _e( 'Keep Shopping', 'mythemeshop' ) ?></a></p>

</div>

<?php if ( $mts_options['mts_featured_products'] == '1' && isset( $mts_options['mts_featured_products_locations']['cart'] ) ) { do_action( 'mts_featured_products' ); } ?>