jQuery.fn.exists = function(callback) {
    var args = [].slice.call(arguments, 1);
    if (this.length) {
        callback.call(this, args);
    }
    return this;
};

/*! .isOnScreen() returns bool */
jQuery.fn.isOnScreen = function(){

    var win = jQuery(window);

    var viewport = {
        top : win.scrollTop(),
        left : win.scrollLeft()
    };
    viewport.right = viewport.left + win.width();
    viewport.bottom = viewport.top + win.height();

    var bounds = this.offset();
    bounds.right = bounds.left + this.outerWidth();
    bounds.bottom = bounds.top + this.outerHeight();

    return (!(viewport.right < bounds.left || viewport.left > bounds.right || viewport.bottom < bounds.top || viewport.top > bounds.bottom));

};

/*----------------------------------------------------
/* Header Search
/*---------------------------------------------------*/
jQuery(document).ready(function($){
    var $header = $('#header');
    var $input = $header.find('.hideinput, .header-search .fa-search');
    $header.find('.fa-search').hover(function(e){
        $input.addClass('active').focus();
    }, function() {
       
    });
    $('.header-search .hideinput').click(function(e) {
        e.stopPropagation();
    });
}).click(function(e) {
    jQuery('#header .hideinput, .header-search .fa-search').removeClass('active');
});

jQuery(document).ready(function($){
    $('.header-search .fa-search').click(function(e) {
        e.preventDefault();
        e.stopPropagation();
    });
});

/*----------------------------------------------------
/* Scroll to top
/*--------------------------------------------------*/
jQuery(document).ready(function($) {
    var scrollDes = 'html,body';
    /*Opera does a strange thing if we use 'html' and 'body' together so my solution is to do the UA sniffing thing*/
    if(navigator.userAgent.match(/opera/i)){
        scrollDes = 'html';
    }
    // scroll to top when click ( footer .to-top too )
    jQuery('.to-top').click(function(e) {
        e.preventDefault();
        jQuery(scrollDes).animate({
            scrollTop: 0
        },{
            duration :500
        });
    });
});

/*----------------------------------------------------
/* Responsive Navigation
/*--------------------------------------------------*/
if (mts_customscript.responsive && mts_customscript.nav_menu != 'none') {
    jQuery(document).ready(function($){
        
        var menu_wrapper = $('.primary-navigation')
            .clone().attr('class', 'mobile-menu primary').removeAttr('id')
            .wrap('<div id="mobile-menu-wrapper" />').parent().hide()
            .appendTo('body');
    
        $('.toggle-mobile-menu').click(function(e) {
            e.preventDefault();
            e.stopPropagation();
            menu_wrapper.show();
            $('body').toggleClass('mobile-menu-active');
        });
        
        // prevent propagation of scroll event to parent
        $(document).on('DOMMouseScroll mousewheel', '#mobile-menu-wrapper .mobile-menu', function(ev) {
            var $this = $(this),
                scrollTop = this.scrollTop,
                scrollHeight = this.scrollHeight,
                height = $this.height(),
                delta = (ev.type == 'DOMMouseScroll' ?
                    ev.originalEvent.detail * -40 :
                    ev.originalEvent.wheelDelta),
                up = delta > 0;
        
            var prevent = function() {
                ev.stopPropagation();
                ev.preventDefault();
                ev.returnValue = false;
                return false;
            }
        
            if (!up && -delta > scrollHeight - height - scrollTop) {
                // Scrolling down, but this will take us past the bottom.
                $this.scrollTop(scrollHeight);
                return prevent();
            } else if (up && delta > scrollTop) {
                // Scrolling up, but this will take us past the top.
                $this.scrollTop(0);
                return prevent();
            }
        });
    }).click(function() {
        jQuery('body').removeClass('mobile-menu-active');
    });
}
/*----------------------------------------------------
/*  Dropdown menu
/* ------------------------------------------------- */
jQuery(document).ready(function($) { 
	$('#navigation ul.sub-menu, #navigation ul.children').hide(); // hides the submenus in mobile menu too
	$('#navigation li').hover( 
		function() {
			$(this).children('ul.sub-menu, ul.children').slideDown('fast');
		}, 
		function() {
			$(this).children('ul.sub-menu, ul.children').hide();
		}
	);
});

/*----------------------------------------------------
/* Social button scripts
/*---------------------------------------------------*/
jQuery(document).ready(function($){
	(function(d, s) {
	  var js, fjs = d.getElementsByTagName(s)[0], load = function(url, id) {
		if (d.getElementById(id)) {return;}
		js = d.createElement(s); js.src = url; js.id = id;
		fjs.parentNode.insertBefore(js, fjs);
	  };
	jQuery('span.facebookbtn, .facebook_like').exists(function() {
	  load('//connect.facebook.net/en_US/all.js#xfbml=1', 'fbjssdk');
	});
	jQuery('span.gplusbtn').exists(function() {
	  load('https://apis.google.com/js/plusone.js', 'gplus1js');
	});
	jQuery('span.twitterbtn').exists(function() {
	  load('//platform.twitter.com/widgets.js', 'tweetjs');
	});
	jQuery('span.linkedinbtn').exists(function() {
	  load('//platform.linkedin.com/in.js', 'linkedinjs');
	});
	jQuery('span.pinbtn').exists(function() {
	  load('//assets.pinterest.com/js/pinit.js', 'pinterestjs');
	});
	jQuery('span.stumblebtn').exists(function() {
	  load('//platform.stumbleupon.com/1/widgets.js', 'stumbleuponjs');
	});
	}(document, 'script'));

    $('a.share-link').click(function(e) {
        e.preventDefault();
        $(this).toggleClass('active');
        $('.product-share-buttons').slideToggle();
    });
});

/*----------------------------------------------------
/* Checkout Tabs
/*---------------------------------------------------*/
jQuery(document).ready(function($) {

    if ( $('#checkout-progress').length ) {

        $('.checkout-tab').hide();

        $('#checkout-progress a').click(function(e) {
            e.preventDefault();
            var $this = $(this);
            if ( $this.attr('data-tab') && ! $this.parent().hasClass('active') && ! $this.hasClass('disabled') ) {

                $('.checkout-tab').hide();
                $this.parent().addClass('active').siblings().removeClass('active');
                $('.'+$this.data('tab')).fadeIn(600);
            }
        });

        if ( ! $('#checkout-progress li.active').length ) {
            $('#checkout-progress li:first a').click();
            $('#checkout-progress li:first').addClass('active');
        } else {
            $('#checkout-progress li.active').removeClass('active').children('a').click().parent().addClass('active');
        }

        $('.checkout-next-button').click(function(e) {
            e.preventDefault();
            var $this = $(this);
            
            $('#checkout-progress a[data-tab="'+$this.data('activate')+'"]').click();
            window.scrollTo(0, $("#checkout-progress").offset().top);
        });

        // Return to first step on error
        $('body').on( 'checkout_error', function() {
            $('#checkout-progress a[data-tab="tab-billing-shipping"]').click();
        });
    }
});

/*---------------------------------------------------
/*  Vertical ( widget ) menus/lists
/* -------------------------------------------------*/
jQuery(document).ready(function($) {

    $('.widget_nav_menu, .widget_product_categories, .widget_pages').addClass('toggle-menu');
    $('.toggle-menu ul.sub-menu, .toggle-menu ul.children').addClass('toggle-submenu');
    $('.toggle-menu .current-menu-item, .toggle-menu .current-cat, .toggle-menu .current_page_item').addClass('toggle-menu-current-item');
    $('.toggle-menu .menu-item-has-children, .toggle-menu .cat-parent, .toggle-menu .page_item_has_children').addClass('toggle-menu-item-parent');

    $('.toggle-menu').each(function() {
        var $this = $(this);

        $this.find('.toggle-submenu').hide();

        $this.find('.toggle-menu-current-item').last().parents('.toggle-menu-item-parent').addClass('active').children('.toggle-submenu').show();
        $this.find('.toggle-menu-item-parent').append('<span class="toggle-caret"><i class="fa fa-angle-down"></i></span>');
    });
    

    $('.toggle-caret').click(function(e) {
        e.preventDefault();
        $(this).parent().toggleClass('active').children('.toggle-submenu').slideToggle('fast');
    });
});

/*---------------------------------------------------
/*  Accordion Widget
/* -------------------------------------------------*/
jQuery(document).ready(function($) {

    if ( $('.mts-accordion').length ) {

        $('.mts-accordion').each(function() {

            var $this = $(this);

            $this.find(".mts_accordion_togglec").hide();
            $this.find(".mts_accordion_togglec:first").show().prev(".mts_accordion_togglet").addClass("mts_accordion_toggleta");
        });

        $(".mts_accordion_togglet").click(function(){

            var $this = $(this),
                $accWrap = $this.closest('.mts-accordion');

            if ( ! $this.hasClass("mts_accordion_toggleta") ) {
                $accWrap.find(".mts_accordion_toggleta").removeClass("mts_accordion_toggleta").next(".mts_accordion_togglec").slideUp("normal");
                $this.addClass("mts_accordion_toggleta").next(".mts_accordion_togglec").slideDown("normal");
            }
        });
    }
});

/*----------------------------------------------------
/* Other
/*---------------------------------------------------*/
jQuery(document).ready(function($) {
    // Lightbox Icon in product gallery slider
    $('a.lightbox-icon').click(function(e) {
        e.preventDefault();
        $('#product-img-slider .flex-active-slide a').click();
    });
    // Toggle order details on Order Complete page
    $('a.toggle-receipt').click(function(e) {
        e.preventDefault();
        $('.message-big.completed .order_details').slideToggle();
    });
    // Compare button loading
    if ( mts_customscript.compare_autopopup ) {

        $('a.compare').click(function(e) {
            e.preventDefault();
            $(this).addClass('loading');
        });

        $('body').on( 'yith_woocompare_open_popup', function( e ) {
            $('a.compare.loading').removeClass('loading');
        });
    }
});