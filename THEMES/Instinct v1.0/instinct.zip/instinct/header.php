<!DOCTYPE html>
<?php $options = get_option('instinct'); ?>
<html class="no-js" <?php language_attributes(); ?>>
<head>
	<meta charset="<?php bloginfo('charset'); ?>">
	<title><?php wp_title(''); ?></title>
	<?php mts_meta(); ?>
	<link rel="stylesheet" type="text/css" media="all" href="<?php bloginfo( 'stylesheet_url' ); ?>" />
	<link rel="pingback" href="<?php bloginfo( 'pingback_url' ); ?>" />
	<?php wp_enqueue_script("jquery"); ?>
	<?php if ( is_singular() ) wp_enqueue_script( 'comment-reply' ); ?>
	<!--[if lt IE 9]>
	<script src="http://html5shim.googlecode.com/svn/trunk/html5.js"></script>
	<![endif]-->
	<?php mts_head(); ?>
	<?php wp_head(); ?>
</head>

<?php flush(); ?>

<body id ="blog" <?php body_class('main'); ?>>
	<header class="main-header">
		<div class="container">
			<div id="header">
				<?php if( is_front_page() || is_home() || is_404() ) { ?>
						<h1 id="logo">
							<a href="<?php echo home_url(); ?>"><?php bloginfo( 'name' ); ?></a>
						</h1><!-- END #logo -->
				<?php } else { ?>
						<h2 id="logo">
							<a href="<?php echo home_url(); ?>"><?php bloginfo( 'name' ); ?></a>
						</h2><!-- END #logo -->
				<?php } ?>  
				<div class="secondary-navigation">
					<nav id="navigation" >
						<?php if ( has_nav_menu( 'primary-menu' ) ) { ?>
							<?php wp_nav_menu( array( 'theme_location' => 'primary-menu', 'menu_class' => 'menu', 'container' => '' ) ); ?>
						<?php } else { ?>
							<ul class="menu">
								<?php wp_list_categories('title_li='); ?>
							</ul>
						<?php } ?>
					</nav>
				</div>
				<div class="slider-container">
				<?php if (is_home() && !is_paged()) { ?>
					<?php if($options['mts_featured_slider'] == '1') { ?>
					<div class="flex-container">
				  <div class="flexslider">
					<ul class="slides">
					<?php
				$my_query = new WP_Query('cat='.$options['mts_featured_cat'].'&posts_per_page=3');
				while ($my_query->have_posts()) : $my_query->the_post();
				?>
					  <li>	<?php the_post_thumbnail('slider',array('title' => '')); ?>
						<div class="flex-caption">
						<a href="<?php the_permalink() ?>"><span class="slidertitle"><?php the_title(); ?></span></a>
						<span class="slidertext"><?php echo excerpt(20); ?></span>
<div class="slidermeta"><div class="sliderauthor"><?php _e('By ','mythemeshop'); the_author_meta('nickname'); ?> <?php the_time('F j, Y'); ?></div>
<div class="readMore1"><a href="<?php the_permalink() ?>" title="<?php the_title(); ?>" rel="bookmark">More &gt;&gt;</a></div>
						</div>
					  </li>
				   <?php endwhile; ?> </ul>
				  </div>
				</div>
				<?php } ?> 
				<?php } ?>
				</div>

				<?php if (is_single() && !is_paged()) { ?>
				<div class="breadcrumbs">
				<div class="container">
				<?php if ($options['mts_breadcrumb'] == '1') { ?>
					<div class="breadcrumb"><?php the_breadcrumb(); ?></div>
				<?php } ?>
				</div>
				</div>
				<?php } ?>
			</div><!--#header-->
		</div><!--.container-->        
	</header>
<div class="main-container">