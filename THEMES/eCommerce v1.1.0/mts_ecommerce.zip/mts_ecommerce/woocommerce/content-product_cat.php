<?php
/**
 * The template for displaying product category thumbnails within loops.
 *
 * Override this template by copying it to yourtheme/woocommerce/content-product_cat.php
 *
 * @author 		WooThemes
 * @package 	WooCommerce/Templates
 * @version     2.4.0
 */

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

global $woocommerce_loop;

// Store loop count we're currently on
if ( empty( $woocommerce_loop['loop'] ) )
	$woocommerce_loop['loop'] = 0;

// Store column count for displaying the grid
if ( empty( $woocommerce_loop['columns'] ) )
	$woocommerce_loop['columns'] = apply_filters( 'loop_shop_columns', 4 );

// Increase loop count
$woocommerce_loop['loop']++;
$tag = is_home() ? 'div' : 'li';
?>
<<?php echo $tag; ?> class="product-category browse-category product">

	<?php do_action( 'woocommerce_before_subcategory', $category ); ?>

	<a href="<?php echo get_term_link( $category->slug, 'product_cat' ); ?>">
		<?php
			/**
			 * woocommerce_before_subcategory_title hook
			 *
			 * @hooked woocommerce_subcategory_thumbnail - 10
			 */
			do_action( 'woocommerce_before_subcategory_title', $category );
		?>
		<div class="browse-category-info">
			<div class="browse-category-title"><?php echo esc_html( $category->name ); ?></div>
			<?php if ( $category->count > 0 ) echo apply_filters( 'woocommerce_subcategory_count_html', '<div class="browse-category-products">' . $category->count . __( ' Products', MTS_THEME_TEXTDOMAIN ) . '</div>', $category ); ?>
			<?php
				/**
				 * woocommerce_after_subcategory_title hook
				 */
				do_action( 'woocommerce_after_subcategory_title', $category );
			?>
		</div>
	</a>

	<?php do_action( 'woocommerce_after_subcategory', $category ); ?>

</<?php echo $tag; ?>>