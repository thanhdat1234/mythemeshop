<?php
/**
 * The custom template for displaying product content within carousel loops.
 */

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

global $product, $woocommerce_loop, $mts_options;

// Store loop count we're currently on
if ( empty( $woocommerce_loop['loop'] ) )
	$woocommerce_loop['loop'] = 0;

// Store column count for displaying the grid
if ( empty( $woocommerce_loop['columns'] ) )
	$woocommerce_loop['columns'] = apply_filters( 'loop_shop_columns', 4 );

// Ensure visibility
if ( ! $product || ! $product->is_visible() )
	return;

// Increase loop count
$woocommerce_loop['loop']++;

// Extra post classes
$classes = array('related-products-slider');
?>
<div <?php post_class( $classes ); ?>>

	<?php $product_effect =  isset( $mts_options['mts_related_products_hover_effect'] ) ? $mts_options['mts_related_products_hover_effect'] : 'featured'; ?>

	<?php do_action( 'woocommerce_before_shop_loop_item' ); ?>

	<?php wc_get_template_part( 'loop/product-hover-effect', $product_effect ); ?>

	<?php do_action( 'woocommerce_after_shop_loop_item' ); ?>
</div>