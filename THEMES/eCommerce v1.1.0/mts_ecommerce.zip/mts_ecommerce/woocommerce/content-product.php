<?php
/**
 * The template for displaying product content within loops.
 *
 * Override this template by copying it to yourchildtheme/woocommerce/content-product.php
 *
 * @author 		WooThemes
 * @package 	WooCommerce/Templates
 * @version     2.4.0
 */

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

global $product, $woocommerce_loop, $mts_options;

// Store loop count we're currently on
if ( empty( $woocommerce_loop['loop'] ) )
	$woocommerce_loop['loop'] = 0;

// Store column count for displaying the grid
if ( empty( $woocommerce_loop['columns'] ) )
	$woocommerce_loop['columns'] = apply_filters( 'loop_shop_columns', 4 );

// Ensure visibility
if ( ! $product || ! $product->is_visible() )
	return;

// Increase loop count
$woocommerce_loop['loop']++;

// Extra post classes
$classes = array('excerpt');
if ( 0 == ( $woocommerce_loop['loop'] - 1 ) % $woocommerce_loop['columns'] || 1 == $woocommerce_loop['columns'] )
	$classes[] = 'first';
if ( 0 == $woocommerce_loop['loop'] % $woocommerce_loop['columns'] )
	$classes[] = 'last';
?>
<li <?php post_class( $classes ); ?>>

	<?php $product_effect =  isset( $mts_options['mts_shop_hover_effect'] ) ? $mts_options['mts_shop_hover_effect'] : 'default'; ?>

	<?php do_action( 'woocommerce_before_shop_loop_item' ); ?>

	<?php wc_get_template_part( 'loop/product-hover-effect', $product_effect ); ?>

	<?php do_action( 'woocommerce_after_shop_loop_item' ); ?>

</li>