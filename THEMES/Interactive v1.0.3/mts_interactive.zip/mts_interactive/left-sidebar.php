<aside id="sidebar" class="sidebar c-4-12 sidebar-left" role="complementary" itemscope itemtype="http://schema.org/WPSideBar">
	<?php if ( is_active_sidebar( 'left-sidebar' ) ) : ?>
	    <?php dynamic_sidebar( 'left-sidebar' ); ?>
	<?php endif; ?>
</aside>