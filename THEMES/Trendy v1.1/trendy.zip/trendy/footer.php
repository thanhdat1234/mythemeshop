<?php $options = get_option('trendy'); ?>
	</div><!--#page-->
</div>
	<footer>
		<div class="container">
			<div class="footer-widgets">
				<?php widgetized_footer(); ?>
			</div><!--.footer-widgets-->
		</div><!--.container-->
				<div class="copyrights">
				<div class="row" id="copyright-note">
<?php if ($options['mts_copyrights'] != '') { ?>
<div class="top"><?php echo $options['mts_copyrights']; ?></div>
<?php } else { ?>
<div class="top">&copy; 2012 <a href="<?php echo home_url(); ?>/" title="<?php bloginfo('description'); ?>"><?php bloginfo('name'); ?></a>. Theme by <a href="http://mythemeshop.com/">MyThemeShop</a>.</div>
<?php } ?>
			</div>
			</div>
	</footer><!--footer-->
</div><!--.container-->
<?php wp_footer(); ?>

<script src="<?php bloginfo('template_directory'); ?>/js/socialite.js"></script>
<script>

	// Only use jQuery if the website already makes extensive use of it!

	$(document).ready(function()
	{

		$('#social').one('mouseenter', function()
		{
			Socialite.load($(this)[0]);
		});

	});

	</script>
<?php if ($options['mts_analytics_code'] != '') { ?>
<?php echo(stripslashes ($options['mts_analytics_code']));?>
<?php } ?>
</body>
</html>