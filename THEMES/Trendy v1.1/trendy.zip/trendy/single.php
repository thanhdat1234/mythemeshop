<?php $options = get_option('trendy'); ?>
<?php get_header(); ?>
<div id="page" class="single">
	<div class="content">
		<article class="article">
			<div id="content_box" >
				<?php if ( have_posts() ) while ( have_posts() ) : the_post(); ?>
				<div id="post-<?php the_ID(); ?>" <?php post_class('g post'); ?>>
				<?php if ($options['mts_breadcrumb'] == '1') { ?>
					<div class="breadcrumb"><?php the_breadcrumb(); ?></div>
				<?php } ?>
                <h1 class="title single-title"><?php the_title(); ?></h1>
                <?php if($options['mts_headline_meta'] == '1') { ?>
                <div class="post-info">
				<span class="theauthor"> <?php _e('Posted on ', 'mythemeshop'); the_time('F j, Y'); ?><?php _e(' in  ', 'mythemeshop'); the_category(', ') ?><?php _e(' by ', 'mythemeshop'); the_author_posts_link(); ?></span>
		</div>
                <?php }?>
<?php if($options['mts_single_thumb'] == '1') { ?>	
                <?php if ( has_post_thumbnail() ) { ?>                
				<?php echo the_post_thumbnail('slider',array('title' => ''));?>
				<?php }?>
<?php }?>
                <div id="single-post-wrapper">
						<div class="post-content box mark-links">
			<?php if ($options['mts_posttop_adcode'] != '') { ?>
				<?php $toptime = $options['mts_posttop_adcode_time']; if (strcmp( date("Y-m-d", strtotime( "-$toptime day")), get_the_time("Y-m-d") ) >= 0) { ?>
					<div class="topad">
						<?php echo $options['mts_posttop_adcode']; ?>
					</div>
				<?php } ?>
			<?php } ?>
							<?php the_content(); ?>
							<?php wp_link_pages('before=<div class="pagination2">&after=</div>'); ?>
			<?php if ($options['mts_postend_adcode'] != '') { ?>
				<?php $endtime = $options['mts_postend_adcode_time']; if (strcmp( date("Y-m-d", strtotime( "-$endtime day")), get_the_time("Y-m-d") ) >= 0) { ?>
					<div class="bottomad">
						<?php echo $options['mts_postend_adcode'];?>
					</div>
				<?php } ?>
			<?php } ?>
<?php if($options['mts_social_buttons'] == '1') { ?>
<div id="social" class="cf shareit">
<?php if($options['mts_twitter'] == '1') { ?>
	<span class="share-item twitterbtn">
		<a href="#" class="socialite twitter-share" data-via="<?php echo $options['mts_twitter_username']; ?>" data-count="horizontal" rel="nofollow" target="_blank">
		<span class="vhidden">Share on Twitter</span>
		</a>
	</span>
<?php } ?>
<?php if($options['mts_gplus'] == '1') { ?>
	<span class="share-item gplusbtn">
		<a href="#" class="socialite googleplus-one" data-size="medium" rel="nofollow" target="_blank">
		<span class="vhidden">Share on Google+</span>
		</a>
	</span>
<?php } ?>
<?php if($options['mts_facebook'] == '1') { ?>
	<span class="share-item fbbutton">
		<a href="#" class="socialite facebook-like" data-send="false" data-layout="button_count" data-width="60" data-show-faces="false" rel="nofollow" target="_blank">
		<span class="vhidden">Share on Facebook</span>
		</a>
	</span>
<?php } ?>
<?php if($options['mts_pinterest'] == '1') { ?>
	<span class="share-item pinbtn">
		<a href="http://pinterest.com/pin/create/button/?url=<?php the_permalink() ?>&amp;media=<?php $image =wp_get_attachment_image_src(get_post_thumbnail_id($post->ID), 'slider'); echo $image[0]; ?>&amp;description=<?php the_title(); ?>" class="socialite pinterest-pinit" data-count-layout="horizontal">
		<span class="vhidden">Pin It!</span>
		</a>
	</span>
<?php } ?>
<?php if($options['mts_linkedin'] == '1') { ?>
	<span class="share-item linkedinbtn">
		<a href="#" class="socialite linkedin-share" data-counter="right" rel="nofollow" target="_blank">
		<span class="vhidden">Share on LinkedIn</span>
		</a>
	</span>
<?php } ?>
<?php if($options['mts_stumble'] == '1') { ?>
<script>
/** Script for Stumble Upon Button  */
$(document).ready(function () {
var element, script;
element = document.getElementById('stumble-widget');
element.onmouseover = function () {
this.onmouseover = null;
this.parentNode.removeChild(this);
var li = document.createElement('script'); li.type = 'text/javascript'; li.async = true;
li.src = 'https://platform.stumbleupon.com/1/widgets.js';
var s = document.getElementsByTagName('script')[0]; s.parentNode.insertBefore(li, s);
script = document.createElement('script');
script.async = true;
script.src = '//platform.stumbleupon.com/1/widgets.js';
document.body.appendChild(script);
};
});
</script>
	<span class="share-item stumblebtn stumble-widget">
		<a rel="nofollow" href="http://www.stumbleupon.com/submit?url=<?php echo get_permalink(); ?>" id="stumble-widget" class="socialite"><span class="vhidden">Stumble<span></a>
		<su:badge layout="1"></su:badge>
	</span>
<?php } ?>
    </div>
<?php } ?>
					    </div>		
						</div><!--.post-content box mark-links-->
                        <?php if($options['mts_tags'] == '1') { ?>
							<div class="tags"><?php the_tags('<span class="tagtext">Tags:</span>','') ?></div>
						<?php } ?>
						<?php if($options['mts_related_posts'] == '1') { ?>
							<div class="related-posts">
                            <h4><?php _e('Related Posts', 'mythemeshop'); ?></h4>
								<?php
								$categories = get_the_category($post->ID);
								if ($categories) {
								$category_ids = array();
								foreach($categories as $individual_category) $category_ids[] = $individual_category->term_id;

								$args=array(
								'category__in' => $category_ids,
								'post__not_in' => array($post->ID),
								'orderby' => 'rand',
								'showposts'=>2, // Number of related posts that will be shown.
								'caller_get_posts'=>1
								);

								$my_query = new wp_query( $args );
								if( $my_query->have_posts() ) {
								echo '<ul>';
								while( $my_query->have_posts() ) {
								++$counter;
								if($counter == 2) {
								$postclass = 'last';
								$counter = 0;
								} else { $postclass = '';}
								$my_query->the_post();?>

								<li class="<?php echo $postclass; ?>">
								
                                    <h3><a href="<?php the_permalink()?>" title="<?php the_title()?>" rel="bookmark"><?php the_title()?></a></h3>
										<?php if(has_post_thumbnail()): ?>
											<span class="rthumb"><?php the_post_thumbnail('featured', 'title='); ?></span>
											
										<?php else: ?>
											<span class="rthumb"><img src="<?php echo get_template_directory_uri(); ?>/images/nothumb.png" alt="<?php the_title(); ?>"  width='50' height='50' class="wp-post-image" /></span>											
										<?php endif; ?>
									
                                    <div class="post-small-related"><p><?php  echo excerpt(10)?></p></div>
                                    
									<?php //if (strlen($post->post_title) > 52) {
										//echo substr(the_title($before = '', $after = '', FALSE), 0, 52) . '...'; } else {
										//the_title();
									//} ?>
							
								</li>
								<?php
								}
								echo '</ul>';
								}
								}
								wp_reset_query();
								?>
							</div><!-- .related-posts -->	
                        <?php } ?>
						<?php if($options['mts_author_box'] == '1') { ?>
						<div class="postauthor">
						<h4><?php _e('About the Author:', 'mythemeshop'); ?></h4>
							<?php if(function_exists('get_avatar')) { echo get_avatar( get_the_author_meta('email'), '75' );  } ?>
                            <h5><?php the_author_meta( 'nickname' ); ?></h5>
							<p><?php the_author_meta('description') ?></p>
						</div>
						<?php } ?>						
					</div><!--.g post-->
					<?php comments_template( '', true ); ?>
				<?php endwhile; /* end loop */ ?>
			</div>
</article>
<?php get_sidebar(); ?>
<?php get_footer(); ?>