<?php
/*
Template Name: Latest Posts
*/
?>
<?php get_header(); ?>
<div id="page">
	<div class="content">
		<article class="article">
			<div id="content_box">
					<h1 class="postsby">Latest Posts</h1>
					<?php
$temp = $wp_query;
$wp_query= null;
$wp_query = new WP_Query();
$wp_query->query('showposts=5'.'&paged='.$paged);
?>
<?php while ($wp_query->have_posts()): $wp_query->the_post(); ?>
						<div class="post excerpt">
							<header>					
								<h2 class="title">
									<a href="<?php the_permalink() ?>" title="<?php the_title(); ?>" rel="bookmark"><?php the_title(); ?></a>
								</h2>
								<?php if($options['mts_headline_meta'] == '1') { ?>
								<div class="post-info">
									<span class="theauthor"><?php _e('Posted by ', 'mythemeshop'); the_author_posts_link(); ?></span>
									<time><?php _e('On ', 'mythemeshop'); the_time('F j, Y'); ?></time>
									<span class="thecategory"><?php _e('In ', 'mythemeshop'); the_category(', ') ?></span>
									<span class="thecomments"><a href="<?php comments_link(); ?>"><?php comments_number('No comments','1 Comment','% Comments'); ?></a></span>
								</div>
								<?php } ?>
							</header><!--.header-->
															<a href="<?php the_permalink() ?>" title="<?php the_title(); ?>" rel="nofollow" id="featured-thumbnail">
								<?php if ( has_post_thumbnail() ) { ?> 
								<?php echo '<div class="featured-thumbnail">'; the_post_thumbnail('featured',array('title' => '')); echo '</div>'; ?>
								<?php } else { ?>
								<div class="featured-thumbnail">
								<img width="50" height="50" src="<?php echo get_template_directory_uri(); ?>/images/nothumb.png" class="attachment-featured wp-post-image" alt="<?php the_title(); ?>">
								</div>
								<?php } ?>
								</a>
							<div class="post-content image-caption-format-1">
								<?php echo excerpt(48);?>
							</div>
						</div><!--.post excerpt-->
					<?php endwhile;?>
						
							<?php pagination($additional_loop->max_num_pages);?>
							
			</div>
		</article>
<?php get_sidebar(); ?>
<?php get_footer(); ?>