<?php $mts_options = get_option('glamour'); ?>
<?php get_header(); ?>
<div id="page">
	<div class="article">
		<div id="content_box">
			<?php if (is_home() && !is_paged()) { ?>
				<?php if($mts_options['mts_featured_slider'] == '1') { ?>
					<div class="slider-container loading">
						<div class="flex-container">
							<div id="slider" class="flexslider">
								<ul class="slides">
									<?php $slider_cat = implode(",", $mts_options['mts_featured_slider_cat']); $my_query = new WP_Query('cat='.$slider_cat.'&posts_per_page=4');
										while ($my_query->have_posts()) : $my_query->the_post();
										$image_id = get_post_thumbnail_id();
										$image_url = wp_get_attachment_image_src($image_id,'slider_thumb');
										$image_url = $image_url[0]; ?>
									<li data-thumb="<?php echo $image_url; ?>"> 
										<a href="<?php the_permalink() ?>">
											<?php the_post_thumbnail('slider',array('title' => '')); ?>
											<div class="flex-caption">
												<span class="slidertitle"><?php the_title(); ?></span>
											</div>
										</a> 
									</li>
									<?php endwhile; wp_reset_query(); ?>
								</ul>
							</div>
						</div>
					</div>
					<!-- slider-container -->
				<?php } ?>
			<?php } ?>
			<div class="post-content-in">
				<?php if($mts_options['mts_layout'] == 'rcslayout' || $mts_options['mts_layout'] == 'crslayout' || $mts_options['mts_layout'] == 'scrlayout' || $mts_options['mts_layout'] == 'srclayout') { ?>
					<?php if (is_home() && !is_paged()) { ?>
						<div class="post-content-upper">
							<div class="post-content-row">
								<h2 class="post-heading"><span><?php $first_cat = $mts_options['mts_featured_first_cat']; echo get_cat_name( $first_cat ); ?></span></h2>
								<?php $j=1; $my_query = new WP_Query('cat='.$mts_options['mts_featured_first_cat'].'&posts_per_page=3');     if (have_posts()) : while ($my_query->have_posts()) : $my_query->the_post(); ?>                         
									<div class="latestPost excerpt <?php if($j == 3){ echo 'nomargin'; }?>">
										<header>
											<a href="<?php the_permalink() ?>" title="<?php the_title(); ?>" rel="nofollow" id="featured-thumbnail">
												<?php if ( has_post_thumbnail() ) { ?> 
													<?php echo '<div class="featured-thumbnail">'; the_post_thumbnail('featured',array('title' => '')); echo '</div>'; ?>
												<?php } else { ?>
													<div class="featured-thumbnail">
														<img width="145" height="100" src="<?php echo get_template_directory_uri(); ?>/images/nothumb.png" class="attachment-featured wp-post-image" alt="<?php the_title(); ?>">
													</div>
												<?php } ?>
											</a>                                               
										</header><!--.header-->
										<div class="post-container">
											<div class="post-content image-caption-format-1">
												<a href="<?php the_permalink() ?>" title="<?php the_title(); ?>" ><b><?php the_title(); ?></b></a>: <?php echo mts_excerpt(13);?>
											</div>
											<div class="readMore"><a href="<?php the_permalink() ?>" title="<?php the_title(); ?>" rel="bookmark"><?php _e('More','mythemeshop'); ?> +</a></div>
										</div>    
									</div><!--.latestPost excerpt-->
								<?php $j++;  endwhile; endif; ?>
							</div>
							<h2 class="post-heading"><span><?php $second_cat = $mts_options['mts_featured_second_cat']; echo get_cat_name( $second_cat ); ?></span></h2>
							<div class="post-content-row">
								<?php $j=1; $my_query = new WP_Query('cat='.$mts_options['mts_featured_second_cat'].'&posts_per_page=3'); if (have_posts()) : while ($my_query->have_posts()) : $my_query->the_post(); ?>                        
									<div class="latestPost excerpt <?php if($j == 3){ echo 'nomargin'; }?>">
										<header>
											<a href="<?php the_permalink() ?>" title="<?php the_title(); ?>" rel="nofollow" id="featured-thumbnail">
												<?php if ( has_post_thumbnail() ) { ?> 
													<?php echo '<div class="featured-thumbnail">'; the_post_thumbnail('featured',array('title' => '')); echo '</div>'; ?>
												<?php } else { ?>
													<div class="featured-thumbnail">
														<img width="145" height="100" src="<?php echo get_template_directory_uri(); ?>/images/nothumb.png" class="attachment-featured wp-post-image" alt="<?php the_title(); ?>">
													</div>
												<?php } ?>
											</a>                                               
										</header><!--.header-->
										<div class="post-container">
											<div class="post-content image-caption-format-1">
												<a href="<?php the_permalink() ?>" title="<?php the_title(); ?>" ><b><?php the_title(); ?></b></a>: <?php echo mts_excerpt(13);?>
											</div>
											<div class="readMore"><a href="<?php the_permalink() ?>" title="<?php the_title(); ?>" rel="bookmark"><?php _e('More','mythemeshop'); ?> +</a></div>
										</div>    
									</div><!--.post excerpt-->
								<?php $j++;  endwhile; endif; ?>                 
							</div>
							
							<h2 class="post-heading"><span><?php $third_cat = $mts_options['mts_featured_third_cat']; echo get_cat_name( $third_cat ); ?></span></h2>
							<div class="post-content-row">
								<?php $j=1; $my_query = new WP_Query('cat='.$mts_options['mts_featured_third_cat'].'&posts_per_page=6'); if (have_posts()) : while ($my_query->have_posts()) : $my_query->the_post(); ?>
									<div class="latestPost excerpt galleryposts <?php if($j % 3 == 0){ echo 'nomargin'; }?>">
										<header>
											<a href="<?php the_permalink() ?>" title="<?php the_title(); ?>" rel="nofollow" id="featured-thumbnail">
												<?php if ( has_post_thumbnail() ) { ?> 
													<?php echo '<div class="featured-thumbnail">'; the_post_thumbnail('featured',array('title' => '')); echo '</div>'; ?>
												<?php } else { ?>
													<div class="featured-thumbnail">
														<img width="145" height="100" src="<?php echo get_template_directory_uri(); ?>/images/nothumb.png" class="attachment-featured wp-post-image" alt="<?php the_title(); ?>">
													</div>
												<?php } ?>
											</a>                                               
										</header><!--.header-->
									</div><!--.post excerpt-->
								<?php $j++;  endwhile; endif; ?>
							</div>
						</div>
					<?php } ?>
				<?php } ?>

				<h2 class="post-heading"><span><?php _e('Latest','mythemeshop'); ?></span></h2>
				<?php if($mts_options['mts_layout'] == 'cslayout' || $mts_options['mts_layout'] == 'sclayout') { ?>
					<div class="archive">
						<?php $j = 0; if ( get_query_var('paged') ) { $paged = get_query_var('paged'); } elseif ( get_query_var('page') ) { $paged = get_query_var('page'); } else { $paged = 1; }
							if($mts_options['mts_latest_section'] == '1') { 
								$latestsection = implode(",", $mts_options['mts_latest_section_cat']);
								query_posts('cat='.$latestsection.'&paged='.$paged);
							} else {
								query_posts( array( 'post_type' => 'post', 'paged' => $paged ) ); 
							}
							if (have_posts()) : while (have_posts()) : the_post();
						?>
						<article class="latestPost excerpt  <?php echo (++$j % 4 == 0) ? 'last' : ''; ?>">
							<header>
								<a href="<?php the_permalink() ?>" title="<?php the_title(); ?>" rel="nofollow" id="featured-thumbnail">
									<?php if ( has_post_thumbnail() ) { ?> 
										<?php echo '<div class="featured-thumbnail">'; the_post_thumbnail('featured',array('title' => '')); echo '</div>'; ?>
									<?php } else { ?>
										<div class="featured-thumbnail">
											<img width="145" height="100" src="<?php echo get_template_directory_uri(); ?>/images/nothumb.png" class="attachment-featured wp-post-image" alt="<?php the_title(); ?>">
										</div>
									<?php } ?>
								</a>                                               
							</header><!--.header-->
							<div class="post-container">
								<div class="post-content image-caption-format-1">
									<a href="<?php the_permalink() ?>" title="<?php the_title(); ?>" ><b><?php the_title(); ?></b></a>: <?php echo mts_excerpt(13);?>
								</div>
								<div class="readMore"><a href="<?php the_permalink() ?>" title="<?php the_title(); ?>" rel="bookmark"><?php _e('More','mythemeshop'); ?> +</a></div>
							</div> 
						</article><!--.post excerpt-->
						<?php endwhile; endif; ?>
					</div>
				<?php } else { ?>
					<div class="post-content-row">
						<?php $j = 1; if ( get_query_var('paged') ) { $paged = get_query_var('paged'); } elseif ( get_query_var('page') ) { $paged = get_query_var('page'); } else { $paged = 1; }
							if($mts_options['mts_latest_section'] == '1') { 
								$latestsection = implode(",", $mts_options['mts_latest_section_cat']);
								query_posts('cat='.$latestsection.'&showposts=4&paged='.$paged);
							} else {
								query_posts( array( 'post_type' => 'post', 'paged' => $paged ) ); 
							}
							if (have_posts()) : while (have_posts()) : the_post();
						?>
							<article class="latestPost excerpt-text <?php if($j % 2 == 0){ echo 'last'; } ?>">
								<div class="post-container">     
									<div class="post-content image-caption-format-1 <?php if($mts_options['mts_layout'] == 'cslayout' || $mts_options['mts_layout'] == 'sclayout') { ?>cslayout<?php } ?>">
										<strong><a href="<?php the_permalink() ?>" title="<?php the_title(); ?>"><?php echo the_title();?></a></strong>
										<?php echo mts_excerpt(20);?>
									</div>
									<?php if($mts_options['mts_home_headline_meta'] == '1') { ?>
									<div class="post-info">
										<?php _e('Posted by ','mythemeshop'); ?><?php the_author_posts_link(); ?><?php comments_number(__(' 0 Comments','mythemeshop'),__(' 1 Comment','mythemeshop'),__(' % Comments','mythemeshop')); ?>
									</div>
									<?php } ?>
								</div>    
							</article><!--.post excerpt-->
						<?php $j++;  endwhile; endif; ?>
						<span class="latestposts"><a href="<?php echo home_url(); ?>/latest"><?php _e('See All Latest Posts','mythemeshop'); ?></a></span>
					</div>	
				<?php } ?>					
			</div><!--post content -->
			<?php if($mts_options['mts_layout'] == 'rcslayout' || $mts_options['mts_layout'] == 'crslayout' || $mts_options['mts_layout'] == 'scrlayout' || $mts_options['mts_layout'] == 'srclayout') { ?>
				<div class="addon-content">
					<div class="addon-content-in">
						<h2 class="post-heading-span"><span><?php $forth_cat = $mts_options['mts_featured_forth_cat']; echo get_cat_name( $forth_cat ); ?></span></h2>
						<?php $j=1;	$my_query = new WP_Query('cat='.$mts_options['mts_featured_forth_cat'].'&posts_per_page=3'); if (have_posts()) : while ($my_query->have_posts()) : $my_query->the_post(); ?>
							<div class="post worldnews">
								<div class="post-container">
									<div class="post-content image-caption-format-1">
										<strong><a href="<?php the_permalink() ?>" title="<?php the_title(); ?>"><?php echo the_title();?></a></strong>
										 <?php echo mts_excerpt(30);?>
									</div>
									<?php if($mts_options['mts_home_headline_meta'] == '1') { ?>
									<div class="post-info">
										<?php _e('Posted by ','mythemeshop'); ?><?php the_author_posts_link(); ?><?php _e(' On ','mythemeshop'); ?><?php the_time('M j, Y'); ?>
									</div>
									<?php } ?>
								</div>    
							</div><!--.post excerpt-->
						<?php $j++;  endwhile; endif; ?>               
					</div>
							
					<div class="addon-content-in last">
						<h2 class="post-heading-span"><span><?php $fifth_cat = $mts_options['mts_featured_fifth_cat']; echo get_cat_name( $fifth_cat ); ?></span></h2>
						<?php $j=1; $my_query = new WP_Query('cat='.$mts_options['mts_featured_fifth_cat'].'&posts_per_page=3'); if (have_posts()) : while ($my_query->have_posts()) : $my_query->the_post(); ?>
							<div class="post classifieds">
								<header>
									<a href="<?php the_permalink() ?>" title="<?php the_title(); ?>" rel="nofollow" id="featured-thumbnail-middle">
										<?php if ( has_post_thumbnail() ) { ?> 
											<?php echo '<div class="featured-thumbnail-middle"><div class="classtitle">'.$post->post_title.'</div>'; the_post_thumbnail('featured-middle',array('title' => '')); echo '</div>'; ?>
										<?php } else { ?>
											<div class="featured-thumbnail-middle">
												<div class="classtitle"><?php echo $post->post_title; ?></div>
												<img width="241" height="145" src="<?php echo get_template_directory_uri(); ?>/images/nothumb2.png" class="attachment-featured wp-post-image" alt="<?php the_title(); ?>">
											</div>
										<?php } ?>
									</a>                                               
								</header><!--.header-->
								<div class="post-container">
									<div class="post-content image-caption-format-1">
										<?php echo mts_excerpt(10);?>
									</div>
								</div>    
							</div><!--.post excerpt-->
						<?php $j++;  endwhile; endif; ?>               
					</div>
				</div>
			<?php } ?>
		</div>
	</div>
	<?php get_sidebar(); ?>
<?php get_footer(); ?>