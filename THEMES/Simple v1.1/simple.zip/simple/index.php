<?php $options = get_option('simple'); ?>
<?php get_header(); ?>
<div id="page">
	<div class="content">
		<article class="article">
			<div id="content_box" >
	
					<?php if (have_posts()) : while (have_posts()) : the_post(); ?>
						<div class="post excerpt">
							<header>
								<a href="<?php the_permalink() ?>" title="<?php the_title(); ?>" rel="nofollow">
								<?php if ($options['mts_thumbnails'] == '1') { ?>
								<?php if ( has_post_thumbnail() ) { echo '<div class="featured-thumbnail">'; the_post_thumbnail('featured',array('title' => '')); echo '</div>'; } ?>
								<?php } ?>
								</a>
								<h2 class="title">
									<a href="<?php the_permalink() ?>" title="<?php the_title(); ?>" rel="bookmark"><?php the_title(); ?></a>
								</h2>
								<div class="post-info">
									<span class="theauthor"><?php _e('By ', 'mythemeshop'); the_author_posts_link(); ?></span>
									<span class="thecomment"><a href="<?php comments_link(); ?>"><?php comments_number(', No comments, on',', 1 Comment, on',', % Comments, on'); ?></a></span>
									<time><?php the_time('F j, Y'); ?></time>
								</div>
							</header><!--.header-->
							<div class="post-content image-caption-format-1">
								<p><?php echo excerpt(48);?></p>
								<?php if($options['mts_home_social'] == '1') { ?>
									<span class="share-item twitterbtn">
										<a href="https://twitter.com/share" class="twitter-share-button" data-text="<?php the_title(); ?>" data-url="<?php the_permalink() ?>" data-via="<?php echo $options['mts_twitter_username']; ?>">Tweet</a>
									</span>
									<span class="share-item gplusbtn">
										<g:plusone size="medium"></g:plusone>
									</span>
								<?php } ?>
<p><a href="<?php the_permalink() ?>" rel="nofollow" class="read-more">Read More</a></p>
							</div>
						</div><!--.post excerpt-->
					<?php endwhile; else: ?>
						<div class="post excerpt">
							<div class="no-results">
								<p><strong><?php _e('There has been an error.', 'mythemeshop'); ?></strong></p>
								<p><?php _e('We apologize for any inconvenience, please hit back on your browser or use the search form below.', 'mythemeshop'); ?></p>
								<?php get_search_form(); ?>
							</div><!--noResults-->
						</div>
					<?php endif; ?>
						<?php if ($options['mts_pagenavigation'] == '1') { ?>
							<?php pagination($additional_loop->max_num_pages);?>
						<?php } else { ?>
							<div class="pnavigation2">
								<div class="nav-previous left"><?php next_posts_link( __( '<span class="meta-nav">&larr;</span> '.'Older posts', 'twentyten' ) ); ?></div>
								<div class="nav-next right"><?php previous_posts_link( __( 'Newer posts'.' <span class="meta-nav">&rarr;</span>', 'twentyten' ) ); ?></div>
							</div>
						<?php } ?>
			</div>
		</article>
<?php get_sidebar(); ?>
<?php get_footer(); ?>