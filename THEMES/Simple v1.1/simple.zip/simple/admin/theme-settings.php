<?php

add_action('init','of_options');

if (!function_exists('of_options')) {
function of_options(){

//Theme Shortname
$shortname = "smp";


//Populate the options array
global $tt_options;
$tt_options = get_option('of_options');


//Access the WordPress Pages via an Array
$tt_pages = array();
$tt_pages_obj = get_pages('sort_column=post_parent,menu_order');    
foreach ($tt_pages_obj as $tt_page) {
$tt_pages[$tt_page->ID] = $tt_page->post_name; }
$tt_pages_tmp = array_unshift($tt_pages, "Select a page:"); 


//Access the WordPress Categories via an Array
$tt_categories = array();  
$tt_categories_obj = get_categories('hide_empty=0');
foreach ($tt_categories_obj as $tt_cat) {
$tt_categories[$tt_cat->cat_ID] = $tt_cat->cat_name;}
$categories_tmp = array_unshift($tt_categories, "Select a category:");


//Arrays for options
$stylesheet_array = array ("light","dark");
$title_size_array = array ("18","22","24","28");


//Advanced Array
$title_fonts = array( "" => "", "Oswald" => "Oswald", "Yanone+Kaffeesatz" => "Yanone Kaffeesatz", "Droid+Serif" => "Droid Serif", "Ubuntu" => "Ubuntu", "Merriweather" => "Merriweather", "Cuprum" => "Cuprum", "Lobster" => "Lobster", "Molengo" => "Molengo", "Raleway" => "Raleway", "Helvetica" => "Helvetica", "Frutiger" => "Frutiger", "Futura" => "Futura", "Garamond" => "Garamond", "Gill+Sans" => "Gill Sans", "Minion" => "Minion", "Univers" => "Univers", "Bodoni" => "Bodoni", "Myriad" => "Myriad", "Avenir" => "Avenir", "Caslon" => "Caslon", "FF+Din" => "FF Din", "Trade+Gothic" => "Trade Gothic", "Baskerville" => "Baskerville", "Akzidenz+Grotesk" => "Akzidenz Grotesk", "Clarendon" => "Clarendon", "Franklin+Gothic" => "Franklin Gothic", "Warnock" => "Warnock", "Allerta" => "Allerta", "Arvo" => "Arvo", "Dancing+Script" => "Dancing Script", "" => "", "arial" => "Arial", "Open+Sans" => "Open Sans", "Lora" => "Lora", "Rokkitt" => "Rokkitt", "News+Cycle" => "News Cycle", "Junge" => "Junge", "Cabin" => "Cabin", "Lekton" => "Lekton", "Goudy+Bookletter+1911" => "Goudy Bookletter 1911", "Crimson+Text" => "Crimson Text", "PT Sans" => "PT+Sans", "Droid+Sans" => "Droid Sans"); 

$content_fonts = array( "" => "", "arial" => "Arial", "Droid+Serif" => "Droid Serif", "Droid+Sans" => "Droid Sans", "Open+Sans" => "Open Sans", "Lora" => "Lora", "Rokkitt" => "Rokkitt", "News+Cycle" => "News Cycle", "Junge" => "Junge", "Cabin" => "Cabin", "Lekton" => "Lekton", "Goudy+Bookletter+1911" => "Goudy Bookletter 1911", "Garamond" => "Garamond", "Univers" => "Univers", "Minion" => "Minion", "Bodoni" => "Bodoni", "Futura" => "Futura", "Caslon" => "Caslon", "Gill+Sans" => "Gill Sans", "Warnock" => "Warnock", "Franklin+Gothic" => "Franklin Gothic", "Baskerville" => "Baskerville", "Clarendon" => "Clarendon", "Trade+Gothic" => "Trade Gothic", "Crimson+Text" => "Crimson Text", "PT Sans" => "PT+Sans", "" => "", "Oswald" => "Oswald", "Yanone+Kaffeesatz" => "Yanone Kaffeesatz", "Ubuntu" => "Ubuntu", "Merriweather" => "Merriweather", "Cuprum" => "Cuprum", "Lobster" => "Lobster", "Molengo" => "Molengo", "Raleway" => "Raleway", "Helvetica" => "Helvetica", "Frutiger" => "Frutiger", "Myriad" => "Myriad", "Avenir" => "Avenir", "FF+Din" => "FF Din", "Akzidenz+Grotesk" => "Akzidenz Grotesk", "Allerta" => "Allerta", "Arvo" => "Arvo", "Dancing+Script" => "Dancing Script", ); 


//Folder Paths for "type" => "images"
$layouturl =  get_template_directory_uri() . '/admin/images/layouts/';
$patternurl =  get_template_directory_uri() . '/admin/images/patterns/';


/*-----------------------------------------------------------------------------------*/
/* Create The Custom Site Options Panel
/*-----------------------------------------------------------------------------------*/
$options = array(); // do not delete this line - sky will fall

/*-----------------------------------------------------------------------------------*/
/* General Theme Settings
/*-----------------------------------------------------------------------------------*/
$options[] = array( "name" => __('General Settings','framework_localize'),
			"type" => "heading");

$options[] = array( "name" => __('Logo Image','framework_localize'),
			"desc" => __('Upload your logo <strong>(225 x 100 px)</strong> using Upload Button or insert image URL.','framework_localize'),
			"id" => $shortname."_logo",
			"std" => "",
			"type" => "upload");

$options[] = array( "name" => __('Favicon','framework_localize'),
			"desc" => __('Upload a <strong>16 x 16 px</strong> image that will represent your website\'s favicon. You can refer to this link for more information on how to make it: <a href="http://www.favicon.cc/" target="blank" rel="nofollow">http://www.favicon.cc/</a>','framework_localize'),
			"id" => $shortname."_favicon",
			"std" => "",
			"type" => "upload");

$options[] = array( "name" => __('FeedBurner URL','framework_localize'),
			"desc" => __('Enter your FeedBurner\'s URL here, ex: <strong>http://feeds.feedburner.com/mythemeshop</strong> and your main feed (http://example.com/feed) will get redirected to the FeedBurner\'s ID entered here.)','framework_localize'),
			"id" => $shortname."_feedburner",
			"std" => "",
			"type" => "text");
			
$options[] = array( "name" => __('Twitter Username','framework_localize'),
			"desc" => __('Enter your Username here.','framework_localize'),
			"id" => $shortname."_twitter_username",
			"std" => "mythemeshopteam",
			"type" => "text");

$options[] = array( "name" => __('Excerpt Length','framework_localize'),
			"desc" => __('Change the excerpt text length, whether to increase it or decrease it by entering the value here.','framework_localize'),
			"id" => $shortname."_excerpt_length",
			"std" => "55",
			"type" => "text");

$options[] = array( "name" => __('Footer Copyright Notice','framework_localize'),
			"desc" => __('Change the <strong>Footer Copyright Text</strong> from here. <strong>Hint</strong>: You can even use our affiliate link.','framework_localize'),
			"id" => $shortname."_copyrights",
			"std" => "",
			"type" => "textarea");

$options[] = array( "name" => __('Header Code','framework_localize'),
			"desc" => __('Enter the codes which you need to place <strong>before closing </head> tag</strong>. (ex: Google Webmaster Tools verification, Bing Webmaster Center, BuySellAds Script, Alexa verification etc.)','framework_localize'),
			"id" => $shortname."_header_code",
			"std" => "",
			"type" => "textarea");
			
$options[] = array( "name" => __('Footer Code','framework_localize'),
			"desc" => __('Enter the codes which you need to place in your footer. <strong>(ex: Google Analytics, Clicky, STATCOUNTER, Woopra, Histats, etc.)</strong>.','framework_localize'),
			"id" => $shortname."_analytics_code",
			"std" => "",
			"type" => "textarea");

$options[] = array( "name" => __('Enable Thumbnails on Homepage','framework_localize'),
			"desc" => __('Check this box to enable thumbnails on Homepage as well as Archive pages.','framework_localize'),
			"id" => $shortname."_thumbnails",
			"std" => "true",
			"type" => "checkbox");

$options[] = array( "name" => __('Pagination','framework_localize'),
			"desc" => __('Enable or Disable <strong>page navigation</strong> which will replace older posts and newer post links with great looking numbered links.','framework_localize'),
			"id" => $shortname."_pagenavigation",
			"std" => "false",
			"type" => "checkbox");

			
/*-----------------------------------------------------------------------------------*/
/* Styling Options
/*-----------------------------------------------------------------------------------*/
$options[] = array( "name" => __('Styling Options','framework_localize'),
			"type" => "heading");

$options[] = array( "name" => __('Layout Style','framework_localize'),
			"desc" => __('Choose from <strong>2 different layouts</strong> for your site.','framework_localize'),
			"id" => $shortname."_layout",
			"std" => "cslayout",
			"type" => "images",
			"options" => array(
				'sclayout' => $layouturl . 'sc.png',
				'cslayout' => $layouturl . 'cs.png',
				));

$options[] = array( "name" => __('Background Color','framework_localize'),
			"desc" => __('Pick any color using <strong>Color Picker</strong> or enter the <strong>hex value</strong> in the input field to make it the background color of your theme. <strong>This setting will be overridden if a Background Pattern is used</strong>.','framework_localize'),
			"id" => $shortname."_bg_color",
			"std" => "",
			"type" => "color");
			
$options[] = array( "name" => __('Background Pattern','framework_localize'),
			"desc" => __('Pick from <strong>16</strong> awesome looking patterns, to make them your site\'s background.','framework_localize'),
			"id" => $shortname."_bg_pattern",
			"std" => "nobg",
			"type" => "images",
			"options" => array(
				'nobg' => $patternurl . 'nobg.png',
				'pattern0' => $patternurl . 'pattern0.png',
				'pattern1' => $patternurl . 'pattern1.png',
				'pattern2' => $patternurl . 'pattern2.png',
				'pattern3' => $patternurl . 'pattern3.png',
				'pattern4' => $patternurl . 'pattern4.png',
				'pattern5' => $patternurl . 'pattern5.png',
				'pattern6' => $patternurl . 'pattern6.png',
				'pattern7' => $patternurl . 'pattern7.png',
				'pattern8' => $patternurl . 'pattern8.png',
				'pattern9' => $patternurl . 'pattern9.png',
				'pattern10' => $patternurl . 'pattern10.png',
				'pattern11' => $patternurl . 'pattern11.png',
				'pattern12' => $patternurl . 'pattern12.png',
				'pattern13' => $patternurl . 'pattern13.png',
				'pattern14' => $patternurl . 'pattern14.png',
				'pattern15' => $patternurl . 'pattern15.png',
				));
			
$options[] = array( "name" => __('Navigation Tab Height','framework_localize'),
			"desc" => __('Define padding in pixels, ex. 30px.'),
			"id" => $shortname."_nav_height",
			"std" => "33",
			"type" => "text");

$options[] = array( "name" => __('Navigation Hover Color','framework_localize'),
			"desc" => __('Pick any color using Color Picker or enter the hex value in the input field to make it the <strong>background hover color</strong> of your secondary navigation menu. This setting will be overridden if a Background Pattern is used.','framework_localize'),
			"id" => $shortname."_nav_color",
			"std" => "",
			"type" => "color");
			
$options[] = array( "name" => __('Navigation Hover Pattern','framework_localize'),
			"desc" => __('Pick from <strong>16</strong> awesome patterns, to make it your secondary navigation menu\'s background hover pattern.','framework_localize'),
			"id" => $shortname."_nav_pattern",
			"std" => "nobg",
			"type" => "images",
			"options" => array(
				'nobg' => $patternurl . 'nobg.png',
				'pattern0' => $patternurl . 'pattern0.png',
				'pattern1' => $patternurl . 'pattern1.png',
				'pattern2' => $patternurl . 'pattern2.png',
				'pattern3' => $patternurl . 'pattern3.png',
				'pattern4' => $patternurl . 'pattern4.png',
				'pattern5' => $patternurl . 'pattern5.png',
				'pattern6' => $patternurl . 'pattern6.png',
				'pattern7' => $patternurl . 'pattern7.png',
				'pattern8' => $patternurl . 'pattern8.png',
				'pattern9' => $patternurl . 'pattern9.png',
				'pattern10' => $patternurl . 'pattern10.png',
				'pattern11' => $patternurl . 'pattern11.png',
				'pattern12' => $patternurl . 'pattern12.png',
				'pattern13' => $patternurl . 'pattern13.png',
				'pattern15' => $patternurl . 'pattern15.png',
				));

$options[] = array( "name" => __('Footer Background Color','framework_localize'),
			"desc" => __('Pick any color using Color Picker or enter the hex value in the input field to make it the <strong>background color</strong> of the footer. This setting will be overridden if a Background Pattern is used.','framework_localize'),
			"id" => $shortname."_footer_bg",
			"std" => "",
			"type" => "color");
			
$options[] = array( "name" => __('Footer background Pattern','framework_localize'),
			"desc" => __('Pick from <strong>16</strong> awesome patterns, to make it your footer\'s Background pattern.','framework_localize'),
			"id" => $shortname."_footer_pattern",
			"std" => "",
			"type" => "images",
			"options" => array(
				'fbg' => $patternurl . 'fbg.png',
				'pattern0' => $patternurl . 'pattern0.png',
				'pattern1' => $patternurl . 'pattern1.png',
				'pattern2' => $patternurl . 'pattern2.png',
				'pattern3' => $patternurl . 'pattern3.png',
				'pattern4' => $patternurl . 'pattern4.png',
				'pattern5' => $patternurl . 'pattern5.png',
				'pattern6' => $patternurl . 'pattern6.png',
				'pattern7' => $patternurl . 'pattern7.png',
				'pattern8' => $patternurl . 'pattern8.png',
				'pattern9' => $patternurl . 'pattern9.png',
				'pattern10' => $patternurl . 'pattern10.png',
				'pattern11' => $patternurl . 'pattern11.png',
				'pattern12' => $patternurl . 'pattern12.png',
				'pattern13' => $patternurl . 'pattern13.png',
				'pattern15' => $patternurl . 'pattern15.png',
				));
				
$options[] = array( "name" => __('Link Color','framework_localize'),
			"desc" => __('Pick any color using Color Picker or enter the hex value in the input field to make it the color of the <strong>Links</strong> on the site.','framework_localize'),
			"id" => $shortname."_link_color",
			"std" => "",
			"type" => "color");
			
$options[] = array( "name" => __('Body Font Color','framework_localize'),
			"desc" => __('Pick any color using Color Picker or enter the hex value in the input field to make it the <strong>Font Color</strong> of Article\'s Text. This setting will be overridden if a Background Pattern is used.','framework_localize'),
			"id" => $shortname."_body_font_color",
			"std" => "",
			"type" => "color");

$options[] = array( "name" => __('Lightbox','framework_localize'),
			"desc" => __('Lightbox is a <strong>stylized pop-up</strong> that permits your readers to view larger versions of images without having to leave the current page. Enable or Disable it from here.','framework_localize'),
			"id" => $shortname."_lightbox",
			"std" => "false",
			"type" => "checkbox");

$options[] = array( "name" => __('Custom CSS','framework_localize'),
			"desc" => __('You can enter your own <strong>custom CSS</strong> here and play with your theme. This will <strong>override</strong> the default CSS used on your site.','framework_localize'),
			"id" => $shortname."_custom_css",
			"std" => "",
			"type" => "textarea");
			
/*-----------------------------------------------------------------------------------*/
/* Single Post
/*-----------------------------------------------------------------------------------*/
$options[] = array( "name" => __('Single Post','framework_localize'),
			"type" => "heading");

$options[] = array( "name" => __('Post Meta Info.','framework_localize'),
			"desc" => __('Use this box to Show or Hide Post Meta Info like <strong>Author name, published date and Categories</strong>.','framework_localize'),
			"id" => $shortname."_headline_meta",
			"std" => "true",
			"type" => "checkbox");

$options[] = array( "name" => __('Breadcrumbs','framework_localize'),
			"desc" => __('Breadcrumbs are great way to <strong>make user-friendly site</strong>, you can enable it by checking this box.','framework_localize'),
			"id" => $shortname."_breadcrumb",
			"std" => "false",
			"type" => "checkbox");
			
$options[] = array( "name" => __('Highlight Author Comment','framework_localize'),
			"desc" => __('Check this box to <strong>highlight Author Comments</strong>.','framework_localize'),
			"id" => $shortname."_author_comment",
			"std" => "false",
			"type" => "checkbox");

$options[] = array( "name" => __('Related Posts','framework_localize'),
			"desc" => __('Check this box if you want to show <strong>Related Posts with Thumbnails</strong> below content area.','framework_localize'),
			"id" => $shortname."_related_posts",
			"std" => "true",
			"type" => "checkbox");

$options[] = array( "name" => __('Tag Links','framework_localize'),
			"desc" => __('Check this box if you want to show <strong>Tag Buttons</strong> placed below related posts.','framework_localize'),
			"id" => $shortname."_tags",
			"std" => "true",
			"type" => "checkbox");

$options[] = array( "name" => __('Author Box','framework_localize'),
			"desc" => __('Check this box if you want to enable <strong>Author Information Box</strong> below article\'s body.','framework_localize'),
			"id" => $shortname."_author_box",
			"std" => "true",
			"type" => "checkbox");
			
$options[] = array( "name" => __('Date in Comments','framework_localize'),
			"desc" => __('Check this box to show <strong>date on comments</strong>.','framework_localize'),
			"id" => $shortname."_comment_date",
			"std" => "true",
			"type" => "checkbox");

/*-----------------------------------------------------------------------------------*/
/* Fonts
/*-----------------------------------------------------------------------------------*/
$options[] = array( "name" => __('Fonts','framework_localize'),
			"type" => "heading");

$options[] = array( "name" => __('Title Font','framework_localize'),
			"desc" => __('Pick from <strong>Top 42 Hand-Picked</strong> Fonts for your titles.','framework_localize'),
			"id" => $shortname."_title_font",
			"std" => "",
			"type" => "select",
			"options" => $title_fonts);

$options[] = array( "name" => __('Title Font Size','framework_localize'),
			"desc" => __('Change <strong>Title</strong> Font Size by entering a value in pixels.','framework_localize'),
			"id" => $shortname."_title_size",
			"std" => "18",
			"type" => "text");

$options[] = array( "name" => __('Body Font','framework_localize'),
			"desc" => __('Pick from <strong>Top 42 Hand-Picked</strong> Fonts for your body text.','framework_localize'),
			"id" => $shortname."_content_font",
			"std" => "14",
			"type" => "select",
			"options" => $content_fonts);


$options[] = array( "name" => __('Body Font Size','framework_localize'),
			"desc" => __('Change <strong>body Font</strong> Size by entering a value in pixels.','framework_localize'),
			"id" => $shortname."_body_size",
			"std" => "14",
			"type" => "text");	

/*-----------------------------------------------------------------------------------*/
/* Social Buttons
/*-----------------------------------------------------------------------------------*/
$options[] = array( "name" => __('Social Buttons','framework_localize'),
			"type" => "heading");


$options[] = array( "name" => __('Social Media Buttons','framework_localize'),
			"desc" => __('Check this box to show social sharing buttons <strong>after article\'s body</strong> text on single pages. This setting will be overridden if Floating Social Media buttons are activated.','framework_localize'),
			"id" => $shortname."_social_buttons",
			"std" => "true",
			"type" => "checkbox");

$options[] = array( "name" => __('Social Buttons on Homepage','framework_localize'),
			"desc" => __('Enable or Disable only <strong>Twitter and Facebook</strong> social sharing buttons on homepage and archive pages.','framework_localize'),
			"id" => $shortname."_home_social",
			"std" => "false",
			"type" => "checkbox");

$options[] = array( "name" => __('Floating Social Buttons','framework_localize'),
			"desc" => __('Enable or Disable the <strong>Floating social sharing buttons</strong> on single posts.','framework_localize'),
			"id" => $shortname."_floating_social",
			"std" => "false",
			"type" => "checkbox");
			
$options[] = array( "name" => __('<strong>Enable or Disable</strong> Social Sharing buttons on Single posts by using check boxes:','framework_localize'),
			"desc" => __('Twitter','framework_localize'),
			"id" => $shortname."_twitter",
			"std" => "true",
			"type" => "checkbox");
			
$options[] = array( "name" => __('','framework_localize'),
			"desc" => __('Google+','framework_localize'),
			"id" => $shortname."_gplus",
			"std" => "true",
			"type" => "checkbox");
			
$options[] = array( "name" => __('','framework_localize'),
			"desc" => __('Facebook Like','framework_localize'),
			"id" => $shortname."_facebook",
			"std" => "true",
			"type" => "checkbox");
			
$options[] = array( "name" => __('','framework_localize'),
			"desc" => __('LinkedIn','framework_localize'),
			"id" => $shortname."_linkedin",
			"std" => "false",
			"type" => "checkbox");
			
$options[] = array( "name" => __('','framework_localize'),
			"desc" => __('Digg','framework_localize'),
			"id" => $shortname."_digg",
			"std" => "false",
			"type" => "checkbox");
			
$options[] = array( "name" => __('','framework_localize'),
			"desc" => __('StumbleUpon','framework_localize'),
			"id" => $shortname."_stumble",
			"std" => "false",
			"type" => "checkbox");
			
$options[] = array( "name" => __('','framework_localize'),
			"desc" => __('Pinterest','framework_localize'),
			"id" => $shortname."_pinterest",
			"std" => "true",
			"type" => "checkbox");

/*-----------------------------------------------------------------------------------*/
/* Advertisement Management
/*-----------------------------------------------------------------------------------*/
$options[] = array( "name" => __('Ad Management','framework_localize'),
			"type" => "heading");

$options[] = array( "name" => __('Below Post Title','framework_localize'),
			"desc" => __('Paste your AdSense, BSA or other Ad code here to show them below article title in single pages.','framework_localize'),
			"id" => $shortname."_posttop_adcode",
			"std" => "",
			"type" => "textarea");

$options[] = array( "name" => __('','framework_localize'),
			"desc" => __('Enter the number of days after which you want to show your below title Ad. Keep it to 0 for disabling this feature.','framework_localize'),
			"id" => $shortname."_posttop_adcode_time",
			"std" => "0",
			"type" => "text");

$options[] = array( "name" => __('Below Post Content','framework_localize'),
			"desc" => __('Paste your AdSense, BSA or other Ad code here to show them below post content in single pages.','framework_localize'),
			"id" => $shortname."_postend_adcode",
			"std" => "",
			"type" => "textarea");

$options[] = array( "name" => __('','framework_localize'),
			"desc" => __('Enter the number of days after which you want to show your below post content Ad. Keep it to 0 for disabling this feature.','framework_localize'),
			"id" => $shortname."_postend_adcode_time",
			"std" => "0",
			"type" => "text");

/*-----------------------------------------------------------------------------------*/
/* Navigation
/*-----------------------------------------------------------------------------------*/
$options[] = array( "name" => __('Navigation','framework_localize'),
			"type" => "heading");

$navnote = '<b>Navigation settings can now be modified from <a href="nav-menus.php">Menus Section</a>.</b>';
$options[] = array( "name" => __('Note','framework_localize'),
			"desc" => "",
			"id" => $shortname."_sample_callout",
			"std" => $navnote,
			"type" => "info");


update_option('of_template',$options); 					  
update_option('of_themename',$themename);   
update_option('of_shortname',$shortname);

}
}
?>