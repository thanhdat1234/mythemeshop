<!DOCTYPE html>
<?php $options = get_option('simple'); ?>
<html class="no-js" lang="en" dir="ltr">

<head>
	<meta charset="UTF-8">
	
	<title><?php wp_title(''); ?></title>
	
	<?php if ($options['mts_favicon'] != '') { ?>
	<link rel="icon" href="<?php echo $options['mts_favicon']; ?>" type="image/x-icon" />
	<?php } ?>
	
	<!--iOS/android/handheld specific -->	
	<link rel="apple-touch-icon" href="apple-touch-icon.png">			
	<meta name="viewport" content="width=device-width, initial-scale=1.0">						
	<meta name="apple-mobile-web-app-capable" content="yes">
	<meta name="apple-mobile-web-app-status-bar-style" content="black">
	
	<link rel="stylesheet" type="text/css" media="all" href="<?php bloginfo( 'stylesheet_url' ); ?>" />
	
	
	<link href='http://fonts.googleapis.com/css?family=Oswald:400,700' rel='stylesheet' type='text/css'>
	<?php if ($options['mts_title_font'] != '') { ?>
		<?php if ($options['mts_title_font'] == 'Arial') { ?>
			<style type="text/css">
				.title, h1,h2,h3,h4,h5,h6, #header-logo h1, #header-logo h2, .secondary-navigation a, .read-more, .widget h3, .total-comments, .reply a, .pagination a, .pagination span, .tags {
					font-family: arial, sans-serif;
				}
			</style>
		<?php } else { ?>
			<link href="http://fonts.googleapis.com/css?family=<?php echo $options['mts_title_font']; ?>:400,400italic,600,600italic,700,700italic" rel="stylesheet" type="text/css">
			<style type="text/css">
				.title, h1,h2,h3,h4,h5,h6, #header-logo h1, #header-logo h2, .secondary-navigation a, .read-more, .widget h3, .total-comments, .reply a, .pagination a, .pagination span {
					font-family: '<?php echo $options['mts_title_font']; ?>', sans-serif;
				}
			</style>
		<?php } ?>
	<?php } ?>
	<?php if($options['mts_lightbox'] == '1') { ?>
		<link rel="stylesheet" href="<?php bloginfo('template_directory'); ?>/css/prettyPhoto.css" type="text/css" media="screen" charset="utf-8" />
<script src="http://ajax.googleapis.com/ajax/libs/jquery/1.6.2/jquery.min.js"></script>
		<script src="<?php bloginfo('template_directory'); ?>/js/jquery.prettyPhoto.js"></script>
		<script type="text/javascript">  
			jQuery(document).ready(function($) {
				$("a[href$='.jpg'], a[href$='.jpeg'], a[href$='.gif'], a[href$='.png']").prettyPhoto({
				slideshow: 5000, /* false OR interval time in ms */
				autoplay_slideshow: false, /* true/false */
				animationSpeed: 'normal', /* fast/slow/normal */
				padding: 40, /* padding for each side of the picture */
				opacity: 0.35, /* Value betwee 0 and 1 */
				showTitle: true, /* true/false */	
				social_tools: false
				});
			})
		</script>
	<?php } ?>
	<?php if ($options['mts_content_font'] != '') { ?>
		<?php if ($options['mts_content_font'] == 'Arial') { ?>
			<style type="text/css">
				body {
					font-family: arial, sans-serif;
				}
			</style>
		<?php } else { ?>
			<link href="http://fonts.googleapis.com/css?family=<?php echo $options['mts_content_font']; ?>" rel="stylesheet" type="text/css">
			<style type="text/css">
				body {
					font-family: '<?php echo $options['mts_content_font']; ?>', sans-serif;
				}
			</style>
		<?php } ?>
	<?php } ?>

	<link rel="pingback" href="<?php bloginfo( 'pingback_url' ); ?>" />

	<?php wp_enqueue_script("jquery"); ?>
	<?php if ( is_singular() ) wp_enqueue_script( 'comment-reply' ); ?>
	<!--[if lt IE 9]>
		<script src="http://html5shim.googlecode.com/svn/trunk/html5.js"></script>
	<![endif]-->
	
	<?php wp_head(); ?>
	<script src="http://ajax.googleapis.com/ajax/libs/jquery/1.6.2/jquery.min.js"></script>
	<script src="<?php echo get_template_directory_uri(); ?>/js/modernizr.min.js"></script>
	<script src="<?php echo get_template_directory_uri(); ?>/js/customscript.js" type="text/javascript"></script>
	
	<style type="text/css">
		body {
			<?php if ($options['mts_bg_pattern_upload'] != '') { ?>
				background-image: url(<?php echo $options['mts_bg_pattern_upload']; ?>);
			<?php } else { ?>
			<?php if($options['mts_bg_pattern'] != '') { ?>
				background: <?php if($options['mts_bg_color'] != '') { ?><?php echo $options['mts_bg_color']; ?><?php } ?> url(<?php echo get_template_directory_uri(); ?>/images/<?php echo $options['mts_bg_pattern']; ?>.png) repeat;
			<?php } ?>
			<?php } ?>
			<?php if ($options['mts_body_font_color'] != '') { ?>
				color: <?php echo $options['mts_body_font_color']; ?>;
			<?php } ?>
			}
		<?php if ($options['mts_logo'] != '') { ?>
			#header-logo h1, #header-logo h2 {
			text-indent: -999em;
			min-width:150px;
			}
			#header-logo h1 a, #header-logo h2 a{
			background: url(<?php echo $options['mts_logo']; ?>) no-repeat;
			min-width: 225px;
			display: block;
			margin-top: 20px;
			min-height: 80px;
			line-height: 50px;
			}
		<?php } ?>
		.secondary-navigation a:hover {
			<?php if($options['mts_nav_color'] != '') { ?>
				background-color: <?php echo $options['mts_nav_color']; ?>;
			<?php } ?>
			<?php if($options['mts_nav_pattern'] != '') { ?>
				background-image: url(<?php echo get_template_directory_uri(); ?>/images/<?php echo $options['mts_nav_pattern']; ?>.png);
			<?php } ?>
			}
		<?php if ($options['mts_link_color'] != '') { ?>
			a{
				color: <?php echo $options['mts_link_color']; ?>;
			}
		<?php } ?>
		<?php if ($options['mts_nav_height'] != '') { ?>
			.secondary-navigation a {
				padding: <?php echo $options['mts_nav_height']; ?> 0;
			}
		<?php } ?>
		<?php if($options['mts_title_size'] != '') { ?>
			.title {
				font-size:<?php echo $options['mts_title_size']; ?>;
				line-height:150%;
			}
		<?php } ?>
		<?php if ($options['mts_body_size'] != '') { ?>
			body {
				font-size:<?php echo $options['mts_body_size']; ?>;
				line-height:150%;
			}
		<?php } ?>
		<?php if($options['mts_headline_meta'] == '0') { ?>
			.post-info {
				display:none;
			}
		<?php } ?>
		<?php if($options['mts_author_comment'] == '1') { ?>
			.bypostauthor {
				border: 1px solid #bbb!important;
			}
		<?php } ?>
		<?php if($options['mts_floating_social'] == '1') { ?>
			.shareit {
				top: 305px;
				left: auto;
				z-index: 0;
				margin: 0 0 0 -95px;
				width: 90px;
				position: fixed;
				overflow: hidden;
				border-radius: 6px;
				-moz-border-radius: 6px;
				-webkit-border-radius: 6px;
				padding-left: 3px;
			}
			.share-item {
				margin: 2px;
			}
		<?php } ?>
		footer {
			<?php if($options['mts_footer_pattern'] != '') { ?>
				background-image:url(<?php echo get_template_directory_uri(); ?>/images/<?php echo $options['mts_footer_pattern']; ?>.png);
			<?php } ?>
			<?php if($options['mts_footer_bg'] != '') { ?>
				background-color:<?php echo $options['mts_footer_bg']; ?>;
			<?php } ?>
			}
		<?php if($options['mts_layout'] == 'sclayout') { ?>
			.article {
				float:right;
			}
			#content_box {
				padding-right: 0;
				padding-left: 40px;
			}
			<?php if($options['mts_floating_social'] == '1') { ?>
				.shareit {
					margin: 0 0 0 660px;
				}
			<?php } ?>
		<?php } ?>
<?php echo $options['mts_custom_css']; ?>
	</style>

	<?php echo $options['mts_header_code']; ?>
</head>

<?php flush(); ?>

<body id ="blog" <?php body_class('main'); ?>>
	<div class="main-container">
		<header class="main-header">
		<div class="container">
				<div id="header-logo">
				
					<?php if( is_front_page() || is_home() || is_404() ) { ?>
							<h1 id="logo">
								<a href="<?php echo home_url(); ?>"><?php bloginfo( 'name' ); ?></a>
							</h1><!-- END #logo -->
					<?php } else { ?>
							<h2 id="logo">
								<a href="<?php echo home_url(); ?>"><?php bloginfo( 'name' ); ?></a>
							</h2><!-- END #logo -->
					<?php } ?>
					<?php if ( ! dynamic_sidebar( 'Header' ) ) : ?>
					<?php endif ?>
					<div class="right head-right">
					<div class="main-navigation">
			<nav id="navigation">
				<?php if ( has_nav_menu( 'primary-menu' ) ) { ?>
					<?php wp_nav_menu( array( 'theme_location' => 'primary-menu', 'menu_class' => 'menu', 'container' => '' ) ); ?>
				<?php } else { ?>
					<ul class="menu">
						<li class="home-tab"><a href="<?php echo home_url(); ?>">Home</a></li>
						<?php wp_list_pages('title_li='); ?>
					</ul>
				<?php } ?><!--#nav-primary-->
			</nav>
			</div>
			<div class="clear"></div>
					<div class="header-search">
				<?php get_search_form( $echo ); ?>
			</div>
			</div>
				</div><!--#header-logo-->
			
			<div class="secondary-navigation">
				<nav id="navigation" >
					<?php if ( has_nav_menu( 'secondary-menu' ) ) { ?>
						<?php wp_nav_menu( array( 'theme_location' => 'secondary-menu', 'menu_class' => 'menu', 'container' => '' ) ); ?>
					<?php } else { ?>
						<ul class="menu">
							<?php wp_list_categories('title_li='); ?>
						</ul>
					<?php } ?>
				</nav>
			</div>
		</div><!--.container-->
		</header>