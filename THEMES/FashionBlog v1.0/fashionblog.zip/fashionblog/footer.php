<?php $options = get_option('fashionblog'); ?>
	</div><!--#page-->
</div><!--.container-->
</div>
	<footer>
		<div class="container">
			<div class="footer-widgets">
				<?php widgetized_footer(); ?>
			</div><!--.footer-widgets-->
		</div><!--.container-->
	</footer><!--footer-->
</div>
<div class="copyrights">
	<?php mts_copyrights_credit(); ?>
</div> 
<?php mts_footer(); ?>
<?php wp_footer(); ?>
</body>
</html>