<?php $mts_options = get_option(MTS_THEME_NAME); ?>
<?php get_header(); ?>
<div id="page">
	<div class="container fixed-width-page">
    <div class="<?php mts_article_class(); ?>">
      <div id="content_box">     
        <h1 class="postsby">
  				<?php if (is_category()) { ?>
  					<span><?php single_cat_title(); ?><?php _e(" Archive", "mythemeshop"); ?></span>
  				<?php } elseif (is_tag()) { ?> 
  					<span><?php single_tag_title(); ?><?php _e(" Archive", "mythemeshop"); ?></span>
  				<?php } elseif (is_author()) { ?>
  					<span><?php  $curauth = (isset($_GET['author_name'])) ? get_user_by('slug', $author_name) : get_userdata(intval($author)); echo $curauth->nickname; _e(" Archive", "mythemeshop"); ?></span> 
  				<?php } elseif (is_day()) { ?>
  					<span><?php _e("Daily Archive:", "mythemeshop"); ?></span> <?php the_time('l, F j, Y'); ?>
  				<?php } elseif (is_month()) { ?>
  					<span><?php _e("Monthly Archive:", "mythemeshop"); ?></span> <?php the_time('F Y'); ?>
  				<?php } elseif (is_year()) { ?>
  					<span><?php _e("Yearly Archive:", "mythemeshop"); ?></span> <?php the_time('Y'); ?>
  				<?php } ?>
  			</h1>
        <?php $j = 1; if ( have_posts() ) : while ( have_posts() ) : the_post(); ?>
          <article class="latestPost latestPoster excerpt <?php echo (++$m % 3 == 0) ? 'last' : ''; ?>" itemscope itemtype="http://schema.org/BlogPosting">
            <?php if ( has_post_thumbnail() ) { ?>
              <a href="<?php the_permalink(); ?>" title="<?php the_title(); ?>" rel="nofollow" class="post-image post-image-left">
                <div class="featured-thumbnail"><?php the_post_thumbnail('featured1',array('title' => '','itemprop'=>'image')); ?>
                  <?php if (function_exists('wp_review_show_total')) wp_review_show_total(true, 'latestPost-review-wrapper'); ?>
                </div>  
              </a>
            <?php } ?> 

            <header>
              <?php if ($mts_options['mts_category_home'] == '1') { ?><div class="post-info thecategory" itemprop="articleSection"><?php mts_the_category(', ') ?></div><?php } ?>
              <h2 class="title front-view-title" itemprop="headline"><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h2>
            </header>

            <div class="front-view-content">
              <?php echo mts_excerpt(15); ?>
            </div>
            <?php mts_the_postinfo(); ?>
          </article>
        <?php $j++; endwhile; endif; ?>
        <?php if (isset($mts_options['mts_pagenavigation_type']) && $mts_options['mts_pagenavigation_type'] == '1' ) { ?>
          <?php $additional_loop = 0; mts_pagination($additional_loop['max_num_pages']); ?>
        <?php } else { ?>
          <div class="pagination pagination-previous-next">
            <ul>
              <li class="nav-previous"><?php next_posts_link( '<i class="fa fa-chevron-left"></i> '. __( 'Previous', 'mythemeshop' ) ); ?></li>
              <li class="nav-next"><?php previous_posts_link( __( 'Next', 'mythemeshop' ).' <i class="fa fa-chevron-right"></i>' ); ?></li>
            </ul>
          </div>
        <?php } ?>
      </div>
    </div>
  <?php get_sidebar(); ?>
</div>
<?php get_footer(); ?>