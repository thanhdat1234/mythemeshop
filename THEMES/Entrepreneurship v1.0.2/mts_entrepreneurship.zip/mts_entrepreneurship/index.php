<?php $mts_options = get_option(MTS_THEME_NAME); ?>
<?php get_header(); ?>
<div id="page">
  <?php if ( !is_paged() && $mts_options['mts_featured_slider'] == '1' ) { ?>
	<div class="full-slider-container clearfix loading">
	  <div id="slider" class="full-slider">
		<?php if ( empty( $mts_options['mts_featured_slider_cat'] ) || !is_array( $mts_options['mts_featured_slider_cat'] ) ) {
		  $mts_options['mts_featured_slider_cat'] = array('0');
		}
		$slider_cat = implode( ",", $mts_options['mts_featured_slider_cat'] );
		$slider_query = new WP_Query('cat='.$slider_cat.'&posts_per_page='.$mts_options['mts_featured_slider_num']);
		while ( $slider_query->have_posts() ) : $slider_query->the_post();
		?>
		  <div style="background:url(<?php echo wp_get_attachment_url( get_post_thumbnail_id(get_the_ID()) ); ?>); background-position: center center; background-repeat:no-repeat; background-size:cover; min-height:400px"> 
			<div>                                 
			  <div class="slide-caption">
				<?php if ($mts_options['mts_category_home'] == '1') { ?><div class="post-info thecategory"><?php mts_the_category(', ') ?></div><?php } ?>
				<h2 class="slide-title"><a href="<?php the_permalink(); ?>" ><?php the_title(); ?></a></h2>
				<?php mts_the_postinfo(); ?>
			  </div>
			</div> 
		  </div>
		<?php endwhile; wp_reset_query(); ?>   
	  </div><!-- .primary-slider -->
	</div><!-- .primary-slider-container -->
  <?php } ?>
  <?php $latest_posts_used = false;
  if ( !empty( $mts_options['mts_featured_categories'] ) ) {
	foreach ( $mts_options['mts_featured_categories'] as $section ) {
	  $category_id = $section['mts_featured_category'];
	  $featured_category_layout = $section['mts_featured_category_layout'];
	  $posts_num = $section['mts_featured_category_postsnum'];
	  if( $category_id === 'latest' && $featured_category_layout =='withsidebar' ) {
		$latest_posts_used = true; ?>
		<div class="container fixed-width-page">
		  <div class="<?php mts_article_class(); ?>">
			<div id="content_box">     
			  <h3 class="featured-category-title"><?php _e( "Latest", "mythemeshop" ); ?></h3>
			  <?php $j = 1; $m=0; if ( have_posts() ) : while ( have_posts() ) : the_post(); ?>
				<article class="latestPost latestPoster excerpt <?php echo (++$m % 3 == 0) ? 'last' : ''; ?>" itemscope itemtype="http://schema.org/BlogPosting">
				  <?php if ( has_post_thumbnail() ) { ?><a href="<?php the_permalink(); ?>" title="<?php the_title(); ?>" rel="nofollow" class="post-image post-image-left">
					<div class="featured-thumbnail"><?php the_post_thumbnail('featured1',array('title' => '','itemprop'=>'image')); ?>
					  <?php if (function_exists('wp_review_show_total')) wp_review_show_total(true, 'latestPost-review-wrapper'); ?>
					</div>  
				  </a><?php } ?> 

				  <header>
					<?php if ($mts_options['mts_category_home'] == '1') { ?><div class="post-info thecategory" itemprop="articleSection"><?php mts_the_category(', ') ?></div><?php } ?>
					<h2 class="title front-view-title" itemprop="headline"><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h2>
				  </header>

				  <div class="front-view-content">
					<?php echo mts_excerpt(15); ?>
				  </div>
				  <?php mts_the_postinfo(); ?>
				</article>
			  <?php $j++; endwhile; endif; ?>
			  <!--Start Pagination-->
			  <?php if ( $m !== 0 ) { // No pagination if there is no posts ?>
				<?php mts_pagination(); ?>
			  <?php } ?>
			</div>
		  </div>
		  <?php get_sidebar(); ?>
		</div>
	  <?php } 
	  elseif( !is_paged() &&  $category_id === 'latest' && $featured_category_layout =='bigcolumn') { ?>
		<div class="full-width-page">
		  <div class="container">
			<h3 class="featured-category-title"><?php _e( "Latest", "mythemeshop" ); ?></h3>
			<?php $j=1; $m=0;  if ( have_posts() ) : while ( have_posts() ) : the_post(); ?>
			  <?php if($j == 1) { ?>
				<article class="latestPost latestPoster excerpt main-post <?php echo (++$m % 3 == 0) ? 'last' : ''; ?>" itemscope itemtype="http://schema.org/BlogPosting">
				  <?php if ( has_post_thumbnail() ) { ?> <a href="<?php the_permalink(); ?>" title="<?php the_title(); ?>" rel="nofollow" class="post-image post-image-left">
					<div class="featured-thumbnail"><?php the_post_thumbnail('featured2',array('title' => '','itemprop'=>'image')); ?>
					<?php if (function_exists('wp_review_show_total')) wp_review_show_total(true, 'latestPost-review-wrapper'); ?></div>  
				  </a> 
				  <?php } ?>

				  <header>
					<?php if ($mts_options['mts_category_home'] == '1') { ?><div class="post-info thecategory" itemprop="articleSection"><?php mts_the_category(', ') ?></div><?php } ?>
					<h2 class="title front-view-title" itemprop="headline"><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h2>
				  </header>

				  <div class="front-view-content">
					<?php echo mts_excerpt(15); ?>
				  </div>
				  <?php mts_the_postinfo(); ?>
				</article> <!--big article-->
			  <?php } else { ?>
				<article class="latestPost latestPoster excerpt small-post <?php echo (++$m % 3 == 0) ? 'last' : ''; ?>" itemscope itemtype="http://schema.org/BlogPosting">
				  <header>
					<?php if ($mts_options['mts_category_home'] == '1') { ?><div class="post-info thecategory" itemprop="articleSection"><?php mts_the_category(', ') ?></div><?php } ?>
					<h2 class="title front-view-title" itemprop="headline"><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h2>
				  </header>

				  <div class="front-view-content">
					<?php echo mts_excerpt(15); ?>
				  </div>
				</article> <!--2nd article-->
			  <?php
			  }
			  ?>
			<?php $j++; endwhile; endif; ?>
			<!--Start Pagination-->
			<?php if ( $m !== 0 ) { // No pagination if there is no posts ?>
			  <?php mts_pagination(); ?>
			<?php } ?>
		  </div>
		</div>
	  <?php } 
	  elseif ( $category_id === 'latest' && $featured_category_layout =='withbanner') { ?>
		<div class="full-width-page">
		  <h3 class="featured-category-title"><?php _e( "Latest", "mythemeshop" ); ?></h3>
		  <?php $j=1; $m=0;  if ( have_posts() ) : while ( have_posts() ) : the_post(); ?>
			<?php if($j == 1)
			{
			?>
			  <article class="latestPost excerpt full-image-1 <?php echo (++$m % 3 == 0) ? 'last' : ''; ?>" itemscope itemtype="http://schema.org/BlogPosting" style="background: url(<?php echo wp_get_attachment_url( get_post_thumbnail_id(get_the_ID()) ); ?>); background-position: center center; background-repeat: no-repeat; background-size: cover;">
				<?php if (mts_get_thumbnail_url()) : ?>
					<meta itemprop="image" content="<?php echo mts_get_thumbnail_url(); ?>" />
				<?php endif; ?>
				<div class="post-image post-image-left">
				  <div class="featured-overlay">
					<?php if ($mts_options['mts_category_home'] == '1') { ?><div class="post-info thecategory" itemprop="articleSection"><?php mts_the_category(', ') ?></div><?php } ?>
					<h2 class="title front-view-title" itemprop="headline"><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h2>
					<?php mts_the_postinfo(); ?>
				  </div>
				</div> 
			  </article> <!--1st article-->
			<?php
			}
			else{}
		  $j++; endwhile; endif; 
		  ?>
		  <div class="page_inner">
			<?php $k=1; $m=0;  if ( have_posts() ) : while ( have_posts() ) : the_post(); ?>
			  <?php if($k == 1) {echo '';}
			  else
			  {
			  ?>
				<article class="latestPost latestPoster excerpt grid-3 <?php echo (++$m % 3 == 0) ? 'last' : ''; ?>" itemscope itemtype="http://schema.org/BlogPosting">
				   <?php if ( has_post_thumbnail() ) { ?><a href="<?php the_permalink(); ?>" title="<?php the_title(); ?>" rel="nofollow" class="post-image post-image-left">
				   <div class="featured-thumbnail"><?php the_post_thumbnail('featured3',array('title' => '','itemprop'=>'image')); ?>
					<?php if (function_exists('wp_review_show_total')) wp_review_show_total(true, 'latestPost-review-wrapper'); ?></div>  
				  </a> <?php } ?>
				  <header>
					<?php if ($mts_options['mts_category_home'] == '1') { ?><div class="post-info thecategory" itemprop="articleSection"><?php mts_the_category(', ') ?></div><?php } ?>
					<h2 class="title front-view-title" itemprop="headline"><a href="<?php the_permalink(); ?>" title="<?php the_title(); ?>"><?php the_title(); ?></a></h2>
				  </header>
				  <div class="front-view-content">
					<?php echo mts_excerpt(12); ?>
				  </div>
				  <?php mts_the_postinfo(); ?>
				</article> <!--2nd article-->
			  <?php
			  }
			  ?>
			<?php $k++; endwhile; endif; ?>
			<?php if ( $m !== 0 ) { // No pagination if there is no posts ?>
			  <?php mts_pagination(); ?>
			<?php } ?>
		  </div>
		</div>
	  <?php } else { ?>
		<?php $cat_query = new WP_Query('cat='.$category_id.'&posts_per_page='.$posts_num); ?>
		  <?php if(!is_paged() && $category_id != 'latest' && $featured_category_layout =='withsidebar') {?>
			<div class="container">
			  <div class="<?php mts_article_class(); ?>">
				<div id="content_box">     
				  <h3 class="featured-category-title"><?php _e( get_cat_name($category_id), "mythemeshop" ); ?></h3>
				  <?php $j = 1; if ($cat_query->have_posts()) : while ($cat_query->have_posts()) : $cat_query->the_post(); ?>
					<article class="latestPost excerpt" itemscope itemtype="http://schema.org/BlogPosting">
					 <?php if ( has_post_thumbnail() ) { ?> <a href="<?php the_permalink(); ?>" title="<?php the_title(); ?>" rel="nofollow" class="post-image post-image-left">
						<div class="featured-thumbnail"><?php the_post_thumbnail('featured1',array('title' => '','itemprop'=>'image')); ?>
						<?php if (function_exists('wp_review_show_total')) wp_review_show_total(true, 'latestPost-review-wrapper'); ?></div>   
					  </a><?php } ?>
					  <header>
						<?php if ($mts_options['mts_category_home'] == '1') { ?><div class="post-info thecategory" itemprop="articleSection"><?php mts_the_category(', ') ?></div><?php } ?>
						<h2 class="title front-view-title" itemprop="headline"><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h2>
					  </header>
					  <div class="front-view-content">
						<?php echo mts_excerpt(15); ?>
					  </div>
					  <?php mts_the_postinfo(); ?>
					</article>
				  <?php $j++; endwhile; endif; wp_reset_postdata();?>
				</div>
			  </div>
			  <?php get_sidebar(); ?>
			</div>
		  <?php } else if( !is_paged() && $category_id != 'latest' && $featured_category_layout =='bigcolumn') { ?>
			<div class="full-width-page">
			  <div class="container">
				<h3 class="featured-category-title"><?php _e(get_cat_name($category_id), "mythemeshop" ); ?></h3>
				<?php $j = 1; if ($cat_query->have_posts()) : while ($cat_query->have_posts()) : $cat_query->the_post(); ?>
				  <?php if($j == 1)
				  {
				  ?>
					<article class="latestPost excerpt main-post" itemscope itemtype="http://schema.org/BlogPosting">
					  <a href="<?php the_permalink(); ?>" title="<?php the_title(); ?>" rel="nofollow" class="post-image post-image-left">
						<div class="featured-thumbnail"><?php the_post_thumbnail('featured2',array('title' => '','itemprop'=>'image')); ?>
						<?php if (function_exists('wp_review_show_total')) wp_review_show_total(true, 'latestPost-review-wrapper'); ?></div>   
					  </a>

					  <header>
						<?php if ($mts_options['mts_category_home'] == '1') { ?><div class="post-info thecategory" itemprop="articleSection"><?php mts_the_category(', ') ?></div><?php } ?>
						<h2 class="title front-view-title" itemprop="headline"><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h2>
					  </header>

					  <div class="front-view-content">
						<?php echo mts_excerpt(15); ?>
					  </div>
					  <?php mts_the_postinfo(); ?>
					</article> <!--big article-->
				  <?php
				  }
				  else
				  {
				  ?>
				  <article class="latestPost excerpt small-post" itemscope itemtype="http://schema.org/BlogPosting">
					<header>
					  <?php if ($mts_options['mts_category_home'] == '1') { ?><div class="post-info thecategory" itemprop="articleSection"><?php mts_the_category(', ') ?></div><?php } ?>
					  <h2 class="title front-view-title" itemprop="headline"><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h2>
					</header>

					<div class="front-view-content">
					  <?php echo mts_excerpt(10); ?>
					</div>
				  </article> <!--2nd article-->
				<?php
				}
				?>
			  <?php $j++; endwhile; endif; wp_reset_postdata();?>
			</div> 
		  </div>        
		<?php } elseif ( !is_paged() && $category_id != 'latest' && $featured_category_layout =='withbanner') { ?>
		  <div class="full-width-page">
			<h3 class="featured-category-title"><?php _e( get_cat_name($category_id), "mythemeshop" ); ?></h3>
			  <?php $j = 1; if ($cat_query->have_posts()) : while ($cat_query->have_posts()) : $cat_query->the_post(); ?>
				<?php if($j == 1)
				{
				?>
				  <article class="latestPost excerpt full-image-1" itemscope itemtype="http://schema.org/BlogPosting" style="background: url(<?php echo wp_get_attachment_url( get_post_thumbnail_id(get_the_ID()) ); ?>); background-position: center center; background-repeat: no-repeat; background-size: cover;">
					<?php if (mts_get_thumbnail_url()) : ?>
						<meta itemprop="image" content="<?php echo mts_get_thumbnail_url(); ?>" />
					<?php endif; ?>
					<div class="post-image post-image-left">
					  <div class="featured-overlay">
						<?php if ($mts_options['mts_category_home'] == '1') { ?><div class="post-info thecategory" itemprop="articleSection"><?php mts_the_category(', ') ?></div><?php } ?>
						<h2 class="title front-view-title" itemprop="headline"><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h2>
						<?php mts_the_postinfo(); ?>
					  </div>
					</div> 
				  </article> <!--1st article-->
				<?php
				}
				else{} ?>
			  <?php $j++; endwhile; endif; wp_reset_postdata();?>
			  <div class="page_inner">
				<?php $k = 1; if ($cat_query->have_posts()) : while ($cat_query->have_posts()) : $cat_query->the_post(); ?>
				  <?php if($k == 1) {echo '';}
				  else
				  {
				  ?>
					<article class="latestPost excerpt grid-3" itemscope itemtype="http://schema.org/BlogPosting">
					  <a href="<?php the_permalink(); ?>" title="<?php the_title(); ?>" rel="nofollow" class="post-image post-image-left">
						<div class="featured-thumbnail"><?php the_post_thumbnail('featured3',array('title' => '','itemprop'=>'image')); ?>
						<?php if (function_exists('wp_review_show_total')) wp_review_show_total(true, 'latestPost-review-wrapper'); ?></div>  
					  </a>

					  <header>
						<?php if ($mts_options['mts_category_home'] == '1') { ?><div class="post-info thecategory" itemprop="articleSection"><?php mts_the_category(', ') ?></div><?php } ?>
						<h2 class="title front-view-title" itemprop="headline"><a href="<?php the_permalink(); ?>" title="<?php the_title(); ?>"><?php the_title(); ?></a></h2>
					  </header>

					  <div class="front-view-content">
						<?php echo mts_excerpt(15); ?>
					  </div>
					  <?php mts_the_postinfo(); ?>
					</article>
				  <?php
				  }
				  ?>
				<?php $k++; endwhile; endif; wp_reset_postdata();?>
			  </div>
			</div>
		<?php } 
	  }
	}
  } ?>
<?php get_footer(); ?>