<?php
/**
 * Template Name: Contact Page
 */
$mts_options = get_option(MTS_THEME_NAME);
get_header(); ?>
<div id="page" class="<?php mts_single_page_class(); ?>">
<?php $header_animation = mts_get_post_header_effect();
	if ( have_posts() ) while ( have_posts() ) : the_post();
		$header_animation = mts_get_post_header_effect();
		$mts_featured_image = wp_get_attachment_url( get_post_thumbnail_id(get_the_ID()) );
			
		if (!empty($mts_featured_image)) {
			if ( 'parallax' === $header_animation ) {
				if (mts_get_thumbnail_url()) : ?>
			        <div class="single-featured-thumbnail" id="parallax" <?php echo 'style="background-image: url('.mts_get_thumbnail_url().');"'; ?>>
			    <?php endif;
			} else if ( 'zoomout' === $header_animation ) {
				if (mts_get_thumbnail_url()) : ?>
			        <div  id="zoom-out-effect"><div class="single-featured-thumbnail" id="zoom-out-bg" <?php echo 'style="background-image: url('.mts_get_thumbnail_url().');"'; ?>>
			    <?php endif;
			} else { ?>
		 		<div class="single-featured-thumbnail" style="background: url(<?php echo $mts_featured_image; ?>); background-repeat: no-repeat; background-size: cover;">
		 	<?php } ?>
		        <header>
		            <?php if ($mts_options['mts_category_single'] == '1') { ?><div class="post-info thecategory" itemprop="articleSection"><?php mts_the_category(', ') ?></div><?php } ?>
		            <h1 class="title front-view-title"><?php the_title(); ?></h1>            
		        </header><!--.headline_area-->
	       	</div>
	       	<div class="container fixed-width-page">
	       		<article class="<?php mts_article_class(); ?>" itemscope itemtype="http://schema.org/BlogPosting">
	    <?php } else { ?>
	    	<div class="container fixed-width-page">
	    		<article class="<?php mts_article_class(); ?>" itemscope itemtype="http://schema.org/BlogPosting">
			    	<header class="no-thumb">
			    		<?php if ($mts_options['mts_category_single'] == '1') { ?><div class="post-info thecategory" itemprop="articleSection"><?php mts_the_category(', ') ?></div><?php } ?>
			            <h1 class="title front-view-title"><?php the_title(); ?></h1>     
			        </header><!--.headline_area-->
	    <?php } ?>

			<div id="content_box">
	     		<div id="post-<?php the_ID(); ?>" <?php post_class('g post'); ?>>
			        <div class="single_post">
						<?php if ($mts_options['mts_breadcrumb'] == '1') { ?>
							<div class="breadcrumb" xmlns:v="http://rdf.data-vocabulary.org/#"><?php mts_the_breadcrumb(); ?></div>
						<?php } ?>
						<div class="post-single-content box mark-links entry-content">
							<div class="thecontent" itemprop="articleBody">
								<?php the_content(); ?>
								<?php mts_contact_form() ?>
							</div>
							<?php wp_link_pages(array('before' => '<div class="pagination">', 'after' => '</div>', 'link_before'  => '<span class="current"><span class="currenttext">', 'link_after' => '</span></span>', 'next_or_number' => 'next_and_number', 'nextpagelink' => __('Next','mythemeshop'), 'previouspagelink' => __('Previous','mythemeshop'), 'pagelink' => '%','echo' => 1 )); ?>
						</div><!--.post-single-content-->
					</div>
				</div>
				<?php comments_template( '', true ); ?>
			</div>
		</article>
		<?php endwhile; /* end loop */ ?>
		<?php get_sidebar(); ?>
	</div>
<?php get_footer(); ?>