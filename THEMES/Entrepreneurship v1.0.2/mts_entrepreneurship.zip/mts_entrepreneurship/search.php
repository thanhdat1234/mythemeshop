<?php $mts_options = get_option(MTS_THEME_NAME); ?>
<?php get_header(); ?>
<div id="page">
	<div class="container fixed-width-page">
    <div class="<?php mts_article_class(); ?>">
      <div id="content_box">   
		    <h1 class="postsby">
				  <span><?php _e("Search Results for:", "mythemeshop"); ?></span> <?php the_search_query(); ?>
	      </h1>
			  <?php $j = 1; if ( have_posts() ) : while ( have_posts() ) : the_post(); ?>
          <article class="latestPost latestPoster excerpt <?php echo (++$m % 3 == 0) ? 'last' : ''; ?>" itemscope itemtype="http://schema.org/BlogPosting">
            <?php if ( has_post_thumbnail() ) { ?>
              <a href="<?php the_permalink(); ?>" title="<?php the_title(); ?>" rel="nofollow" class="post-image post-image-left">
                <div class="featured-thumbnail"><?php the_post_thumbnail('featured1',array('title' => '','itemprop'=>'image')); ?>
                  <?php if (function_exists('wp_review_show_total')) wp_review_show_total(true, 'latestPost-review-wrapper'); ?>
                </div>  
              </a>
            <?php } ?> 

            <header>
              <?php if ($mts_options['mts_category_home'] == '1') { ?><div class="post-info thecategory" itemprop="articleSection"><?php mts_the_category(', ') ?></div><?php } ?>
              <h2 class="title front-view-title" itemprop="headline"><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h2>
            </header>

            <div class="front-view-content">
              <?php echo mts_excerpt(15); ?>
            </div>
            <?php mts_the_postinfo(); ?>
          </article>
        <?php $j++; endwhile; else: ?>
          <div class="no-results">
  					<h2><?php _e('We apologize for any inconvenience, please hit back on your browser or use the search form below.', 'mythemeshop'); ?></h2>
  					<?php get_search_form(); ?>
  				</div><!--noResults-->
			  <?php endif; ?>
        <?php if ( $j !== 0 ) { // No pagination if there is no posts ?>
  				<?php mts_pagination(); ?>
  			<?php } ?>
		  </div>
    </div>
  <?php get_sidebar(); ?>
  </div>
<?php get_footer(); ?>