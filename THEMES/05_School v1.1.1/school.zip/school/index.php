<?php
$mts_options = get_option(MTS_THEME_NAME); 
$homepage_layout = array(
    'slider'     => 'Slider',
    'highlights' => 'Highlights',
    'widgetarea' => 'Wiget Area',
);
get_header(); ?>
<!-- Start Introduction -->
<div class="container intro-slider">
    <?php $mts_options = get_option(MTS_THEME_NAME);
    if ( !empty($mts_options['mts_custom_slider']) && is_array($mts_options['mts_custom_slider'])) { ?>
        <div class="slider-container clearfix">
            <div class="flex-container loading">
                <div id="slider" class="slider2">
                    <ul class="slides">
                        <?php foreach($mts_options['mts_custom_slider'] as $slide) : ?>
                            <li>
                                <div style="background-image: url('<?php $image = wp_get_attachment_image_src( $slide['mts_custom_slider_image'], 'full' ); echo $image[0]; ?>')">
                                <?php if($slide['mts_custom_slider_title'] != '' || $slide['mts_custom_slider_text'] != ''): ?>
                                    <div class="slider-content">
                                        <?php  
                                        $button['mts_intro_button_label'] = str_replace("\n\r", "\n",$slide['mts_custom_slider_title']);
                                        $btn_texts  = explode("\n", $button['mts_intro_button_label']);
                                        $label      = !empty($btn_texts[0]) ? $btn_texts[0] : '';
                                        $boldText   = !empty($btn_texts[1]) ? $btn_texts[1] : '';
                                        ?>
                                        <span class="text-section">                                                
                                            <?php if($slide['mts_custom_slider_title'] != ''): ?>
                                                <h2><span class="button-label"><?php echo $label; ?></span><br>
                                                <span class="button-bold-text"><?php echo $boldText; ?></span></h2>
                                            <?php endif; ?>

                                            <?php if($slide['mts_custom_slider_text'] != ''): ?>
                                                <p class="slidertext"><?php echo $slide['mts_custom_slider_text']; ?></p>
                                            <?php endif; ?>
                                            
                                            <?php if($slide['mts_custom_slider_link'] != ''): ?>
                                                <a class="button" href="<?php echo $slide['mts_custom_slider_link']; ?>" style="background-color:<?php echo $slide['mts_custom_slider_button_bg']; ?>"><?php echo $slide['mts_custom_slider_button_label']; ?></a>
                                            <?php endif; ?>
                                        </span>   
                                    </div>
                                <?php endif; ?>
                                </div>
                            </li>
                        <?php endforeach; ?>
                    </ul>
                </div>
            </div>
        </div>
    <?php } ?>
</div>
<!-- End Introduction -->
</div><!--.header-wrap-->
<!-- Start Highlights -->
<?php if ( ! empty( $mts_options['mts_homepage_highlights'] ) ) {
    if(!empty($mts_options['mts_highlights'])) { ?>
    <div class="intro-outer-container">
        <div class="container">
            <div id="homepage-highlights" class="highlights-section">
                 <div class="slides_container clearfix loading">
                    <div id="highlights" class="slides">
                        <?php foreach($mts_options['mts_highlights'] as $highlight) : ?>
                            <div class="highlight" >
                                <div class="top-line"><span class="highlight-icon" style="color: <?php echo $highlight['mts_highlight_icon_color']; ?>"><i class="fa fa-<?php echo $highlight['mts_highlight_icon_select']; ?> hg highlight-head-icon-color"></i></span></div>
                                <h3 class="highlight-title"><?php echo $highlight['mts_highlight_title']; ?></h3>
                                <p class="highlight-desc"><?php echo $highlight['mts_highlight_description']; ?></p>
                            </div>                      
                        <?php endforeach; ?>
                    </div>    
                </div>
            </div>
        </div>
    </div>
<?php }
} ?>
<!-- End Highlights -->
<!-- Start Home Widgets -->
<?php $top_footer_num = (!empty($mts_options['mts_top_footer_num']) && $mts_options['mts_top_footer_num'] == 4) ? 4 : 3;
      if ($mts_options['mts_top_footer']) { ?>
    <div class="widgetarea-outer-container">
        <div class="container">
            <div class="footer-widgets top-footer-widgets widgets-num-<?php echo $top_footer_num; ?>">
                <div class="f-widget f-widget-1">
                    <?php if ( !function_exists('dynamic_sidebar') || !dynamic_sidebar('footer-top') ) : ?><?php endif; ?>
                </div>
                <div class="f-widget f-widget-2">
                    <?php if ( !function_exists('dynamic_sidebar') || !dynamic_sidebar('footer-top-2') ) : ?><?php endif; ?>
                </div>
                <div class="f-widget f-widget-3 <?php echo ($top_footer_num == 3) ? 'last' : ''; ?>">
                    <?php if ( !function_exists('dynamic_sidebar') || !dynamic_sidebar('footer-top-3') ) : ?><?php endif; ?>
                </div>
                <?php if ($top_footer_num == 4) : ?>
                    <div class="f-widget f-widget-4 last">
                        <?php if ( !function_exists('dynamic_sidebar') || !dynamic_sidebar('footer-top-4') ) : ?><?php endif; ?>
                    </div>
                <?php endif; ?>
            </div><!--.top-footer-widgets-->
        </div>
    </div>
<?php } ?>
<!-- End Home Widgets -->
<?php get_footer(); ?>