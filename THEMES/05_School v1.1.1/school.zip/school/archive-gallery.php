<?php 
	$mts_options = get_option(MTS_THEME_NAME);	
	get_header(); 
?>
<!-- header section -->
	<div class="page-header clearfix">
		<div class="container">
			<h1 class="title entry-title"><?php echo post_type_archive_title(); ?></h1>
			<?php if ($mts_options['mts_breadcrumb'] == '1') { ?>
				<div class="breadcrumb" xmlns:v="http://rdf.data-vocabulary.org/#"><?php mts_the_breadcrumb(); ?></div>
			<?php } ?>
			<div id="filters">
	            <ul class="option-set" data-option-key="filter">
	            <?php  ?>    
	                <li>
	                    <a href="<?php echo get_post_type_archive_link( 'gallery' ); ?>" class="selected" data-category="all"><?php _e("All","mythemeshop"); ?></a>
	                </li>
					<?php wp_list_categories(array('title_li' => '','taxonomy' => 'gallery_category')); ?>
	            </ul>
			</div>
		</div>		
	</div>
</div><!--.header-wrap-->

<div class="gallery-outer-container">
	<div class="container">
		<div class="gallery-row clearfix">
			<div id="page" class="gallery-section">
				<div class="ss-full-width clearfix">
					<?php $paged = 1;
					if ( get_query_var('paged') ) $paged = get_query_var('paged');
					if ( get_query_var('page') ) $paged = get_query_var('page');
	                $gallery_query = new WP_Query();
	                $gallery_query->query('post_type=gallery&order=DESC&ignore_sticky_posts=1&paged='.$paged.'&posts_per_page='.$mts_options['mts_gallery_items']);
					while ($gallery_query->have_posts()) : $gallery_query->the_post();

		                if (has_post_thumbnail()) {
							$thumb = wp_get_attachment_image_src( get_post_thumbnail_id($post->ID),'gallerythumb');							
		                } else {
		                    $thumb = array(get_template_directory_uri().'/images/nothumb-portfolio.png');
		                } ?>
			            <article class="latestPost excerpt">
							<div class="gallery-item">
								<a href="<?php the_permalink(); ?>">
									<img src="<?php echo $thumb[0]; ?>" width="200" height="200" alt="<?php the_title(); ?>"/>
									<div class="overlay">
			                        	<div class="overlay_container">                                
			                                <span class="button"><i class="fa fa-chain"></i></span>
			                            </div>                             
		                        	</div>
								</a>
							</div>
						</article><!--.post excerpt-->
					<?php endwhile; ?>
					
					<?php if ( $gallery_query->max_num_pages > 1 ) { ?>
						<div class="gallery-pagination clearfix">
							<!--Start Pagination-->
				            <?php if (isset($mts_options['mts_gallery_navigation_type']) && $mts_options['mts_gallery_navigation_type'] == '1' ) { ?>
				                <?php mts_pagination(); ?> 
							<?php } else { ?>
								<div class="pagination">
									<ul>
										<li class="nav-previous"><?php next_posts_link( __( '&larr; '.'Older posts', 'mythemeshop' ) ); ?></li>
										<li class="nav-next"><?php previous_posts_link( __( 'Newer posts'.' &rarr;', 'mythemeshop' ) ); ?></li>
									</ul>
								</div>
							<?php } ?>
							<!--End Pagination-->
			            </div>
			        <?php } ?>
				</div>
			</div>
		</div>
	</div>
</div>
<?php get_footer(); ?>