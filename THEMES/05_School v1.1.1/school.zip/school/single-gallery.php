<?php get_header(); ?>
<?php $mts_options = get_option(MTS_THEME_NAME); ?>
<!-- header section -->
	<div class="page-header clearfix">
		<div class="container single">
			<h3 class="title entry-title"><?php _e('Gallery','mythemeshop'); ?></h3>
			<?php if ($mts_options['mts_breadcrumb'] == '1') { ?>
				<div class="breadcrumb" xmlns:v="http://rdf.data-vocabulary.org/#"><?php mts_the_breadcrumb(); ?></div>
			<?php } ?>
		</div>		
	</div>
</div><!--.header-wrap-->
<div id="page" class="single">
	<article class="article ss-full-width" itemscope itemtype="http://schema.org/BlogPosting">
		<div id="content_box" >
			<?php if ( have_posts() ) while ( have_posts() ) : the_post(); ?>
				<div id="post-<?php the_ID(); ?>" <?php post_class('g post'); ?>>
					<div class="single_post">
						<div class="single-featured">
							<?php the_post_thumbnail( 'full', array( 'title' => '' ) ); ?>
						</div>
						<header class="gallery-header">
							<h1 class="title single-title gallery-title entry-title" itemprop="headline"><?php the_title(); ?></h1>
							<?php if (isset($mts_options['mts_social_button_position']) && $mts_options['mts_social_button_position'] == 'top') mts_social_buttons(); ?>
						</header><!--.headline_area-->
						<div class="post-single-content box mark-links entry-content">
                            <div class="thecontent" itemprop="articleBody">
		                        <?php the_content(); ?>
							</div>
                            <?php wp_link_pages(array('before' => '<div class="pagination">', 'after' => '</div>', 'link_before'  => '<span class="current"><span class="currenttext">', 'link_after' => '</span></span>', 'next_or_number' => 'next_and_number', 'nextpagelink' => __('Next','mythemeshop'), 'previouspagelink' => __('Previous','mythemeshop'), 'pagelink' => '%','echo' => 1 )); ?>
							<?php if (empty($mts_options['mts_social_button_position']) || $mts_options['mts_social_button_position'] == 'bottom' || $mts_options['mts_social_button_position'] == 'floating') mts_social_buttons(); ?>
							<?php if($mts_options['mts_tags'] == '1') { ?>
								<div class="tags"><?php mts_the_tags('<span class="tagtext">'.__('Tags','mythemeshop').':</span>',' ') ?></div>
							<?php } ?>
						</div>
					</div><!--.post-content box mark-links--> 
				</div><!--.g post-->
			<?php endwhile; /* end loop */ ?>
		</div>
	</article>
<?php get_footer(); ?>