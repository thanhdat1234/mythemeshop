<?php $mts_options = get_option( MTS_THEME_NAME ); ?>
<?php get_header(); ?>
<!-- header section -->
    <div class="page-header clearfix">
		<div class="container single">
			<h1 class="title entry-title"><?php _e('Events','mythemeshop'); ?></h1>
			<?php if ($mts_options['mts_breadcrumb'] == '1') { ?>
				<div class="breadcrumb" xmlns:v="http://rdf.data-vocabulary.org/#"><?php mts_the_breadcrumb(); ?></div>
			<?php } ?>
		</div>		
	</div>
</div><!--.header-wrap-->
<div class="blog-outer-container clearfix">
	<div class="container">
		<div id="homepage-blog" class="blog-row clearfix">
            <div id="page" class="blog-section">
                <div class="<?php mts_article_class(); ?>">
                    <div id="content_box">				
                        <?php $j = 0;
                        if ( get_query_var('paged') ) $paged = get_query_var('paged');
                        if ( get_query_var('page') ) $paged = get_query_var('page');
                        $gallery_query = new WP_Query();
                        $gallery_query->query('post_type=events&order=ASC&ignore_sticky_posts=1&paged='.$paged.'&posts_per_page='.$mts_options['mts_gallery_items']);
                        while ($gallery_query->have_posts()) : $gallery_query->the_post(); 
                        ?>
                            <article class="latestPost excerpt  <?php echo (++$j % 3 == 0) ? 'last' : ''; ?>" itemscope itemtype="http://schema.org/BlogPosting">
                                <header>
                                    <div class="event-details">
            	            			<p><span><?php
                                        $time = get_post_meta(get_the_ID(),'mts_events_starttime', true);
                                        $shortdesc = get_post_meta(get_the_ID(),'mts_events_desc', true);
                                        echo $time; ?></span></p>
            	            		</div>
                                    <h2 class="title front-view-title" itemprop="headline"><a href="<?php the_permalink() ?>" title="<?php the_title(); ?>"><?php the_title(); ?></a></h2>
                                </header>

                                <?php if (empty($mts_options['mts_full_posts'])) : ?>
                                    <div class="front-view-content">
                                        <?php echo mts_excerpt(55); ?>
                                    </div>
                                    <?php mts_readmore(); ?>
                                <?php else : ?>
                                    <div class="front-view-content full-post">
                                        <?php the_content(); ?>
                                    </div>
                                    <?php if (mts_post_has_moretag()) : ?>
                                        <?php mts_readmore(); ?>
                                    <?php endif; ?>
                                <?php endif; ?>
                            </article><!--.post excerpt-->
                        <?php endwhile; ?>
                    </div>
                    <!--Start Pagination-->
                    <?php if (isset($mts_options['mts_pagenavigation_type']) && $mts_options['mts_pagenavigation_type'] == '1' ) { ?>
                        <?php mts_pagination(); ?> 
                    <?php } else { ?>
                        <div class="pagination">
                            <ul>
                                <li class="nav-previous"><?php next_posts_link( __( '&larr; '.'Older posts', 'mythemeshop' ) ); ?></li>
                                <li class="nav-next"><?php previous_posts_link( __( 'Newer posts'.' &rarr;', 'mythemeshop' ) ); ?></li>
                            </ul>
                        </div>
                    <?php } ?>
                    <!--End Pagination-->
                </div>
                <?php get_sidebar(); ?>
            </div> 
        </div><!-- end blog-row -->
    </div><!-- end container -->
</div><!-- end blog-outer-container -->
<?php get_footer(); ?>