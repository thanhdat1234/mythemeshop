<?php $mts_options = get_option(MTS_THEME_NAME);
// default = 3
$bottom_footer_num = (!empty($mts_options['mts_bottom_footer_num']) && $mts_options['mts_bottom_footer_num'] == 4) ? 4 : 3;
?>
	</div><!--#page-->
	<footer class="footer" role="contentinfo" itemscope itemtype="http://schema.org/WPFooter">
		<div class="container">            
            <?php if ($mts_options['mts_bottom_footer']) : ?>
                <div class="footer-widgets bottom-footer-widgets widgets-num-<?php echo $bottom_footer_num;?>">
    				<div class="f-widget f-widget-1">
    					<?php if ( !function_exists('dynamic_sidebar') || !dynamic_sidebar('footer-bottom') ) : ?><?php endif; ?>
    				</div>
    				<div class="f-widget f-widget-2">
    					<?php if ( !function_exists('dynamic_sidebar') || !dynamic_sidebar('footer-bottom-2') ) : ?><?php endif; ?>
    				</div>
    				<div class="f-widget f-widget-3 <?php echo ($bottom_footer_num == 3) ? 'last' : ''; ?>">
    					<?php if ( !function_exists('dynamic_sidebar') || !dynamic_sidebar('footer-bottom-3') ) : ?><?php endif; ?>
    				</div>
                    <?php if ($bottom_footer_num == 4) : ?>
                    <div class="f-widget f-widget-4 last">
    					<?php if ( !function_exists('dynamic_sidebar') || !dynamic_sidebar('footer-bottom-4') ) : ?><?php endif; ?>
    				</div>
                    <?php endif; ?>
    			</div><!--.bottom-footer-widgets-->
            <?php endif; ?>
		</div><!--.container-->
        <div class="copyrights">
            <div class="container">
                <?php mts_copyrights_credit(); ?>
            </div>
        </div> 
	</footer><!--footer-->
</div><!--.main-container-->
<?php mts_footer(); ?>
<?php wp_footer(); ?>
</body>
</html>