<?php $mts_options = get_option( MTS_THEME_NAME ); ?>
<?php get_header(); ?>
<!-- header section -->
    <div class="page-header clearfix">
		<div class="container single">
			<h1 class="title entry-title"><?php _e('Blog','mythemeshop'); ?></h1>
			<?php if ($mts_options['mts_breadcrumb'] == '1') { ?>
				<div class="breadcrumb" xmlns:v="http://rdf.data-vocabulary.org/#"><?php mts_the_breadcrumb(); ?></div>
			<?php } ?>
		</div>		
	</div>
</div><!--.header-wrap-->
<div class="blog-outer-container clearfix">
	<div class="container">
		<div id="homepage-blog" class="blog-row clearfix">
            <div id="page" class="blog-section">
				<article class="article">
					<div id="content_box" >
						<header>
							<div class="title">
								<h1><?php _e('Error 404 Not Found', 'mythemeshop'); ?></h1>
							</div>
						</header>
						<div class="post-content">
							<p><?php _e('Oops! We couldn\'t find this Page.', 'mythemeshop'); ?></p>
							<p><?php _e('Please check your URL or use the search form below.', 'mythemeshop'); ?></p>
							<?php get_search_form();?>
						</div><!--.post-content--><!--#error404 .post-->
					</div><!--#content-->
				</article>
				<?php get_sidebar(); ?>
			</div> 
        </div><!-- end blog-row -->
    </div><!-- end container -->
</div><!-- end blog-outer-container -->
<?php get_footer(); ?>