<?php get_header(); ?>
<?php $mts_options = get_option(MTS_THEME_NAME); ?>
<!-- header section -->
    <div class="page-header clearfix">
        <div class="container single">
            <h3 class="title entry-title"><?php _e('Event','mythemeshop'); ?></h3>
            <?php if ($mts_options['mts_breadcrumb'] == '1') { ?>
                <div class="breadcrumb" xmlns:v="http://rdf.data-vocabulary.org/#"><?php mts_the_breadcrumb(); ?></div>
            <?php } ?>
        </div>      
    </div>
</div><!--.header-wrap-->
<div class="blog-outer-container clearfix">
    <div class="container">
        <div id="homepage-blog" class="blog-row clearfix">
            <div id="page" class="blog-section single">
                <article class="<?php mts_article_class(); ?>" itemscope itemtype="http://schema.org/BlogPosting">
                    <div id="content_box" >
                        <?php if ( have_posts() ) while ( have_posts() ) : the_post(); ?>
                            <div id="post-<?php the_ID(); ?>" <?php post_class('g post'); ?>>
                                <div class="single_post">                                             
                                    <header class="event-header">
                                        <?php
                                            $date = get_post_meta(get_the_ID(),'mts_events_startdate', true);
                                            
                                            $time = get_post_meta(get_the_ID(),'mts_events_starttime', true);
                                            $shortdesc = get_post_meta(get_the_ID(),'mts_events_desc', true);
                                            $dat = date("d", $date);
                                            $month  = date("M", $date); 
                                        ?>      
                                        <div class="event-date">
                                            <span class="event-cal-date"><?php echo $dat; ?></span>
                                            <span class="event-cal-month"><h3 class="month"><?php echo $month; ?></h3></span>
                                        </div> 
                                        <h1 class="title single-title event-title entry-title" itemprop="headline"><?php the_title(); ?></h1>
                                        <div class="event-details">
                                            <p><span><?php
                                            $time = get_post_meta(get_the_ID(),'mts_events_starttime', true);
                                            $shortdesc = get_post_meta(get_the_ID(),'mts_events_desc', true);
                                            echo $time; ?></span></p>
                                        </div>
                                    </header><!--.headline_area-->
                                    <div class="post-single-content box mark-links entry-content">
                                        <?php if (isset($mts_options['mts_social_button_position']) && $mts_options['mts_social_button_position'] == 'top') mts_social_buttons(); ?>
                                        <?php if ($mts_options['mts_posttop_adcode'] != '') { ?>
                                            <?php $toptime = $mts_options['mts_posttop_adcode_time']; if (strcmp( date("Y-m-d", strtotime( "-$toptime day")), get_the_time("Y-m-d") ) >= 0) { ?>
                                                <div class="topad">
                                                    <?php echo do_shortcode($mts_options['mts_posttop_adcode']); ?>
                                                </div>
                                            <?php } ?>
                                        <?php } ?>
                                        <div class="thecontent" itemprop="articleBody">
                                            <?php the_content(); ?>
                                        </div>
                                        <?php wp_link_pages(array('before' => '<div class="pagination">', 'after' => '</div>', 'link_before'  => '<span class="current"><span class="currenttext">', 'link_after' => '</span></span>', 'next_or_number' => 'next_and_number', 'nextpagelink' => __('Next','mythemeshop'), 'previouspagelink' => __('Previous','mythemeshop'), 'pagelink' => '%','echo' => 1 )); ?>
                                        <?php if ($mts_options['mts_postend_adcode'] != '') { ?>
                                            <?php $endtime = $mts_options['mts_postend_adcode_time']; if (strcmp( date("Y-m-d", strtotime( "-$endtime day")), get_the_time("Y-m-d") ) >= 0) { ?>
                                                <div class="bottomad">
                                                    <?php echo do_shortcode($mts_options['mts_postend_adcode']); ?>
                                                </div>
                                            <?php } ?>
                                        <?php } ?> 
                                        <?php if (empty($mts_options['mts_social_button_position']) || $mts_options['mts_social_button_position'] == 'bottom' || $mts_options['mts_social_button_position'] == 'floating') mts_social_buttons(); ?>
                                        <?php if($mts_options['mts_tags'] == '1') { ?>
                                            <div class="tags"><?php mts_the_tags('<span class="tagtext">'.__('Tags','mythemeshop').':</span>',' ') ?></div>
                                        <?php } ?>
                                    </div>
                                </div><!--.post-content box mark-links-->
                            </div><!--.g post-->
                            <?php comments_template( '', true ); ?>
                        <?php endwhile; /* end loop */ ?>
                    </div>
                </article>
                <?php get_sidebar(); ?>
            </div>
        </div><!-- end blog-row -->
    </div><!-- end container -->
</div><!-- end blog-outer-container -->
<?php get_footer(); ?>