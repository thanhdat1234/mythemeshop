<?php
/*-----------------------------------------------------------------------------------

	Plugin Name: SchoolTheme Open Hours Widget
	Version: 1.0
	
-----------------------------------------------------------------------------------*/
class mts_openhours_widget extends WP_Widget {

	public function __construct() {
		
		parent::__construct(
	 		'mts_openhours_widget',
			__('MyThemeShop: Open Hours Widget','mythemeshop'),
			array( 'description' => __( 'Displays the Open Hours Information.','mythemeshop' ) )
		);
	}

	public function  form($instance) {
		$defaults = array(
			'title' => __( 'Open Hours','mythemeshop' ),
		);
		$instance = wp_parse_args((array) $instance, $defaults);
		extract($instance);
		?>
		<p>
			<p><?php _e('NOTE: Add/Modify the Open hours from the Theme options -> Open Hours tab','mythemeshop'); ?> <br/> <a href="<?php echo admin_url('themes.php?page=theme_options'); ?>"><?php _e('Theme Options','mythemeshop'); ?></a> </p>
			<label for="<?php echo $this->get_field_id('title'); ?>"><?php _e('Title','mythemeshop'); ?></label>
			<input 
			type="text" 
			id="<?php echo $this->get_field_id('title'); ?>" 
			name="<?php echo $this->get_field_name('title'); ?>" 
			value="<?php if(isset($title)) echo $title;  ?>"
			class="widefat">
		</p>
		<?php
	}

	public function widget($args, $instance) {
		extract($instance);
		extract($args);
		echo $before_widget;
		?>
		<div class="title-div"><?php if ( ! empty( $title ) ) echo $before_title . $title . $after_title; ?></div>
		<ul class="open-hours">
		<?php $mts_options = get_option( MTS_THEME_NAME );
		foreach ($mts_options['mts_hours'] as $key => $data) { ?>
			<li class="open-hours-li">
				<?php if(isset($data['mts_openhrs_closed']['closed']) && !empty($data['mts_openhrs_closed']['closed'])) { ?>
					<div class="closed">
						<div class="open-hours-img">
							<span><i class="fa fa-times-circle"></i></span>
						</div>
						<div class="open-p">
							<div class="open-hours-title">
								<?php echo $data['mts_openhrs_days']; ?>
							</div>
							<div class="closed-msg">
								<?php _e("Sorry, we're closed","mythemeshop"); ?>
							</div>
						</div>
					</span>
				<?php } else { ?>
					<ul class="inner-ul"> 
						<li class="inner-li">
							<div class="open-hours-img">
								<span><i class="fa fa-clock-o"></i></span>
							</div>
							<div class="open-p">
								<div class="open-hours-title">
									<?php echo $data['mts_openhrs_days']; ?>
								</div>
								<div class="open-hours-time">
									<?php echo $data['mts_openhrs_timings']; ?>
								</div>
							</div>
						</li>
						<?php if(isset($data['mts_openhrs_breaktitle']) || isset($data['mts_openhrs_breaktime'])){ ?>
							<li class="inner-li"> <!--  class="break-li" -->
								<div class="open-hours-img"><span><i class="fa fa-bell"></i> </span></div>
								<div class="break-p">
									<div class="open-hours-title"><?php echo (isset($data['mts_openhrs_breaktitle']))? $data['mts_openhrs_breaktitle']: "" ; ?></div>
									<div class="break-time"><?php echo (isset($data['mts_openhrs_breaktime']))? $data['mts_openhrs_breaktime'] : ""; ?></div>
								</div>
							</li>
						<?php } ?>
					</ul>		
				<?php } //end if ?>
			</li>
		 	<?php
		 }
		 echo "</ul>";
		 echo $after_widget;
	}
}

add_action( 'widgets_init', create_function( '', 'register_widget( "mts_openhours_widget" );' ) );