<?php
/*-----------------------------------------------------------------------------------

	Plugin Name: Events Widget
	Version: 1.0
	
-----------------------------------------------------------------------------------*/
class mts_events_widget extends WP_Widget {

	public function __construct() {
		
		parent::__construct(
	 		'mts_events_widget',
			__('MyThemeShop: Events Widget','mythemeshop'),
			array( 'description' => __( 'Displays the latest gallery items from the gallery.','mythemeshop' ) )
		);
	}

	public function  form($instance) {
		$defaults = array(
			'title' => __( 'Events','mythemeshop' ),
			'qty' => 3,
		);
		$instance = wp_parse_args((array) $instance, $defaults);
		$qty = isset( $instance[ 'qty' ] ) ? intval( $instance[ 'qty' ] ) : 5;
		extract($instance);
		?>
		<p>
			<label for="<?php echo $this->get_field_id('title'); ?>"><?php _e('Title','mythemeshop'); ?></label>
			<input 
			type="text" 
			id="<?php echo $this->get_field_id('title'); ?>" 
			name="<?php echo $this->get_field_name('title'); ?>" 
			value="<?php if(isset($title)) echo $title;  ?>"
			class="widefat">
		</p>
		<p>
			<label for="<?php echo $this->get_field_id( 'qty' ); ?>"><?php _e( 'Number of Events','mythemeshop' ); ?></label> 
			<input id="<?php echo $this->get_field_id( 'qty' ); ?>" name="<?php echo $this->get_field_name( 'qty' ); ?>" type="number" min="1" step="1" value="<?php echo $qty; ?>" />
		</p>
		<?php
	}

	public function update( $new_instance, $old_instance ) {
		$instance = array();
		$instance['title'] = strip_tags( $new_instance['title'] );
		$instance['qty'] = intval( $new_instance['qty'] );
		return $instance;
	}

	public function widget($args, $instance) {
		extract($args);
		$title = apply_filters( 'widget_title', $instance['title'] );
		$qty = (int) $instance['qty'];
		extract($instance); //$title
		 // $post_count = 0;
		
		echo $before_widget;
				?>
				<div class="event-widget">
					<div><?php if ( ! empty( $title ) ) echo $before_title . $title . $after_title; ?><a  class="event-link" href="<?php echo  home_url().'/?post_type=events'; ?>"><?php _e( 'All Events', 'mythemeshop' ); ?></a> </div>
	            	<ul class="event-list">
				<?php	
	                $query = new WP_Query();
	                $query->query('post_type=events&ignore_sticky_posts=1&order=ASC&posts_per_page='.$qty);
					
					while ($query->have_posts()) : $query->the_post();
	                // $terms = get_the_terms( get_the_ID(), 'categories');                
					$date = get_post_meta(get_the_ID(),'mts_events_startdate', true);
		            
					$time = get_post_meta(get_the_ID(),'mts_events_starttime', true);
					$shortdesc = get_post_meta(get_the_ID(),'mts_events_desc', true);
					$dat = date("d", $date);
					$month	= date("M", $date); 

	            ?>
	            	<li class="widget-single-event">
	            		<div class="event-date">
	            			<span class="event-cal-date"><?php echo $dat; ?></span>
	            			<span class="event-cal-month"><?php echo $month; ?></span>
	            		</div>
	            		<div class="event-details">
							<a href="<?php the_permalink(); ?>" class="title">
								<?php the_title(); ?>
							</a>
	            			<p><span><?php echo $time; ?></span><br><?php echo $shortdesc; ?></p>
	            		</div>
	            	</li>
	            
                
            <?php endwhile;  wp_reset_query();
            ?>
            </ul>
            </div>
            <?php
            echo $after_widget;
	}
}


add_action( 'widgets_init', create_function( '', 'register_widget( "mts_events_widget" );' ) );