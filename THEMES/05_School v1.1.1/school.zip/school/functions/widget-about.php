<?php

/*-----------------------------------------------------------------------------------

	Plugin Name: MyThemeShop About Us Widget
	Description: A widget for showing About us information.
	Version: 1.0

-----------------------------------------------------------------------------------*/


// load widget
add_action( 'widgets_init', 'mts_about_widgets' );

// Register widget
function mts_about_widgets() {
	register_widget( 'mts_about_Widget' );
}

// Widget class
class mts_about_widget extends WP_Widget {


/*-----------------------------------------------------------------------------------*/
/*	Widget Setup
/*-----------------------------------------------------------------------------------*/
	
function mts_about_Widget() {

	// Widget settings
	$widget_ops = array (
		'classname' => 'mts_about_widget',
		'description' => __('A widget for showing About us information', 'mythemeshop')
	);

	// Widget control settings
	$control_ops = array (
		'width' => 300,
		'height' => 350,
		'id_base' => 'mts_about_widget'
	);

	// Create the widget
	$this->WP_Widget( 'mts_about_widget', __('MyThemeShop: About Us Widget', 'mythemeshop'), $widget_ops, $control_ops );
	
}

/*-----------------------------------------------------------------------------------*/
/*	Display Widget
/*-----------------------------------------------------------------------------------*/
	
function widget( $args, $instance ) {
	extract( $args );

	// variables from the widget settings
	$title = apply_filters('widget_title', $instance['title'] );
	$about_text = $instance['about_text'];
	$school_name = $instance['school_name'];
	$school_address = $instance['school_address'];
	$school_phone = $instance['school_phone'];
	$school_email = $instance['school_email'];

	// Before widget (defined by theme functions file)
	echo $before_widget;

	// Display the widget title if one was input
	if ( $title )
		echo $before_title . $title . $after_title;

	// Randomize ads order in a new array
	$ads = array();
		
	// Display a containing div
	echo '<div class="mts-about-us">';
	
	echo '<div>';

	// Display About Text
	if ( $about_text )
		$texts[] = '<p>'. nl2br($about_text). '</p>';
	
	// Display School Name
	if ( $school_name )
		$texts[] = '<div class="school-name"><strong>'. $school_name . '</strong></div>';
		
	// Display School Address
	if ( $school_address )
		$texts[] = '<address>'. nl2br($school_address) .'</address>';
		
	// Display School Phone
	if ( $school_phone )
		$texts[] = '<div class="school-phone"><i class="fa fa-phone"></i> '. $school_phone .'</div>';
		
	// Display School Email
	if ( $school_email )
		$texts[] = '<div class="school-email"><a href="mailto:'.$school_email.'" target="_top"><i class="fa fa-envelope-o"></i> '. $school_email .'</a></div>';
	
	//Display texts
	foreach($texts as $text){
		echo $text;
	}
	
	echo '</div>';
		
	echo '</div>';

	// After widget (defined by theme functions file)
	echo $after_widget;
}

/*-----------------------------------------------------------------------------------*/
/*	Update Widget
/*-----------------------------------------------------------------------------------*/
	
function update( $new_instance, $old_instance ) {
	$instance = $old_instance;

	// Strip tags to remove HTML (important for text inputs)
	$instance['title'] = strip_tags( $new_instance['title'] );

	// No need to strip tags
	$instance['about_text'] = $new_instance['about_text'];
	$instance['school_name'] = $new_instance['school_name'];
	$instance['school_address'] = $new_instance['school_address'];
	$instance['school_phone'] = $new_instance['school_phone'];
	$instance['school_email'] = $new_instance['school_email'];

	return $instance;
}

/*-----------------------------------------------------------------------------------*/
/*	Widget Settings (Displays the widget settings controls on the widget panel)
/*-----------------------------------------------------------------------------------*/
	
function form( $instance ) {

	// Set up some default widget settings
	$defaults = array(
		'title' => 'About Us',
		'about_text' => '',
		'school_name' => '',
		'school_address' => '',
		'school_phone' => '',
		'school_email' => '',
	);
		
	$instance = wp_parse_args( (array) $instance, $defaults ); ?>

	<!-- Widget Title: Text Input -->
	<p>
		<label for="<?php echo $this->get_field_id( 'title' ); ?>"><?php _e('Title:', 'mythemeshop') ?></label>
		<input type="text" class="widefat" id="<?php echo $this->get_field_id( 'title' ); ?>" name="<?php echo $this->get_field_name( 'title' ); ?>" value="<?php echo $instance['title']; ?>" />
	</p>

	<!-- About Text Input -->
	<p>
		<label for="<?php echo $this->get_field_id( 'about_text' ); ?>"><?php _e('Text:', 'mythemeshop') ?></label>
		<textarea class="widefat" id="<?php echo $this->get_field_id( 'about_text' ); ?>" name="<?php echo $this->get_field_name( 'about_text' ); ?>"><?php echo $instance['about_text']; ?></textarea>
	</p>
	
	<!-- School Name Text Input -->
	<p>
		<label for="<?php echo $this->get_field_id( 'school_name' ); ?>"><?php _e('School Name:', 'mythemeshop') ?></label>
		<input type="text" class="widefat" id="<?php echo $this->get_field_id( 'school_name' ); ?>" name="<?php echo $this->get_field_name( 'school_name' ); ?>" value="<?php echo $instance['school_name']; ?>" />
	</p>
	
	<!-- School Address Text Input -->
	<p>
		<label for="<?php echo $this->get_field_id( 'school_address' ); ?>"><?php _e('School Address:', 'mythemeshop') ?></label>
		<textarea class="widefat" id="<?php echo $this->get_field_id( 'school_address' ); ?>" name="<?php echo $this->get_field_name( 'school_address' ); ?>"><?php echo $instance['school_address']; ?></textarea>
	</p>
	
	<!-- School Phone Text Input -->
	<p>
		<label for="<?php echo $this->get_field_id( 'school_phone' ); ?>"><?php _e('School Phone:', 'mythemeshop') ?></label>
		<input type="text" class="widefat" id="<?php echo $this->get_field_id( 'school_phone' ); ?>" name="<?php echo $this->get_field_name( 'school_phone' ); ?>" value="<?php echo $instance['school_phone']; ?>" />
	</p>
	
	<!-- School Email Text Input -->
	<p>
		<label for="<?php echo $this->get_field_id( 'school_email' ); ?>"><?php _e('School Email:', 'mythemeshop') ?></label>
		<input type="text" class="widefat" id="<?php echo $this->get_field_id( 'school_email' ); ?>" name="<?php echo $this->get_field_name( 'school_email' ); ?>" value="<?php echo $instance['school_email']; ?>" />
	</p>
	
	<?php
	}
}
?>