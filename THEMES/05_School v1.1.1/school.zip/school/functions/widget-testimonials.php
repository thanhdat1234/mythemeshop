<?php
/*-----------------------------------------------------------------------------------

	Plugin Name: SchoolTheme Testimonial Widget
	Version: 1.0
	
-----------------------------------------------------------------------------------*/
class mts_testimonials_widget extends WP_Widget {

	public function __construct() {
		
		parent::__construct(
	 		'mts_testimonials_widget',
			__('MyThemeShop: Testimonials Widget','mythemeshop'),
			array( 'description' => __( 'Displays the Testimonials.','mythemeshop' ) )
		);
	}

	public function  form($instance) {
		$defaults = array(
			'title' => __( 'Testimonials','mythemeshop' ),
		);
		$instance = wp_parse_args((array) $instance, $defaults);
		extract($instance); ?>
		<p>
			<p><?php _e('NOTE: Add/Modify the testimonials from the Theme options -> Testimonial tab','mythemeshop'); ?> <br/> <a href="<?php echo admin_url('themes.php?page=theme_options'); ?>"><?php _e('Theme Options','mythemeshop'); ?></a></p>
			<label for="<?php echo $this->get_field_id('title'); ?>"><?php _e('Title','mythemeshop'); ?></label>
			<input 
			type="text" 
			id="<?php echo $this->get_field_id('title'); ?>" 
			name="<?php echo $this->get_field_name('title'); ?>" 
			value="<?php if(isset($title)) echo $title;  ?>"
			class="widefat">
		</p>
	<?php }

	public function widget($args, $instance) {
		extract($instance);
		extract($args);
		$mts_options = get_option(MTS_THEME_NAME);
		echo $before_widget;

		wp_enqueue_script( 'flexslider' );
		wp_enqueue_style( 'flexslider' );


		if ( !empty($title) || !empty($mts_options['mts_testimonials']) ) { ?>

			<div class="title-div"><?php if ( ! empty( $title ) ) echo $before_title . $title . $after_title; ?></div>
			
			<?php $extra_margin_class = ' testimonial-extra-margin';
			if ( !empty($mts_options['mts_testimonial_description']) ) {
				$extra_margin_class = ''; ?>
				<div class="testimonial-section-description">
					<?php
						echo nl2br($mts_options['mts_testimonial_description']);
					?>
				</div>
			<?php }

			if ( !empty($mts_options['mts_testimonials']) ) { ?>
				<div id="homepage-testimonials" class="testimonial-section">
					<div class="slides_container clearfix">
						<div id="testimonials">
							<ul class="slides">
								<?php $i = 0; foreach($mts_options['mts_testimonials'] as $testimonials) : ?>
									<?php if ($i % 2 - 1) : ?>
									<li class="testimonial-page">
									<?php endif; ?>
									<div class="testimonial-item">
										<blockquote class="rectangle-speech-border">
											<h6>"<?php echo $testimonials['mts_testimonial_description']; ?>"</h6>
											<div class="testimonial-description">
												<div class="parent-name"><?php echo $testimonials['mts_testimonial_name']; ?></div>
												<div class="parent-label"><?php echo $testimonials['mts_testimonial_Parent']; ?></div>
											</div>
										</blockquote>
									</div>
									<?php if ($i % 2) : ?>
									</li>
									<?php endif; ?>
								<?php $i++; endforeach; ?>
								<?php if ($i % 2) : // closing tag if needed ?>
								</li>
								<?php endif; ?>
							</ul>
						</div>
					</div>
				</div>
			<?php }
		} 
		echo $after_widget;
	}
}

add_action( 'widgets_init', create_function( '', 'register_widget( "mts_testimonials_widget" );' ) );