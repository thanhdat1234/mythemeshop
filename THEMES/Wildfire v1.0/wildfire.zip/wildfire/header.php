<!DOCTYPE html>
<?php $options = get_option('wildfire'); ?>
<html class="no-js" <?php language_attributes(); ?>>
<head>
	<meta charset="<?php bloginfo('charset'); ?>">
	<title><?php wp_title(''); ?></title>
	<?php mts_meta(); ?>
	<link rel="stylesheet" type="text/css" media="all" href="<?php bloginfo( 'stylesheet_url' ); ?>" />
	<link rel="pingback" href="<?php bloginfo( 'pingback_url' ); ?>" />
	<?php wp_enqueue_script("jquery"); ?>
	<?php if ( is_singular() ) wp_enqueue_script( 'comment-reply' ); ?>
	<!--[if lt IE 9]>
	<script src="http://html5shim.googlecode.com/svn/trunk/html5.js"></script>
	<![endif]-->
	<?php mts_head(); ?>
	<?php wp_head(); ?>
</head>
<?php flush(); ?>
<body id ="blog" <?php body_class('main'); ?>>
	<header class="main-header">
		<div class="secondary-navigation">
			<nav id="navigation" >
				<?php if ( has_nav_menu( 'primary-menu' ) ) { ?>
					<?php wp_nav_menu( array( 'theme_location' => 'primary-menu', 'menu_class' => 'menu', 'container' => '' ) ); ?>
				<?php } else { ?>
					<ul class="menu">
						<?php wp_list_categories('title_li='); ?>
					</ul>
				<?php } ?>
				<?php if ($options['header_social_buttons'] == '1') { ?>
				<div class="social-icons">
					<ul>
						<li><a class="twt" href="http://twitter.com/<?php echo $options['mts_twitter_username'];?>"><div class="sicon icon-twitter"><div>Twitter</div></div></a></li>
						<li><a class="fb" href="<?php echo $options['header_social_button_facebook'];?>"><div class="sicon icon-facebook"><div>Facebook</div></div></a></li>
						<li><a class="gp" href="<?php echo $options['header_social_button_gp'];?>"><div class="sicon icon-gplus"><div>Google</div></div></a></li>
					</ul>
				</div>
				<?php } ?>
			</nav>
		</div>  
		<div class="container">
			<div id="header">
				<div class="head-left">
					<?php if ($options['mts_logo'] != '') { ?>
						<?php if( is_front_page() || is_home() || is_404() ) { ?>
								<h1 id="logo" class="image-logo">
									<a href="<?php echo home_url(); ?>"><img src="<?php echo $options['mts_logo']; ?>" alt="<?php bloginfo( 'name' ); ?>"></a>
								</h1><!-- END #logo -->
						<?php } else { ?>
								<h2 id="logo" class="image-logo">
									<a href="<?php echo home_url(); ?>"><img src="<?php echo $options['mts_logo']; ?>" alt="<?php bloginfo( 'name' ); ?>"></a>
								</h2><!-- END #logo -->
						<?php } ?>
					<?php } else { ?>
						<?php if( is_front_page() || is_home() || is_404() ) { ?>
								<h1 id="logo" class="text-logo">
									<a href="<?php echo home_url(); ?>"><?php bloginfo( 'name' ); ?></a>
								</h1><!-- END #logo -->
								<div class="site-description"><?php bloginfo( 'description' ); ?></div>
						<?php } else { ?>
								<h2 id="logo" class="text-logo">
									<a href="<?php echo home_url(); ?>"><?php bloginfo( 'name' ); ?></a>
								</h2><!-- END #logo -->
								<div class="site-description"><?php bloginfo( 'description' ); ?></div>
						<?php } ?>
					<?php } ?>
				</div>
				<?php if ( !function_exists('dynamic_sidebar') || !dynamic_sidebar('Header Banner') ) : ?><?php endif; ?>            
			</div><!--#header-->
		</div><!--.container-->        
	</header>
	<div class="main-container">