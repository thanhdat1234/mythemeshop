<?php
$options = get_option('wildfire');	

/*------------[ Meta ]-------------*/
if ( ! function_exists( 'mts_meta' ) ) {
	function mts_meta() { 
	global $options
?>
<?php if ($options['mts_favicon'] != '') { ?>
<link rel="icon" href="<?php echo $options['mts_favicon']; ?>" type="image/x-icon" />
<?php } ?>
<meta http-equiv="x-ua-compatible" content="IE=8" >
<!--iOS/android/handheld specific -->
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<meta name="apple-mobile-web-app-capable" content="yes">
<meta name="apple-mobile-web-app-status-bar-style" content="black">
<?php if($options['mts_prefetching'] == '1') { ?>
<?php if (is_front_page()) { $args = array( 'numberposts' => 1); $myposts = get_posts( $args ); setup_postdata($myposts); ?>
	<link rel="prefetch" href="<?php the_permalink(); ?>">
	<link rel="prerender" href="<?php the_permalink(); ?>">
<?php } elseif (is_singular()) { ?>
	<link rel="prefetch" href="<?php echo home_url(); ?>">
	<link rel="prerender" href="<?php echo home_url(); ?>">
<?php } ?>
<?php } ?>
<?php }
}

/*------------[ Head ]-------------*/
if ( ! function_exists( 'mts_head' ) ) {
	function mts_head() { 
	global $options
?>
<!--start fonts-->
<?php if ($options['mts_title_font'] == 'Arial') { ?>
<?php } else { ?>
<?php if ($options['mts_title_font'] != '' || $options['mts_google_title_font'] != '') { ?>
<link href="http://fonts.googleapis.com/css?family=<?php if ($options['mts_google_title_font'] != '') { ?><?php echo $options['mts_google_title_font']; ?><?php } else { ?><?php echo $options['mts_title_font']; ?><?php } ?>:400,700" rel="stylesheet" type="text/css">
<style type="text/css">
.title, .readMore, .sbutton, .mts-subscribe input[type="submit"], #commentform input#submit, .total-comments, .pagination, h1,h2,h3,h4,h5,h6, .secondary-navigation a, .related-posts a, #tabber ul.tabs li a, #tabber .inside li div.info .entry-title, .plink, .advanced-recent-posts a, .sicon div { font-family: '<?php if ($options['mts_google_title_font'] != '') { ?><?php echo $options['mts_google_title_font']; ?><?php } else { ?><?php echo $options['mts_title_font']; ?><?php } ?>', sans-serif;}
</style>
<?php } ?>
<?php } ?>
<?php if ($options['mts_content_font'] == 'Arial') { ?>
<?php } else { ?>
<?php if ($options['mts_content_font'] != '' || $options['mts_google_content_font'] != '') { ?>
<link href="http://fonts.googleapis.com/css?family=<?php if ($options['mts_google_content_font'] != '') { ?><?php echo $options['mts_google_content_font']; ?><?php } else { ?><?php echo $options['mts_content_font']; ?><?php } ?>:400,400italic,700,700italic" rel="stylesheet" type="text/css">
<style type="text/css">
body, .widget li {font-family: '<?php if ($options['mts_google_content_font'] != '') { ?><?php echo $options['mts_google_content_font']; ?><?php } else { ?><?php echo $options['mts_content_font']; ?><?php } ?>', sans-serif;}
</style>
<?php } ?>
<?php } ?>
<!--end fonts-->
<style type="text/css">
<?php if($options['mts_bg_color'] != '') { ?>
body {background-color:<?php echo $options['mts_bg_color']; ?>;}
<?php } ?>
<?php if ($options['mts_bg_pattern_upload'] != '') { ?>
body {background-image: url(<?php echo $options['mts_bg_pattern_upload']; ?>);}
<?php } else { ?>
<?php if($options['mts_bg_pattern'] != '') { ?>
body {background-image:url(<?php echo get_template_directory_uri(); ?>/images/<?php echo $options['mts_bg_pattern']; ?>.png);}
<?php } ?>
<?php } ?>
<?php if ($options['mts_color_scheme'] != '') { ?>
.mts-subscribe input[type="submit"], .sbutton, .currenttext, .pagination a:hover, .readMore a, #tabber ul.tabs li a.selected, #commentform input#submit, .tagcloud a, .site-description {background-color:<?php echo $options['mts_color_scheme']; ?>; }
a:hover, .textwidget a, #commentform a, #navigation ul ul a:hover, .copyrights a:hover, a, .sidebar.c-4-12 a:hover, footer .widget li a:hover, #copyright-note span a, .icon-forward, .sidebar.c-4-12 .textwidget a {color:<?php echo $options['mts_color_scheme']; ?>; }
#tabber ul.tabs li a.selected:after { border-top-color: <?php echo $options['mts_color_scheme']; ?>; }
<?php } ?>
<?php if($options['mts_floating_social'] == '1') { ?>
.shareit { top: 282px; left: auto; z-index: 0; margin: 0 0 0 -110px; width: 90px; position: fixed; overflow: hidden; }
.share-item {margin: 2px;}
<?php } ?>
<?php if ($options['mts_layout'] == 'sclayout') { ?>
.article { float: right; padding-right: 0}
.sidebar.c-4-12 { float: left; padding-right: 0; }
<?php if($options['mts_floating_social'] == '1') { ?>
.shareit { margin: 0 870px 0; border-left: 0; }
<?php } ?>
<?php } ?>
<?php if($options['mts_author_comment'] == '1') { ?>
.bypostauthor {border: 1px solid #EEE!important; padding: 2%!important; background: #FAFAFA; width: 95.6%!important;}
.bypostauthor:before {
content: "\e808";
position: absolute;
right: 12px;
top: 8px;
color: #888;
font-family: 'iconfonts';
font-size: 18px;
}
<?php } ?>
<?php echo $options['mts_custom_css']; ?>
</style>
<?php echo $options['mts_header_code']; ?>
<?php }
}

/*------------[ Copyrights ]-------------*/
if ( ! function_exists( 'mts_copyrights_credit' ) ) {
	function mts_copyrights_credit() { 
	global $options
?>
<!--start copyrights-->
<div class="row" id="copyright-note">
<span><a href="<?php echo home_url(); ?>/" title="<?php bloginfo('description'); ?>"><?php bloginfo('name'); ?></a> Copyright &copy; <?php echo date("Y") ?>. <?php echo $options['mts_copyrights']; ?></span>
<div class="top"><a href="#top" class="toplink"><?php _e('Back to Top ','mythemeshop'); ?>&uarr;</a></div>
<div class="footer-menu">
	<?php if ( has_nav_menu( 'footer-menu' ) ) { ?>
		<?php wp_nav_menu( array( 'theme_location' => 'footer-menu', 'menu_class' => 'menu', 'container' => '' ) ); ?>
	<?php } ?>
</div>
</div>
<!--end copyrights-->
<?php }
}
/*------------[ footer ]-------------*/
if ( ! function_exists( 'mts_footer' ) ) {
	function mts_footer() { 
	global $options
?>
<!--Twitter Button Script------>
<script>!function(d,s,id){var js,fjs=d.getElementsByTagName(s)[0];if(!d.getElementById(id)){js=d.createElement(s);js.id=id;js.src="//platform.twitter.com/widgets.js";fjs.parentNode.insertBefore(js,fjs);}}(document,"script","twitter-wjs");</script>
<script type="text/javascript">
  (function() {
    var po = document.createElement('script'); po.type = 'text/javascript'; po.async = true;
    po.src = 'https://apis.google.com/js/plusone.js';
    var s = document.getElementsByTagName('script')[0]; s.parentNode.insertBefore(po, s);
  })();
</script>
<!--Facebook Like Button Script------>
<script>(function(d, s, id) {
  var js, fjs = d.getElementsByTagName(s)[0];
  if (d.getElementById(id)) return;
  js = d.createElement(s); js.id = id;
  js.src = "//connect.facebook.net/en_US/all.js#xfbml=1&appId=136911316406581";
  fjs.parentNode.insertBefore(js, fjs);
}(document, 'script', 'facebook-jssdk'));</script>
<?php if($options['mts_featured_slider'] == '1') { ?>
<!--start slider-->
<?php if( is_home() ) { ?>
<script type="text/javascript">
jQuery(document).ready(function(e) {
   (function($){
	$(window).load(function() {
	$('.flexslider').flexslider({
		animation: "fade",
		pauseOnHover: true,
		controlsContainer: ".flex-container",
		controlNav:false,
		directionNav:true
	});
	});
   }(jQuery));
});
</script>
<?php } ?>
<!--end slider-->
<?php } ?>
<?php if($options['mts_lightbox'] == '1') { ?>
<!--start lightbox-->
<script type="text/javascript">  
jQuery(document).ready(function($) {
$("a[href$='.jpg'], a[href$='.jpeg'], a[href$='.gif'], a[href$='.png']").prettyPhoto({
slideshow: 5000,
autoplay_slideshow: false,
animationSpeed: 'normal',
padding: 40,
opacity: 0.35,
showTitle: true,
social_tools: false
});
})
</script>
<!--end lightbox-->
<?php } ?>
<?php if ($options['mts_analytics_code'] != '') { ?>
<!--start footer code-->
<?php echo $options['mts_analytics_code']; ?>
<!--end footer code-->
<?php } ?>
<?php }
}
?>