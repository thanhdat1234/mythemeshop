<div class="mts_metabox">
<?php

$this->textarea(	'pros',
				'Pros'
			);
			
$this->textarea(	'cons',
				'Cons'
			);
?>
</div>