<?php $mts_options = get_option(MTS_THEME_NAME); ?>
<?php get_header(); ?>

<?php if ( !is_paged() && is_home() && $mts_options['mts_featured_slider'] == '1' ) { ?>

    <div class="primary-slider-container clearfix loading">
        <?php if( $mts_options['mts_featured_slider_full_width'] == '0' ) { echo "<div class=\"container\">"; } ?>
        
            <div id="slider" class="primary-slider<?php echo ( $mts_options['mts_featured_slider_full_width'] == '0' ) ? '' : ' option-2'; ?>">
                <?php
                // prevent implode error
                if ( empty( $mts_options['mts_featured_slider_cat'] ) || !is_array( $mts_options['mts_featured_slider_cat'] ) ) {
                    $mts_options['mts_featured_slider_cat'] = array('0');
                }

                $slider_cat = implode( ",", $mts_options['mts_featured_slider_cat'] );
                $slider_query = new WP_Query('cat='.$slider_cat.'&posts_per_page='.$mts_options['mts_featured_slider_num']);
                if(!empty($mts_options['mts_featured_slider_full_width'])) {
                    $excerpt_length = 22;
                } else {
                    $excerpt_length = 15;
                }
                $i = 0; while ( $slider_query->have_posts() ) : $slider_query->the_post();
                ?>
                <div> 
                    <div class="image-caption image-caption-<?php echo ++$i; ?>" style="background: url(<?php echo mts_get_thumbnail_url(__(( $mts_options['mts_featured_slider_full_width'] == '0' ) ? 'slider' : 'full')) ?>); background-position: center center; background-repeat:no-repeat; background-size:cover; min-height:450px">
                        <div class="slide-caption">
                            <div class="post-info"><span class="thecategory"><?php mts_slider_category(', ') ?></span></div>
                            <a href="<?php echo esc_url( get_the_permalink() ); ?>" title="<?php echo esc_attr( get_the_title() ); ?>"><h2 class="slide-title"><?php the_title(); ?></h2></a>
                            <div class="slide-description"><?php echo mts_excerpt($excerpt_length); ?></div>
                            <div class="readMore">
                                <a href="<?php echo esc_url( get_the_permalink() ); ?>" title="<?php echo esc_attr( get_the_title() ); ?>" rel="nofollow">
                                    <?php _e( 'Read Full Article', MTS_THEME_TEXTDOMAIN ); ?>
                                </a>
                            </div>
                        </div><!-- .slide-caption -->
                    </div>
                </div>
                <?php endwhile; wp_reset_postdata(); ?>
            </div><!-- .primary-slider -->
        <?php if( $mts_options['mts_featured_slider_full_width'] == '0' ) { echo "</div>"; } ?>
    </div><!-- .primary-slider-container -->

<?php } ?>

<div id="page">
	<div id="content_box">
        <?php $sidebar_used = false;
        $featured_categories = array();
        if ( !empty( $mts_options['mts_featured_categories'] ) ) {
            foreach ( $mts_options['mts_featured_categories'] as $section ) {
                $category_id = $section['mts_featured_category'];
                $featured_category_layout = $section['mts_featured_category_layout'];
                $featured_categories[] = $category_id;
                $posts_num = $section['mts_featured_category_postsnum'];
                if ( $category_id === 'latest' && ($featured_category_layout =='withsidebar' || is_paged()) ) {
                    $sidebar_used = true; ?>
                    <div class="<?php mts_article_class(); ?>">
                        <?php $j = 0; $i = 0; if ( have_posts() ) : while ( have_posts() ) : the_post(); ?>
                            <article class="latestPost excerpt <?php echo ( ++$i > 1 || is_paged() ) ? 'latestPost-left post-with-sidebar' : ''; ?> <?php echo (++$j % 3 == 0) ? 'last' : ''; ?>" itemscope itemtype="http://schema.org/BlogPosting">
    				            <a href="<?php the_permalink(); ?>" title="" rel="nofollow" class="post-image post-image-left">
                                    <?php echo '<div class="featured-thumbnail">'; the_post_thumbnail( __(( $i > 1 || is_paged() ) ? 'featured' : 'featuredfull') ,array('title' => '', 'itemprop'=> 'image')); echo '</div>'; ?>
                                    <?php if (function_exists('wp_review_show_total')) wp_review_show_total(true, 'latestPost-review-wrapper'); ?>
                                    <?php if(!empty($mts_options['mts_total_views'])) { ?>
                                        <div class="views">                                            
                                            <?php $count = get_post_meta( get_the_id(), '_mts_view_count', true ); if ( $count )  echo __('<i class="fa fa-eye"></i>', MTS_THEME_NAME) . ' ' . $count;  ?>
                                        </div>
                                    <?php } ?>
                                </a>
                                <header>
                                    <?php mts_the_postinfo(); ?>
                                    <h2 class="title front-view-title" itemprop="headline"><a href="<?php the_permalink(); ?>" title="<?php the_title(); ?>"><?php the_title(); ?></a></h2>
                                </header>
                                <div class="front-view-content">
                                    <?php echo mts_excerpt(20); ?>
                                </div>
                            </article>
              			<?php $j++; endwhile; endif; ?>
                        <!--Start Pagination-->
                        <?php if ( $j !== 0 ) { // No pagination if there is no posts ?>
                            <?php mts_pagination(); ?>
                        <?php } ?>
                    </div>
                <?php } else { // if $category_id != 'latest': ?>
                    <?php $j = 0;
                    $cat_query = new WP_Query('cat='.$category_id.'&posts_per_page='.$posts_num.'&ignore_sticky_posts=1');
                    if(!is_paged() && $category_id != 'latest' && $featured_category_layout =='withsidebar') { ?>
                        <div class="<?php mts_article_class(); ?>">
                            <?php $j = 1; $i = 0;
                            if ($cat_query->have_posts()) : while ($cat_query->have_posts()) : $cat_query->the_post();
                                $sidebar_used = true; ?>                            
                                <article class="latestPost excerpt <?php echo ( ++$i > 1 ) ? 'latestPost-left post-with-sidebar' : ''; ?> <?php echo (++$j % 3 == 0) ? 'last' : ''; ?>" itemscope itemtype="http://schema.org/BlogPosting">
                                    <a href="<?php the_permalink(); ?>" title="" rel="nofollow" class="post-image post-image-left">
                                        <?php echo '<div class="featured-thumbnail">'; the_post_thumbnail( __(( $i > 1 ) ? 'featured' : 'featuredfull'),array('title' => '', 'itemprop'=> 'image')); echo '</div>'; ?>
                                        <?php if (function_exists('wp_review_show_total')) wp_review_show_total(true, 'latestPost-review-wrapper'); ?>
                                        <?php if(!empty($mts_options['mts_total_views'])) { ?>
                                            <div class="views">                                            
                                                <?php  $count = get_post_meta( get_the_id(), '_mts_view_count', true ); if ( $count )  echo __('<i class="fa fa-eye"></i>', MTS_THEME_NAME) . ' ' . $count;  ?>
                                            </div>
                                        <?php } ?>
                                    </a>
                                    <header>
                                        <?php mts_the_postinfo(); ?>
                                        <h2 class="title front-view-title" itemprop="headline"><a href="<?php the_permalink(); ?>" title="<?php the_title(); ?>"><?php the_title(); ?></a></h2>
                                    </header>
                                    <div class="front-view-content">
                                        <?php echo mts_excerpt(20); ?>
                                    </div>
                                </article>
                            <?php $j++; 
                            endwhile; endif; ?>
                        </div> 
                    <?php } wp_reset_postdata();
                }
                if($featured_category_layout == 'withsidebar'){

                	if ( 'latest' != $category_id ) {
	                    $cat_name = ucwords(get_cat_name( $category_id ));
	                } else {
	                    $cat_name = __( 'Home Sidebar', MTS_THEME_TEXTDOMAIN );
	                }
                    
                    $sidebar_name = sanitize_title( strtolower( 'post-layout-'.$cat_name ));

                    get_category_sidebar($sidebar_name, $cat_name);
                }
            }
        } ?>
	</div><!--.content_box-->
    
    <?php if ( !empty( $mts_options['mts_featured_categories'] ) ) {
        foreach ( $mts_options['mts_featured_categories'] as $section ) {
            $category_id = $section['mts_featured_category'];
            $featured_category_layout = $section['mts_featured_category_layout'];
            $featured_categories[] = $category_id;
            $posts_num = $section['mts_featured_category_postsnum'];
            if( !is_paged() && $category_id === 'latest' && $featured_category_layout =='smallbig') { ?>
                <div class="full-width-post">
                    <?php $j=1; $i = 0; if ( have_posts() ) : while ( have_posts() ) : the_post(); ?>
                    <article class="latestPost excerpt <?php echo ( ++$i % 2 == 0 ) ? 'large-post' : 'small-post'; ?>" itemscope itemtype="http://schema.org/BlogPosting">
                        <a href="<?php the_permalink(); ?>" title="" rel="nofollow" class="post-image post-image-left">
                            <?php echo '<div class="featured-thumbnail">'; the_post_thumbnail( __(( $i % 2 == 0 ) ? 'featuredfull' : 'featuredsmallpost'),array('title' => '', 'itemprop'=> 'image')); echo '</div>'; ?>
                            <?php if (function_exists('wp_review_show_total')) wp_review_show_total(true, 'latestPost-review-wrapper'); ?>
                            <?php if(!empty($mts_options['mts_total_views'])) { ?>
                                <div class="views">                                            
                                    <?php $count = get_post_meta( get_the_id(), '_mts_view_count', true ); if ( $count )  echo __('<i class="fa fa-eye"></i>', MTS_THEME_NAME) . ' ' . $count;  ?>
                                </div>
                            <?php } ?>
                        </a>
                        <header>
                            <?php mts_the_postinfo(); ?>
                            <h2 class="title front-view-title" itemprop="headline"><a href="<?php the_permalink(); ?>" title="<?php the_title(); ?>"><?php the_title(); ?></a></h2>
                        </header>
                        <?php if( $i % 2 == 0 ) { ?>
                            <div class="front-view-content">
                                <?php echo mts_excerpt(20); ?>
                            </div>
                        <?php } ?>
                    </article>
                    <?php $j++; endwhile; endif; ?>
                    <!--Start Pagination-->
                    <?php if ( $j !== 0 ) { // No pagination if there is no posts ?>
                        <?php mts_pagination(); ?>
                    <?php } ?>
                </div>
            <?php } elseif( !is_paged() && $category_id != 'latest' && $featured_category_layout =='smallbig') { ?>
                <div class="full-width-post">
                    <?php $cat_query0 = new WP_Query('cat='.$category_id.'&posts_per_page='.$posts_num.'&ignore_sticky_posts=1');
                    $j = 1; $i = 0; if ($cat_query0->have_posts()) : while ($cat_query0->have_posts()) : $cat_query0->the_post(); ?>
                        <article class="latestPost excerpt <?php echo ( ++$i % 2 == 0 ) ? 'large-post' : 'small-post'; ?>" itemscope itemtype="http://schema.org/BlogPosting">
                            <a href="<?php the_permalink(); ?>" title="" rel="nofollow" class="post-image post-image-left">
                                <?php echo '<div class="featured-thumbnail">'; the_post_thumbnail( __(( $i % 2 == 0 ) ? 'featuredfull' : 'featuredsmallpost'),array('title' => '', 'itemprop'=> 'image')); echo '</div>'; ?>
                                <?php if (function_exists('wp_review_show_total')) wp_review_show_total(true, 'latestPost-review-wrapper'); ?>
                                <?php if(!empty($mts_options['mts_total_views'])) { ?>
                                    <div class="views">                                            
                                        <?php  $count = get_post_meta( get_the_id(), '_mts_view_count', true ); if ( $count )  echo __('<i class="fa fa-eye"></i>', MTS_THEME_NAME) . ' ' . $count;  ?>
                                    </div>
                                <?php } ?>
                            </a>
                            <header>
                                <?php mts_the_postinfo(); ?>
                                <h2 class="title front-view-title" itemprop="headline"><a href="<?php the_permalink(); ?>" title="<?php the_title(); ?>"><?php the_title(); ?></a></h2>
                            </header>
                            <?php if( $i % 2 == 0 ) { ?>
                                <div class="front-view-content">
                                    <?php echo mts_excerpt(20); ?>
                                </div>
                            <?php } ?>
                        </article>
                    <?php $j++; endwhile; endif; wp_reset_postdata(); ?>
                </div>
            <?php } elseif( !is_paged() && $category_id === 'latest' && $featured_category_layout == 'grid' ) { ?>
                <div class="full-width-post grid-4">
                <?php //echo $category_id; ?>
                    <div class="thecategory"><a href="<?php echo get_category_link(get_cat_ID($category_id)); ?>" title="View all posts in <?php echo $category_id; ?>"><?php echo $category_id; ?></a></div>
                    <?php $j=1; $i = 0; if ( have_posts() ) : while ( have_posts() ) : the_post(); ?>
                    <article class="latestPost excerpt <?php echo (++$i % 4 == 0) ? 'last' : ''; ?>" itemscope itemtype="http://schema.org/BlogPosting">
                        <a href="<?php the_permalink(); ?>" title="" rel="nofollow" class="post-image post-image-left">
                            <?php echo '<div class="featured-thumbnail">'; the_post_thumbnail('grid',array('title' => '', 'itemprop'=> 'image')); echo '</div>'; ?>
                            <?php if (function_exists('wp_review_show_total')) wp_review_show_total(true, 'latestPost-review-wrapper'); ?>
                            <?php if(!empty($mts_options['mts_total_views'])) { ?>
                                <div class="views">                                            
                                    <?php $count = get_post_meta( get_the_id(), '_mts_view_count', true ); if ( $count )  echo __('<i class="fa fa-eye"></i>', MTS_THEME_NAME) . ' ' . $count;  ?>
                                </div>
                            <?php } ?>
                        </a>
                        <header>
                            <h2 class="title front-view-title" itemprop="headline"><a href="<?php the_permalink(); ?>" title="<?php the_title(); ?>"><?php the_title(); ?></a></h2>
                        </header>
                    </article>
                    <?php $j++; endwhile; endif; ?>
                </div>
                <!--Start Pagination-->
                <?php if ( $j !== 0 ) { // No pagination if there is no posts ?>
                    <?php mts_pagination(); ?>
                <?php } ?>
            <?php } elseif( !is_paged() &&  $category_id != 'latest' && $featured_category_layout == 'grid' ) { ?>
                <div class="full-width-post grid-4">
                    <div class="thecategory"><a href="<?php echo get_category_link($category_id); ?>" title="View all posts in <?php echo get_cat_name($category_id); ?>"><?php echo get_cat_name($category_id); ?></a></div>
                    <?php $cat_query1 = new WP_Query('cat='.$category_id.'&posts_per_page='.$posts_num.'&ignore_sticky_posts=1');
                    $j = 1; $i = 0; if ($cat_query1->have_posts()) : while ($cat_query1->have_posts()) : $cat_query1->the_post(); ?>
                    <article class="latestPost excerpt <?php echo (++$i % 4 == 0) ? 'last' : ''; ?>" itemscope itemtype="http://schema.org/BlogPosting">
                        <a href="<?php the_permalink(); ?>" title="" rel="nofollow" class="post-image post-image-left">
                            <?php echo '<div class="featured-thumbnail">'; the_post_thumbnail('grid',array('title' => '', 'itemprop'=> 'image')); echo '</div>'; ?>
                            <?php if (function_exists('wp_review_show_total')) wp_review_show_total(true, 'latestPost-review-wrapper'); ?>
                            <?php if(!empty($mts_options['mts_total_views'])) { ?>
                                <div class="views">                                            
                                    <?php $count = get_post_meta( get_the_id(), '_mts_view_count', true ); if ( $count )  echo __('<i class="fa fa-eye"></i>', MTS_THEME_NAME) . ' ' . $count;  ?>
                                </div>
                            <?php } ?>
                        </a>
                        <header>
                            <h2 class="title front-view-title" itemprop="headline"><a href="<?php the_permalink(); ?>" title="<?php the_title(); ?>"><?php the_title(); ?></a></h2>
                        </header>
                    </article>
                    <?php $j++; endwhile; endif; wp_reset_postdata(); ?>
                </div>
            <?php } elseif( !is_paged() && $category_id === 'latest' && $featured_category_layout == 'list' ) { ?>
                <div class="full-width-post grid-1">
                    <?php $j=1; if ( have_posts() ) : while ( have_posts() ) : the_post(); ?>
                    <article class="latestPost excerpt latestPost-left" itemscope itemtype="http://schema.org/BlogPosting">
                        <a href="<?php the_permalink(); ?>" title="" rel="nofollow" class="post-image post-image-left">
                            <?php echo '<div class="featured-thumbnail">'; the_post_thumbnail('featuredextrasmall',array('title' => '', 'itemprop'=> 'image')); echo '</div>'; ?>
                            <?php if (function_exists('wp_review_show_total')) wp_review_show_total(true, 'latestPost-review-wrapper'); ?>
                            <?php if(!empty($mts_options['mts_total_views'])) { ?>
                                <div class="views">                                            
                                    <?php $count = get_post_meta( get_the_id(), '_mts_view_count', true ); if ( $count )  echo __('<i class="fa fa-eye"></i>', MTS_THEME_NAME) . ' ' . $count;  ?>
                                </div>
                            <?php } ?>
                        </a>
                        <header>
                            <?php mts_the_postinfo(); ?>
                            <h2 class="title front-view-title" itemprop="headline"><a href="<?php the_permalink(); ?>" title="<?php the_title(); ?>"><?php the_title(); ?></a></h2>
                        </header>
                        <div class="front-view-content">
                            <?php echo mts_excerpt(20); ?>
                        </div>
                    </article>
                    <?php $j++; endwhile; endif; ?>
                    <!--Start Pagination-->
                    <?php if ( $j !== 0 ) { // No pagination if there is no posts ?>
                        <?php mts_pagination(); ?>
                    <?php } ?>
                </div>
            <?php } elseif( !is_paged() &&  $category_id != 'latest' && $featured_category_layout == 'list' ) { ?>
                <div class="full-width-post grid-1">
                    <?php $cat_query1 = new WP_Query('cat='.$category_id.'&posts_per_page='.$posts_num.'&ignore_sticky_posts=1');
                    $j = 0; if ($cat_query1->have_posts()) : while ($cat_query1->have_posts()) : $cat_query1->the_post(); ?>
                    <article class="latestPost excerpt latestPost-left" itemscope itemtype="http://schema.org/BlogPosting">
                        <a href="<?php the_permalink(); ?>" title="" rel="nofollow" class="post-image post-image-left">
                            <?php echo '<div class="featured-thumbnail">'; the_post_thumbnail('featuredextrasmall',array('title' => '', 'itemprop'=> 'image')); echo '</div>'; ?>
                            <?php if (function_exists('wp_review_show_total')) wp_review_show_total(true, 'latestPost-review-wrapper'); ?>
                            <?php if(!empty($mts_options['mts_total_views'])) { ?>
                                <div class="views">                                            
                                    <?php $count = get_post_meta( get_the_id(), '_mts_view_count', true ); if ( $count )  echo __('<i class="fa fa-eye"></i>', MTS_THEME_NAME) . ' ' . $count;  ?>
                                </div>
                            <?php } ?>
                        </a>
                        <header>
                            <?php mts_the_postinfo(); ?>
                            <h2 class="title front-view-title" itemprop="headline"><a href="<?php the_permalink(); ?>" title="<?php the_title(); ?>"><?php the_title(); ?></a></h2>
                        </header>
                        <div class="front-view-content">
                            <?php echo mts_excerpt(20); ?>
                        </div>
                    </article>
                    <?php $j++; endwhile; endif; wp_reset_postdata(); ?>
                </div>
            <?php }
        }
    } ?>
<?php get_footer(); ?>