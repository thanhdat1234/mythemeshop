<?php $mts_options = get_option(MTS_THEME_NAME); ?>
<?php get_header(); ?>
<div id="page">
	<div class="<?php mts_article_class(); ?>">
		<div id="content_box">
			<h1 class="postsby">
				<?php if (is_category()) { ?>
					<span><?php single_cat_title(); ?><?php _e(" Archive", MTS_THEME_TEXTDOMAIN ); ?></span>
				<?php } elseif (is_tag()) { ?> 
					<span><?php single_tag_title(); ?><?php _e(" Archive", MTS_THEME_TEXTDOMAIN ); ?></span>
				<?php } elseif (is_author()) { ?>
					<span><?php  $curauth = (isset($_GET['author_name'])) ? get_user_by('slug', $author_name) : get_userdata(intval($author)); echo esc_html( $curauth->nickname ); _e(" Archive", MTS_THEME_TEXTDOMAIN ); ?></span> 
				<?php } elseif (is_day()) { ?>
					<span><?php _e("Daily Archive:", MTS_THEME_TEXTDOMAIN ); ?></span> <?php the_time('l, F j, Y'); ?>
				<?php } elseif (is_month()) { ?>
					<span><?php _e("Monthly Archive:", MTS_THEME_TEXTDOMAIN ); ?></span> <?php the_time('F Y'); ?>
				<?php } elseif (is_year()) { ?>
					<span><?php _e("Yearly Archive:", MTS_THEME_TEXTDOMAIN ); ?></span> <?php the_time('Y'); ?>
				<?php } ?>
			</h1>
			<?php $m = 1; $n = 1; $j = 0; $i = 0; if (have_posts()) : while (have_posts()) : the_post();
				 if ( $m == 1 )  { ?>
					<article class="latestPost excerpt <?php echo ( ++$i > 1 ) ? 'latestPost-left post-with-sidebar' : ''; ?> <?php echo (++$j % 3 == 0) ? 'last' : ''; ?>" itemscope itemtype="http://schema.org/BlogPosting">
                        <a href="<?php the_permalink(); ?>" title="" rel="nofollow" class="post-image post-image-left">
                            <?php echo '<div class="featured-thumbnail">'; the_post_thumbnail( __(( $i > 1 ) ? 'featured' : 'featuredfull'),array('title' => '', 'itemprop'=> 'image')); echo '</div>'; ?>
                            <?php if (function_exists('wp_review_show_total')) wp_review_show_total(true, 'latestPost-review-wrapper'); ?>
                            <?php if(!empty($mts_options['mts_total_views'])) { ?>
	                            <div class="views">                                            
	                                <?php $count = get_post_meta( get_the_id(), '_mts_view_count', true ); if ( $count )  echo __('<i class="fa fa-eye"></i>', MTS_THEME_NAME) . ' ' . $count;  ?>
	                            </div>
	                        <?php } ?>
                        </a>
                        <header>
                            <?php mts_the_postinfo(); ?>
                            <h2 class="title front-view-title" itemprop="headline"><a href="<?php the_permalink(); ?>" title="<?php the_title(); ?>"><?php the_title(); ?></a></h2>
                        </header>
                        <div class="front-view-content">
                            <?php echo mts_excerpt(20); ?>
                        </div>
                    </article>
	            <?php } else { ?>
					<article class="latestPost excerpt <?php echo ( ++$i > 1 ) ? 'latestPost-left post-with-sidebar' : ''; ?> <?php echo (++$j % 3 == 0) ? 'last' : ''; ?>" itemscope itemtype="http://schema.org/BlogPosting">
			            <a href="<?php the_permalink(); ?>" title="" rel="nofollow" class="post-image post-image-left">
                            <?php echo '<div class="featured-thumbnail">'; the_post_thumbnail( __(( $i > 1 ) ? 'featured' : 'featuredfull') ,array('title' => '', 'itemprop'=> 'image')); echo '</div>'; ?>
                            <?php if (function_exists('wp_review_show_total')) wp_review_show_total(true, 'latestPost-review-wrapper'); ?>
                            <?php if(!empty($mts_options['mts_total_views'])) { ?>
	                            <div class="views">                                            
	                                <?php $count = get_post_meta( get_the_id(), '_mts_view_count', true ); if ( $count )  echo __('<i class="fa fa-eye"></i>', MTS_THEME_NAME) . ' ' . $count;  ?>
	                            </div>
	                        <?php } ?>
                        </a>
                        <header>
                            <?php mts_the_postinfo(); ?>
                            <h2 class="title front-view-title" itemprop="headline"><a href="<?php the_permalink(); ?>" title="<?php the_title(); ?>"><?php the_title(); ?></a></h2>
                        </header>
                        <div class="front-view-content">
                            <?php echo mts_excerpt(20); ?>
                        </div>
                    </article>
                	<?php } ?>
			<?php $m++; $n+3; endwhile; endif; ?>

			<?php if ( $j !== 0 ) { // No pagination if there is no posts ?>
				<?php mts_pagination(); ?>
			<?php } ?>
		</div>
	</div>
	<?php get_sidebar(); ?>
<?php get_footer(); ?>