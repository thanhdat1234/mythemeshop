<?php get_header();
$mts_options = get_option(MTS_THEME_NAME); ?>
<div id="page" class="<?php mts_single_page_class(); ?> clearfix">

	<article class="<?php mts_article_class(); ?>">
		<div id="content_box" >
			<?php if ( have_posts() ) while ( have_posts() ) : the_post(); ?>
				<div id="post-<?php the_ID(); ?>" <?php post_class('g post'); ?>>
					<header>										
						<div class="inner-page-header border-bottom clearfix">
							<?php if ($mts_options['mts_breadcrumb'] == '1') { ?>
							<div class="breadcrumb" xmlns:v="http://rdf.data-vocabulary.org/#"><?php mts_the_breadcrumb(); ?></div>
							<?php } ?>
							<h1 class="single-title inner-page-title"><?php the_title(); ?></h1>
						</div>
					</header><!--.headline_area-->
					<div class="single_post border-bottom">							
						<div class="post-single-content box mark-links entry-content">
							<div class="thecontent">
								<?php the_content(); ?>
							</div>
							<?php wp_link_pages(array('before' => '<div class="pagination">', 'after' => '</div>', 'link_before'  => '<span class="current"><span class="currenttext">', 'link_after' => '</span></span>', 'next_or_number' => 'next_and_number', 'nextpagelink' => '<i class="fa fa-angle-right"></i>', 'previouspagelink' => '<i class="fa fa-angle-left"></i>', 'pagelink' => '%','echo' => 1 )); ?>
						</div><!--.post-single-content-->
					</div><!--.single_post-->
				</div><!--.g post-->
			<?php endwhile; /* end loop */ ?>
		</div>
	</article>
<?php get_footer(); ?>