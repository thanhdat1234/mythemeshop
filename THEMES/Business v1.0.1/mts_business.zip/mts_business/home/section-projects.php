<?php
$mts_options = get_option(MTS_THEME_NAME);

$mts_homepage_projects_title = $mts_options['mts_homepage_projects_title'];

$mts_projects_num    = empty ( $mts_options['mts_projects_count_home'] ) ? '3' : $mts_options['mts_projects_count_home'];
$mts_projects_layout = $mts_options['mts_projects_layout'];

if ( '1' == $mts_projects_layout ) {
	$cols    = ' one-fourth';
	$thumb_w = 216;
	$thumb_h = 150;
} else {
	$cols    = ' one-third';
	$thumb_w = 302;
	$thumb_h = 150;
}
?>
<div id="projects" class="section clearfix">
	<div class="container">

		<?php if ( !empty( $mts_homepage_projects_title ) ) { ?>
			<h3 class="section-title pull-left"><?php echo $mts_homepage_projects_title; ?></h3>
		<?php }?>
		<a href="<?php echo get_post_type_archive_link( 'portfolio' ); ?>" class="btn-link pull-right posttype-archive-link"><?php _e( 'All projects', 'mythemeshop' ); ?></a>
		<div class="grid">
			<?php
			$query = new WP_Query();
			$query->query('post_type=portfolio&ignore_sticky_posts=1&posts_per_page='.$mts_projects_num);

			while ( $query->have_posts() ) : $query->the_post(); ?>
				
				<article class="portfolio-item grid-box<?php echo $cols; ?>">
					<div class="grid-inner project-box-inner">
						<a class="portfolio-image" href="<?php the_permalink() ?>" title="<?php the_title_attribute(); ?>" rel="nofollow">
							<?php
							if ( has_post_thumbnail() ) {

								$post_id = get_the_ID();
								$project_image = wp_get_attachment_image_src( get_post_thumbnail_id( $post_id ), 'full' );
								$project_image = $project_image[0];

								$project_image_url = bfi_thumb( $project_image, array( 'width' => $thumb_w, 'height' => $thumb_h, 'crop' => true ) );

							} else {

								$project_image_url = get_template_directory_uri().'/images/nothumb-'.$thumb_w.'x'.$thumb_h.'.png';
							}
							echo '<img src="'.$project_image_url.'">';
							?>
						</a>					
						<h2 class="project-title title"><a href="<?php the_permalink() ?>" title="<?php the_title_attribute(); ?>" rel="nofollow"><?php the_title(); ?></a></h2>
						<div class="project-description description"><?php echo mts_excerpt(18); ?></div>
								
					</div>
				</article>

	        <?php endwhile; ?>
	        <?php wp_reset_query(); ?>
		</div>
	</div>
</div>