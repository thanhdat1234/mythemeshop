<?php
$mts_options = get_option(MTS_THEME_NAME);

if ( isset( $mts_options['mts_custom_slider'] ) ) { ?>
<div id="home-slider" class="clearfix bg-slider loading has-<?php echo count($mts_options['mts_custom_slider']); ?>-slides">
	<?php
	foreach( $mts_options['mts_custom_slider'] as $slide ) :
		$image_url    = $slide['mts_custom_slider_image'];
		$slide_title  = $slide['mts_custom_slider_title'];
		$slider_text  = $slide['mts_custom_slider_text'];
	?>
		<div class="home-slide bg-slide clearfix">
			<?php
				$slide_image = empty( $image_url ) ? '' : '<img src="'. bfi_thumb( $image_url, array( 'width' => 1072, 'height' => 450, 'crop' => true ) ) .'" alt="">';
				echo $slide_image;
			?>
			<div class="home-slide-content">
				<?php if ( !empty( $slide_title ) ) { ?>
					<h2 class="home-slide-title">
						<?php echo $slide_title; ?>
					</h2>
				<?php } ?>
				<?php if ( !empty( $slider_text ) ) { ?>
					<p><?php echo $slider_text; ?></p>
				<?php } ?>
			</div><!-- .home-slide-content -->
		</div><!-- .home-slide -->
	<?php endforeach; ?>
</div><!-- #home-slider -->
<?php } ?>