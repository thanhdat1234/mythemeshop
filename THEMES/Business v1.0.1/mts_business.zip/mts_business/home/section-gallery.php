<?php
$mts_options = get_option(MTS_THEME_NAME);

$mts_homepage_gallery_title = $mts_options['mts_homepage_gallery_title'];
$mts_gallery_num    = empty ( $mts_options['mts_gallery_count_home'] ) ? '6' : $mts_options['mts_gallery_count_home'];
$mts_gallery_layout = $mts_options['mts_gallery_layout'];

if ( '1' == $mts_gallery_layout ) {
	$cols    = ' one-fourth';
	$thumb_w = 216;
	$thumb_h = 200;
} else {
	$cols    = ' one-third';
	$thumb_w = 302;
	$thumb_h = 200;
} ?>
<div id="gallery" class="section clearfix">
	<div class="container">
		<?php if ( !empty( $mts_homepage_gallery_title ) ) { ?>
			<h3 class="section-title pull-left"><?php echo $mts_homepage_gallery_title; ?></h3>
		<?php }?>
		<a href="<?php echo get_post_type_archive_link( 'gallery' ); ?>" class="btn-link pull-right posttype-archive-link"><?php _e( 'All gallery', 'mythemeshop' ); ?></a>
		<div class="grid">
			<?php
			$query = new WP_Query();
			$query->query('post_type=gallery&ignore_sticky_posts=1&posts_per_page='.$mts_gallery_num);

			while ( $query->have_posts() ) : $query->the_post(); ?>
				
				<article class="gallery-item grid-box<?php echo $cols; ?>">
					<div class="grid-inner project-box-inner">
						<a class="gallery-image" href="<?php the_permalink() ?>" title="<?php the_title_attribute(); ?>" rel="nofollow">
							<?php
							$mts_gallery_pf = get_post_meta( get_the_ID(), '_mts_gallery_post_format_type', true );
							if ( has_post_thumbnail() ) {

								$post_id = get_the_ID();
								$project_image = wp_get_attachment_image_src( get_post_thumbnail_id( $post_id ), 'full' );
								$project_image = $project_image[0];

								$project_image_url = bfi_thumb( $project_image, array( 'width' => $thumb_w, 'height' => $thumb_h, 'crop' => true ) );

							} else {

								$project_image_url = get_template_directory_uri().'/images/nothumb-'.$thumb_w.'x'.$thumb_h.'.png';
							}
							echo '<img src="'.$project_image_url.'">';
							if( $mts_gallery_pf == 'video' ){
								echo '<span class="video-icon"><i class="fa fa-play"></i></span>';
							}
							?>
						</a>	
					</div>
				</article>

	        <?php endwhile; ?>
	        <?php wp_reset_query(); ?>
		</div>
	</div>
</div>