<?php
$mts_options = get_option(MTS_THEME_NAME);

$callout_title      = $mts_options['mts_homepage_callout_title'];
$callout_description = $mts_options['mts_homepage_callout_description'];
$callout_button_label  = $mts_options['mts_homepage_callout_button_label'];
$callout_button_link  = $mts_options['mts__homepage_callout_button_link'];
?>

<div id="callout" class="section clearfix">
    <div class="container">
    <?php if( $callout_title || $callout_description ){ //Content - Title & Description?>
		<div class="grid-box callout-content">
	    	<?php if( $callout_title  ){
	    		echo '<h3 class="callout-title">'. $callout_title .'</h3>';
	    	}
	    	if( $callout_description  ){   
				echo '<div class="description callout-description">'. $callout_description .'</div>';
			} ?>
		</div>
	<?php } ?>
    </div>
    <?php
    //Button
    if ( !empty( $callout_button_link ) && !empty( $callout_button_label ) ) { ?>
    	<a href="<?php echo $callout_button_link; ?>" class="btn callout-btn"><?php echo $callout_button_label; ?></a>
    <?php } ?>
</div>