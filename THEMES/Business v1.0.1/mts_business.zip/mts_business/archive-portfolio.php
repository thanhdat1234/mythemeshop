<?php
$mts_options = get_option(MTS_THEME_NAME);

$mts_homepage_projects_title = empty ( $mts_options['mts_homepage_projects_title'] ) ? __('Portfolio', 'mythemeshop') : $mts_options['mts_homepage_projects_title'] ;
$mts_projects_layout = $mts_options['mts_projects_layout'];

if ( '1' == $mts_projects_layout ) {
	$cols    = ' one-fourth';
	$thumb_w = 216;
	$thumb_h = 200;
} else {
	$cols    = ' one-third';
	$thumb_w = 302;
	$thumb_h = 200;
}
get_header(); ?>
<div id="page">

	<div class="portfolio-header inner-page-header border-bottom clearfix">	
		<div class="container">		
			<h3 class="inner-page-title pull-left"><?php echo $mts_homepage_projects_title; ?></h3>
			<div class="pull-right portfolio-categories">
				<?php echo '<a href="' . esc_url( get_post_type_archive_link( 'portfolio' ) ) . '" class="btn active">' . __('All','mythemeshop') . '</a>';
				$terms = get_terms( 'mts_categories' );
				foreach ( $terms as $term ) {
				    $term_link = get_term_link( $term );
				    if ( is_wp_error( $term_link ) ) {
				        continue;
				    }
				    echo '<a href="' . esc_url( $term_link ) . '" class="outline-btn">' . $term->name . '</a>';
				} ?>
			</div>
		</div>
	</div>

	<div class="container">	
		<div id="projects-archive" class="grid cpt-archive">
		<?php 
			$j = 0; if ( have_posts() ) : while ( have_posts() ) : the_post(); ?>
				<article class="portfolio-item grid-box<?php echo $cols; ?>">
					<div class="grid-inner project-box-inner">
						<a class="portfolio-image" href="<?php the_permalink() ?>" title="<?php the_title_attribute(); ?>" rel="nofollow">
						<?php
						if ( has_post_thumbnail() ) {

							$post_id = get_the_ID();
							$project_image = wp_get_attachment_image_src( get_post_thumbnail_id( $post_id ), 'full' );
							$project_image = $project_image[0];

							$project_image_url = bfi_thumb( $project_image, array( 'width' => $thumb_w, 'height' => $thumb_h, 'crop' => true ) );

						} else {

							$project_image_url = get_template_directory_uri().'/images/nothumb-'.$thumb_w.'x'.$thumb_h.'.png';
						}
						echo '<img src="'.$project_image_url.'">';
						?>
					</a>
					<h2 class="project-title title"><a href="<?php the_permalink() ?>" title="<?php the_title_attribute(); ?>" rel="nofollow"><?php the_title(); ?></a></h2>
					<div class="project-description description"><?php echo mts_excerpt(18); ?></div>
					</div>
				</article><!--.post excerpt-->
			<?php $j++; endwhile; endif;
			if ( $j !== 0 ) { // No pagination if there is no results ?>
				<!--Start Pagination-->
				<?php mts_pagination('', 3, 'mts_portfolio_pagenavigation_type'); ?>
				<!--End Pagination-->
			<?php }
			?>
		</div>
	</div>
<?php get_footer(); ?>