<?php
/**
 * Template Name: Blog Page
 */
$mts_options = get_option(MTS_THEME_NAME);
get_header();
?>
<div id="page" class="blog-home clearfix">
	<div class="grid-box <?php mts_article_class(); ?>">
		<div class="inner-page-header border-bottom clearfix">
			<h1 class="inner-page-title" itemprop="headline"><?php the_title(); ?></h1>
		</div>
        <div class="blog-posts-wrapper">
			<?php $paged = ( get_query_var('paged') > 1 ) ? get_query_var('paged') : 1;
			$args = array(
				'post_type' => 'post',
				'post_status' => 'publish',
				'paged' => $paged,
				'ignore_sticky_posts'=> 1,
			);
			$latest_posts = new WP_Query( $args );

			global $wp_query;
			// Put default query object in a temp variable
			$tmp_query = $wp_query;
			// Now wipe it out completely
			$wp_query = null;
			// Re-populate the global with our custom query
			$wp_query = $latest_posts;

			$j = 0; if ( $latest_posts->have_posts() ) : while ( $latest_posts->have_posts() ) : $latest_posts->the_post(); ?>
				<article class="latestPost section excerpt panel" itemscope itemtype="http://schema.org/BlogPosting">
					<?php mts_archive_post(); ?>
				</article><!--.post excerpt-->
			<?php $j++; endwhile; endif; ?>
	    </div>
		<?php if ( $j !== 0 ) { // No pagination if there is no posts ?>
        	<?php mts_pagination(); ?> 
		<!--End Pagination-->
		<?php }
		// Restore original query object
		$wp_query = $tmp_query;
		// Be kind; rewind
		wp_reset_postdata();
		?>
	</div>
	<?php get_sidebar(); ?>
<?php get_footer(); ?>