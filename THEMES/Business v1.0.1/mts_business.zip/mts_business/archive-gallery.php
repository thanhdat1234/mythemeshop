<?php
$mts_options = get_option(MTS_THEME_NAME);

$mts_homepage_gallery_title = empty ( $mts_options['mts_homepage_gallery_title'] ) ? __('gallery', 'mythemeshop') : $mts_options['mts_homepage_gallery_title'] ;
$mts_gallery_layout = $mts_options['mts_gallery_layout'];

if ( '1' == $mts_gallery_layout ) {
	$cols    = ' one-fourth';
	$thumb_w = 216;
	$thumb_h = 200;
} else {
	$cols    = ' one-third';
	$thumb_w = 302;
	$thumb_h = 200;
}
get_header(); ?>
<div id="page">

	<div class="inner-page-header border-bottom clearfix">	
		<div class="container">		
			<h3 class="inner-page-title pull-left"><?php echo $mts_homepage_gallery_title; ?></h3>
		</div>
	</div>

	<div class="container">	
		<div id="gallery-archive" class="grid cpt-archive">
			<?php wp_reset_query(); $paged = ( get_query_var('paged') > 1 ) ? get_query_var('paged') : 1;
			$args = array(
				'post_type' => 'gallery',
				'post_status' => 'publish',
				'paged' => $paged,
				'ignore_sticky_posts'=> 1,
				'posts_per_page' => empty ( $mts_options['mts_gallery_count'] ) ? '9' : $mts_options['mts_gallery_count']
			);
			$latest_posts = new WP_Query( $args );
			$j = 0; if ( $latest_posts->have_posts() ) : while ( $latest_posts->have_posts() ) : $latest_posts->the_post(); ?>
				<article class="gallery-item grid-box<?php echo $cols; ?>">
					<div class="grid-inner project-box-inner">
						<a class="gallery-image" href="<?php the_permalink() ?>" title="<?php the_title_attribute(); ?>" rel="nofollow">
						<?php
						$mts_gallery_pf = get_post_meta( get_the_ID(), '_mts_gallery_post_format_type', true );
						if ( has_post_thumbnail() ) {

							$post_id = get_the_ID();
							$project_image = wp_get_attachment_image_src( get_post_thumbnail_id( $post_id ), 'full' );
							$project_image = $project_image[0];

							$project_image_url = bfi_thumb( $project_image, array( 'width' => $thumb_w, 'height' => $thumb_h, 'crop' => true ) );

						} else {

							$project_image_url = get_template_directory_uri().'/images/nothumb-'.$thumb_w.'x'.$thumb_h.'.png';
						}
						echo '<img src="'.$project_image_url.'">';
						if( $mts_gallery_pf == 'video' ){
							echo '<span class="video-icon"><i class="fa fa-play"></i></span>';
						}
						?>
					</a>					
					</div>
				</article><!--.post excerpt-->
			<?php $j++; endwhile; endif;
			if ( $j !== 0 ) { // No pagination if there is no results ?>
				<!--Start Pagination-->
				<?php mts_pagination('', 3, 'mts_gallery_pagenavigation_type'); ?>
				<!--End Pagination-->
			<?php } ?>
		</div>
	</div>
<?php get_footer(); ?>