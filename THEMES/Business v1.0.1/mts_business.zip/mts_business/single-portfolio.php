<?php get_header(); ?>
<div id="page" class="single single-project">

	<div class="clearfix project-showcase-wrap">
		<?php
		$showcase_type = get_post_meta( get_the_ID(), '_mts_project_showcase_type', true );
		$showcase_parallax = get_post_meta( get_the_ID(), '_mts_project_showcase_parallax', true );
		$info_title = get_post_meta( get_the_ID(), '_mts_project_info_title', true );
		$info_des = get_post_meta( get_the_ID(), '_mts_project_info_des', true );
		$entries = get_post_meta( get_the_ID(), '_mts_project_info_group', true );
		$parallax_class = ( 'on' == $showcase_parallax ) ? ' parallax' : '';
		$btn_text = get_post_meta( get_the_ID(), '_mts_project_info_btn_text', true );
		$btn_link = get_post_meta( get_the_ID(), '_mts_project_info_btn_link', true );

		if ( 'image' == $showcase_type ) {
			if( has_post_thumbnail() ) {
	            $thumb_id = get_post_thumbnail_id();
	            $thumb_url_array = wp_get_attachment_image_src($thumb_id, 'full', true);
	            $thumb_url = $thumb_url_array[0];
		        ?>
		        <div class="project-showcase project-showcase-image<?php echo $parallax_class; ?>" style="background-image: url(<?php echo $thumb_url;?>);">
		        </div>
		        <?php
		    }
		} else {
			$args = array(
				'post_type'   => 'attachment',
				'numberposts' => -1,
				'post_parent' => get_the_ID(),
				'order' => 'ASC',
				'orderby' => 'menu_order',
				'post_mime_type' => 'image',
				'exclude' => get_post_thumbnail_id(get_the_ID())
				);

			$attachments = get_posts( $args );
			if ( $attachments ){
				?>
				<div class="project-showcase project-showcase-slider bg-slider loading">
				<?php
				foreach ( $attachments as $attachment ){
					$id = $attachment->ID;
					$src =  wp_get_attachment_url($id, 'full');
					?>
					<div class="bg-slide project-showcase-image<?php echo $parallax_class; ?>" style="background-image: url(<?php echo $src;?>);"></div>
					<?php
				}
				?>
				</div>
			<?php }
		} ?>
	</div>

	<?php if ( have_posts() ) : while ( have_posts() ) : the_post(); ?>
		<article id="post-<?php the_ID(); ?>" itemscope itemtype="http://schema.org/CreativeWork" class="<?php if(empty($entries) && empty($info_title) && empty($info_des) && empty($btn_text)) { echo 'ss-full-width'; } ?>">
			<div class="inner-page-header border-bottom clearfix">	
				<h1 class="inner-page-title" itemprop="headline"><?php the_title(); ?></h1>
			</div>

			<div class="container clearfix">
				<div class="portfolio-content full-border">
					<div class="thecontent description" itemprop="description">
                        <?php the_content(); ?>
					</div>
					<?php wp_link_pages(array('before' => '<div class="pagination">', 'after' => '</div>', 'link_before'  => '<span class="current"><span class="currenttext">', 'link_after' => '</span></span>', 'next_or_number' => 'next_and_number', 'nextpagelink' => __('Next','mythemeshop'), 'previouspagelink' => __('Previous','mythemeshop'), 'pagelink' => '%','echo' => 1 )); ?>
				</div>
				<?php if(!empty($entries) || !empty($info_title) || !empty($info_des) || !empty($btn_text)) { ?>
					<div class="portfolio-sidebar">
						<?php
						if( ! empty( $info_title ) ) {
							echo '<h3 class="project-info-title">' . esc_html( $info_title ) .'</h3>';
						}

						if( ! empty( $info_des ) ){
							echo '<div class="description">' . wpautop( $info_des ) .'</div>';
						}

						if ( !empty( $entries ) ) { ?>
							<div class="project-info panel">
								<dl>
								<?php
								foreach ( (array) $entries as $key => $entry ) {

									$name = $value = $link = '';
									if ( isset( $entry['key'] ) ) $name = esc_html( $entry['key'] );
								    if ( isset( $entry['value'] ) ) $value = esc_html( $entry['value'] );
								    if ( isset( $entry['link'] ) ) $link = esc_url( $entry['link'] );

								    if ( !empty( $name ) ) {
								    	echo '<dt>'.$name.'</dt>';
								    	if( $link ){
								    		echo '<dd><a href="'. $link .'" itemprop="url">'. $value.'</a></dd>';
								    	}else{
								    		echo '<dd>'.$value.'</dd>';
								    	}
								    	
								    }
								}
								?>
								<dl>
							</div><!--.project-info-->
						<?php } 
						if( $btn_text && $btn_link ){
								echo '<a href="'. esc_url( $btn_link ) .'" class="btn launch-btn">'. esc_html( $btn_text ).'</a>';
						} ?>
					</div>
				<?php } ?>
			</div>
		</article>
	<?php endwhile; endif; /* end loop */ ?>
<?php get_footer(); ?>