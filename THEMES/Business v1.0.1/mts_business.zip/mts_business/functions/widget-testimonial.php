<?php
/*-----------------------------------------------------------------------------------

	Plugin Name: MyThemeShop Testimonial Widget
	Version: 2.0.1
	
-----------------------------------------------------------------------------------*/

class mts_testimonial_widget extends WP_Widget {

	public function __construct() {
		parent::__construct(
	 		'mts_testimonial_widget',
			__('MyThemeShop: Testimonials','mythemeshop'),
			array( 'description' => __( 'Displays Testimonials\' Carousel.','mythemeshop' ) )
		);
	}

 	public function form( $instance ) {
		$defaults = array(
			'mail' => ''
		);
		$instance = wp_parse_args((array) $instance, $defaults);
		$title = isset( $instance[ 'title' ] ) ? $instance[ 'title' ] : __( 'Testimonials','mythemeshop' );
		?>
		<p>
			<label for="<?php echo $this->get_field_id( 'title' ); ?>"><?php _e( 'Title:','mythemeshop' ); ?></label> 
			<input class="widefat" id="<?php echo $this->get_field_id( 'title' ); ?>" name="<?php echo $this->get_field_name( 'title' ); ?>" type="text" value="<?php echo esc_attr( $title ); ?>" />
		</p>
		<p>
			<?php _e('You can add testimonials from <strong>Theme Options Panel >> Sidebars Settings</strong>.','mythemeshop'); ?>
		</p>
		<?php 
	}

	public function update( $new_instance, $old_instance ) {
		$instance = array();
		$instance['title'] = strip_tags( $new_instance['title'] );
		return $instance;
	}

	public function widget( $args, $instance ) {
		extract( $args );
		$title = apply_filters( 'widget_title', $instance['title'] );

		$mts_options = get_option(MTS_THEME_NAME);

		echo $before_widget;
		if ( ! empty( $title ) ) echo $before_title . $title . $after_title;
			$testimonial_slider =  isset($mts_options['mts_testimonial_widget_slider']) ? $mts_options['mts_testimonial_widget_slider'] : '';

			if ( isset( $testimonial_slider ) && !empty($testimonial_slider)) {

				echo '<div id="testimonial-slider" class="testimonial-slider loading has-'.count($testimonial_slider).'-slides">';

					$i = 1; $m = '';

					foreach( $testimonial_slider as $slide ){
						$content    = $slide['mts_testimonial_widget_client_content'];
						$name    = $slide['mts_testimonial_widget_client_name'];

						$j = $i%2;
						$k = $i%2;

						$count = count($testimonial_slider);

						if($count % 2 != 0){
							$m = $count;
						}

						

					?>

						<?php
							if ( $j == 1 ) {
								echo '<div class="testimonial-slide">';
							}
						?>
							<div class="testimonial-slide-content">
								<?php if ( !empty( $content ) ) { ?>
								<p class="client-content">
									<?php echo $content; ?>
								</p>
								<?php } ?>
								<?php if ( !empty( $name ) ) { ?>
								<p class="client-name">- <?php echo $name; ?></p>
								<?php } ?>
							</div><!-- .testimonial-slide-content -->

						<?php
							if ( $k == 0 || $i == $m) {
								echo '</div>';
							}
						?>

					<?php

					$i++;

					}
				echo '</div>';
			}
			else{
				echo '<div><p>'.__('No Testimonial Found. You can add testimonials from <strong>Theme Options Panel >> Sidebars Settings</strong>.','mythemeshop').'</p></div>';
			}
		echo $after_widget;
	}

}

// Register widget
add_action( 'widgets_init', 'register_mts_testimonial_widget' );
function register_mts_testimonial_widget() {
	register_widget( 'mts_testimonial_widget' );
}