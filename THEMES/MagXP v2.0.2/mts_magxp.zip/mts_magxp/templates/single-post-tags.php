<?php $mts_options = get_option(MTS_THEME_NAME); ?>
<div class="tags">
	<?php mts_the_tags('<span class="tagtext">'.__('Tags','mythemeshop').':</span>',', ') ?>
</div>