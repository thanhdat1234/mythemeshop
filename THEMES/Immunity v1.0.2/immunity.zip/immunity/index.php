<?php $mts_options = get_option('immunity'); ?>
<?php get_header(); ?>
<div id="page">
	<?php if($mts_options['mts_featured_carousel'] == '1') { ?>
		<?php if (is_home() && !is_paged()) { ?>
			<div class="carousel-container loading">
				<div id="slider" class="carousel">
					<ul class="slides">
						<?php $slider_cat = 1; if($mts_options['mts_featured_carousel_cat'] != '') { $slider_cat = implode(",", $mts_options['mts_featured_carousel_cat']); } $my_query = new WP_Query('cat='.$slider_cat.'&posts_per_page=13');
							while ($my_query->have_posts()) : $my_query->the_post(); ?>
						<li> 
							<a href="<?php the_permalink() ?>">
								<?php if ( has_post_thumbnail() ) { ?> 
									<?php the_post_thumbnail('slider_thumb',array('title' => '')); ?>
								<?php } else { ?>
									<div class="featured-thumbnail">
										<img src="<?php echo get_template_directory_uri(); ?>/images/100x100.png" class="attachment-featured wp-post-image" alt="<?php the_title(); ?>">
									</div>
								<?php } ?>
								<div class="flex-caption">
									<h2 class="carouseltitle"><?php the_title(); ?></h2>
								</div>
							</a> 
						</li>
						<?php endwhile; wp_reset_query(); ?>
					</ul>
				</div>
			</div>
			<!-- carousel-container -->
		<?php } ?>
	<?php } ?>
	<?php if (is_home() && !is_paged()) { ?>
		<?php if($mts_options['mts_featured_slider'] == '1') { ?>
			<div class="slider-container loading">
				<div class="flex-container">
					<div id="slider" class="flexslider">
						<ul class="slides">
							<?php $slider_cat = implode(",", $mts_options['mts_featured_slider_cat']); $my_query = new WP_Query('cat='.$slider_cat.'&posts_per_page=9');
								while ($my_query->have_posts()) : $my_query->the_post();
								$image_id = get_post_thumbnail_id();
								$image_url = wp_get_attachment_image_src($image_id,'slider_thumb');
								$image_url = $image_url[0]; ?>
							<li data-thumb="<?php echo $image_url; ?>"> 
								<a href="<?php the_permalink() ?>">
									<?php the_post_thumbnail('slider',array('title' => '')); ?>
									<div class="flex-caption">
										<span class="slidertitle"><?php the_title(); ?></span>
									</div>
								</a> 
							</li>
							<?php endwhile; wp_reset_query(); ?>
						</ul>
					</div>
				</div>
			</div>
			<!-- slider-container -->
		<?php } ?>
	<?php } ?>
	<?php if (is_home() && !is_paged()) { ?>
		<?php get_sidebar('home'); ?>
	<?php } ?>
</div>
<?php if($mts_options['mts_grid_layout'] == '1'){ ?>
	<div class="home article">
		<?php if (is_home() && !is_paged()) { ?>
			<div class="latest-title"><h3><?php _e('Latest','mythemeshop'); ?></h3></div>
		<?php } ?>
		<div id="content_box">
			<?php if (have_posts()) : while (have_posts()) : the_post(); ?>
				<?php get_template_part( 'functions/post-format/content', get_post_format() ); ?>
			<?php endwhile; endif; ?>
		</div>
	</div>
<?php } elseif($mts_options['mts_grid_layout'] == '0'){ ?>
	<div id="page" >
		<div class="home blog-layout">
			<div id="content_box_blog">
				<?php if (have_posts()) : while (have_posts()) : the_post(); ?>
					<?php get_template_part( 'functions/post-format/content-blog', get_post_format() ); ?>
				<?php endwhile; endif; ?>
				<!--Start Pagination-->
				<?php if ($mts_options['mts_pagenavigation'] == '1' ) { ?>
					<?php if ($mts_options['mts_pagenavigation_type'] == '1' ) { ?>
						<?php  $additional_loop = 0; mts_pagination($additional_loop['max_num_pages']); ?>           
					<?php } else { ?>
						<div class="pagination">
							<ul>
								<li class="nav-previous"><?php next_posts_link( __( '&larr; '.'Older posts', 'mythemeshop' ) ); ?></li>
								<li class="nav-next"><?php previous_posts_link( __( 'Newer posts'.' &rarr;', 'mythemeshop' ) ); ?></li>
							</ul>
						</div>
					<?php } ?>
				<?php } ?>
				<!--End Pagination-->
			</div>
			<?php get_sidebar(); ?>
		</div>
	</div>
<?php } ?>
<div id="page">
	<?php if (is_home() && !is_paged()) { ?>
		<?php if($mts_options['mts_featured_tab_1'] == '1' || $mts_options['mts_featured_tab_2'] == '1' || $mts_options['mts_featured_tab_3'] == '1') { ?>
			<div id="tabber" class="home-tabber">	
				<ul class="tabs">
					<?php if($mts_options['mts_featured_tab_1'] == '1'){ ?>
						<li class="tab1"><a href="#tab1"><?php $first_tab_cat = $mts_options['mts_featured_tab_1_cat']; echo get_cat_name( $first_tab_cat ); ?></a></li>
					<?php } ?>
					<?php if($mts_options['mts_featured_tab_2'] == '1'){ ?>
						<li class="tab2"><a href="#tab2"><?php $second_tab_cat = $mts_options['mts_featured_tab_2_cat']; echo get_cat_name( $second_tab_cat ); ?></a></li>
					<?php } ?>
					<?php if($mts_options['mts_featured_tab_3'] == '1'){ ?>
						<li class="tab3"><a href="#tab3"><?php $third_tab_cat = $mts_options['mts_featured_tab_3_cat']; echo get_cat_name( $third_tab_cat ); ?></a></li>
					<?php } ?>
				</ul> <!--end .tabs-->
				<div class="clear"></div>
				<div class="inside">
					<?php if($mts_options['mts_featured_tab_1'] == '1'){ ?>
						<div id="tab1"> 
					        <ul>
								<?php $i = 1; $the_query = new WP_Query('cat='.$mts_options['mts_featured_tab_1_cat'].'&posts_per_page=6'); while ($the_query->have_posts()) : $the_query->the_post(); ?>
									<?php if($i == 1){ ?> 
										<article class="latestPost first excerpt">
											<a href="<?php the_permalink() ?>" title="<?php the_title(); ?>" rel="nofollow" id="featured-thumbnail">
												<?php if ( has_post_thumbnail() ) { ?>
													<?php echo '<div class="featured-thumbnail">'; the_post_thumbnail('featured2',array('title' => '')); echo '</div>'; ?>
												<?php } else { ?>
													<div class="featured-thumbnail">
														<img width="300" height="150" src="<?php echo get_template_directory_uri(); ?>/images/300x150.png" class="attachment-featured wp-post-image" alt="<?php the_title(); ?>">
													</div>
												<?php } ?>
											</a>
											<div class="home-content">
												<?php $post_format = (get_post_format()) ? get_post_format() : 'standard'; 	
													$icon_default = array('standard' => 'icon-pushpin', 'audio' => 'icon-volume-down', 'video' => 'icon-facetime-video','quote' => 'icon-quote-left', 'link' => 'icon-link', 'image' => 'icon-picture', 'gallery' => 'icon-camera', 'status' => 'icon-comment', 'aside' => 'icon-pushpin', 'chat' => 'icon-comment');
													$icon = $icon_default[$post_format];
													echo '<div class="center"><div class="format-icon"><i class="'.$icon.'"></i></div></div>';
												?>
												<header>
													<?php if($mts_options['mts_home_headline_meta'] == '1') { ?>
														<div class="post-info">
															<?php if(isset($mts_options['mts_home_headline_meta_info']['a']) == '1') { ?>
																<span class="theauthor"><?php  the_author_posts_link(); ?> </span>
															<?php } ?>
															<?php if(isset($mts_options['mts_home_headline_meta_info']['b']) == '1') { ?>
																<span class="thecomment"> <a rel="nofollow" href="<?php comments_link(); ?>"><?php comments_number(__('0 Comments','mythemeshop'), __('1 Comment','mythemeshop'),  __('% Comments','mythemeshop') ); ?></a></span>
															<?php } ?>
															<?php if(isset($mts_options['mts_home_headline_meta_info']['c']) == '1') { ?>
																<span class="thetime"> <?php the_time('j M Y'); ?></span> 
															<?php } ?>
														</div>
													<?php } ?>
													<h2 class="title front-view-title"><a href="<?php the_permalink() ?>" title="<?php the_title(); ?>"><?php the_title(); ?></a></h2>
												</header>
												<div class="front-view-content">
													<?php echo mts_excerpt(10);?>
												</div>
												<div class="readMore"><a href="<?php the_permalink() ?>" title="<?php the_title(); ?>" rel="nofollow"><?php _e('Read More','mythemeshop'); ?> &rarr;</a></div>
											</div>
										</article><!--.post excerpt-->
									<?php } else { ?>
										<article class="latestPost excerpt">
											<a href="<?php the_permalink() ?>" title="<?php the_title(); ?>">
												<div class="small-title">
													<div id="featured-thumbnail">
														<?php if ( has_post_thumbnail() ) { ?>
															<?php echo '<div class="featured-thumbnail">'; the_post_thumbnail('widgetthumb2',array('title' => '')); echo '</div>'; ?>
														<?php } else { ?>
															<?php $post_format = (get_post_format()) ? get_post_format() : 'standard'; 	
																$icon_default = array('standard' => 'icon-pushpin', 'audio' => 'icon-volume-down', 'video' => 'icon-facetime-video','quote' => 'icon-quote-left', 'link' => 'icon-link', 'image' => 'icon-picture', 'gallery' => 'icon-camera', 'status' => 'icon-comment', 'aside' => 'icon-pushpin', 'chat' => 'icon-comment');
																$icon = $icon_default[$post_format];
																echo '<div class="widget-icon"><i class="'.$icon.'"></i></div>';
															?>
														<?php } ?>
													</div>
													<h3 class="title front-view-title"><?php the_title(); ?></h3>
												</div>
												<div class="small thetime"><?php the_time('j M'); ?></div>
											</a>
										</article><!--.post excerpt-->
									<?php } ?>
								<?php $i++; endwhile; wp_reset_query(); ?>               
							</ul>	
					    </div> <!--end #tab1 -->
				    <?php } ?>

				    <?php if($mts_options['mts_featured_tab_2'] == '1'){ ?>
					    <div id="tab2"> 
					        <ul>
								<?php $i = 1; $the_query = new WP_Query('cat='.$mts_options['mts_featured_tab_2_cat'].'&posts_per_page=6'); while ($the_query->have_posts()) : $the_query->the_post(); ?>
									<?php if($i == 1){ ?> 
										<article class="latestPost first excerpt">
											<a href="<?php the_permalink() ?>" title="<?php the_title(); ?>" rel="nofollow" id="featured-thumbnail">
												<?php if ( has_post_thumbnail() ) { ?>
													<?php echo '<div class="featured-thumbnail">'; the_post_thumbnail('featured2',array('title' => '')); echo '</div>'; ?>
												<?php } else { ?>
													<div class="featured-thumbnail">
														<img width="300" height="150" src="<?php echo get_template_directory_uri(); ?>/images/300x150.png" class="attachment-featured wp-post-image" alt="<?php the_title(); ?>">
													</div>
												<?php } ?>
											</a>
											<div class="home-content">
												<?php $post_format = (get_post_format()) ? get_post_format() : 'standard'; 	
													$icon_default = array('standard' => 'icon-pushpin', 'audio' => 'icon-volume-down', 'video' => 'icon-facetime-video','quote' => 'icon-quote-left', 'link' => 'icon-link', 'image' => 'icon-picture', 'gallery' => 'icon-camera', 'status' => 'icon-comment', 'aside' => 'icon-pushpin', 'chat' => 'icon-comment');
													$icon = $icon_default[$post_format];
													echo '<div class="center"><div class="format-icon"><i class="'.$icon.'"></i></div></div>';
												?>
												<header>
													<?php if($mts_options['mts_home_headline_meta'] == '1') { ?>
														<div class="post-info">
															<?php if($mts_options['mts_home_headline_meta_info']['a'] == '1') { ?>
																<span class="theauthor"><?php  the_author_posts_link(); ?> </span>
															<?php } ?>
															<?php if($mts_options['mts_home_headline_meta_info']['b'] == '1') { ?>
																<span class="thecomment"> <a rel="nofollow" href="<?php comments_link(); ?>"><?php comments_number(__('0 Comments','mythemeshop'), __('1 Comment','mythemeshop'),  __('% Comments','mythemeshop') ); ?></a></span>
															<?php } ?>
															<?php if($mts_options['mts_home_headline_meta_info']['c'] == '1') { ?>
																<span class="thetime"> <?php the_time('j M Y'); ?></span> 
															<?php } ?>
														</div>
													<?php } ?>
													<h2 class="title front-view-title"><a href="<?php the_permalink() ?>" title="<?php the_title(); ?>"><?php the_title(); ?></a></h2>
												</header>
												<div class="front-view-content">
													<?php echo mts_excerpt(10);?>
												</div>
												<div class="readMore"><a href="<?php the_permalink() ?>" title="<?php the_title(); ?>" rel="nofollow"><?php _e('Read More','mythemeshop'); ?> &rarr;</a></div>
											</div>
										</article><!--.post excerpt-->
									<?php } else { ?>
										<article class="latestPost excerpt">
											<a href="<?php the_permalink() ?>" title="<?php the_title(); ?>">
												<div class="small-title">
													<div id="featured-thumbnail">
														<?php if ( has_post_thumbnail() ) { ?>
															<?php echo '<div class="featured-thumbnail">'; the_post_thumbnail('widgetthumb2',array('title' => '')); echo '</div>'; ?>
														<?php } else { ?>
															<?php $post_format = (get_post_format()) ? get_post_format() : 'standard'; 	
																$icon_default = array('standard' => 'icon-pushpin', 'audio' => 'icon-volume-down', 'video' => 'icon-facetime-video','quote' => 'icon-quote-left', 'link' => 'icon-link', 'image' => 'icon-picture', 'gallery' => 'icon-camera', 'status' => 'icon-comment', 'aside' => 'icon-pushpin', 'chat' => 'icon-comment');
																$icon = $icon_default[$post_format];
																echo '<div class="widget-icon"><i class="'.$icon.'"></i></div>';
															?>
														<?php } ?>
													</div>
													<h3 class="title front-view-title"><?php $short_title = the_title('','',false); $short_title = substr($short_title,0,32); echo $short_title . '..'; ?></h3>
												</div>
												<div class="small thetime"><?php the_time('j M'); ?></div>
											</a>
										</article><!--.post excerpt-->
									<?php } ?>
								<?php $i++; endwhile; wp_reset_query(); ?>               
							</ul>	
					    </div> <!--end #tab2 -->
					<?php } ?>

					<?php if($mts_options['mts_featured_tab_3'] == '1'){ ?>
						<div id="tab3"> 
					        <ul>
								<?php $i = 1; $the_query = new WP_Query('cat='.$mts_options['mts_featured_tab_3_cat'].'&posts_per_page=6'); while ($the_query->have_posts()) : $the_query->the_post(); ?>
									<?php if($i == 1){ ?> 
										<article class="latestPost first excerpt">
											<a href="<?php the_permalink() ?>" title="<?php the_title(); ?>" rel="nofollow" id="featured-thumbnail">
												<?php if ( has_post_thumbnail() ) { ?>
													<?php echo '<div class="featured-thumbnail">'; the_post_thumbnail('featured2',array('title' => '')); echo '</div>'; ?>
												<?php } else { ?>
													<div class="featured-thumbnail">
														<img width="300" height="150" src="<?php echo get_template_directory_uri(); ?>/images/300x150.png" class="attachment-featured wp-post-image" alt="<?php the_title(); ?>">
													</div>
												<?php } ?>
											</a>
											<div class="home-content">
												<?php $post_format = (get_post_format()) ? get_post_format() : 'standard'; 	
													$icon_default = array('standard' => 'icon-pushpin', 'audio' => 'icon-volume-down', 'video' => 'icon-facetime-video','quote' => 'icon-quote-left', 'link' => 'icon-link', 'image' => 'icon-picture', 'gallery' => 'icon-camera', 'status' => 'icon-comment', 'aside' => 'icon-pushpin', 'chat' => 'icon-comment');
													$icon = $icon_default[$post_format];
													echo '<div class="center"><div class="format-icon"><i class="'.$icon.'"></i></div></div>';
												?>
												<header>
													<?php if($mts_options['mts_home_headline_meta'] == '1') { ?>
														<div class="post-info">
															<?php if($mts_options['mts_home_headline_meta_info']['a'] == '1') { ?>
																<span class="theauthor"><?php  the_author_posts_link(); ?> </span>
															<?php } ?>
															<?php if($mts_options['mts_home_headline_meta_info']['b'] == '1') { ?>
																<span class="thecomment"> <a rel="nofollow" href="<?php comments_link(); ?>"><?php comments_number(__('0 Comments','mythemeshop'), __('1 Comment','mythemeshop'),  __('% Comments','mythemeshop') ); ?></a></span>
															<?php } ?>
															<?php if($mts_options['mts_home_headline_meta_info']['c'] == '1') { ?>
																<span class="thetime"> <?php the_time('j M Y'); ?></span> 
															<?php } ?>
														</div>
													<?php } ?>
													<h2 class="title front-view-title"><a href="<?php the_permalink() ?>" title="<?php the_title(); ?>"><?php the_title(); ?></a></h2>
												</header>
												<div class="front-view-content">
													<?php echo mts_excerpt(10);?>
												</div>
												<div class="readMore"><a href="<?php the_permalink() ?>" title="<?php the_title(); ?>" rel="nofollow"><?php _e('Read More','mythemeshop'); ?> &rarr;</a></div>
											</div>
										</article><!--.post excerpt-->
									<?php } else { ?>
										<article class="latestPost excerpt">
											<a href="<?php the_permalink() ?>" title="<?php the_title(); ?>">
												<div class="small-title">
													<div id="featured-thumbnail">
														<?php if ( has_post_thumbnail() ) { ?>
															<?php echo '<div class="featured-thumbnail">'; the_post_thumbnail('widgetthumb2',array('title' => '')); echo '</div>'; ?>
														<?php } else { ?>
															<?php $post_format = (get_post_format()) ? get_post_format() : 'standard'; 	
																$icon_default = array('standard' => 'icon-pushpin', 'audio' => 'icon-volume-down', 'video' => 'icon-facetime-video','quote' => 'icon-quote-left', 'link' => 'icon-link', 'image' => 'icon-picture', 'gallery' => 'icon-camera', 'status' => 'icon-comment', 'aside' => 'icon-pushpin', 'chat' => 'icon-comment');
																$icon = $icon_default[$post_format];
																echo '<div class="widget-icon"><i class="'.$icon.'"></i></div>';
															?>
														<?php } ?>
													</div>
													<h3 class="title front-view-title"><?php $short_title = the_title('','',false); $short_title = substr($short_title,0,32); echo $short_title . '..'; ?></h3>
												</div>
												<div class="small thetime"><?php the_time('j M'); ?></div>
											</a>
										</article><!--.post excerpt-->
									<?php } ?>
								<?php $i++; endwhile; wp_reset_query(); ?>               
							</ul>	
					    </div> <!--end #tab3 -->
				    <?php } ?>
				    
					<div class="clear"></div>
				</div> <!--end .inside -->
				<div class="clear"></div>
			</div><!--end #tabber -->
		<?php } ?>
		<div class="home-ad"><?php get_sidebar('home-2'); ?></div>
	<?php } ?>
	<?php if($mts_options['mts_grid_layout'] == '1'){ ?>
		<!--Start Pagination-->
		<?php if ($mts_options['mts_pagenavigation'] == '1' ) { ?>
			<?php if ($mts_options['mts_pagenavigation_type'] == '1' ) { ?>
				<?php  $additional_loop = 0; mts_pagination($additional_loop['max_num_pages']); ?>           
			<?php } else { ?>
				<div class="pagination">
					<ul>
						<li class="nav-previous"><?php next_posts_link( __( '&larr; '.'Older posts', 'mythemeshop' ) ); ?></li>
						<li class="nav-next"><?php previous_posts_link( __( 'Newer posts'.' &rarr;', 'mythemeshop' ) ); ?></li>
					</ul>
				</div>
			<?php } ?>
		<?php } ?>
		<!--End Pagination-->
	<?php } ?>
<?php get_footer(); ?>