jQuery(document).ready(function() {
	function isScrolledTo(elem) {
		var docViewTop = jQuery(window).scrollTop(); //num of pixels hidden above current screen
		var docViewBottom = docViewTop + jQuery(window).height();

		var elemTop = jQuery(elem).offset().top; //num of pixels above the elem
		var elemBottom = elemTop + jQuery(elem).height();

		return ((elemTop <= docViewTop));
	}

	var catcher = jQuery('#catcher');
	var sticky = jQuery('#sticky');
	
	jQuery(window).scroll(function() {
		if(isScrolledTo(sticky)) {
			sticky.css({'position':'fixed','top':'0','width':'960px'});
			jQuery('#sticky #navigation ul li a, #sticky #navigation ul li i, #sticky #headersearch #searchform .icon-search').css({'line-height':'40px'});
			jQuery('#sticky #headersearch #search-image, #sticky #headersearch #searchform .icon-search').css({'height':'40px','top':'-40px'});
			jQuery("head").append($('<style>#sticky #navigation ul li a:after, #sticky #headersearch #searchform .icon-search:after { display: none; } #sticky #navigation ul li:before { line-height: 40px; }</style>'));
		} 
		var stopHeight = catcher.offset().top + catcher.height();
		if ( stopHeight > sticky.offset().top) {
			sticky.css({'position':'relative','top':'auto','width':'auto'});
			jQuery('#sticky #navigation ul li a, #sticky #navigation ul li i, #sticky #headersearch #searchform .icon-search').css({'line-height':'80px'});
			jQuery('#sticky #headersearch #search-image, #sticky #headersearch #searchform .icon-search').css({'height':'80px','top':'-80px'});
			jQuery("head").append($('<style>#sticky #navigation ul li:before { line-height: 80px; }</style>'));
			if ($('.logo-wrap').css('display') === 'none'){
				sticky.css({'width':'100%'});
			}
		}
	});
});
