<aside class="home sidebar2 c-4-12">
	<div id="sidebars" class="g">
		<div class="sidebar">
			<ul class="sidebar_list">
				<?php if ( ! dynamic_sidebar( 'Home 300x250 Ad' )) : ?>
					
				<?php endif; ?>
			</ul>
		</div>
	</div><!--sidebars-->
</aside>