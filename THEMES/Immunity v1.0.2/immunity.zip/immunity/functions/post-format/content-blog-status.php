<?php $mts_options = get_option('immunity'); ?>
<article class="latestPost excerpt quote-post">
	<div class="home-content">
		<header>
			<h2 class="title front-view-title"><i class="icon-comment"></i><?php echo get_the_content() ?></h2>
		</header>
	</div>
</article><!--.post excerpt-->