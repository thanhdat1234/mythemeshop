<?php $mts_options = get_option('immunity'); ?>
<div class="single_post">
	<div class="format-icon"><i class="icon-comment"></i></div>
	<?php if ($mts_options['mts_breadcrumb'] == '1') { ?>
		<div class="breadcrumb" itemprop="breadcrumb"><?php mts_the_breadcrumb(); ?></div>
	<?php } ?>
	<div class="post-single-content box mark-links">
		<?php if ($mts_options['mts_posttop_adcode'] != '') { ?>
			<?php $toptime = $mts_options['mts_posttop_adcode_time']; if (strcmp( date("Y-m-d", strtotime( "-$toptime day")), get_the_time("Y-m-d") ) >= 0) { ?>
				<div class="topad">
					<?php echo $mts_options['mts_posttop_adcode']; ?>
				</div>
			<?php } ?>
		<?php } ?>
		<div class="status-post">
			<?php echo get_the_content() ?>
		</div>
		<?php wp_link_pages(array('before' => '<div class="pagination">', 'after' => '</div>', 'link_before'  => '<span class="current"><span class="currenttext">', 'link_after' => '</span></span>', 'next_or_number' => 'next_and_number', 'nextpagelink' => __('Next','mythemeshop'), 'previouspagelink' => __('Previous','mythemeshop'), 'pagelink' => '%','echo' => 1 )); ?>
		<?php if ($mts_options['mts_postend_adcode'] != '') { ?>
			<?php $endtime = $mts_options['mts_postend_adcode_time']; if (strcmp( date("Y-m-d", strtotime( "-$endtime day")), get_the_time("Y-m-d") ) >= 0) { ?>
				<div class="bottomad">
					<?php echo $mts_options['mts_postend_adcode'];?>
				</div>
			<?php } ?>
		<?php } ?> 
		<?php if($mts_options['mts_tags'] == '1') { ?>
			<div class="tags"><?php the_tags('<span class="tagtext">'.__('Tags','mythemeshop').':</span>',', ') ?></div>
		<?php } ?>
	</div>
</div><!--.single-post -->