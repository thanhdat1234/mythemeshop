<?php $mts_options = get_option('immunity'); ?>
<article class="latestPost excerpt">
	<a href="<?php the_permalink() ?>" title="<?php the_title(); ?>" rel="nofollow" id="featured-thumbnail">
		<?php if ( has_post_thumbnail() ) { ?>
			<?php echo '<div class="featured-thumbnail">'; the_post_thumbnail('slider',array('title' => '')); echo '</div>'; ?>
		<?php } ?>
	</a>
	<div class="home-content">
		<div class="center">
			<div class="format-icon"><i class="icon-pushpin"></i></div>
		</div>
		<header>
			<?php if($mts_options['mts_home_headline_meta'] == '1') { ?>
				<div class="post-info">
					<?php if(isset($mts_options['mts_home_headline_meta_info']['a']) == '1') { ?>
						<span class="theauthor"><?php  the_author_posts_link(); ?> </span>
					<?php } ?>
					<?php if(isset($mts_options['mts_home_headline_meta_info']['b']) == '1') { ?>
						<span class="thecomment"> <a rel="nofollow" href="<?php comments_link(); ?>"><?php comments_number(__('0 Comments','mythemeshop'), __('1 Comment','mythemeshop'),  __('% Comments','mythemeshop') ); ?></a></span>
					<?php } ?>
					<?php if(isset($mts_options['mts_home_headline_meta_info']['c']) == '1') { ?>
						<span class="thetime"> <?php the_time('j M Y'); ?></span> 
					<?php } ?>
				</div>
			<?php } ?>
			<h2 class="title front-view-title"><a href="<?php the_permalink() ?>" title="<?php the_title(); ?>"><?php the_title(); ?></a></h2>
		</header>
		<div class="front-view-content">
			<?php echo mts_excerpt(50);?>
		</div>
		<div class="readMore"><a href="<?php the_permalink() ?>" title="<?php the_title(); ?>" rel="nofollow"><?php _e('Read More','mythemeshop'); ?> &rarr;</a></div>
	</div>
</article><!--.post excerpt-->