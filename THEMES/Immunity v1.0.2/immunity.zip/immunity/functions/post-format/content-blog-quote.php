<?php $mts_options = get_option('immunity'); ?>
<article class="latestPost excerpt quote-post">
	<div class="home-content">
		<header>
			<h2 class="title front-view-title"><i class="icon-quote-left"></i><?php echo get_the_content() ?></h2>
			<div class="front-view-content">
				<a href="<?php echo get_post_meta($post->ID, '_format_quote_source_url', true); ?>" target="_blank"><?php if(get_post_meta($post->ID, '_format_quote_source_name', true) != ""){ echo '- ' . get_post_meta($post->ID, '_format_quote_source_name', true); } ?></a>
			</div>
		</header>
	</div>
</article><!--.post excerpt-->