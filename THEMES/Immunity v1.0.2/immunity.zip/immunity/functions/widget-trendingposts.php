<?php
/*-----------------------------------------------------------------------------------

	Plugin Name: MyThemeShop Trending Posts
	Version: 1.0
	
-----------------------------------------------------------------------------------*/


class mts_trending_posts_widget extends WP_Widget {

	public function __construct() {
		parent::__construct(
	 		'mts_trending_posts_widget',
			__('MyThemeShop: Trending Posts','mythemeshop'),
			array( 'description' => __( 'Display the most recent posts from selected category.','mythemeshop' ) )
		);
	}

 	public function form( $instance ) {
		$instance = wp_parse_args((array) $instance);
		$title = isset( $instance[ 'title' ] ) ? $instance[ 'title' ] : __( 'Trending Stories','mythemeshop' );
		$cat = isset( $instance[ 'cat' ] ) ? intval( $instance[ 'cat' ] ) : 0;
		$qty = isset( $instance[ 'qty' ] ) ? esc_attr( $instance[ 'qty' ] ) : 3;
		?>
		<p>
			<label for="<?php echo $this->get_field_id( 'title' ); ?>"><?php _e( 'Title:','mythemeshop' ); ?></label> 
			<input class="widefat" id="<?php echo $this->get_field_id( 'title' ); ?>" name="<?php echo $this->get_field_name( 'title' ); ?>" type="text" value="<?php echo esc_attr( $title ); ?>" />
		</p>
		<p>
			<label for="<?php echo $this->get_field_id( 'cat' ); ?>"><?php _e( 'Category:','mythemeshop' ); ?></label> 
			<?php wp_dropdown_categories( Array(
						'orderby'            => 'ID', 
						'order'              => 'ASC',
						'show_count'         => 1,
						'hide_empty'         => 1,
						'hide_if_empty'      => true,
						'echo'               => 1,
						'selected'           => $cat,
						'hierarchical'       => 1, 
						'name'               => $this->get_field_name( 'cat' ),
						'id'                 => $this->get_field_id( 'cat' ),
						'taxonomy'           => 'category',
					) ); ?>
		</p>
		<p>
			<label for="<?php echo $this->get_field_id( 'qty' ); ?>"><?php _e( 'Number of Posts to show','mythemeshop' ); ?></label> 
			<input id="<?php echo $this->get_field_id( 'qty' ); ?>" name="<?php echo $this->get_field_name( 'qty' ); ?>" type="number" min="1" step="1" value="<?php echo $qty; ?>" />
		</p>
	   
		<?php 
	}

	public function update( $new_instance, $old_instance ) {
		$instance = array();
		$instance['title'] = strip_tags( $new_instance['title'] );
		$instance['cat'] = intval( $new_instance['cat'] );
		$instance['qty'] = intval( $new_instance['qty'] );
		return $instance;
	}

	public function widget( $args, $instance ) {
		extract( $args );
		$title = apply_filters( 'widget_title', $instance['title'] );
		$cat = $instance['cat'];
		$qty = (int) $instance['qty'];

		echo $before_widget;
		if ( ! empty( $title ) ) echo $before_title . $title . $after_title;
		echo self::get_cat_posts( $cat, $qty );
		echo $after_widget;
	}

	public function get_cat_posts( $cat, $qty ) {
		$posts = new WP_Query(
			"cat=".$cat."&orderby=date&order=DESC&posts_per_page=".$qty
		);

		echo '<ul class="trending-posts">';
		
		while ( $posts->have_posts() ) { $posts->the_post(); ?>
		<li>
			<a href="<?php the_permalink(); ?>">
				<div class="small-title">
					<?php if(has_post_thumbnail()): ?>
						<?php the_post_thumbnail('widgetthumb2',array('title' => '')); ?>
					<?php else: ?>
						<?php $post_format = (get_post_format()) ? get_post_format() : 'standard'; 	
							$icon_default = array('standard' => 'icon-pushpin', 'audio' => 'icon-volume-down', 'video' => 'icon-facetime-video','quote' => 'icon-quote-left', 'link' => 'icon-link', 'image' => 'icon-picture', 'gallery' => 'icon-camera', 'status' => 'icon-comment', 'aside' => 'icon-pushpin', 'chat' => 'icon-comment');
							$icon = $icon_default[$post_format];
							echo '<div class="widget-icon"><i class="'.$icon.'"></i></div>';
						?>
					<?php endif; ?>
					<div class="post-title"><?php the_title(); ?></div>
				</div>
				<div class="small thetime"><?php the_time('j M'); ?></div>
			</a>
		</li>	
		<?php }			
		echo '</ul>'."\r\n";
	}

}
add_action( 'widgets_init', create_function( '', 'register_widget( "mts_trending_posts_widget" );' ) );