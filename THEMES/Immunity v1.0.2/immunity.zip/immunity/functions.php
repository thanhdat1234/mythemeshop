<?php
/*-----------------------------------------------------------------------------------*/
/*	Do not remove these lines, sky will fall on your head.
/*-----------------------------------------------------------------------------------*/
require_once( dirname( __FILE__ ) . '/theme-options.php' );
if ( ! isset( $content_width ) ) $content_width = 1060;

/*-----------------------------------------------------------------------------------*/
/*	Load Translation Text Domain
/*-----------------------------------------------------------------------------------*/
load_theme_textdomain( 'mythemeshop', get_template_directory().'/lang' );
if ( function_exists('add_theme_support') ) add_theme_support('automatic-feed-links');

/*-----------------------------------------------------------------------------------*/
/*	Post Thumbnail Support
/*-----------------------------------------------------------------------------------*/
if ( function_exists( 'add_theme_support' ) ) { 
	add_theme_support( 'post-thumbnails' );
	set_post_thumbnail_size( 223, 137, true );
	add_image_size( 'featured', 226, 150, true ); //featured
	add_image_size( 'featured2', 300, 150, true ); //featured big
	add_image_size( 'widgetthumb', 90, 75, true ); //widget thumb & Related Posts
	add_image_size( 'widgetthumb2', 66, 60, true ); //widget thumb small
	add_image_size( 'slider', 660, 300, true ); //slider
	add_image_size( 'slider_thumb', 100, 100, true ); //slider thumb
	add_image_size( 'related', 125, 80, true ); //slider thumb
}

/*-----------------------------------------------------------------------------------*/
/*	Custom Menu Support
/*-----------------------------------------------------------------------------------*/
add_theme_support( 'menus' );
if ( function_exists( 'register_nav_menus' ) ) {
	register_nav_menus(
		array(
		  'primary-menu' => 'Primary Menu'
		)
	);
}

/*-----------------------------------------------------------------------------------*/
/*	Enable Widgetized sidebar and Footer
/*-----------------------------------------------------------------------------------*/
if ( function_exists('register_sidebar') )
	register_sidebar(array(
		'name'=>'HomePage Widget Area',
		'description'   => __( 'Appears on Homepage below slider.', 'mythemeshop' ),
		'before_widget' => '<li id="%1$s" class="widget widget-sidebar %2$s">',
		'after_widget' => '</li>',
		'before_title' => '<h3 class="widget-title">',
		'after_title' => '</h3>',
	));
	register_sidebar(array(
		'name'=>'Home 300x250 Ad',
		'description'   => __( 'Appears to the right side of HomePage Tabbed Area.', 'mythemeshop' ),
		'before_widget' => '<li id="%1$s" class="widget widget-sidebar %2$s">',
		'after_widget' => '</li>',
		'before_title' => '<h3 class="widget-title">',
		'after_title' => '</h3>',
	));
	register_sidebar(array(
		'name'=>'Sidebar',
		'description'   => __( 'Appears on Posts and Pages.', 'mythemeshop' ),
		'before_widget' => '<li id="%1$s" class="widget widget-sidebar %2$s">',
		'after_widget' => '</li>',
		'before_title' => '<h3 class="widget-title">',
		'after_title' => '</h3>',
	));
	register_sidebar(array(
		'name' => 'Left Footer',
		'description'   => __( 'Appears in left side of footer.', 'mythemeshop' ),
		'id' => 'footer-1',
		'before_widget' => '<div id="%1$s" class="widget %2$s">',
		'after_widget' => '</div>',
		'before_title' => '<h3 class="widget-title">',
		'after_title' => '</h3>',
	));
	register_sidebar(array(
		'name' => 'Center Footer',
		'description'   => __( 'Appears in center of footer.', 'mythemeshop' ),
		'id' => 'footer-2',
		'before_widget' => '<div id="%1$s" class="widget %2$s">',
		'after_widget' => '</div>',
		'before_title' => '<h3 class="widget-title">',
		'after_title' => '</h3>',
	));
	register_sidebar(array(
		'name' => 'Right Footer',
		'description'   => __( 'Appears in right side of footer.', 'mythemeshop' ),
		'id' => 'footer-3',
		'before_widget' => '<div id="%1$s" class="widget %2$s">',
		'after_widget' => '</div>',
		'before_title' => '<h3 class="widget-title">',
		'after_title' => '</h3>',
	));

/*-----------------------------------------------------------------------------------*/
/*  Load Widgets & Shortcodes
/*-----------------------------------------------------------------------------------*/
// Add the 125x125 Ad Block Custom Widget
include("functions/widget-ad125.php");

// Add the 300x250 Ad Block Custom Widget
include("functions/widget-ad300.php");

// Add the Tabbed Custom Widget
include("functions/widget-tabs.php");

// Add the Latest Tweets Custom Widget
include("functions/widget-tweets.php");

// Add the Theme Shortcodes
include("functions/theme-shortcodes.php");

// Add Recent Posts Widget
include("functions/widget-recentposts.php");

// Add Related Posts Widget
include("functions/widget-relatedposts.php");

// Add Popular Posts Widget
include("functions/widget-popular.php");

// Add Facebook Like box Widget
include("functions/widget-fblikebox.php");

// Add Google Plus box Widget
include("functions/widget-googleplus.php");

// Add Subscribe Widget
include("functions/widget-subscribe.php");

// Add Social Profile Widget
include("functions/widget-social.php");

// Add Featured Category slider Posts Widget
include("functions/widget-catposts.php");

// Add Trending Posts Widget
include("functions/widget-trendingposts.php");

// Add Welcome message
include("functions/welcome-message.php");

// Theme Functions
include("functions/theme-actions.php");

// Plugin Activation
include("functions/class-tgm-plugin-activation.php");

/*-----------------------------------------------------------------------------------*/
/*	Filters customize wp_title
/*-----------------------------------------------------------------------------------*/
function mts_wp_title( $title, $sep ) {
	global $paged, $page;

	if ( is_feed() )
		return $title;

	// Add the site name.
	$title .= get_bloginfo( 'name' );

	// Add the site description for the home/front page.
	$site_description = get_bloginfo( 'description', 'display' );
	if ( $site_description && ( is_home() || is_front_page() ) )
		$title = "$title $sep $site_description";

	// Add a page number if necessary.
	if ( $paged >= 2 || $page >= 2 )
		$title = "$title $sep " . sprintf( __( 'Page %s', 'mythemeshop' ), max( $paged, $page ) );

	return $title;
}
add_filter( 'wp_title', 'mts_wp_title', 10, 2 );

/*-----------------------------------------------------------------------------------*/
/*	Javascsript
/*-----------------------------------------------------------------------------------*/
function mts_add_scripts() {
	$mts_options = get_option('immunity');

	wp_enqueue_script('jquery');

	if ( is_singular() && comments_open() && get_option( 'thread_comments' ) ) {
		wp_enqueue_script( 'comment-reply' );
	}
	
	wp_register_script('customscript', get_template_directory_uri() . '/js/customscript.js', true);
	wp_enqueue_script ('customscript');

	//Slider
	wp_register_script('flexslider', get_template_directory_uri() . '/js/jquery.flexslider-min.js');
	wp_enqueue_script ('flexslider');

	global $is_IE;
    if ($is_IE) {
        wp_register_script ('html5shim', "http://html5shim.googlecode.com/svn/trunk/html5.js");
        wp_enqueue_script ('html5shim');
	}
}
add_action('wp_enqueue_scripts','mts_add_scripts');
   
function mts_load_footer_scripts() {  
	$mts_options = get_option('immunity');
	
	// Site wide js
	wp_register_script('modernizr', get_template_directory_uri() . '/js/modernizr.min.js', true);
	wp_enqueue_script ('modernizr');

	//Lightbox
	if($mts_options['mts_lightbox'] == '1') {
		wp_register_script('prettyPhoto', get_template_directory_uri() . '/js/jquery.prettyPhoto.js', true);
		wp_enqueue_script('prettyPhoto');
	}
	
	//Sticky Nav
	if($mts_options['mts_sticky_nav'] == '1') {
		wp_register_script('StickyNav', get_template_directory_uri() . '/js/sticky.js', true);
		wp_enqueue_script('StickyNav');
	}
}  
add_action('wp_footer', 'mts_load_footer_scripts');  

/*-----------------------------------------------------------------------------------*/
/* Enqueue CSS
/*-----------------------------------------------------------------------------------*/
function mts_enqueue_css() {
	$mts_options = get_option('immunity');

	//Font Awesome
	wp_register_style('fontawesome', get_template_directory_uri() . '/css/font-awesome.min.css', 'style');
	wp_enqueue_style('fontawesome');
	global $is_IE;
    if ($is_IE) {
       wp_register_style('ie7-fontawesome', get_template_directory_uri() . '/css/font-awesome-ie7.min.css', 'style');
	   wp_enqueue_style('ie7-fontawesome');
	}

	//slider
	wp_register_style('flexslider', get_template_directory_uri() . '/css/flexslider.css', 'style');
	wp_enqueue_style('flexslider');

	if ( in_array( 'woocommerce/woocommerce.php', apply_filters( 'active_plugins', get_option( 'active_plugins' ) ) ) ) {
		//WooCommerce
		wp_register_style('woocommerce', get_template_directory_uri() . '/css/woocommerce2.css', 'style');
		wp_enqueue_style('woocommerce');
	}
	
	//lightbox
	if($mts_options['mts_lightbox'] == '1') {
		wp_register_style('prettyPhoto', get_template_directory_uri() . '/css/prettyPhoto.css', 'style');
		wp_enqueue_style('prettyPhoto');
	}
	
	wp_enqueue_style('stylesheet', get_stylesheet_directory_uri() . '/style.css', 'style');
	
	//Responsive
	if($mts_options['mts_responsive'] == '1') {
        wp_enqueue_style('responsive', get_template_directory_uri() . '/css/responsive.css', 'style');
	}
	
	if ($mts_options['mts_header_bg_pattern_upload'] != '') {
		$mts_header_bg = $mts_options['mts_header_bg_pattern_upload'];
	} else {
		if($mts_options['mts_header_bg_pattern'] != '') {
			$mts_header_bg = get_template_directory_uri().'/images/'.$mts_options['mts_header_bg_pattern'].'.png';
		}
	}
	if ($mts_options['mts_bg_pattern_upload'] != '') {
		$mts_bg = $mts_options['mts_bg_pattern_upload'];
	} else {
		if($mts_options['mts_bg_pattern'] != '') {
			$mts_bg = get_template_directory_uri().'/images/'.$mts_options['mts_bg_pattern'].'.png';
		}
	}

	if ($mts_options['mts_footer_bg_pattern_upload'] != '') {
		$mts_footer_bg = $mts_options['mts_footer_bg_pattern_upload'];
	} else {
		if($mts_options['mts_footer_bg_pattern'] != '') {
			$mts_footer_bg = get_template_directory_uri().'/images/'.$mts_options['mts_footer_bg_pattern'].'.png';
		}
	}
	$mts_sclayout = '';
	$mts_shareit_left = '';
	$mts_shareit_right = '';
	$mts_author = '';
	$mts_header_section = '';
	$mts_slider_active = '';
	$mts_single_layout = '';
	$home_ad_sidebar = '';
	$mts_cart_position = '';
	$mts_home_icon = '';
	$mts_single_icon = '';
	$mts_header_search = '';
	if ($mts_options['mts_search_form'] == '0') {
		$mts_header_search = '#navigation ul { margin-right: 0; }';
	}
	if ($mts_options['mts_home_post_format_icon'] == '0') {
		$mts_home_icon = '.home-content .center { display:none; } .home-content { padding-top: 10px; }';
	}
	if ($mts_options['mts_single_post_format_icon'] == '0') {
		$mts_single_icon = '.single_post .format-icon { display:none; }';
	}
	if ($mts_options['mts_layout'] == 'sclayout') {
		$mts_sclayout = '.article, #content_box_blog { float: right;}
		.sidebar.c-4-12 { float: left; padding-right: 0; }';
	}
	if ($mts_options['mts_featured_slider'] == '0') {
		$mts_slider_active = '.home .main-container-bg { background: none; } .home .main-header, .paged .main-header, .single .main-header { background-color:'.$mts_options['mts_header_bg_color'].'; background-image: url("'.$mts_header_bg.'"); margin-bottom: 30px; }';
	}
	if ($mts_options['mts_header_section2'] == '0') {
		$mts_header_section = '.logo-wrap, .widget-header { display: none; } #navigation { border-top: 0; } 		#header { min-height: 47px; } .secondary-navigation { width: 100%; float: left; }
@media screen and (max-width:865px) { .home .main-header, .paged .main-header, .single .main-header { min-height: 0; padding-bottom: 13px!important; } #header { min-height: 0;} }';
	}
	if($mts_options['mts_social_button_position'] == '3') {
		$mts_shareit_left = '.shareit { top: 300px; left: auto; z-index: 0; margin: 0 0 0 -110px; width: 90px; position: fixed; overflow: hidden; padding: 5px; border:none; border-right: 0; background: #fff; }
		.share-item {margin: 2px;}';
	} else {
		$mts_shareit_left = '.shareit { margin-right: 0; margin-left: 0; }';
	}
	if($mts_options['mts_author_comment'] == '1') {
		$mts_author = '.bypostauthor .comment-wrap {background: #E9E9E9;-webkit-box-shadow: none;-moz-box-shadow: none;box-shadow: none;}';
	}
	if($mts_options['mts_featured_tab_1'] == '0' && $mts_options['mts_featured_tab_2'] == '0' && $mts_options['mts_featured_tab_3'] == '0') {
		$home_ad_sidebar = '.home-ad { width:100%; } .home-ad .widget {width: 31.2%; clear: none; margin-right: 3%;}';
	}
	if($mts_options['mts_layout'] == 'cslayout') {
		if ($mts_options['mts_single_post_layout'] == 'rclayout' && $mts_options['mts_social_button_position'] 
== '3' ) {
			$mts_shareit_right = '.shareit { margin: 0 0 0 -110px; }';
		}
	}
	if($mts_options['mts_layout'] == 'sclayout') {
		if ($mts_options['mts_single_post_layout'] == 'rclayout' && $mts_options['mts_social_button_position'] 
== '3' ) {
			$mts_shareit_right = '.shareit { margin: 0 0 0 645px; }';
		} elseif ($mts_options['mts_single_post_layout'] == 'crlayuot' || $mts_options['mts_single_post_layout'] == 'cbrlayout' || $mts_options['mts_single_post_layout'] == 'clayout') {
			if( $mts_options['mts_social_button_position'] == '3') {
				$mts_shareit_right = '.shareit { margin: 0 0 0 648px; }';
			}
		}
		$mts_cart_position = '.single-product .mts-cart { left:0; }';
	}
	if($mts_options['mts_single_post_layout'] == 'crlayuot') {
		$mts_single_layout = '
			.single_post { width: 77%; float: left; }';
	}elseif($mts_options['mts_single_post_layout'] == 'rclayout') {
		$mts_single_layout = '
			.single_post { width: 77%; float: right; }
			.related-posts2 { float: left; }';
	}elseif($mts_options['mts_single_post_layout'] == 'clayout' || $mts_options['mts_single_post_layout'] == 'cbrlayout') {
		$mts_single_layout = '
			.single_post { width: 100%; }';
	}
	$custom_css = "
		body, .main-container {background-color:{$mts_options['mts_bg_color']}; background-image: url({$mts_bg}); }
		.main-container-bg, .main-header {background-color:{$mts_options['mts_header_bg_color']}; background-image: url({$mts_header_bg});}
		footer {background-color:{$mts_options['mts_footer_bg_color']}; background-image: url({$mts_footer_bg});}
		.secondary-navigation, #navigation ul li, #headersearch #searchform .icon-search, #header #searchform, #navigation ul ul li:hover {background-color:{$mts_options['mts_nav_bg_color']}; }
		.postauthor h5, .copyrights a, .single_post a, .sidebar .textwidget a, footer .textwidget a, #logo a, .pnavigation2 a, .sidebar.c-4-12 a:hover, .copyrights a:hover, footer .widget li a:hover, .sidebar.c-4-12 a:hover, .related-posts li:hover a, .title a:hover, .post-info a:hover, .comm, #tabber .inside li a:hover, .readMore a:hover, .fn a, a, a:hover, .related-posts .post-info a, .comment-meta a, .sidebar.c-4-12 .mts_recent_tweets a, footer .mts_recent_tweets a, .readMore a, .thecomment span, #wp-calendar a { color:{$mts_options['mts_color_scheme']}; }
			.reply a, #commentform input#submit, .contactform #submit, .mts-subscribe input[type='submit'], #move-to-top:hover, #searchform .icon-search, #navigation ul li.current-menu-item, #navigation ul li:hover, .pagination a, #tabber ul.tabs li a.selected, .tagcloud a, #navigation ul .sfHover li, .flex-caption, .widget-slider .slider-title, .widget .widget-slider .flex-direction-nav li,.widget-slider .format-icon:after, .small.thetime, .widget-icon, .mts_recent_tweets.tweets .icon-twitter, .quote-post .home-content, .home .latestPost .format-icon:before, .single_post .format-icon, .mejs-controls .mejs-time-rail .mejs-time-loaded, .woocommerce a.button, .woocommerce-page a.button, .woocommerce button.button, .woocommerce-page button.button, .woocommerce input.button, .woocommerce-page input.button, .woocommerce #respond input#submit, .woocommerce-page #respond input#submit, .woocommerce #content input.button, .woocommerce-page #content input.button, .woocommerce nav.woocommerce-pagination ul li a, .woocommerce-page nav.woocommerce-pagination ul li a, .woocommerce #content nav.woocommerce-pagination ul li a, .woocommerce-page #content nav.woocommerce-pagination ul li a, .woocommerce .bypostauthor:after, #searchsubmit, .woocommerce nav.woocommerce-pagination ul li a:focus, .woocommerce-page nav.woocommerce-pagination ul li a:focus, .woocommerce #content nav.woocommerce-pagination ul li a:focus, .woocommerce-page #content nav.woocommerce-pagination ul li a:focus, .woocommerce a.button, .woocommerce-page a.button, .woocommerce button.button, .woocommerce-page button.button, .woocommerce input.button, .woocommerce-page input.button, .woocommerce #respond input#submit, .woocommerce-page #respond input#submit, .woocommerce #content input.button, .woocommerce-page #content input.button, .woocommerce ul.products li.product .onsale, .woocommerce-page ul.products li.product .onsale, .woocommerce span.onsale, .woocommerce-page span.onsale, .flex-control-thumbs li, .carousel .flex-direction-nav a, .carousel .flex-caption { background-color:{$mts_options['mts_color_scheme']}; color: #fff!important; }
		{$mts_sclayout}
		{$mts_shareit_left}
		{$mts_header_search}
		{$mts_single_icon}
		{$mts_home_icon}
		{$mts_shareit_right}
		{$mts_cart_position}
		{$mts_author}
		{$mts_header_section}
		{$home_ad_sidebar}
		{$mts_slider_active}
		{$mts_single_layout}
		{$mts_options['mts_custom_css']}
			";
	wp_add_inline_style( 'stylesheet', $custom_css );
}
add_action('wp_enqueue_scripts', 'mts_enqueue_css', 99);

/*-----------------------------------------------------------------------------------*/
/*	Filters that allow shortcodes in Text Widgets
/*-----------------------------------------------------------------------------------*/
add_filter('widget_text', 'shortcode_unautop');
add_filter('widget_text', 'do_shortcode');
add_filter('the_content_rss', 'do_shortcode');

/*-----------------------------------------------------------------------------------*/
/*	Custom Comments template
/*-----------------------------------------------------------------------------------*/
function mts_comments($comment, $args, $depth) {
	$GLOBALS['comment'] = $comment; ?>
	<li <?php comment_class(); ?> id="li-comment-<?php comment_ID() ?>">
		<div id="comment-<?php comment_ID(); ?>" style="position:relative;">
			<div class="comment-author vcard">
				<?php echo get_avatar( $comment->comment_author_email, 68 ); ?>
			</div>
			<div class="comment-wrap">
				<?php printf(__('<span class="fn">%s</span>', 'mythemeshop'), get_comment_author_link()) ?> 
				<?php $mts_options = get_option('immunity'); if($mts_options['mts_comment_date'] == '1') { ?>
					<span class="ago"><?php comment_date(get_option( 'date_format' )); ?></span>
				<?php } ?>
				<span class="comment-meta">
					<?php edit_comment_link(__('(Edit)', 'mythemeshop'),'  ','') ?>
				</span>
				<?php if ($comment->comment_approved == '0') : ?>
					<em><?php _e('Your comment is awaiting moderation.', 'mythemeshop') ?></em>
					<br />
				<?php endif; ?>
				<div class="commentmetadata">
					<?php comment_text() ?>
		            <div class="reply">
						<?php comment_reply_link(array_merge( $args, array('depth' => $depth, 'max_depth' => $args['max_depth']))) ?>
					</div>
				</div>
			</div>
		</div>
	</li>
<?php }

/*-----------------------------------------------------------------------------------*/
/*	excerpt
/*-----------------------------------------------------------------------------------*/
function mts_excerpt($limit) {
  $excerpt = explode(' ', get_the_excerpt(), $limit);
  if (count($excerpt)>=$limit) {
    array_pop($excerpt);
    $excerpt = implode(" ",$excerpt);
  } else {
    $excerpt = implode(" ",$excerpt);
  }
  $excerpt = preg_replace('`[[^]]*]`','',$excerpt);
  return $excerpt;
}

/*-----------------------------------------------------------------------------------*/
/* nofollow to next/previous links
/*-----------------------------------------------------------------------------------*/
function mts_pagination_add_nofollow($content) {
    return 'rel="nofollow"';
}
add_filter('next_posts_link_attributes', 'mts_pagination_add_nofollow' );
add_filter('previous_posts_link_attributes', 'mts_pagination_add_nofollow' );

/*-----------------------------------------------------------------------------------*/
/* Nofollow to category links
/*-----------------------------------------------------------------------------------*/
add_filter( 'the_category', 'mts_add_nofollow_cat' ); 
function mts_add_nofollow_cat( $text ) {
$text = str_replace('rel="category tag"', 'rel="nofollow"', $text); return $text;
}

/*-----------------------------------------------------------------------------------*/	
/* nofollow post author link
/*-----------------------------------------------------------------------------------*/
add_filter('the_author_posts_link', 'mts_nofollow_the_author_posts_link');
function mts_nofollow_the_author_posts_link ($link) {
return str_replace('<a href=', '<a rel="nofollow" href=',$link); 
}

/*-----------------------------------------------------------------------------------*/	
/* nofollow to reply links
/*-----------------------------------------------------------------------------------*/
function mts_add_nofollow_to_reply_link( $link ) {
return str_replace( '")\'>', '")\' rel=\'nofollow\'>', $link );
}
add_filter( 'comment_reply_link', 'mts_add_nofollow_to_reply_link' );

/*-----------------------------------------------------------------------------------*/
/* removes the WordPress version from your header for security
/*-----------------------------------------------------------------------------------*/
function wb_remove_version() {
	return '<!--Theme by MyThemeShop.com-->';
}
add_filter('the_generator', 'wb_remove_version');
	
/*-----------------------------------------------------------------------------------*/
/* Removes Trackbacks from the comment count
/*-----------------------------------------------------------------------------------*/
add_filter('get_comments_number', 'mts_comment_count', 0);
function mts_comment_count( $count ) {
	if ( ! is_admin() ) {
		global $id;
		$comments_by_type = &separate_comments(get_comments('status=approve&post_id=' . $id));
		return count($comments_by_type['comment']);
	} else {
		return $count;
	}
}

/*-----------------------------------------------------------------------------------*/
/* adds a class to the post if there is a thumbnail
/*-----------------------------------------------------------------------------------*/
function has_thumb_class($classes) {
	global $post;
	if( has_post_thumbnail($post->ID) ) { $classes[] = 'has_thumb'; }
		return $classes;
}
add_filter('post_class', 'has_thumb_class');

/*-----------------------------------------------------------------------------------*/	
/* Breadcrumb
/*-----------------------------------------------------------------------------------*/
function mts_the_breadcrumb() {
	echo '<a href="';
	echo home_url();
	echo '" rel="nofollow"><i class="icon-home"></i>&nbsp;'.__('Home','mythemeshop');
	echo "</a>";
	if (is_category() || is_single()) {
		echo "&nbsp;>&nbsp;";
		the_category(' & ');
			if (is_single()) {
				echo "&nbsp;>&nbsp;";
				the_title();
			}
	} elseif (is_page()) {
		echo "&nbsp;>&nbsp;";
		echo the_title();
	} elseif (is_search()) {
		echo "&nbsp;>&nbsp;".__('Search Results for','mythemeshop')."... ";
		echo '"<em>';
		echo the_search_query();
		echo '</em>"';
	}
}

/*-----------------------------------------------------------------------------------*/	
/* Pagination
/*-----------------------------------------------------------------------------------*/
function mts_pagination($pages = '', $range = 3) { 
	$showitems = ($range * 3)+1;
	global $paged; if(empty($paged)) $paged = 1;
	if($pages == '') {
		global $wp_query; $pages = $wp_query->max_num_pages; 
		if(!$pages){ $pages = 1; } 
	}
	if(1 != $pages) { 
		echo "<div class='pagination'><ul>";
		if($paged > 2 && $paged > $range+1 && $showitems < $pages) 
			echo "<li><a rel='nofollow' href='".get_pagenum_link(1)."'>&laquo; ".__('First','mythemeshop')."</a></li>";
		if($paged > 1 && $showitems < $pages) 
			echo "<li><a rel='nofollow' href='".get_pagenum_link($paged - 1)."' class='inactive'>&lsaquo; ".__('Previous','mythemeshop')."</a></li>";
		for ($i=1; $i <= $pages; $i++){ 
			if (1 != $pages &&( !($i >= $paged+$range+1 || $i <= $paged-$range-1) || $pages <= $showitems )) { 
				echo ($paged == $i)? "<li class='current'><span class='currenttext'>".$i."</span></li>":"<li><a rel='nofollow' href='".get_pagenum_link($i)."' class='inactive'>".$i."</a></li>";
			} 
		} 
		if ($paged < $pages && $showitems < $pages) 
			echo "<li><a rel='nofollow' href='".get_pagenum_link($paged + 1)."' class='inactive'>".__('Next','mythemeshop')." &rsaquo;</a></li>";
		if ($paged < $pages-1 &&  $paged+$range-1 < $pages && $showitems < $pages) 
			echo "<li><a rel='nofollow' class='inactive' href='".get_pagenum_link($pages)."'>".__('Last','mythemeshop')." &raquo;</a></li>";
			echo "</ul></div>"; 
	}
}

/*-----------------------------------------------------------------------------------*/
/* Redirect feed to feedburner
/*-----------------------------------------------------------------------------------*/
$mts_options = get_option('immunity');
if ( isset($mts_options['mts_feedburner']) != '') {
function mts_rss_feed_redirect() {
    $mts_options = get_option('immunity');
    global $feed;
    $new_feed = $mts_options['mts_feedburner'];
    if (!is_feed()) {
            return;
    }
    if (preg_match('/feedburner/i', $_SERVER['HTTP_USER_AGENT'])){
            return;
    }
    if ($feed != 'comments-rss2') {
            if (function_exists('status_header')) status_header( 302 );
            header("Location:" . $new_feed);
            header("HTTP/1.1 302 Temporary Redirect");
            exit();
    }
}
add_action('template_redirect', 'mts_rss_feed_redirect');
}

/*-----------------------------------------------------------------------------------*/
/* Single Post Pagination
/*-----------------------------------------------------------------------------------*/
function mts_wp_link_pages_args_prevnext_add($args)
{
    global $page, $numpages, $more, $pagenow;
    if (!$args['next_or_number'] == 'next_and_number')
        return $args; 
    $args['next_or_number'] = 'number'; 
    if (!$more)
        return $args; 
    if($page-1) 
        $args['before'] .= _wp_link_page($page-1)
        . $args['link_before']. $args['previouspagelink'] . $args['link_after'] . '</a>'
    ;
    if ($page<$numpages) 
    
        $args['after'] = _wp_link_page($page+1)
        . $args['link_before'] . $args['nextpagelink'] . $args['link_after'] . '</a>'
        . $args['after']
    ;
    return $args;
}
add_filter('wp_link_pages_args', 'mts_wp_link_pages_args_prevnext_add');

/*-----------------------------------------------------------------------------------*/
/* WooCommerce
/*-----------------------------------------------------------------------------------*/
if ( in_array( 'woocommerce/woocommerce.php', apply_filters( 'active_plugins', get_option( 'active_plugins' ) ) ) ) {
add_theme_support('woocommerce');

// Register Single Product Sidebar
register_sidebar(array(
	'name' => 'Shop Sidebar',
	'description'   => __( 'Appears on single product pages.', 'mythemeshop' ),
	'id' => 'product-sidebar',
	'before_widget' => '<li id="%1$s" class="widget %2$s">',
	'after_widget' => '</li>',
	'before_title' => '<h3 class="widget-title">',
	'after_title' => '</h3>',
));

// Change number or products per row to 3
add_filter('loop_shop_columns', 'loop_columns');
if (!function_exists('loop_columns')) {
	function loop_columns() {
		return 4; // 4 products per row
	}
}

// Redefine woocommerce_output_related_products()
function woocommerce_output_related_products() {
woocommerce_related_products(3,1); // Display 3 products in rows of 1
}

/*** Hook in on activation */
global $pagenow;
if ( is_admin() && isset( $_GET['activated'] ) && $pagenow == 'themes.php' ) add_action( 'init', 'mythemeshop_woocommerce_image_dimensions', 1 );
 
/*** Define image sizes */
function mythemeshop_woocommerce_image_dimensions() {
  	$catalog = array(
		'width' 	=> '226',	// px
		'height'	=> '150',	// px
		'crop'		=> 1 		// true
	);
	$single = array(
		'width' 	=> '300',	// px
		'height'	=> '200',	// px
		'crop'		=> 1 		// true
	);
	$thumbnail = array(
		'width' 	=> '100',	// px
		'height'	=> '100',	// px
		'crop'		=> 1 		// false
	); 
	// Image sizes
	update_option( 'shop_catalog_image_size', $catalog ); 		// Product category thumbs
	update_option( 'shop_single_image_size', $single ); 		// Single product image
	update_option( 'shop_thumbnail_image_size', $thumbnail ); 	// Image gallery thumbs
}

add_filter ( 'woocommerce_product_thumbnails_columns', 'mts_thumb_cols' );
 function mts_thumb_cols() {
     return 3; // .last class applied to every 3th thumbnail
 }
}

// Display 24 products per page. Goes in functions.php
$mts_home_producst = $mts_options['mts_shop_products'];
add_filter( 'loop_shop_per_page', create_function( '$cols', 'return '.$mts_home_producst.';' ), 20 );

/*------------[ Cart ]-------------*/
if ( ! function_exists( 'mts_cart' ) ) {
	function mts_cart() { 
	global $mts_options;
if ( in_array( 'woocommerce/woocommerce.php', apply_filters( 'active_plugins', get_option( 'active_plugins' ) ) ) ) {
?>
<div class="mts-cart">
	<?php global $woocommerce; ?>
	<span>
		<i class="icon-user"></i> 
		<?php if ( is_user_logged_in() ) { ?>
			<a href="<?php echo get_permalink( get_option('woocommerce_myaccount_page_id') ); ?>" title="<?php _e('My Account','mythemeshop'); ?>"><?php _e('My Account','mythemeshop'); ?></a>
		<?php } 
		else { ?>
			<a href="<?php echo get_permalink( get_option('woocommerce_myaccount_page_id') ); ?>" title="<?php _e('Login / Register','mythemeshop'); ?>"><?php _e('Login ','mythemeshop'); ?></a>
		<?php } ?>
	</span>
	<span>
		<i class="icon-shopping-cart"></i> <a class="cart-contents" href="<?php echo $woocommerce->cart->get_cart_url(); ?>" title="<?php _e('View your shopping cart', 'mythemeshop'); ?>"><?php echo sprintf(_n('%d item', '%d items', $woocommerce->cart->cart_contents_count, 'mythemeshop'), $woocommerce->cart->cart_contents_count);?> - <?php echo $woocommerce->cart->get_cart_total(); ?></a>
	</span>
</div>
<?php } }

// Ensure cart contents update when products are added to the cart via AJAX
add_filter('add_to_cart_fragments', 'mts_header_add_to_cart_fragment');
 
function mts_header_add_to_cart_fragment( $fragments ) {
	global $woocommerce;
	ob_start();	?>
	
	<a class="cart-contents" href="<?php echo $woocommerce->cart->get_cart_url(); ?>" title="<?php _e('View your shopping cart', 'mythemeshop'); ?>"><?php echo sprintf(_n('%d item', '%d items', $woocommerce->cart->cart_contents_count, 'mythemeshop'), $woocommerce->cart->cart_contents_count);?> - <?php echo $woocommerce->cart->get_cart_total(); ?></a>
	
	<?php $fragments['a.cart-contents'] = ob_get_clean();
	return $fragments;
}
}

/*-----------------------------------------------------------------------------------*/
/* add <!-- next-page --> button to tinymce
/*-----------------------------------------------------------------------------------*/
add_filter('mce_buttons','wysiwyg_editor');
function wysiwyg_editor($mce_buttons) {
   $pos = array_search('wp_more',$mce_buttons,true);
   if ($pos !== false) {
       $tmp_buttons = array_slice($mce_buttons, 0, $pos+1);
       $tmp_buttons[] = 'wp_page';
       $mce_buttons = array_merge($tmp_buttons, array_slice($mce_buttons, $pos+1));
   }
   return $mce_buttons;
}

/*-----------------------------------------------------------------------------------*/
/*	Custom Gravatar Support
/*-----------------------------------------------------------------------------------*/
if( !function_exists( 'mts_custom_gravatar' ) ) {
    function mts_custom_gravatar( $avatar_defaults ) {
        $mts_avatar = get_bloginfo('template_directory') . '/images/gravatar.png';
        $avatar_defaults[$mts_avatar] = 'Custom Gravatar (/images/gravatar.png)';
        return $avatar_defaults;
    }
    add_filter( 'avatar_defaults', 'mts_custom_gravatar' );
}

/*-----------------------------------------------------------------------------------*/
/*  TGM plugin activation
/*-----------------------------------------------------------------------------------*/
function mts_plugins() {
	// Add the following plugins
	$plugins = array(
		array(
			'name'     				=> 'CF Post Formats', // The plugin name
			'slug'     				=> 'cf-post-formats', // The plugin slug (typically the folder name)
			'source'   				=> get_template_directory_uri() . '/plugins/cf-post-formats.zip', // The plugin source
			'required' 				=> false, // If false, the plugin is only 'recommended' instead of required
			'version' 				=> '', // E.g. 1.0.0. If set, the active plugin must be this version or higher, otherwise a notice is presented
			'force_activation' 		=> false, // If true, plugin is activated upon theme activation and cannot be deactivated until theme switch
			'force_deactivation' 	=> false, // If true, plugin is deactivated upon theme switch, useful for theme-specific plugins
		),
		array(
            'name'      => 'WP Shortcode by MyThemeShop',
            'slug'      => 'wp-shortcode',
            'required'  => false,
        ),
        array(
            'name'      => 'WP Review by MyThemeShop',
            'slug'      => 'wp-review',
            'required'  => false,
        ),
        array(
            'name'      => 'WP Tab Widget by MyThemeShop',
            'slug'      => 'wp-tab-widget',
            'required'  => false,
        ),
        array(
            'name'      => 'MyThemeShop Connect',
            'slug'      => 'mythemeshop-connect',
            'required'  => false,
        ),
	);
	// Change this to your theme text domain, used for internationalising strings
    $theme_text_domain = 'mythemeshop';
		/**
		 * Array of configuration settings. Amend each line as needed.
		 * If you want the default strings to be available under your own theme domain,
		 * leave the strings uncommented.
		 * Some of the strings are added into a sprintf, so see the comments at the
		 * end of each line for what each argument will be.
		 */
		$config = array(
			'domain'       		=> $theme_text_domain,         	// Text domain - likely want to be the same as your theme.
			'default_path' 		=> '',                         	// Default absolute path to pre-packaged plugins
			'parent_menu_slug' 	=> 'themes.php', 				// Default parent menu slug
			'parent_url_slug' 	=> 'themes.php', 				// Default parent URL slug
			'menu'         		=> 'mythemeshop-required-plugins', 	// Menu slug
			'has_notices'      	=> true,                       	// Show admin notices or not
			'is_automatic'    	=> true,					   	// Automatically activate plugins after installation or not
			'message' 			=> '',							// Message to output right before the plugins table
			'strings'      		=> array(
				'page_title'                       			=> __( 'Install Required Plugins', 'mythemeshop' ),
				'menu_title'                       			=> __( 'Theme Plugins', 'mythemeshop' ),
				'installing'                       			=> __( 'Installing Plugin: %s', 'mythemeshop' ), // %1$s = plugin name
				'oops'                             			=> __( 'Something went wrong with the plugin API.', 'mythemeshop' ),
				'notice_can_install_required'     			=> _n_noop( 'This theme requires the following plugin: %1$s.', 'This theme requires the following plugins: %1$s.' ), // %1$s = plugin name(s)
				'notice_can_install_recommended'			=> _n_noop( 'This theme requires the following plugin to enable Post Formats: %1$s.', 'This theme requires the following plugin to enable Post Formats: %1$s.' ), // %1$s = plugin name(s)
				'notice_cannot_install'  					=> _n_noop( 'Sorry, but you do not have the correct permissions to install the %s plugin. Contact the administrator of this site for help on getting the plugin installed.', 'Sorry, but you do not have the correct permissions to install the %s plugins. Contact the administrator of this site for help on getting the plugins installed.' ), // %1$s = plugin name(s)
				'notice_can_activate_required'    			=> _n_noop( 'The following required plugin is currently inactive: %1$s.', 'The following required plugins are currently inactive: %1$s.' ), // %1$s = plugin name(s)
				'notice_can_activate_recommended'			=> _n_noop( 'The following recommended plugin is currently inactive: %1$s.', 'The following recommended plugins are currently inactive: %1$s.' ), // %1$s = plugin name(s)
				'notice_cannot_activate' 					=> _n_noop( 'Sorry, but you do not have the correct permissions to activate the %s plugin. Contact the administrator of this site for help on getting the plugin activated.', 'Sorry, but you do not have the correct permissions to activate the %s plugins. Contact the administrator of this site for help on getting the plugins activated.' ), // %1$s = plugin name(s)
				'notice_ask_to_update' 						=> _n_noop( 'The following plugin needs to be updated to its latest version to ensure maximum compatibility with this theme: %1$s.', 'The following plugins need to be updated to their latest version to ensure maximum compatibility with this theme: %1$s.' ), // %1$s = plugin name(s)
				'notice_cannot_update' 						=> _n_noop( 'Sorry, but you do not have the correct permissions to update the %s plugin. Contact the administrator of this site for help on getting the plugin updated.', 'Sorry, but you do not have the correct permissions to update the %s plugins. Contact the administrator of this site for help on getting the plugins updated.' ), // %1$s = plugin name(s)
				'install_link' 					  			=> _n_noop( 'Begin installing plugin', 'Begin installing plugins' ),
				'activate_link' 				  			=> _n_noop( 'Activate installed plugin', 'Activate installed plugins' ),
				'return'                           			=> __( 'Return to Required Plugins Installer', 'mythemeshop' ),
				'plugin_activated'                 			=> __( 'Plugin activated successfully.', 'mythemeshop' ),
				'complete' 									=> __( 'All plugins installed and activated successfully. %s', 'mythemeshop' ), // %1$s = dashboard link
				'nag_type'									=> 'updated' // Determines admin notice type - can only be 'updated' or 'error'
			)
		);
		tgmpa($plugins, $config);
	}
add_action( 'tgmpa_register', 'mts_plugins' );

/*-----------------------------------------------------------------------------------*/
/*  Add support for the multiple Post Formats
/*-----------------------------------------------------------------------------------*/
add_theme_support( 'post-formats', array('gallery', 'image', 'link', 'quote', 'audio', 'video', 'status')); 

?>
