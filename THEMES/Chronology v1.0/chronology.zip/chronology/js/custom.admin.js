/*-----------------------------------------------------------------------------------

 	Custom JS - All back-end jQuery
 
-----------------------------------------------------------------------------------*/
 
jQuery(document).ready(function() {

	var videoOptions = jQuery('#mts-meta-box-video');
	var videoTrigger = jQuery('#post-format-video');
	
	videoOptions.css('display', 'none');

	var group = jQuery('#post-formats-select input');

	group.change( function() {
		
		if(jQuery(this).val() == 'video') {
			videoOptions.css('display', 'block');
			mtsHideAll(videoOptions);
			
		} else {
			videoOptions.css('display', 'none');
		}
		
	});
		
	if(videoTrigger.is(':checked'))
		videoOptions.css('display', 'block');
		
	function mtsHideAll(notThisOne) {
		videoOptions.css('display', 'none');
		notThisOne.css('display', 'block');
	}

});