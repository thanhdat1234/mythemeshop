<?php
$mts_options = get_option('chronology');	

/*------------[ Meta ]-------------*/
if ( ! function_exists( 'mts_meta' ) ) {
	function mts_meta() { 
	global $mts_options
?>
<?php if ($mts_options['mts_favicon'] != '') { ?>
<link rel="icon" href="<?php echo $mts_options['mts_favicon']; ?>" type="image/x-icon" />
<?php } ?>
<!--iOS/android/handheld specific -->
<link rel="apple-touch-icon" href="<?php echo get_template_directory_uri(); ?>/apple-touch-icon.png" />
<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
<meta name="apple-mobile-web-app-capable" content="yes">
<meta name="apple-mobile-web-app-status-bar-style" content="black">
<?php if(isset($mts_options['mts_prefetching']) == '1') { ?>
<?php if (is_front_page()) { ?>
	<?php $my_query = new WP_Query('posts_per_page=1'); while ($my_query->have_posts()) : $my_query->the_post(); ?>
	<link rel="prefetch" href="<?php the_permalink(); ?>">
	<link rel="prerender" href="<?php the_permalink(); ?>">
	<?php endwhile; wp_reset_query(); ?>
<?php } elseif (is_singular()) { ?>
	<link rel="prefetch" href="<?php echo home_url(); ?>">
	<link rel="prerender" href="<?php echo home_url(); ?>">
<?php } ?>
<?php } ?>
<?php }
}

/*------------[ Head ]-------------*/
if ( ! function_exists( 'mts_head' ) ) {
	function mts_head() { 
	global $mts_options
?>
<style type="text/css">
<?php if($mts_options['mts_bg_color'] != '') { ?>
body {background-color:<?php echo $mts_options['mts_bg_color']; ?>;}
<?php } ?>
<?php if ($mts_options['mts_bg_pattern_upload'] != '') { ?>
body {background-image: url(<?php echo $mts_options['mts_bg_pattern_upload']; ?>);}
<?php } else { ?>
<?php if($mts_options['mts_bg_pattern'] != '') { ?>
body {background-image:url(<?php echo get_template_directory_uri(); ?>/images/<?php echo $mts_options['mts_bg_pattern']; ?>.png);}
<?php } ?>
<?php } ?>
<?php if ($mts_options['mts_color_scheme'] != '') { ?>
.mts-subscribe input[type="submit"], .sbutton, .pagination .currenttext, .pagination a:hover, .currenttext, .pagination a:hover, .woocommerce nav.woocommerce-pagination ul li span.current, .woocommerce-page nav.woocommerce-pagination ul li span.current, .woocommerce #content nav.woocommerce-pagination ul li span.current, .woocommerce-page #content nav.woocommerce-pagination ul li span.current, .woocommerce nav.woocommerce-pagination ul li a:hover, .woocommerce-page nav.woocommerce-pagination ul li a:hover, .woocommerce #content nav.woocommerce-pagination ul li a:hover, .woocommerce-page #content nav.woocommerce-pagination ul li a:hover, .announcement h4, #commentform input#submit, .commentlist .children li.bypostauthor .commentmetadata:after, #wp-calendar thead th, #wp-calendar td:hover, #wp-calendar td a:hover, #wp-calendar td:hover a, .woocommerce a.button, .woocommerce-page a.button, .woocommerce button.button, .woocommerce-page button.button, .woocommerce input.button, .woocommerce-page input.button, .woocommerce #respond input#submit, .woocommerce-page #respond input#submit, .woocommerce #content input.button, .woocommerce-page #content input.button, .contactform #submit, #searchsubmit {background-color:<?php echo $mts_options['mts_color_scheme']; ?>; }
.single_post a, a:hover, .sidebar .widget h3, .footer-widget .widget h3, #tabber ul.tabs li a.selected, .heading, .textwidget a, #commentform a, .copyrights a:hover, a, .sidebar.c-4-12 a:hover, footer .widget li a:hover, .woocommerce .woocommerce-breadcrumb a, .woocommerce-page .woocommerce-breadcrumb a {color:<?php echo $mts_options['mts_color_scheme']; ?>; }
input#author:focus, input#email:focus, input#url:focus, #comment:focus, #commentform input#submit {outline-color:<?php echo $mts_options['mts_color_scheme']; ?>; }
.currenttext, .pagination a:hover, .woocommerce nav.woocommerce-pagination ul li span.current, .woocommerce-page nav.woocommerce-pagination ul li span.current, .woocommerce #content nav.woocommerce-pagination ul li span.current, .woocommerce-page #content nav.woocommerce-pagination ul li span.current, .woocommerce nav.woocommerce-pagination ul li a:hover, .woocommerce-page nav.woocommerce-pagination ul li a:hover, .woocommerce #content nav.woocommerce-pagination ul li a:hover, .woocommerce-page #content nav.woocommerce-pagination ul li a:hover, .mts-subscribe input[type="submit"], .announcement h4 { border-color: <?php echo $mts_options['mts_color_scheme']; ?>; }
<?php } ?>
<?php if($mts_options['mts_floating_social'] == '1') { ?>
.shareit { top: 307px; left: auto; z-index: 0; margin: 0 0 0 -130px; width: 90px; position: fixed; overflow: hidden; padding: 5px; background: #EFF4F6; border: 1px solid #C7CED2; -webkit-box-shadow: inset 0 1px 0 0 #FFF; -moz-box-shadow: inset 0 1px 0 0 #fff; box-shadow: inset 0 1px 0 0 #FFF; border-radius: 3px; -webkit-border-radius: 3px; -moz-border-radius: 3px;} 
.share-item {margin: 2px;}
<?php } ?>
<?php if ($mts_options['mts_layout'] == 'sclayout') { ?>
.article { float: right;}
.sidebar.c-4-12 { float: left; padding-right: 0; padding-left: 2%; }
<?php if($mts_options['mts_floating_social'] == '1') { ?>
.shareit { margin: 0 645px 0; }
<?php } ?>
<?php } ?>
<?php if($mts_options['mts_author_comment'] == '1') { ?>
.commentlist .children li.bypostauthor .commentmetadata:after { content: "<?php _e('Author','mythemeshop'); ?>"; position: absolute; left: 0; top: 0; padding: 0 14px; color: #fff; text-indent: 0; background-image: url(<?php echo get_template_directory_uri(); ?>/images/gradientbg.png);}
.bypostauthor .commentmetadata { text-indent: 90px; }
<?php } ?>
<?php echo $mts_options['mts_custom_css']; ?>
</style>
<?php echo $mts_options['mts_header_code']; ?>
<?php }
}
add_action('wp_head', 'mts_head');

/*------------[ Copyrights ]-------------*/
if ( ! function_exists( 'mts_copyrights_credit' ) ) {
	function mts_copyrights_credit() { 
	global $mts_options
?>
<!--start copyrights-->
<div class="row" id="copyright-note">
<span><a href="<?php echo home_url(); ?>/" title="<?php bloginfo('description'); ?>"><?php bloginfo('name'); ?></a> Copyright &copy; <?php echo date("Y") ?>.</span>
<div class="top"><?php echo $mts_options['mts_copyrights']; ?>&nbsp;<a href="#top" class="toplink"><span>&nbsp;</span></a></div>
</div>
<!--end copyrights-->
<?php }
}

/*------------[ footer ]-------------*/
if ( ! function_exists( 'mts_footer' ) ) {
	function mts_footer() { 
	global $mts_options
?>
<?php if ($mts_options['mts_analytics_code'] != '') { ?>
<!--start footer code-->
<?php echo $mts_options['mts_analytics_code']; ?>
<!--end footer code-->
<?php } ?>
<?php }
}
?>