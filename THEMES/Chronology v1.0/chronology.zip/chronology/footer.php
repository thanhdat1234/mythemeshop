<?php $mts_options = get_option('chronology'); ?>
		</div>
	</div><!--#page-->
</div><!--.main-container-->
<footer class="footer-top">
	<div class="container">
		<div class="footer-top-widgets">
			<div class="footer-widget-1 footer-widget"><?php if ( !function_exists('dynamic_sidebar') || !dynamic_sidebar('Top 1st Footer') ) : ?><?php endif; ?></div>
            <div class="footer-widget-2 footer-widget"><?php if ( !function_exists('dynamic_sidebar') || !dynamic_sidebar('Top 2nd Footer') ) : ?><?php endif; ?></div>
            <div class="footer-widget-3 footer-widget last"><?php if ( !function_exists('dynamic_sidebar') || !dynamic_sidebar('Top 3rd Footer') ) : ?><?php endif; ?></div>
		</div>
	</div>
</footer>
<footer class="footer-bottom">
	<div class="footer-container">
		<div class="container">
			<div class="footer-widgets">
				<div class="f-widget f-widget-1"><?php if ( !function_exists('dynamic_sidebar') || !dynamic_sidebar('1st Footer') ) : ?><?php endif; ?></div>
				<div class="f-widget f-widget-2"><?php if ( !function_exists('dynamic_sidebar') || !dynamic_sidebar('2nd Footer') ) : ?><?php endif; ?></div>
				<div class="f-widget f-widget-3"><?php if ( !function_exists('dynamic_sidebar') || !dynamic_sidebar('3rd Footer') ) : ?><?php endif; ?></div>
				<div class="f-widget last"><?php if ( !function_exists('dynamic_sidebar') || !dynamic_sidebar('4th Footer') ) : ?><?php endif; ?></div>
			</div>
		</div>
	</div>
	<div class="copyrights">
		<?php mts_copyrights_credit(); ?>
	</div> 
</footer><!--footer-->
<?php mts_footer(); ?>
<?php wp_footer(); ?>
</div><!-- .wrapper -->
</body>
</html>