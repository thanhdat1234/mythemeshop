<?php
/*-----------------------------------------------------------------------------------*/
/*	Do not remove these lines, sky will fall on your head.
/*-----------------------------------------------------------------------------------*/
require_once( dirname( __FILE__ ) . '/theme-options.php' );
include("functions/tinymce/tinymce.php");
if ( ! isset( $content_width ) ) $content_width = 960;

/*-----------------------------------------------------------------------------------*/
/*	Load Translation Text Domain
/*-----------------------------------------------------------------------------------*/
load_theme_textdomain( 'mythemeshop', get_template_directory().'/lang' );
if ( function_exists('add_theme_support') ) add_theme_support('automatic-feed-links');

/*-----------------------------------------------------------------------------------*/
/*	Post Thumbnail Support
/*-----------------------------------------------------------------------------------*/
if ( function_exists( 'add_theme_support' ) ) { 
	add_theme_support( 'post-thumbnails' );
	set_post_thumbnail_size( 410, 230, true );
	add_image_size( 'featured', 410, 230, true ); //featured
	add_image_size( 'widgetthumb', 61, 61, true ); //widget
	add_image_size( 'slider', 940, 445, true ); //slider
}

/*-----------------------------------------------------------------------------------*/
/*	Javascsript
/*-----------------------------------------------------------------------------------*/
function mts_add_scripts() {
	$mts_options = get_option('chronology');

	wp_enqueue_script('jquery');

	if ( is_singular() && comments_open() && get_option( 'thread_comments' ) ) {
		wp_enqueue_script( 'comment-reply' );
	}
	
	// Site wide js
	wp_enqueue_script('modernizr', get_template_directory_uri() . '/js/modernizr.min.js');
	wp_enqueue_script('customscript', get_template_directory_uri() . '/js/customscript.js');

	//Slider
	if(isset($mts_options['mts_featured_slider']) == '1') {
		wp_enqueue_script('flexslider', get_template_directory_uri() . '/js/jquery.flexslider-min.js');
	}	
	//Lightbox
	if($mts_options['mts_lightbox'] == '1') {
		wp_enqueue_script('prettyPhoto', get_template_directory_uri() . '/js/jquery.prettyPhoto.js');
	}
	
	//jPlayer
	wp_enqueue_script('jPlayer', get_template_directory_uri() . '/js/jquery.jplayer.min.js');

	global $is_IE;
    if ($is_IE) {
        wp_register_script ('html5shim', "http://html5shim.googlecode.com/svn/trunk/html5.js");
        wp_enqueue_script ('html5shim');
	}
}
add_action('wp_enqueue_scripts','mts_add_scripts');

/*-----------------------------------------------------------------------------------*/
/* Load admin javascript
/*-----------------------------------------------------------------------------------*/
if( !function_exists( 'mts_admin_js' ) ) {
    function mts_admin_js($hook) {
    	if ($hook == 'post.php' || $hook == 'post-new.php') {
    		wp_register_script('mts-admin', get_template_directory_uri() . '/js/custom.admin.js', 'jquery');
    		wp_enqueue_script('mts-admin');
    	}
    }
    add_action('admin_enqueue_scripts','mts_admin_js',10,1);
}

/*-----------------------------------------------------------------------------------*/
/* Enqueue CSS
/*-----------------------------------------------------------------------------------*/
function mts_enqueue_css() {
	$mts_options = get_option('chronology');

	//slider
	if(isset($mts_options['mts_featured_slider']) == '1') {
		wp_enqueue_style('flexslider', get_template_directory_uri() . '/css/flexslider.css', 'style');
	}
	
	//lightbox
	if($mts_options['mts_lightbox'] == '1') {
	wp_enqueue_style('prettyPhoto', get_template_directory_uri() . '/css/prettyPhoto.css', 'style');
	}
	
	wp_enqueue_style('stylesheet', get_template_directory_uri() . '/style.css', 'style');
	
}
add_action('wp_enqueue_scripts', 'mts_enqueue_css', 99);

/*-----------------------------------------------------------------------------------*/
/*  Enable Widgetized sidebar
/*-----------------------------------------------------------------------------------*/
if ( function_exists('register_sidebar') )
	register_sidebar(array(
		'name'=>'Sidebar',
		'description'   => __( 'Appears on posts and pages', 'mythemeshop' ),
		'before_widget' => '<li id="%1$s" class="widget widget-sidebar %2$s">',
		'after_widget' => '</li>',
		'before_title' => '<h3><span>',
		'after_title' => '</span></h3>',
	));
	register_sidebar(array(
		'name' => 'Top 1st Footer',
		'description'   => __( 'Appears in first column of top footer.', 'mythemeshop' ),
		'id' => 'widget-footer-1',
		'before_widget' => '<div id="%1$s" class="widget widget-footer-1 %2$s">',
		'after_widget' => '</div>',
		'before_title' => '<h3 class="heading"><span>',
		'after_title' => '</span></h3>',
	));
	register_sidebar(array(
		'name' => 'Top 2nd Footer',
		'description'   => __( 'Appears in second column of top footer.', 'mythemeshop' ),
		'id' => 'widget-footer-2',
		'before_widget' => '<div id="%1$s" class="widget widget-footer-2 %2$s">',
		'after_widget' => '</div>',
		'before_title' => '<h3 class="heading"><span>',
		'after_title' => '</span></h3>',
	));
	register_sidebar(array(
		'name' => 'Top 3rd Footer',
		'description'   => __( 'Appears in third column of top footer.', 'mythemeshop' ),
		'id' => 'widget-footer-3',
		'before_widget' => '<div id="%1$s" class="widget widget-footer-3 %2$s">',
		'after_widget' => '</div>',
		'before_title' => '<h3 class="heading"><span>',
		'after_title' => '</span></h3>',
	));
	register_sidebar(array(
		'name' => '1st Footer',
		'description'   => __( 'Appears in first column of footer.', 'mythemeshop' ),
		'id' => 'footer-1',
		'before_widget' => '<div id="%1$s" class="widget %2$s">',
		'after_widget' => '</div>',
		'before_title' => '<h3 class="widget-title">',
		'after_title' => '</h3>',
	));
	register_sidebar(array(
		'name' => '2nd Footer',
		'description'   => __( 'Appears in second column of footer.', 'mythemeshop' ),
		'id' => 'footer-2',
		'before_widget' => '<div id="%1$s" class="widget %2$s">',
		'after_widget' => '</div>',
		'before_title' => '<h3 class="widget-title">',
		'after_title' => '</h3>',
	));
	register_sidebar(array(
		'name' => '3rd Footer',
		'description'   => __( 'Appears in third column of footer.', 'mythemeshop' ),
		'id' => 'footer-3',
		'before_widget' => '<div id="%1$s" class="widget %2$s">',
		'after_widget' => '</div>',
		'before_title' => '<h3 class="widget-title">',
		'after_title' => '</h3>',
	));
	register_sidebar(array(
		'name' => '4th Footer',
		'description'   => __( 'Appears in fourth column of footer.', 'mythemeshop' ),
		'id' => 'footer-4',
		'before_widget' => '<div id="%1$s" class="widget %2$s">',
		'after_widget' => '</div>',
		'before_title' => '<h3 class="widget-title">',
		'after_title' => '</h3>',
	));

/*-----------------------------------------------------------------------------------*/
/*  Load Widgets & Shortcodes
/*-----------------------------------------------------------------------------------*/
// Add the 125x125 Ad Block Custom Widget
include("functions/widget-ad125.php");

// Add the 300x250 Ad Block Custom Widget
include("functions/widget-ad300.php");

// Add the Tabbed Custom Widget
include("functions/widget-tabs.php");

// Add the Latest Tweets Custom Widget
include("functions/widget-tweets.php");

// Add the Theme Shortcodes
include("functions/theme-shortcodes.php");

// Add Recent Posts Widget
include("functions/widget-recentposts.php");

// Add Popular Posts Widget
include("functions/widget-popular.php");

// Add Facebook Like box Widget
include("functions/widget-fblikebox.php");

// Add Google Plus box Widget
include("functions/widget-googleplus.php");

// Add Subscribe Widget
include("functions/widget-subscribe.php");

// Add Social Profile Widget
include("functions/widget-social.php");

// Add Category Posts Widget
include("functions/widget-catposts.php");

// Add Welcome message
include("functions/welcome-message.php");

// Theme Functions
include("functions/theme-actions.php");

/*-----------------------------------------------------------------------------------*/
/*	Filters customize wp_title
/*-----------------------------------------------------------------------------------*/
function mts_wp_title( $title, $sep ) {
	global $paged, $page;

	if ( is_feed() )
		return $title;

	// Add the site name.
	$title .= get_bloginfo( 'name' );

	// Add the site description for the home/front page.
	$site_description = get_bloginfo( 'description', 'display' );
	if ( $site_description && ( is_home() || is_front_page() ) )
		$title = "$title $sep $site_description";

	// Add a page number if necessary.
	if ( $paged >= 2 || $page >= 2 )
		$title = "$title $sep " . sprintf( __( 'Page %s', 'mythemeshop' ), max( $paged, $page ) );

	return $title;
}
add_filter( 'wp_title', 'mts_wp_title', 10, 2 );
	
/*-----------------------------------------------------------------------------------*/
/*	Filters that allow shortcodes in Text Widgets
/*-----------------------------------------------------------------------------------*/
add_filter('widget_text', 'shortcode_unautop');
add_filter('widget_text', 'do_shortcode');
add_filter('the_content_rss', 'do_shortcode');

/*-----------------------------------------------------------------------------------*/
/*	Custom Comments template
/*-----------------------------------------------------------------------------------*/
function mytheme_comment($comment, $args, $depth) {
	$GLOBALS['comment'] = $comment; ?>
	<li <?php comment_class(); ?> id="li-comment-<?php comment_ID() ?>">
		<div id="comment-<?php comment_ID(); ?>" style="position:relative;">
			<div class="comment-author vcard">
				<?php echo get_avatar( $comment->comment_author_email, 70 ); ?>
			</div>
			<?php if ($comment->comment_approved == '0') : ?>
				<em><?php _e('Your comment is awaiting moderation.', 'mythemeshop') ?></em>
				<br />
			<?php endif; ?>
			<div class="comment-meta">
				<?php edit_comment_link(__('(Edit)', 'mythemeshop'),'  ','') ?>
			</div>
			<div class="commentmetadata">
			<?php comment_text() ?>
			</div>
		</div>
		<div class="comment-bottom">
			<?php printf(__('<span class="fn">By %s</span>', 'mythemeshop'), get_comment_author_link()) ?>
			<?php $mts_options = get_option('chronology'); if($mts_options['mts_comment_date'] == '1') { ?>
				<time><?php comment_date(); ?></time>
			<?php } ?>
			<span class="reply"><?php comment_reply_link(array_merge( $args, array('depth' => $depth, 'max_depth' => $args['max_depth']))) ?></span>
		</div>
	</li>
<?php }

/*-----------------------------------------------------------------------------------*/
/*	Custom Menu Support
/*-----------------------------------------------------------------------------------*/
add_theme_support( 'menus' );
if ( function_exists( 'register_nav_menus' ) ) {
	register_nav_menus(
		array(
		  'primary-menu' => 'Primary Menu'
		)
	);
}

/*-----------------------------------------------------------------------------------*/
/*	excerpt
/*-----------------------------------------------------------------------------------*/
function excerpt($limit) {
  $excerpt = explode(' ', get_the_excerpt(), $limit);
  if (count($excerpt)>=$limit) {
    array_pop($excerpt);
    $excerpt = implode(" ",$excerpt);
  } else {
    $excerpt = implode(" ",$excerpt);
  }
  $excerpt = preg_replace('`[[^]]*]`','',$excerpt);
  return $excerpt;
}

/*-----------------------------------------------------------------------------------*/
/* nofollow to next/previous links
/*-----------------------------------------------------------------------------------*/
function pagination_add_nofollow($content) {
    return 'rel="nofollow"';
}
add_filter('next_posts_link_attributes', 'pagination_add_nofollow' );
add_filter('previous_posts_link_attributes', 'pagination_add_nofollow' );

/*-----------------------------------------------------------------------------------*/
/* Nofollow to category links
/*-----------------------------------------------------------------------------------*/
add_filter( 'the_category', 'add_nofollow_cat' ); 
function add_nofollow_cat( $text ) {
$text = str_replace('rel="category tag"', 'rel="nofollow"', $text); return $text;
}

/*-----------------------------------------------------------------------------------*/	
/* nofollow post author link
/*-----------------------------------------------------------------------------------*/
add_filter('the_author_posts_link', 'mts_nofollow_the_author_posts_link');
function mts_nofollow_the_author_posts_link ($link) {
return str_replace('<a href=', '<a rel="nofollow" href=',$link); 
}

/*-----------------------------------------------------------------------------------*/	
/* nofollow to reply links
/*-----------------------------------------------------------------------------------*/
function add_nofollow_to_reply_link( $link ) {
return str_replace( '")\'>', '")\' rel=\'nofollow\'>', $link );
}
add_filter( 'comment_reply_link', 'add_nofollow_to_reply_link' );

/*-----------------------------------------------------------------------------------*/
/* removes detailed login error information for security
/*-----------------------------------------------------------------------------------*/
add_filter('login_errors',create_function('$a', "return null;"));
	
/*-----------------------------------------------------------------------------------*/
/* removes the WordPress version from your header for security
/*-----------------------------------------------------------------------------------*/
function wb_remove_version() {
	return '<!--Theme by MyThemeShop.com-->';
}
add_filter('the_generator', 'wb_remove_version');
	
/*-----------------------------------------------------------------------------------*/
/* Removes Trackbacks from the comment count
/*-----------------------------------------------------------------------------------*/
add_filter('get_comments_number', 'comment_count', 0);
function comment_count( $count ) {
	if ( ! is_admin() ) {
		global $id;
		$comments_by_type = &separate_comments(get_comments('status=approve&post_id=' . $id));
		return count($comments_by_type['comment']);
	} else {
		return $count;
	}
}

/*-----------------------------------------------------------------------------------*/
/* adds a class to the post if there is a thumbnail
/*-----------------------------------------------------------------------------------*/
function has_thumb_class($classes) {
	global $post;
	if( has_post_thumbnail($post->ID) ) { $classes[] = 'has_thumb'; }
		return $classes;
}
add_filter('post_class', 'has_thumb_class');

/*-----------------------------------------------------------------------------------*/	
/* Breadcrumb
/*-----------------------------------------------------------------------------------*/
function the_breadcrumb() {
	echo '<a href="';
	echo home_url();
	echo '" rel="nofollow">'.__('Home','mythemeshop');
	echo "</a>";
	if (is_category() || is_single()) {
		echo "&nbsp;/&nbsp;";
		the_category(' &bull; ');
			if (is_single()) {
				echo "&nbsp;/&nbsp;";
				the_title();
			}
	} elseif (is_page()) {
		echo "&nbsp;/&nbsp;";
		echo the_title();
	} elseif (is_search()) {
		echo "&nbsp;/&nbsp;".__('Search Results for','mythemeshop')."... ";
		echo '"<em>';
		echo the_search_query();
		echo '</em>"';
	}
}

/*-----------------------------------------------------------------------------------*/ 
/* Pagination
/*-----------------------------------------------------------------------------------*/
function pagination($pages = '', $range = 3) { 
    $showitems = ($range * 3)+1;
    global $paged; if(empty($paged)) $paged = 1;
    if($pages == '') {
        global $wp_query; $pages = $wp_query->max_num_pages; 
        if(!$pages){ $pages = 1; } 
    }
    if(1 != $pages) { 
        echo "<div class='pagination'><ul>";
        if($paged > 2 && $paged > $range+1 && $showitems < $pages) 
            echo "<li><a rel='nofollow' href='".get_pagenum_link(1)."'><span class='pnext'>&laquo; First</span></a></li>";
        if($paged > 1 && $showitems < $pages) 
            echo "<li><a rel='nofollow' href='".get_pagenum_link($paged - 1)."' class='inactive'><span class='pnext'>&lsaquo; Previous</span></a></li>";
        for ($i=1; $i <= $pages; $i++){ 
            if (1 != $pages &&( !($i >= $paged+$range+1 || $i <= $paged-$range-1) || $pages <= $showitems )) { 
                echo ($paged == $i)? "<li class='current'><span class='currenttext'>".$i."</span></li>":"<li><a rel='nofollow' href='".get_pagenum_link($i)."' class='inactive'>".$i."</a></li>";
            } 
        } 
        if ($paged < $pages && $showitems < $pages) 
            echo "<li><a rel='nofollow' href='".get_pagenum_link($paged + 1)."' class='inactive'><span class='pnext'>Next &rsaquo;</span></a></li>";
        if ($paged < $pages-1 &&  $paged+$range-1 < $pages && $showitems < $pages) 
            echo "<li><a rel='nofollow' class='inactive' href='".get_pagenum_link($pages)."'><span class='pnext'>Last &raquo;</span></a></li>";
            echo "</ul></div>"; 
    }
}

/*-----------------------------------------------------------------------------------*/
/* Redirect feed to feedburner
/*-----------------------------------------------------------------------------------*/
$mts_options = get_option('chronology');
if ( $mts_options['mts_feedburner'] != '') {
function mts_rss_feed_redirect() {
    $mts_options = get_option('chronology');
    global $feed;
    $new_feed = $mts_options['mts_feedburner'];
    if (!is_feed()) {
            return;
	}
    if (preg_match('/feedburner/i', $_SERVER['HTTP_USER_AGENT'])){
            return;
    }
    if ($feed != 'comments-rss2') {
            if (function_exists('status_header')) status_header( 302 );
            header("Location:" . $new_feed);
            header("HTTP/1.1 302 Temporary Redirect");
            exit();
    }
}
add_action('template_redirect', 'mts_rss_feed_redirect');
}

/*-----------------------------------------------------------------------------------*/
/* WooCommerce
/*-----------------------------------------------------------------------------------*/
if ( in_array( 'woocommerce/woocommerce.php', apply_filters( 'active_plugins', get_option( 'active_plugins' ) ) ) ) {
add_theme_support('woocommerce');

//WooCommerce
function mtswoo_enqueue_css() {
	wp_enqueue_style('woocommerce', get_template_directory_uri() . '/css/woocommerce2.css', 'style');
}
add_action('wp_enqueue_scripts', 'mtswoo_enqueue_css', 100);

// Register Shop and Single Product Sidebar
register_sidebar(array(
	'name' => 'Shop Page Sidebar',
	'description'   => __( 'Appears on Shop main page and product archive pages.', 'mythemeshop' ),
	'id' => 'shop-sidebar',
	'before_widget' => '<li id="%1$s" class="widget widget-sidebar %2$s">',
	'after_widget' => '</div></li>',
	'before_title' => '<h3><span>',
	'after_title' => '</span></h3>',
));
register_sidebar(array(
	'name' => 'Single Product Sidebar',
	'description'   => __( 'Appears on single product pages.', 'mythemeshop' ),
	'id' => 'product-sidebar',
	'before_widget' => '<li id="%1$s" class="widget widget-sidebar %2$s">',
	'after_widget' => '</div></li>',
	'before_title' => '<h3><span>',
	'after_title' => '</span></h3>',
));

// Change number or products per row to 3
add_filter('loop_shop_columns', 'loop_columns');
if (!function_exists('loop_columns')) {
	function loop_columns() {
		return 3; // 3 products per row
	}
}

// Redefine woocommerce_output_related_products()
function woocommerce_output_related_products() {
	woocommerce_related_products(3,1);
}

/*** Hook in on activation */
global $pagenow;
if ( is_admin() && isset( $_GET['activated'] ) && $pagenow == 'themes.php' ) add_action( 'init', 'mythemeshop_woocommerce_image_dimensions', 1 );
 
/*** Define image sizes */
function mythemeshop_woocommerce_image_dimensions() {
  	$catalog = array(
		'width' 	=> '190',
		'height'	=> '258',
		'crop'		=> 1
	);
	$single = array(
		'width' 	=> '440',
		'height'	=> '600',
		'crop'		=> 1
	);
	$thumbnail = array(
		'width' 	=> '75',
		'height'	=> '75',
		'crop'		=> 1
	); 
	// Image sizes
	update_option( 'shop_catalog_image_size', $catalog ); 		// Product category thumbs
	update_option( 'shop_single_image_size', $single ); 		// Single product image
	update_option( 'shop_thumbnail_image_size', $thumbnail ); 	// Image gallery thumbs
}

add_filter ( 'woocommerce_product_thumbnails_columns', 'mts_thumb_cols' );
 function mts_thumb_cols() {
     return 4; // .last class applied to every 4th thumbnail
 }
}

// Display 24 products per page. Goes in functions.php
$mts_home_producst = $mts_options['mts_shop_products'];
add_filter( 'loop_shop_per_page', create_function( '$cols', 'return '.$mts_home_producst.';' ), 20 );

/*-----------------------------------------------------------------------------------*/
/* Single Post Pagination
/*-----------------------------------------------------------------------------------*/
function wp_link_pages_args_prevnext_add($args)
{
    global $page, $numpages, $more, $pagenow;
    if (!$args['next_or_number'] == 'next_and_number')
        return $args; 
    $args['next_or_number'] = 'number'; 
    if (!$more)
        return $args; 
    if($page-1) 
        $args['before'] .= _wp_link_page($page-1)
        . $args['link_before']. $args['previouspagelink'] . $args['link_after'] . '</a>'
    ;
    if ($page<$numpages) 
    
        $args['after'] = _wp_link_page($page+1)
        . $args['link_before'] . $args['nextpagelink'] . $args['link_after'] . '</a>'
        . $args['after']
    ;
    return $args;
}
add_filter('wp_link_pages_args', 'wp_link_pages_args_prevnext_add');

$mts_options = get_option('chronology');
if ( $mts_options['mts_admin_style'] == '1') {
function admin_css() {
	wp_enqueue_style( 'admin_css', get_template_directory_uri() . '/css/admin.css' );
}
add_action('admin_print_styles', 'admin_css' );

function remove_footer_admin () {
    echo "Thank you for creating with <a href=\"http://wordpress.org/\">WordPress</a>. Dashboard Customization by <a href=\"http://mythemeshop.com/\">MyThemeShop</a>.";
} 
add_filter('admin_footer_text', 'remove_footer_admin');
}

/*-----------------------------------------------------------------------------------*/
/* Video post Format
/*-----------------------------------------------------------------------------------*/
$prefix = 'mts_';
add_theme_support( 'post-formats', array('video','gallery'));
$meta_box_video = array(
	'id' => 'mts-meta-box-video',
	'title' =>  __('Video Settings', 'mythemeshop'),
	'page' => 'post',
	'context' => 'normal',
	'priority' => 'high',
	'fields' => array(
		array( "name" => __('Embeded Code','mythemeshop'),
				"desc" => __('If you\'re not using self hosted video then you can include embedded code here (YouTube/Vimeo). Recommended width 590px. If you are using this option, keep other fields empty.','mythemeshop'),
				"id" => $prefix."video_embed",
				"type" => "textarea",
				"std" => ''
			),
		array( "name" => __('Video Height','mythemeshop'),
				"desc" => __('The video height (e.g. 300).','mythemeshop'),
				"id" => $prefix."video_height",
				"type" => "text",
				"std" => ''
			),
		array( "name" => __('M4V File URL','mythemeshop'),
				"desc" => __('The URL to the .m4v video file','mythemeshop'),
				"id" => $prefix."video_m4v",
				"type" => "text",
				"std" => ''
			),
		array( "name" => __('Preview Image','mythemeshop'),
				"desc" => __('Recommended image width: 590px and recommended image height is same as Video Height.','mythemeshop'),
				"id" => $prefix."video_poster",
				"type" => "text",
				"std" => ''
			),
	)
	
);
add_action('admin_menu', 'mts_add_box');

function mts_add_box() {
	global $meta_box_video;
	add_meta_box($meta_box_video['id'], $meta_box_video['title'], 'mts_show_box_video', $meta_box_video['page'], $meta_box_video['context'], $meta_box_video['priority']);
}

function mts_show_box_video() {
	global $meta_box_video, $post;
	// Use nonce for verification
	echo '<input type="hidden" name="mts_meta_box_nonce" value="', wp_create_nonce(basename(__FILE__)), '" />';
	echo '<table class="form-table">';
	foreach ($meta_box_video['fields'] as $field) {
		// get current post meta data
		$meta = get_post_meta($post->ID, $field['id'], true);
		switch ($field['type']) {
			//If Text		
			case 'text':
			echo '<tr>',
				'<th style="width:25%"><label for="', $field['id'], '"><strong>', $field['name'], '</strong><span style=" display:block; color:#999; margin:5px 0 0 0; line-height: 18px;">'. $field['desc'].'</span></label></th>',
				'<td>';
			echo '<input type="text" name="', $field['id'], '" id="', $field['id'], '" value="', $meta ? $meta : stripslashes(htmlspecialchars(( $field['std']), ENT_QUOTES)), '" size="30" style="width:75%; margin-right: 20px; float:left;" />';
			break;
			//If textarea		
			case 'textarea':
			echo '<tr  style="border-bottom:2px solid #eeeeee;">',
				'<th style="width:25%"><label for="', $field['id'], '"><strong>', $field['name'], '</strong><span style="line-height:18px; display:block; color:#999; margin:5px 0 0 0;">'. $field['desc'].'</span></label></th>',
				'<td>';
			echo '<textarea name="', $field['id'], '" id="', $field['id'], '" value="', $meta ? $meta : stripslashes(htmlspecialchars(( $field['std']), ENT_QUOTES)), '" rows="8" cols="5" style="width:100%; margin-right: 20px; float:left;">', $meta ? $meta : stripslashes(htmlspecialchars(( $field['std']), ENT_QUOTES)), '</textarea>';
			break;
		}
	}
	echo '</table>';
}
add_action('save_post', 'mts_save_data');

/*---------Save data when post is edited-----------*/
function mts_save_data($post_id) {
	global $meta_box_video;
 
	// verify nonce
	if (!isset($_POST['mts_meta_box_nonce']) || !wp_verify_nonce($_POST['mts_meta_box_nonce'], basename(__FILE__))) {
		return $post_id;
	}
 
	// check autosave
	if (defined('DOING_AUTOSAVE') && DOING_AUTOSAVE) {
		return $post_id;
	}
 
	// check permissions
	if ('page' == $_POST['post_type']) {
		if (!current_user_can('edit_page', $post_id)) {
			return $post_id;
		}
	} elseif (!current_user_can('edit_post', $post_id)) {
		return $post_id;
	}
	
	foreach ($meta_box_video['fields'] as $field) {
		$old = get_post_meta($post_id, $field['id'], true);
		$new = $_POST[$field['id']];
 
		if ($new && $new != $old) {
			update_post_meta($post_id, $field['id'], stripslashes(htmlspecialchars($new)));
		} elseif ('' == $new && $old) {
			delete_post_meta($post_id, $field['id'], $old);
		}
	}

}

/*---------Output video-----------*/
if ( !function_exists( 'mts_video' ) ) {
    function mts_video($postid, $width = 410) {
    	$height = get_post_meta($postid, 'mts_video_height', true);
    	$m4v = get_post_meta($postid, 'mts_video_m4v', true);
    	$poster = get_post_meta($postid, 'mts_video_poster', true);
	if($m4v != '') { ?>
    <script type="text/javascript">
    	jQuery(document).ready(function(){
    		if(jQuery().jPlayer) {
    			jQuery("#jquery_jplayer_<?php echo $postid; ?>").jPlayer({
    				ready: function () {
    					jQuery(this).jPlayer("setMedia", {
    						<?php if($m4v != '') : ?>
    						m4v: "<?php echo $m4v; ?>",
    						<?php endif; ?>
    						<?php if ($poster != '') : ?>
    						poster: "<?php echo $poster; ?>"
    						<?php endif; ?>
    					});
    				},
    				size: {
    				    width: "<?php echo $width ?>px",
    				    height: "<?php echo $height . 'px'; ?>"
    				},
    				swfPath: "<?php echo get_template_directory_uri(); ?>/js",
    				cssSelectorAncestor: "#jp_interface_<?php echo $postid; ?>",
    				supplied: "<?php if($m4v != '') : ?>m4v, <?php endif; ?> all"
    			});
    		}
    	});
    </script>
    <div id="jquery_jplayer_<?php echo $postid; ?>" class="jp-jplayer jp-jplayer-video"></div>
    <div class="jp-video-container">
        <div class="jp-video">
            <div class="jp-type-single">
                <div id="jp_interface_<?php echo $postid; ?>" class="jp-interface">
                    <div class="jp-controls">
						<div class="seperator-first"></div>
						<div class="seperator-second"></div>
						<a href="#" class="jp-play" tabindex="1"></a>
						<a href="#" class="jp-pause" tabindex="1"></a>
						<div class="jp-progress-container">
							<div class="jp-progress">
								<div class="jp-seek-bar">
									<div class="jp-play-bar"></div>
								</div>
							</div>
						</div>
						<a href="#" class="jp-mute" tabindex="1"></a>
						<a href="#" class="jp-unmute" tabindex="1"></a>
						<div class="jp-volume-bar-container">
							<div class="jp-volume-bar">
								<div class="jp-volume-bar-value"></div>
							</div>
						</div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <?php } }
}

?>