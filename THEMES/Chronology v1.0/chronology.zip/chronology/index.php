<?php $mts_options = get_option('chronology'); ?>
<?php get_header(); ?>
<div id="page">
	<div class="content">
		<article class="article">
			<div id="content_box">
				<span class="circle"><span class="circle-inner">&nbsp;</span></span>
				<?php 
					$post_classes = array('odd', 'even');
					$post_counter = 0;
				?>
				<?php $j = 0; if (have_posts()) : while (have_posts()) : the_post(); ?>
					<div class="post excerpt <?php echo (++$j % 2 == 0) ? 'last' : ''; ?> <?php $k = $post_counter%2; echo $post_classes[$k]; $post_counter++; ?>">
						<?php if ( has_post_format( 'video' )) {
							echo '<span class="video-icon"></span>';
						  } else if ( has_post_format( 'gallery' )) {
							echo '<span class="gallery-icon"></span>';
						  } else {
							echo '<span class="standard-icon"></span>';
						  }
						?>
						<?php if ( has_post_format( 'video' )) { 
							$embed = get_post_meta($post->ID, 'mts_video_embed', true);
							if( !empty($embed) ) {
								echo "<div id='featured-thumbnail'>";
								echo stripslashes(htmlspecialchars_decode($embed));
								echo "</div>";
							} elseif(isset($m4v) != '') {
								echo "<div id='featured-thumbnail'>";
								mts_video($post->ID);
								echo "</div>";
							} else {
								echo "<div id='featured-thumbnail'>";
								the_post_thumbnail('featured',array('title' => ''));
								echo "</div>";
							} 
						} elseif ( has_post_format( 'gallery' )) { ?>
							<a href="<?php the_permalink() ?>" title="<?php the_title(); ?>" rel="nofollow" id="featured-thumbnail" class="featured-thumbnail-list">
								<?php if ( has_post_thumbnail() ) { ?> 
									<?php the_post_thumbnail('featured',array('title' => '')); ?>
								<?php } else { ?>
								<div class="featured-thumbnail">
									<img width="410" height="230" src="<?php echo get_template_directory_uri(); ?>/images/nothumb.png" class="attachment-featured wp-post-image" alt="<?php the_title(); ?>">
								</div>
								<?php } ?>
							</a>
						<?php } else { ?>	
							<a href="<?php the_permalink() ?>" title="<?php the_title(); ?>" rel="nofollow" id="featured-thumbnail" class="featured-thumbnail-list">
								<?php if ( has_post_thumbnail() ) { ?> 
									<?php the_post_thumbnail('featured',array('title' => '')); ?>
								<?php } else { ?>
								<div class="featured-thumbnail">
									<img width="410" height="230" src="<?php echo get_template_directory_uri(); ?>/images/nothumb.png" class="attachment-featured wp-post-image" alt="<?php the_title(); ?>">
								</div>
								<?php } ?>
							</a>
						<?php } ?>
						<header>						
							<h2 class="title">
								<a href="<?php the_permalink() ?>" title="<?php the_title(); ?>" rel="bookmark"><?php the_title(); ?></a>
							</h2>
						</header><!--.header-->
						<div class="post-content image-caption-format-1">
							<?php echo excerpt(15);?>
						</div>
						<?php if($mts_options['mts_headline_meta'] == '1') { ?>
							<div class="post-info"><span class="theauthor"><?php _e('By ','mythemeshop'); the_author_posts_link(); ?></span><span class="thetime"><?php the_time('F j, Y'); ?></span><span class="readMore"><a href="<?php the_permalink() ?>" title="<?php the_title(); ?>" rel="bookmark"><?php _e('Read More','mythemeshop'); ?></a></span></div>
						<?php } ?>
					</div><!--.post excerpt-->
				<?php endwhile; else: ?>
					<div class="post excerpt">
						<div class="no-results">
							<p><strong><?php _e('There has been an error.', 'mythemeshop'); ?></strong></p>
							<p><?php _e('We apologize for any inconvenience, please hit back on your browser or use the search form below.', 'mythemeshop'); ?></p>
							<?php get_search_form(); ?>
						</div><!--noResults-->
					</div>
				<?php endif; ?>	
				<!--Start Pagination-->
				<?php if ( isset($mts_options['mts_pagenavigation']) == '1' ) { ?>
					<?php  $additional_loop = 0; pagination($additional_loop['max_num_pages']); ?>           
				<?php } else { ?>
					<div class="pagination">
						<ul>
							<li class="nav-previous"><?php next_posts_link( __( '&larr; '.'Older posts', 'mythemeshop' ) ); ?></li>
							<li class="nav-next"><?php previous_posts_link( __( 'Newer posts'.' &rarr;', 'mythemeshop' ) ); ?></li>
						</ul>
					</div>
				<?php } ?>
				<!--End Pagination-->
				<span class="circle-bottom"><span class="circle-inner">&nbsp;</span></span>
			</div>
		</article>
<?php get_footer(); ?>