<!DOCTYPE html>
<?php $mts_options = get_option('chronology'); ?>
<html class="no-js" <?php language_attributes(); ?>>
<head>
	<meta charset="<?php bloginfo('charset'); ?>">
	<!-- Always force latest IE rendering engine (even in intranet) & Chrome Frame -->
	<!--[if IE ]>
	<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
	<![endif]-->
	<link rel="profile" href="http://gmpg.org/xfn/11" />
	<title><?php wp_title( '|', true, 'right' ); ?></title>
	<?php mts_meta(); ?>
	<link rel="pingback" href="<?php bloginfo( 'pingback_url' ); ?>" />
	<?php wp_enqueue_script("jquery"); ?>
	<?php wp_head(); ?>
</head>
<body id ="blog" <?php body_class('main'); ?>>
<div class="wrapper">
	<header class="main-header">
		<div class="container">
			<div id="header">
				<?php if ($mts_options['mts_logo'] != '') { ?>
					<?php if( is_front_page() || is_home() || is_404() ) { ?>
							<h1 id="logo" class="image-logo">
								<a href="<?php echo home_url(); ?>"><img src="<?php echo $mts_options['mts_logo']; ?>" alt="<?php bloginfo( 'name' ); ?>"></a>
							</h1><!-- END #logo -->
					<?php } else { ?>
						  <h2 id="logo" class="image-logo">
								<a href="<?php echo home_url(); ?>"><img src="<?php echo $mts_options['mts_logo']; ?>" alt="<?php bloginfo( 'name' ); ?>"></a>
							</h2><!-- END #logo -->
					<?php } ?>
				<?php } else { ?>
					<?php if( is_front_page() || is_home() || is_404() ) { ?>
							<h1 id="logo" class="text-logo">
								<a href="<?php echo home_url(); ?>"><?php bloginfo( 'name' ); ?></a>
							</h1><!-- END #logo -->
					<?php } else { ?>
						  <h2 id="logo" class="text-logo">
								<a href="<?php echo home_url(); ?>"><?php bloginfo( 'name' ); ?></a>
							</h2><!-- END #logo -->
					<?php } ?>
				<?php } ?>
				<div class="secondary-navigation">
					<nav id="navigation" >
						<?php if ( has_nav_menu( 'primary-menu' ) ) { ?>
							<?php wp_nav_menu( array( 'theme_location' => 'primary-menu', 'menu_class' => 'menu', 'container' => '' ) ); ?>
						<?php } else { ?>
							<ul class="menu">
								<?php wp_list_categories('title_li='); ?>
							</ul>
						<?php } ?>
						<a href="#" id="pull">Menu</a>
					</nav>
				</div>              
			</div><!--#header-->
			
			<?php if (is_singular() && $mts_options['mts_header_adcode'] !='') { ?>			
				<div class="ad-box">
					<div class="widget-header"><?php echo $mts_options['mts_header_adcode']; ?></div>
					<?php if ($mts_options['mts_announcement_title'] != '' || $mts_options['mts_announcement_text'] != '') { ?>
						<div class="announcement">
							<?php if ($mts_options['mts_announcement_title'] != '') { ?>
								<h4><?php echo $mts_options['mts_announcement_title']; ?></h4>
							<?php } ?>
							<?php if ($mts_options['mts_announcement_text'] != '') { ?>
								<p><?php echo $mts_options['mts_announcement_text']; ?>
									<?php if ($mts_options['mts_announcement_link'] != '') { ?>
										<span class="ann-more"><a href="<?php echo $mts_options['mts_announcement_link']; ?>"><?php _e('Read More','mythemeshop'); ?></a></span>
									<?php } ?>
								</p>
							<?php } ?>
						</div>
					<?php } ?>
				</div>
			<?php } ?>
		
			<?php if (is_home() && !is_paged()) { ?>
				<?php if ($mts_options['mts_featured_section'] == '1') { ?>
					<div class="featured-section">
						<?php global $wpdb; $i = 1; if(isset($mts_options['mts_featured_section_cat'])) { $slider_cat = implode(",", $mts_options['mts_featured_section_cat']); } $my_query = new WP_Query('cat='.$slider_cat.'&posts_per_page=1&ignore_sticky_posts=1'); ?>
						<?php if ($my_query->have_posts()) : while ($my_query->have_posts()) : $my_query->the_post(); ?>
							<div class="post featured">
								<a href="<?php the_permalink() ?>" title="<?php the_title(); ?>" rel="nofollow" id="featured-thumbnail">
									<div class="fbanner">&nbsp;</div>
									<?php if ( has_post_thumbnail() ) { ?> 
										<div class="featured-thumbnail"><?php the_post_thumbnail('slider',array('title' => '')); ?></div>
									<?php } ?>
								</a>
								<div class="featured-post-content">
									<header>						
										<h2 class="title featured-title">
											<a href="<?php the_permalink() ?>" title="<?php the_title(); ?>" rel="bookmark"><?php the_title(); ?></a>
										</h2>
									</header><!--.header-->
									<div class="post-content image-caption-format-1">
										<p><?php echo excerpt(33);?></p>
									</div>
									<div class="post-info">
										<span class="theauthor"><?php _e('By ','mythemeshop'); the_author_posts_link(); ?></span>
										<span class="thetime"><?php the_time('F j, Y'); ?></span>
										<span class="thecomment"><?php comments_popup_link( __('No comments','mythemeshop'), __('1 comment','mythemeshop'), __('% comments','mythemeshop')); ?></span>
										<span class="thetags"><?php the_tags(__('Tags','mythemeshop').': ',', ') ?></span>
										<span class="readMore"><a href="<?php the_permalink() ?>" title="<?php the_title(); ?>" rel="bookmark"><?php _e('Read More','mythemeshop'); ?></a></span>
									</div>
								</div>
							</div>
						<?php $i++; endwhile; wp_reset_query(); endif;?>  
					</div>
				<?php } ?>
			<?php } ?>
		</div> 
	</header>
	<div class="main-container">